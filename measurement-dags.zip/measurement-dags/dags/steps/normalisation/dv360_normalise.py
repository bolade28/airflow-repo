from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'DV360Normalise'
    step_script = 'dv360_normalise.py'
    step_args = [
        ("--dv360-campaign", get_path("dv360_campaign")),
        ("--output-path", get_path("dv360_normalised")),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
