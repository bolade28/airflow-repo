from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'YoutubePollenNormalised'
    step_script = 'youtube_normalise_pollen.py'
    step_args = [
        ("--source-table-path", get_path("campaign_booking_media_channel")),
        ("--output-path", get_path("youtube_normalize_pollen")),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
