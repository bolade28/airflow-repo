from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_sns


def tasks(
        step_name: str,
        sku_level_attributed_sales_and_units_level_path: str,
        product_type: str,
        output_path: str,
        mta_baseline_integration_missing_data: str,
        mta_baseline_integration_zero_or_incrementality: str,
        executors: int = 48,
) -> EmrAddAndWatchStep:

    step_script = 'baseline_attribution_integration_sku_level.py'
    step_args = [
        ("--unified-product-path", get_path("unified_product")),
        # TODO: this is temp directory
        ("--baseline-modelling-output-path", get_path("ucm_output_data")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--sales-data-transformation-path", get_path("sales_data_transaction")),
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--sku-level-attributed-sales-and-units-level-path", get_path(sku_level_attributed_sales_and_units_level_path)),
        ("--output-path", get_path(output_path)),
        ("--mta-baseline-integration-missing-data-output-path", get_path(mta_baseline_integration_missing_data)),
        ("--mta-baseline-integration-zero-or-incrementality-output-path", get_path(mta_baseline_integration_zero_or_incrementality)),
        ("--product-type", product_type),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
