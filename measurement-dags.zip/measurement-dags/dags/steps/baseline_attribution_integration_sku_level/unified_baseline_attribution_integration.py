from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_sns, pipeline_run_type


def tasks(executors=48) -> EmrAddAndWatchStep:

    step_name = "unified_baseline_attribution_integration_sku_level"
    step_script = 'unified_baseline_attribution_integration.py'

    step_args = [
        ("--baseline-attribution-integration-sku-level-offer-path", get_path("baseline_attribution_integration_sku_level_offer")),
        ("--baseline-attribution-integration-sku-level-brand-path", get_path("baseline_attribution_integration_sku_level_brand")),
        ("--baseline-attribution-integration-sku-level-aisle-path", get_path("baseline_attribution_integration_sku_level_aisle")),
        ("--output-path", get_path("unified_baseline_attribution_integration")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--run-type", pipeline_run_type()),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
