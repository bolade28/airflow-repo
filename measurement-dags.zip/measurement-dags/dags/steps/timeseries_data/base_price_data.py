from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 48) -> EmrAddAndWatchStep:
    step_name = 'BasePriceData'
    step_script = 'base_price_data.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--fact-sales-path", get_path("processed_fact_sales_transaction_item")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--store-hierarchy-path", get_path("dim_store_org_hierarchy")),
        ("--unified-product-path", get_path("unified_product")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--output-path", get_path("base_price_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
