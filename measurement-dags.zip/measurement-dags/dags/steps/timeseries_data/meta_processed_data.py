from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'MetaProcessedData'
    step_script = 'meta_processed_data.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--fb-campaign-normalize-path", get_path("fb_campaign_normalized")),
        ("--unified-product-path", get_path("unified_product")),
        ("--fb-insight-normalize-path", get_path("fb_insight_normalize")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--output-path", get_path("meta_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
