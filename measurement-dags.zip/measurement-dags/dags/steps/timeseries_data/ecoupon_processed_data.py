from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:
    step_name = 'ECouponProcessedData'
    step_script = 'ecoupon_processed_data.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--base-finance-assets-path", get_path("base_finance_assets")),
        ("--oc-campaign-path", get_path("oc_campaign")),
        ("--oc-products-path", get_path("oc_products")),
        ("--oc-customer-selection-path", get_path("oc_customer_selection")),
        ("--unified-product-path", get_path("unified_product")),
        ("--temp-unified-product-path", get_path("temp_unified_product")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--output-path", get_path("ecoupon_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
