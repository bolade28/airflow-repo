from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:
    step_name = 'CouponAtTillProcessedData'
    step_script = 'coupon_at_till_processed.py'
    step_args = [
        ("--base-finance-assets-path", get_path("base_finance_assets")),
        ("--campaign-path", get_path("campaign")),
        ("--cell-path", get_path("cell")),
        ("--coupon-cell-path", get_path("coupon_cell")),
        ("--coupon-to-product-path", get_path("coupon_to_product")),
        ("--coupon-path", get_path("coupon")),
        ("--unified-product-path", get_path("unified_product")),
        ("--temp-unified-product-path", get_path("temp_unified_product")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--output-path", get_path("coupon_at_till_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
