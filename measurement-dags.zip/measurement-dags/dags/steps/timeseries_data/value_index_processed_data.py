from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'ValueIndexProcessedData'
    step_script = 'value_index_processed_data.py'
    step_args = [
        ("--campaign-selection-python-path", get_path("campaign_selection")),
        ("--agg-value-index-dashboard-w-path", get_path("agg_value_index_dashboard_w")),
        ("--unified-product-path", get_path("unified_product")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--output-path", get_path("value_index_processed_data")),
        ("--correlation-id", get_ci()),
        ('--start-date', get_model_start_end_dates('start_date')),
        ('--end-date', get_model_start_end_dates('end_date')),
        ("--run-date", "{{ data_interval_end | ds }}")
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
