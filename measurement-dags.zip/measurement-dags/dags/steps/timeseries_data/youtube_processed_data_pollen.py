from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:
    step_name = 'YoutubeProcessedDataPollen'
    step_script = 'youtube_processed_data_pollen.py'
    step_args = [
        ("--youtube-normalize-path", get_path("youtube_normalize_pollen")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--unified-product-path", get_path("unified_product")),
        ("--dv360-media-report-path", get_path("dv360_media_report")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--historic-youtube-processed-data", get_path("youtube_processed_data")),
        ("--output-path", get_path("youtube_processed_data_pollen")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
