from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'SalesProcessedData'
    step_script = 'sales_processed_data.py'

    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--sku-cluster-mapping", get_path("sku_cluster_mapping")),
        ("--campaign-selection", get_path("campaign_selection")),
        ("--sales-data-transaction", get_path("sales_data_transaction")),
        ("--output-path", get_path("sales_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]
    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
