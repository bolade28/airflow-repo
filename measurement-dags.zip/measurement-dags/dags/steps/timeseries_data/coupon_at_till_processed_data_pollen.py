from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:
    step_name = 'CouponAtTillProcessedDataPollen'
    step_script = 'coupon_at_till_processed_pollen.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--campaign-booking-media-channel-path", get_path("campaign_booking_media_channel")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--unified-product-path", get_path("unified_product")),
        ("--coupon-path", get_path("coupon")),
        ("--coupon-cell-path", get_path("coupon_cell")),
        ("--cell-path", get_path("cell")),
        ("--campaign-path", get_path("campaign")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--historic-cat-processed-data", get_path("coupon_at_till_processed_data")),
        ("--output-path", get_path("coupon_at_till_processed_data_pollen")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
