from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'InstoreProcessedData'
    step_script = 'instore_processed_data.py'
    step_args = [
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--ie-location-path", get_path("ie_location")),
        ("--ie-product-path", get_path("ie_product")),
        ("--ie-campaign-filt-path", get_path("ie_campaign_filt")),
        ("--cust-by-location-path", get_path("cust_by_location")),
        ("--media-instore-init-path", get_path("media_instore_init")),
        ("--temp-unified-product-path", get_path("temp_unified_product")),
        ("--unified-product-path", get_path("unified_product")),
        ("--is-active-filter-path", get_path("unified_channel_active_media")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--output-path", get_path("instore_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
