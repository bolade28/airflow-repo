from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_model_start_end_dates


def tasks(executors: int = 48) -> EmrAddAndWatchStep:
    step_name = 'SecondarySpaceProccessedData'
    step_script = 'secondary_space_processed_data.py'
    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates_extended")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--plngrm-campaign-item-postn-daily-path", get_path("planogram_campaigns")),
        ("--dim-section-path", get_path("dim_section")),
        ("--output-path", get_path("secondary_space_processed_data")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
