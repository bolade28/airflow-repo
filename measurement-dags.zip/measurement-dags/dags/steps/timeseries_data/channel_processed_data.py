from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(
    step_name: str = 'ChannelProcessedData',
    executors: int = 8,
    pipeline_run_type: str = DTP_RUN_TYPE,
) -> EmrAddAndWatchStep:

    step_script = 'channel_processed_data.py'
    step_args = [
        ("--external-processed-data-output-path", get_path("external_processed_data_output")),
        ("--promotional-discount-processed-data-path", get_path("promotional_discount_processed_data")),
        ("--value-index-processed-data-path", get_path("value_index_processed_data")),
        ("--sales-processed-data-path", get_path("sales_processed_data")),
        ("--base-price-data-path", get_path("base_price_data")),
        ("--secondary-space-data-path", get_path("secondary_space_processed_data")),
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--output-path", get_path("channel_processed_data")),
        ("--correlation-id", get_ci()),
        ("--run-date", "{{ data_interval_end | ds }}")
    ]

    # Determine channel processed data paths based on pipeline run type
    if pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_features_args = [
            ("--instore-processed-data-path", get_path("instore_processed_data_pollen")),
            ("--coupon-at-till-processed-data-path", get_path("coupon_at_till_processed_data_pollen")),
            ("--meta-processed-data-path", get_path("meta_processed_data_pollen")),
            ("--dv360-processed-data-path", get_path("dv360_processed_data_pollen")),
            ("--youtube-processed-data-path", get_path("youtube_processed_data_pollen")),
            ("--citrus-processed-data-path", get_path("citrus_processed_data")),
            ("--ecoupon-processed-data-path", get_path("ecoupon_processed_data_pollen")),
        ]
    elif pipeline_run_type == DTP_RUN_TYPE:
        campaign_features_args = [
            ("--instore-processed-data-path", get_path("instore_processed_data")),
            ("--coupon-at-till-processed-data-path", get_path("coupon_at_till_processed_data")),
            ("--meta-processed-data-path", get_path("meta_processed_data")),
            ("--dv360-processed-data-path", get_path("dv360_processed_data")),
            ("--youtube-processed-data-path", get_path("youtube_processed_data")),
            ("--citrus-processed-data-path", get_path("citrus_processed_data")),
            ("--ecoupon-processed-data-path", get_path("ecoupon_processed_data")),
        ]
    else:
        raise ValueError(
            f"Unsupported pipeline_run_type: {pipeline_run_type}. "
            f"Expected one of: {DTP_RUN_TYPE}, {POLLEN_RUN_TYPE}"
        )

    step_args += campaign_features_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )
    return tg
