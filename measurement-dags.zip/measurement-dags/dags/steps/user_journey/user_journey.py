from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_sns


def tasks(
        step_name: str,
        product_type: str,
        journey_type: str,
        output_path: str,
        executors: int = 48,
) -> EmrAddAndWatchStep:

    step_script = 'user_journey.py'
    step_args = [
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--customer-data-collection-path", get_path("customer_data_collection")),
        ("--output-path", get_path(output_path)),
        ("--product-type", product_type),
        ("--journey-type", journey_type),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
