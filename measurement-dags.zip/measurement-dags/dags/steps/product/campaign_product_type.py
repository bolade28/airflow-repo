from helpers.constants import INCLUDE_AISLE_SKUS
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(
        step_name: str,
        pipeline_run_type: str,
        executors: int = 8
) -> EmrAddAndWatchStep:

    step_script = 'campaign_product_type.py'
    step_args = [
        ("--ean-br-path", get_path("campaign_product_type_ean_br")),
        ("--dim-item-path", get_path("campaign_product_type_dim_item")),
        ("--output-path", get_path("campaign_product_type")),
        ("--include-aisle-skus", f'\"{str(INCLUDE_AISLE_SKUS)}\"'),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    campaign_type_args = [
        ("--unified-campaign-path", get_path("unified_campaigns")),
    ] if pipeline_run_type == DTP_RUN_TYPE else [
        ("--unified-campaign-path", get_path("unified_campaigns_pollen")),
    ] if pipeline_run_type == POLLEN_RUN_TYPE else []

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
