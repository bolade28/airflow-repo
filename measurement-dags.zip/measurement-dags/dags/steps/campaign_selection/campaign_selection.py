from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_manual_campaigns_list, get_ci, get_sns
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE, RUN_BASELINE_MANUALLY, CAMPAIGN_LIST_TYPE


def tasks(
        step_name='CampaignSelection',
        pipeline_run_type: str = DTP_RUN_TYPE,
        executors: int = 48
) -> EmrAddAndWatchStep:

    step_script = 'campaign_selection.py'
    step_args = [
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--unified-product-path", get_path("unified_product")),
        ("--output-path-campaign-selection", get_path("campaign_selection")),
        ("--manual-run-flag", f'\"{str(RUN_BASELINE_MANUALLY)}\"'),
        ("--manual-campaign-list", f'\"{get_manual_campaigns_list()}"'),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
    ]

    # Determine campaign type and unified campaign path based on pipeline run type
    if pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns_pollen")),
            ("--campaign-identifier", CAMPAIGN_LIST_TYPE["Pollen"]),
        ]
    elif pipeline_run_type == DTP_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns")),
            ("--campaign-identifier", CAMPAIGN_LIST_TYPE["DTP"]),
        ]
    else:
        raise ValueError(
            f"Unsupported pipeline_run_type: {pipeline_run_type}. "
            f"Expected one of: {DTP_RUN_TYPE}, {POLLEN_RUN_TYPE}"
        )

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
