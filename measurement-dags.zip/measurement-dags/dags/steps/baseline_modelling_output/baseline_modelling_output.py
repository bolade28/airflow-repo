from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'BaselineModellingOutput'
    step_script = 'baseline_modelling_output.py'
    step_args = [
        ("--baseline-modelling-dataset-path", get_path("baseline_modelling_dataset_output")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--cluster-path", get_path("sku_cluster_mapping")),
        ("--feature-prioritisation-path", get_path("feature_prioritisation")),
        ("--weekly-dates-path", get_path("weekly_dates")),
        # ToDo: Add a specific dir for all checkpoints
        # Temp location to test the run with
        ("--checkpoint-path", get_path('ucm_checkpoint_data')),
        ("--baseline-modelling-base-data-output-path", get_path("ucm_base_data")),
        ("--baseline-modelling-fin-summary-output-path", get_path("ucm_summary_data")),
        ("--baseline-modelling-input-path", get_path("ucm_input_data")),
        ("--baseline-modelling-intermediate-output-path", get_path("ucm_intermediate_data")),
        ("--new-baseline-modelling-output-path", get_path("ucm_output_data")),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci())
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
