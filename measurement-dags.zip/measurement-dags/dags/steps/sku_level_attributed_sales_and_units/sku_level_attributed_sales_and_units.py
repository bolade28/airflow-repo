from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns, pipeline_run_type
import json
from helpers.channel_hierarchy import SUBCHANNELS_CODE


def tasks(
        step_name: str,
        attribution_model_results_level_path: str,
        product_type: str,
        output_path: str,
        executors: int = 48,
) -> EmrAddAndWatchStep:

    step_script = 'sku_level_attributed_sales_and_units.py'
    subchannel_hierarchy_json = json.dumps(SUBCHANNELS_CODE)
    base_args = [
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--customer-data-collection-path", get_path("customer_data_collection")),
        ("--attribution-model-results-level-path", get_path(attribution_model_results_level_path)),
        # this is always going to be offer as its reading the recalibration factors for offsite channel from there
        ("--sku-level-attributed-sales-and-units-offer-path", get_path("sku_level_attributed_sales_and_units_offer")),
        ("--output-path", get_path(output_path)),
        ("--product-type", product_type),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--pipeline-run-type", pipeline_run_type()),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
        ("--measurement-marketing-channel-hierarchy-path", get_path("measurement_marketing_channel_hierarchy")),
        ("--previous-measurement-campaign-reporting", get_path("previous_measurement_campaign_reporting")),
        ("--subchannel-hierarchy-codes", f"'{subchannel_hierarchy_json}'")
    ]

    # Offer-specific args
    offer_args = [
        ("--reach-engagement-path", get_path("reach_engagement")),
        ("--attribution-pre-requisite-offer-path", get_path("attribution_pre_requisite_offer"))
    ] if product_type == "offer" else []

    step_args = base_args + offer_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
