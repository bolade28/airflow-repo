from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'BaselineForecastingCall'
    step_script = 'baseline_forecasting_call.py'
    step_args = [
        ("--baseline-modelling-dataset-path", get_path("baseline_modelling_dataset_output")),
        ("--baseline-forecast-path", get_path("ucm_output_data")),
        ("--baseline-summary-path", get_path("ucm_intermediate_data")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--external-variables-path", get_path("external_processed_data_output")),
        ("--sales-data-path", get_path("sales_data_transaction")),
        # ("--cluster-features-path", get_path("cluster_features")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--output-path", get_path("baseline_forecasting_call_output")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--job-run-id", get_ci())
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
