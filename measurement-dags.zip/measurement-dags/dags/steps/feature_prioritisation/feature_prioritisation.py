from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'FeaturePrioritisation'
    step_script = 'feature_prioritisation.py'
    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--baseline-modelling-dataset-path", get_path("baseline_modelling_dataset_output")),
        ("--baseline-primary-metric-path", get_path("baseline_primary_metric")),
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--output-path-feature-prioritisation", get_path("feature_prioritisation")),
        ("--correlation-id", get_ci()),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
