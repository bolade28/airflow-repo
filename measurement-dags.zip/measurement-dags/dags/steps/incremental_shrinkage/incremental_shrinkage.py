from helpers.xcom import get_path, get_ci
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep


def tasks(
        step_name: str,
        pipeline_run_type: str,
) -> EmrAddAndWatchStep:
    step_script = 'incremental_shrinkage.py'

    step_args = [
        ("--baseline-output-path", get_path("ucm_output_data")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--output-path", get_path("incremental_shrinkage")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    # Determine campaign type and unified campaign path based on pipeline run type
    if pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns_pollen"))
        ]
    elif pipeline_run_type == DTP_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns")),
        ]
    else:
        raise ValueError(
            f"Unsupported pipeline_run_type: {pipeline_run_type}. "
            f"Expected one of: {DTP_RUN_TYPE}, {POLLEN_RUN_TYPE}"
        )

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
