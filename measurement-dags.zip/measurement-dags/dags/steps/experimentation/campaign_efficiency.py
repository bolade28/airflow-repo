from helpers.emr import add_and_watch_step, EmrAddAndWatchStep


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'CampaignEfficiency'
    step_script = 'campaign_efficiency.py'
    correlation_id = "6682631a-8a3f-4e23-85b4-bd13d080f84d"
    step_args = [
        ("--meta-data-path", f"s3://measurement-dev-snowflake-unload/{correlation_id}/meta_data"),
        ("--campaign-execution-path", f"s3://measurement-dev-snowflake-unload/{correlation_id}/measurement_campaign_execution"),
        ("--output-path", "s3://measurement-dev-temp/waqas/customer_data_collection_output"),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
