from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'ThreeLetterCoding'
    step_script = 'three_letter_coding.py'
    step_args = [
        ("--channel-processed-data-path", get_path("channel_processed_data")),
        ("--baseline-modelling-dataset-path", get_path("previous_baseline_modelling_dataset")),
        ("--output-path", get_path("three_letter_coding")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
