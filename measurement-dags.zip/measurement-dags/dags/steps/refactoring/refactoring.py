from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_sns


def tasks(executors: int = 8) -> EmrAddAndWatchStep:

    step_name = 'Refactoring'
    step_script = 'refactoring.py'
    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates")),
        # NOTE: this is the "all features ever" data set from cluster mapping, which is what we need here
        ("--sku-cluster-mapping-path", get_path("sku_cluster_mapping_features_output")),
        ("--campaign-selection-path", get_path("campaign_selection")),
        ("--unified-product-path", get_path("unified_product")),
        # ("--cluster-features-path", get_path("cluster_features")),
        ("--processed-fact-sales-transaction-item-path", get_path("processed_fact_sales_transaction_item_agg")),
        ("--sales-data-transaction-path", get_path("sales_data_transaction")),
        ("--correlation-id", get_ci()),
        ("--output-path", get_path("refactoring")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
