from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns


def tasks(
        step_name: str,
        journey_type: str,
        attribution_pre_requisite: str,
        output_path: str,
        synergy_output: str = "attribution_synergy_results",
        executors: int = 48,
) -> EmrAddAndWatchStep:
    """
    Prepare EMR step for AttributionModelResult job.
    - Adds synergy-output-path only when journey_type == "offer".
    """

    step_script = "attribution_model_results.py"
    step_args = [
        ("--measurement-campaign-path", get_path("measurement_campaign_execution")),
        ("--attribution-prerequisite-path", get_path(attribution_pre_requisite)),
        ("--campaign-decay-path", get_path("campaign_decay_rate")),
        ("--journey-type", journey_type),
        ("--output-path", get_path(output_path)),
        ("--job-run-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    # Add synergy path only for offer journey
    if journey_type.strip().lower() == "offer":
        step_args.append(
            ("--synergy-output-path", get_path(synergy_output))
        )

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=8,
        executor_memory="32g",
    )

    return tg
