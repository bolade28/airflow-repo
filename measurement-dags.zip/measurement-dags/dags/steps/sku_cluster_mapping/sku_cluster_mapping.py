from helpers.constants import RUN_BASELINE_MANUALLY
from helpers.emr import EmrAddAndWatchStep, add_and_watch_step
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE, CAMPAIGN_LIST_TYPE
from helpers.xcom import get_ci, get_manual_campaigns_list, get_path, get_sns


def tasks(
        step_name: str = 'sku_cluster_mapping',
        pipeline_run_type: str = DTP_RUN_TYPE,
        executors: int = 48
) -> EmrAddAndWatchStep:

    step_script = "sku_cluster_mapping.py"
    step_args = [
        ("--correlation-id", get_ci()),
        ("--campaign-selection-input-path", get_path("campaign_selection")),
        ("--campaign-product-type-path", get_path("campaign_product_type")),
        ("--sales-data-input-path", get_path("sales_data_transaction")),
        ("--features-output-path", get_path("sku_cluster_mapping_features_output")),
        ("--final-output-path", get_path("sku_cluster_mapping_final_output")),
        ("--manual-run-flag", f'\"{str(RUN_BASELINE_MANUALLY)}\"'),
        ("--manual-campaign-list", f'\"{get_manual_campaigns_list()}\"'),
        ("--slack-topic-arn", get_sns("slack_topic_arn")),
    ]
    campaign_type_args = [
        ("--unified-campaign-path", get_path("unified_campaigns")),
        ("--campaign-identifier", CAMPAIGN_LIST_TYPE["DTP"]),
    ] if pipeline_run_type == DTP_RUN_TYPE else [
        ("--unified-campaign-path", get_path("unified_campaigns_pollen")),
        ("--campaign-identifier", CAMPAIGN_LIST_TYPE["Pollen"]),
    ] if pipeline_run_type == POLLEN_RUN_TYPE else []

    step_args += campaign_type_args

    # TODO: add a task to push the results of this (from final output path) to snowflake, measurement_sku_cluster_mapping table

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
