from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci
from helpers.xcom import get_sns
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(
        step_name: str = 'ReachEngagement',
        pipeline_run_type: str = DTP_RUN_TYPE,
        executors: int = 48
) -> EmrAddAndWatchStep:

    step_script = 'reach_engagement.py'
    step_args = [
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--digital-trading-campaign-dmfbca-sat-path", get_path("digital_trading_campaign_sat")),
        ("--digital-trading-campaign-channel-dmfbca-link-path", get_path("digital_trading_campaign_link")),

        ("--digital-trading-lineitem-insight-dmfbin-link-path", get_path("digital_trading_lineitem_facebook_insight")),
        ("--media-report-path", get_path("dv360_media_report")),
        ("--unique-reach-lineitem-report-path", get_path("unique_reach_lineitem_report")),

        ("--floodlight-report-path", get_path("floodlight_report")),
        ("--user-journey-offer-path", get_path("user_journey_offer")),
        ("--advertising-campaign-request-realised-link-path", get_path("advertise_request_realised")),

        ("--advertising-campaign-citcam-sat-path", get_path("advertising_campaign_citcam_sat")),
        ("--meta-data-path", get_path("meta_data")),
        ("--output-path", get_path("reach_engagement")),
        ("--output-reporting-path", get_path("reach_engagement_reporting")),
        ("--correlation-id", get_ci()),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--run-type", pipeline_run_type),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]
    campaign_type_args = [
        ("--unified-campaigns-path", get_path("unified_campaigns")),
    ] if pipeline_run_type == DTP_RUN_TYPE else [
        ("--unified-campaigns-path", get_path("unified_campaigns_pollen")),
    ] if pipeline_run_type == POLLEN_RUN_TYPE else []

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )
    return tg
