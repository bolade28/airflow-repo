from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci
from helpers.xcom import get_sns
from helpers.constants import EMULATE_PROD_CAMPAIGN_IN_DEV
from helpers.channel_hierarchy import SUBCHANNELS_CODE
import json


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'ReachEngagementPollen'
    step_script = 'reach_engagement_pollen.py'

    # Determine the value of campaign-complete based on EMULATE_PROD_CAMPAIGN_IN_DEV
    campaign_complete = not EMULATE_PROD_CAMPAIGN_IN_DEV

    # Convert SUBCHANNELS_CODE to JSON string
    subchannel_hierarchy_json = json.dumps(SUBCHANNELS_CODE)

    step_args = [

        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--digital-trading-campaign-channel-dmfbca-link-path", get_path("digital_trading_campaign_link")),

        ("--digital-trading-campaign-insight-dmfbin-link-path", get_path("digital_trading_campaign_insight_link")),

        ("--media-report-path", get_path("dv360_media_report")),
        ("--unique-reach-lineitem-report-path", get_path("unique_reach_lineitem_report")),

        ("--floodlight-report-path", get_path("floodlight_report")),
        ("--user-journey-offer-path", get_path("user_journey_offer")),
        ("--advertising-campaign-request-realised-link-path", get_path("advertise_request_realised")),

        ("--advertising-campaign-citcam-sat-path", get_path("advertising_campaign_citcam_sat")),
        ("--unified-campaigns-path", get_path("unified_campaigns_pollen")),
        ("--meta-data-path", get_path("meta_data")),

        ("--output-path", get_path("reach_engagement")),
        ("--output-reporting-path", get_path("reach_engagement_reporting")),

        ("--correlation-id", get_ci()),
        ("--run-date", "{{ data_interval_end | ds }}"),

        ("--marketing-media-hierarchy-mkthrc-ref-path", get_path("marketing_media_hierarchy_mkthrc_ref")),
        ("--measurement-marketing-channel-hierarchy-path", get_path("measurement_marketing_channel_hierarchy")),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
        ("--campaign-complete", str(campaign_complete).lower()),
        ("--subchannel-hierarchy-codes", f"'{subchannel_hierarchy_json}'"),

    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )
    return tg
