from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_model_start_end_dates


def tasks(executors: int = 48) -> EmrAddAndWatchStep:

    step_name = 'SalesDataTransaction'
    step_script = 'sales_data_transaction.py'

    print("get_model_start_end_dates('end_date')", get_model_start_end_dates('end_date'), type(get_model_start_end_dates('end_date')))

    step_args = [
        ("--weekly-dates-path", get_path("weekly_dates")),
        ("--unified-product-path", get_path("unified_product")),
        ("--processed-dim-location-path", get_path("processed_dim_location")),
        ("--processed-fact-sales-transaction-basket", get_path("processed_fact_sales_transaction_basket")),
        ("--processed-fact-sales-transaction-item", get_path("processed_fact_sales_transaction_item")),
        ("--output-path", get_path("sales_data_transaction")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--sales-start-date", get_model_start_end_dates('start_date')),
        ("--sales-end-date", get_model_start_end_dates('end_date')),
        ("--correlation-id", get_ci()),
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
