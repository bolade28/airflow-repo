from helpers.xcom import get_path, get_ci, get_sns
from helpers.constants import CAMPAIGN_DURATION_POST, DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep


def tasks(
        step_name: str = "MeasurementCampaignReporting",
        num_executors: int = 8,
        executor_cores: int = 4,
        executor_memory: str = "20g",
        pipeline_run_type: str = DTP_RUN_TYPE,
        campaign_duration: str = None,
) -> EmrAddAndWatchStep:
    step_script = 'measurement_campaign_reporting.py'
    step_args = [
        ("--baseline-output-path", get_path("ucm_output_data")),
        ("--campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--sku-level-attributed-sales-units-brand-path", get_path("sku_level_attributed_sales_and_units_brand")),
        ("--sku-level-attributed-sales-units-offer-path", get_path("sku_level_attributed_sales_and_units_offer")),
        ("--pre-mta-brand-path", get_path("attribution_pre_requisite_brand")),
        ("--pre-mta-offer-path", get_path("attribution_pre_requisite_offer")),
        ("--base-price-path", get_path("base_price_data")),
        ("--measurement-marketing-channel-hierarchy-path", get_path("measurement_marketing_channel_hierarchy")),
        ("--output-path", get_path("measurement_campaign_reporting")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
    ]

    # Determine unified campaign path based on pipeline run type
    if pipeline_run_type == POLLEN_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns_pollen")),
        ]
    elif pipeline_run_type == DTP_RUN_TYPE:
        campaign_type_args = [
            ("--unified-campaign-path", get_path("unified_campaigns")),
        ]
    else:
        raise ValueError(
            f"Unsupported pipeline_run_type: {pipeline_run_type}. "
            f"Expected one of: {DTP_RUN_TYPE}, {POLLEN_RUN_TYPE}"
        )

    step_args = [
        ("--baseline-output-path", get_path("ucm_output_data")),
        ("--campaign-execution-path", get_path("measurement_campaign_execution")),
        *campaign_type_args,
        ("--sku-level-attributed-sales-units-brand-path", get_path("sku_level_attributed_sales_and_units_brand")),
        ("--sku-level-attributed-sales-units-offer-path", get_path("sku_level_attributed_sales_and_units_offer")),
        ("--pre-mta-brand-path", get_path("attribution_pre_requisite_brand")),
        ("--pre-mta-offer-path", get_path("attribution_pre_requisite_offer")),
        ("--base-price-path", get_path("base_price_data")),
        ("--measurement-marketing-channel-hierarchy-path", get_path("measurement_marketing_channel_hierarchy")),
        ("--output-path", get_path("measurement_campaign_reporting")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
    ]
    # Add campaign period flag for pollen runs when provided
    if pipeline_run_type == POLLEN_RUN_TYPE:
        step_args.append(("--campaign-period", campaign_duration))

        # Only add previous measurement campaign reporting path for Post period
        if campaign_duration == CAMPAIGN_DURATION_POST:
            step_args.append(("--previous-measurement-campaign-reporting", get_path("previous_measurement_campaign_reporting")))

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=num_executors,
        executor_cores=executor_cores,
        executor_memory=executor_memory,
    )

    return tg
