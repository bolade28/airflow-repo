from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci

from helpers.xcom import get_sns


def tasks(
        step_name: str,
        user_journey_type: str,
        journey_type: str,
        output_path: str,
        executors: int = 8,
) -> EmrAddAndWatchStep:

    step_script = 'attribution_pre_requisite.py'
    step_args = [
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--user-journey-path", get_path(user_journey_type)),
        ("--output-path", get_path(output_path)),
        ("--journey-type", journey_type),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn"))
    ]

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
