from helpers.constants import RUN_BASELINE_MANUALLY
from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns, get_manual_campaigns_list

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(
        step_name='BaselineMetrics',
        pipeline_run_type: str = DTP_RUN_TYPE,
        executors: int = 8
) -> EmrAddAndWatchStep:

    step_script = 'publish_baseline_metrics.py'
    step_args = [
        ("--campaign-selection", get_path("campaign_selection")),
        ("--manual-run-flag", f'\"{str(RUN_BASELINE_MANUALLY)}\"'),
        ("--manual-campaign-list", f'\"{get_manual_campaigns_list()}"'),
        ("--metrics-topic-arn", get_sns("metrics_topic_arn")),
        ("--correlation-id", get_ci()),
    ]

    campaign_type_args = [
        ("--unified-campaign-path", get_path("unified_campaigns")),
    ] if pipeline_run_type == DTP_RUN_TYPE else [
        ("--unified-campaign-path", get_path("unified_campaigns_pollen")),
    ] if pipeline_run_type == POLLEN_RUN_TYPE else []

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="20g",
    )

    return tg
