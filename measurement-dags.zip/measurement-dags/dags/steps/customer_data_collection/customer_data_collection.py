from helpers.emr import add_and_watch_step, EmrAddAndWatchStep
from helpers.xcom import get_path, get_ci, get_sns, pipeline_run_type as get_pipeline_run_type
from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE


def tasks(executors: int = 48, pipeline_run_type: str = DTP_RUN_TYPE) -> EmrAddAndWatchStep:

    step_name = 'CustomerDataCollection'
    step_script = 'customer_data_collection.py'
    step_args = [
        ("--youtube-data", get_path("youtube_data")),
        ("--dv360-data", get_path("dv360_data")),
        ("--citrus-data", get_path("citrus_data")),
        ("--instore-data", get_path("instore_data")),
        ("--meta-data", get_path("meta_data")),
        ("--magazine-data", get_path("magazine_data")),
        ("--ecoupon-data", get_path("ecoupon_data")),
        ("--coupon-at-till-data", get_path("coupon_at_till_data")),
        ("--measurement-campaign-execution-path", get_path("measurement_campaign_execution")),
        ("--output-path", get_path("customer_data_collection")),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--run-type", get_pipeline_run_type()),
        ("--correlation-id", get_ci()),
        ('--slack-topic-arn', get_sns("slack_topic_arn")),
    ]

    campaign_type_args = [
        ("--measurement-marketing-channel-hierarchy-path", get_path("measurement_marketing_channel_hierarchy")),
    ] if pipeline_run_type == POLLEN_RUN_TYPE else []

    step_args += campaign_type_args

    tg = add_and_watch_step(
        step_name=step_name,
        step_script=step_script,
        step_args=step_args,
        num_executors=executors,
        executor_cores=4,
        executor_memory="32g",
    )

    return tg
