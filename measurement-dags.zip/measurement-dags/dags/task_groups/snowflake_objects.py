from airflow.sdk import TaskGroup

from helpers.constants import DEV, SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_ci, get_model_start_end_dates
from helpers.constants import SALES_TRANSACTION_CODES
from helpers.setup import get_environment


def task_group() -> TaskGroup:

    with TaskGroup('create_snowflake_objects', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="create_weekly_dates_table",
            sql="snowflake_objects/create_weekly_dates.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create weekly dates table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_baseline_modelling_table",
            sql="snowflake_objects/baseline_modelling_dataset_table.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create baseline modelling dataset table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_baseline_modelling_output_table",
            sql="snowflake_objects/baseline_modelling_output.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create baseline modelling output table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_sku_cluster_mapping_table",
            sql="snowflake_objects/sku_cluster_mapping.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create SKU cluster mapping table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_campaign_execution_table",
            sql="snowflake_objects/measurement_campaign_execution_table.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement campaign execution table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_customer_data_collection_table",
            sql="snowflake_objects/customer_data_collection.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement customer data collection table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_unified_campaign_pollen_table",
            sql="snowflake_objects/create_unified_campaign_pollen.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement campaign execution table, to be used in baseline DAG
            """,
        )

        if get_environment() == DEV:  # Check if the environment is dev
            MeasurementSnowflakeOperator(
                task_id="create_unified_campaign_pollen_prod_evaluation_table",
                sql="snowflake_objects/create_unified_campaign_pollen_prod_evaluation.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                doc_md="""
                    This is to create measurement unified campaign pollen to emulate prod table, to be used in baseline DAG
                """,
            )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_campaign_reporting_table",
            sql="snowflake_objects/measurement_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement campaign reporting table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_reach_engagement_table",
            sql="snowflake_objects/measurement_reach_engagement.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement reach engagement table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_measurement_booking_reach_engagement_table",
            sql="snowflake_objects/measurement_booking_reach_engagement.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement reach booking engagement table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_planogram_campaign_item_postn_daily_table",
            sql="snowflake_objects/planogram_campaigns_table.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create planogram campaign item postn daily table, to be used in daily ETL DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_unified_product_aws_table",
            sql="snowflake_objects/create_unified_product_aws_table.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create unified_product_aws table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_baseline_attribution_integration_table",
            sql="snowflake_objects/baseline_attribution_integration.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create baseline attribution integration table, to be used in baseline DAG
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="create_post_campaign_period_table",
            sql="snowflake_objects/post_campaign_period.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create post campaign period table, to be used in baseline DAG
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_and_load_transactions_agg_intermediate_table",
            sql="snowflake_objects/transaction_intermediate.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "modelling_end_date": get_model_start_end_dates('end_date'),
                'transaction_codes': SALES_TRANSACTION_CODES,
                "ci": get_ci()
            },
            doc_md="""
                This is to create post campaign period table, to be used in baseline DAG
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_metadata_table",
            sql="snowflake_objects/metadata.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create metadata table, to be used to store DAGs metadata
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_measurement_booking_reach_engagement_table_v1",
            sql="snowflake_objects/measurement_booking_reach_engagement.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement reach booking engagement table, to be used in baseline DAG
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_measurement_booking_reach_engagement_table_detail",
            sql="snowflake_objects/measurement_booking_reach_engagement_detail.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to create measurement reach booking engagement table for detail, to be used in baseline DAG
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_marketing_channel_hierarchy_table",
            sql="snowflake_objects/measurement_ marketing_channel_hierarchy.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Creates marketing channel hierarchy reference table for measurement
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_check_campaign_mismatch_table",
            sql="snowflake_objects/create_check_campaign_mistmatch.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Creates check_campaign_mismatch table for validation task group
            """,
        )
        MeasurementSnowflakeOperator(
            task_id="create_campaign_validation_issues_table",
            sql="snowflake_objects/create_campaign_validation_issues.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates the campaign validation issues table if it does not already exist.
                """,
        )

    return tg
