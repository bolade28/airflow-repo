from airflow.sdk import TaskGroup
from steps.analytical_pipeline import three_letter_coding, baseline_modelling_dataset


def task_group() -> TaskGroup:

    with TaskGroup('analytical_pipeline', ui_color="ff7f00") as tg:

        three_letter = three_letter_coding.tasks(executors=8)
        baseline_modelling_dataset_tg = baseline_modelling_dataset.tasks(executors=8)
        # Explicitly set parallel structure
        three_letter >> baseline_modelling_dataset_tg

    return tg
