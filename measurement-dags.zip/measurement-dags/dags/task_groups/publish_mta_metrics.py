from airflow.sdk import TaskGroup
from steps.metrics import mta_metrics


def task_group() -> TaskGroup:

    with TaskGroup('publish_mta_metrics', ui_color="ff7f00") as tg:

        mta_metrics.tasks(executors=8)

    return tg
