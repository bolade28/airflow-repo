from airflow.sdk import TaskGroup
from dags.steps.timeseries_data import value_index_processed_data


def task_group() -> TaskGroup:

    with TaskGroup('value_index_data', ui_color="ff7f00") as tg:

        value_index_processed_data.tasks(executors=8)

    return tg
