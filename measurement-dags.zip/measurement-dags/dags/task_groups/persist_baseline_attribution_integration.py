from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('persist_baseline_attribution_integration', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="persist_baseline_attribution_integration_to_snowflake",
            sql="load_to_snowflake/persist_baseline_integration.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               This task persists baseline attribution integration data, freshly calculated, into Snowflake
                """,
        )

    return tg
