from airflow.sdk import TaskGroup
from steps.customer_data_collection import customer_data_collection


def task_group() -> TaskGroup:

    with TaskGroup('customer_data_collection', ui_color="ff7f00") as tg:

        customer_data_collection.tasks()

    return tg
