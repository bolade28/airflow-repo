from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from steps.user_journey import user_journey
from helpers.constants import PRODUCT_TYPE, JOURNEY_TYPE, INCLUDE_AISLE_SKUS


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        return "mta_user_journey.user_journey_aisle"
    else:
        return "mta_user_journey.skip"


def task_group() -> TaskGroup:

    with TaskGroup('mta_user_journey', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        user_journey_offer = user_journey.tasks('UserJourneyOffer', PRODUCT_TYPE["offer"], JOURNEY_TYPE["offer"], "user_journey_offer")
        user_journey_brand = user_journey.tasks('UserJourneyBrand', PRODUCT_TYPE["brand"], JOURNEY_TYPE["brand"], "user_journey_brand")

        # Branching decision
        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        user_journey_aisle = user_journey.tasks('UserJourneyAisle', PRODUCT_TYPE["aisle"], JOURNEY_TYPE["aisle"], "user_journey_aisle")

        start >> user_journey_offer >> user_journey_brand >> aisle_decision >> user_journey_aisle >> finish
        aisle_decision >> skip >> finish

    return tg
