from airflow.sdk import TaskGroup

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('cleaning_up_temp_tables', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="tables_cleanup_snowflake",
            sql="cleanup/tables_cleanup.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This is to clean up temporary tables in Snowflake
            """,
        )
    return tg
