from airflow.sdk import TaskGroup

from helpers.constants import DEFAULT_DAILY_ETL_MODEL_START_DATE
from helpers import setup


def task_group() -> TaskGroup:

    start = setup.job_flow_start_time()

    with TaskGroup('setup_tasks') as tg:

        ci = setup.configure_correlation_id()
        setup.configure_paths(ci, '{{data_interval_end | ds }}')
        setup.configure_snowflake_tables(ci)
        setup.configure_campaign_start_date()
        setup.configure_model_start_end_dates(
            '{{data_interval_end | ds }}',
            DEFAULT_DAILY_ETL_MODEL_START_DATE,
            True
        )

    return start >> tg
