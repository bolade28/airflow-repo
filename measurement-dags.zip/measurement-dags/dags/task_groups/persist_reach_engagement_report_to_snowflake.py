from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('persist_reach_engagement_report_to_snowflake', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="persist_reach_engagement_report_to_snowflake",
            sql="load_to_snowflake/persist_reach_engagement_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task updates the reach engagement dataset
                """
        )
        MeasurementSnowflakeOperator(
            task_id="persist_reach_engagement_report_to_snowflake_detail",
            sql="load_to_snowflake/persist_reach_engagement_reporting_detail.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task updates the reach engagement dataset (detailed granular level)
                """
        )

        # No dependency between a and b; they will run independently
    return tg
