from airflow.providers.standard.operators.python import BranchPythonOperator, PythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_model_start_end_dates, get_configured_campaign
from helpers.dag_param import DagParams
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE


def _media_spend_qualified_campaigns(parent_group_id: str, **context):
    """
    Check the campaign validation results and decide whether to continue or skip pipeline
    """
    # Get the results from the previous task
    task_instance = context['task_instance']
    validation_results_media = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.media_spend_campaign_validate.check_media_spend_data'
    )
    # Check if any campaigns exist (have exist = true)
    qualifying_campaigns = ""
    if validation_results_media:
        qualifying_campaigns = {row[0] for row in validation_results_media}
    if qualifying_campaigns == "":
        return ''
    else:
        return str(','.join(qualifying_campaigns))


def _decide_to_continue_or_skip(parent_group_id: str, **context):
    """
    Check the campaign validation results and decide whether to continue or skip pipeline

    We pass a parent_group_id to make sure the task references are correct when used in different DAGs (During and Post)
    """
    # Get the results from the previous task
    task_instance = context['task_instance']
    validation_results_media = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.media_spend_campaign_validate.check_media_spend_data'
    )
    # Check if any campaigns exist (have exist = true)
    qualifying_campaigns = ""
    if validation_results_media:
        qualifying_campaigns = {row[0] for row in validation_results_media}
    if qualifying_campaigns == "":
        return f"{parent_group_id}.campaign_skip_alert_media.slack_alert_campaign_skip"
    else:
        return f"{parent_group_id}.qualified_campaigns.qualified_campaigns_list"


def task_group(campaign_duration: str = 'During', parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('media_spend_campaign_validate', ui_color="ff7f00") as tg:
        campaign_check = MeasurementSnowflakeOperator(
            task_id="check_media_spend_data",
            sql="validate_campaign_data/check_media_spend_amt.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign(),
                'campaign_end_date': get_model_start_end_dates('end_date'),
                'campaign_duration': campaign_duration,
                "post_run_type": 'Post',
                "during_run_type": 'During'
            },
            doc_md="""
                This task validates whether the campaigns provided have media spend amount greater than 0
                    """,
        )
        decide = BranchPythonOperator(
            task_id='campaigns_qualification_check',
            python_callable=_decide_to_continue_or_skip,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="""
                This task decides whether to continue or skip the pipeline based on campaign validation results
                """,
        )
        campaign_check >> decide
        return tg


def qualified_campaigns_list(parent_group_id: str = 'campaign_validations') -> task_group:
    with TaskGroup('qualified_campaigns', ui_color="ff7f00") as tg:
        PythonOperator(
            task_id="qualified_campaigns_list",
            python_callable=_media_spend_qualified_campaigns,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="Filters manual campaigns list to only include campaigns that exist with 'During' status"
        )
        return tg
