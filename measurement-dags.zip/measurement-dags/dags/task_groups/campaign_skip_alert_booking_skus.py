import pendulum

from airflow.sdk import Variable
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.providers.standard.operators.python import PythonOperator

tz = pendulum.timezone('Europe/London')


def _mark_validation_failed(**context):
    """Mark that validation failed"""
    context['task_instance'].xcom_push(key='validation_failed', value=True)


def _get_alert_message(parent_group_id: str, **context):
    task_instance = context['task_instance']

    # ToDo just use the existing xcom helper functions...
    correlation_id = task_instance.xcom_pull(
        task_ids='setup_tasks.configure_correlation_id',
        key='return_value'
    )

    pipelines_version = task_instance.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    validation_results = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.booking_item_cd_list_validate.check_booking_item_cd_list'
    )

    booking_ids = {row[0] for row in validation_results} if validation_results else set()
    reason_codes = {row[1] for row in validation_results} if validation_results else set()

    return f""":red_circle: :owl: *Pipeline Skipped*
        The baseline pipeline has been stopped because the following booking IDs have invalid booking_item_cd_lists.
        *Correlation ID:* `{correlation_id}`
        *Booking IDs:* {', '.join(f'`{bid}`' for bid in sorted(booking_ids))}
        *Reason Codes:* {', '.join(f'`{code}`' for code in sorted(reason_codes))}
        *Pipeline Hash:* `{pipelines_version}`"""


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup("campaign_skip_alert_booking_item_cd") as alert_tg:
        get_message = PythonOperator(
            task_id="prepare_alert_message",
            python_callable=_get_alert_message,
            op_kwargs={'parent_group_id': parent_group_id},
        )

        send_alert = SlackAPIPostOperator(
            task_id="slack_alert_campaign_skip",
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=f"{{{{ task_instance.xcom_pull(task_ids='{parent_group_id}.campaign_skip_alert_booking_item_cd.prepare_alert_message') }}}}"
        )

        skip_downstream = PythonOperator(
            task_id="skip_pipeline",
            python_callable=_mark_validation_failed,
        )

        get_message >> send_alert >> skip_downstream

    return alert_tg
