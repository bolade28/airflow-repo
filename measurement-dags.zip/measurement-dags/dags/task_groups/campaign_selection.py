from airflow.sdk import TaskGroup
from steps.campaign_selection import campaign_selection
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('campaign_selection', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'CampaignSelection'
        pollen_task_name = 'CampaignSelectionPollen'
        task_group_name = 'campaign_selection'

        dtp_campaign_selection = campaign_selection.tasks(step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE,
                                                          executors=8)
        pollen_campaign_selection = campaign_selection.tasks(step_name=pollen_task_name, pipeline_run_type=POLLEN_RUN_TYPE, executors=8)

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_campaign_selection",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_campaign_selection >> finish
        start >> decide >> pollen_campaign_selection >> finish
    return tg
