from airflow.sdk import TaskGroup

from helpers import setup


def task_group() -> TaskGroup:

    start = setup.job_flow_start_time()

    with TaskGroup('setup_tasks') as tg:

        ci = setup.configure_correlation_id()
        setup.configure_snowflake_tables(ci)
        setup.configure_run_type()
        setup.configure_dag_version()

    return start >> tg
