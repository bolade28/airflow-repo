from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule

from steps.sku_level_attributed_sales_and_units import sku_level_attributed_sales_and_units
from helpers.constants import PRODUCT_TYPE, INCLUDE_AISLE_SKUS


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        return "mta_sku_level_attributed_sales_and_units.sku_level_attributed_sales_and_units_aisle"
    else:
        return "mta_sku_level_attributed_sales_and_units.skip"


def task_group() -> TaskGroup:

    with TaskGroup('mta_sku_level_attributed_sales_and_units', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        sku_level_attributed_sales_and_units_offer = sku_level_attributed_sales_and_units.tasks('SkuLevelAttributedSalesAndUnitsOffer', "attribution_model_result_offer", PRODUCT_TYPE["offer"], "sku_level_attributed_sales_and_units_offer")
        sku_level_attributed_sales_and_units_brand = sku_level_attributed_sales_and_units.tasks('SkuLevelAttributedSalesAndUnitsBrand', "attribution_model_result_brand", PRODUCT_TYPE["brand"], "sku_level_attributed_sales_and_units_brand")
        sku_level_attributed_sales_and_units_aisle = sku_level_attributed_sales_and_units.tasks('SkuLevelAttributedSalesAndUnitsAisle', "attribution_model_result_aisle", PRODUCT_TYPE["aisle"], "sku_level_attributed_sales_and_units_aisle")

        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        # explicitly design this way, as offer is used in brand and aisle
        start >> sku_level_attributed_sales_and_units_offer >> sku_level_attributed_sales_and_units_brand >> aisle_decision >> sku_level_attributed_sales_and_units_aisle >> finish
        aisle_decision >> skip >> finish

    return tg
