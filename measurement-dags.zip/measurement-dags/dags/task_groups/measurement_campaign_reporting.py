from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule
from steps.measurement_campaign_reporting import measurement_campaign_reporting

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group(campaign_duration: str = None) -> TaskGroup:

    with TaskGroup('mta_measurement_campaign_reporting', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'MeasurementCampaignReporting'
        pollen_task_name = 'MeasurementCampaignReportingPollen'
        task_group_name = 'mta_measurement_campaign_reporting'

        dtp_measurement_campaign_reporting = measurement_campaign_reporting.tasks(
            step_name=dtp_task_name,
            pipeline_run_type=DTP_RUN_TYPE,
            campaign_duration=campaign_duration,
        )
        pollen_measurement_campaign_reporting = measurement_campaign_reporting.tasks(
            step_name=pollen_task_name,
            pipeline_run_type=POLLEN_RUN_TYPE,
            campaign_duration=campaign_duration,
        )

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_measurement_campaign_reporting",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_measurement_campaign_reporting >> finish
        start >> decide >> pollen_measurement_campaign_reporting >> finish
    return tg
