from airflow.sdk import TaskGroup
from steps.baseline_modelling_dataset import baseline_modelling_dataset


def task_group() -> TaskGroup:

    with TaskGroup('baseline_modelling_dataset', ui_color="ff7f00") as tg:

        baseline_modelling_dataset.tasks(executors=8)

    return tg
