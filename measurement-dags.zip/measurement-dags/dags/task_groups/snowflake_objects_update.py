from airflow.sdk import TaskGroup

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('update_snowflake_objects', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="update_001_add_run_type_dag_run_ts_columns",
            sql="snowflake_objects/update_001_add_run_type_dag_run_ts_columns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds run_type & dag_run_ts columns to 4 result tables
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_002_add_media_spend_source_column",
            sql="snowflake_objects/update_002_add_media_spend_source_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds media_spend_source to measurement_unified_campaign_pollen
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_003_update_unique_brand_name_column_spaces",
            sql="snowflake_objects/update_003_update_unique_brand_name_column_spaces.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               Update field unique brand to append spaces before and after the pipe character.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_004_add_overlapping_campaign_flag_column",
            sql="snowflake_objects/update_004_add_overlapping_campaign_flag_column.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds overlapping_campaign_id to measurement_campaign_execution_status
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_005_add_overlapping_campaign_to_campaign_reporting",
            sql="snowflake_objects/update_005_add_overlapping_campaign_to_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds overlapping_campaign_id to measurement_campaign_reporting_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_004_update_baseline_intergration_aws",
            sql="snowflake_objects/update_004_update_baseline_intergration_aws.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Update field unique brand to append spaces before and after the pipe character.
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_006_add_modelling_weight_to_campaign_reporting",
            sql="snowflake_objects/update_006_add_modelling_weight_to_campaign_reporting.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds Modelling weights to measurement_campaign_reporting_aws
            """,
        )

        MeasurementSnowflakeOperator(
            task_id="update_007_add_marketing_hierarchy_cd",
            sql="snowflake_objects/update_007_add_marketing_hierarchy_cd.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                Adds marketing_hierarchy_cd column to multiple tables:
                - baseline_attribution_integration_aws
                - measurement_campaign_execution_aws
                - measurement_campaign_reporting_aws
                - measurement_reach_engagement_aws
                - measurement_unified_campaign_pollen
            """,
        )
    return tg
