from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_configured_campaign
from helpers.dag_param import DagParams
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE


def _decide_to_continue_or_skip(parent_group_id: str, **context):
    """
    Check the campaign validation results and decide whether to continue or skip pipeline

    We pass a parent_group_id to make sure the task references are correct when used in different DAGs (During and Post)
    """
    # Get the results from the previous task
    task_instance = context['task_instance']
    validation_results = task_instance.xcom_pull(
        task_ids=f'{parent_group_id}.booking_item_cd_list_validate.check_booking_item_cd_list'
    )

    # Check if any campaigns exist, this is a negative check, so if they do exist we skip
    booking_ids = set()
    if validation_results:
        booking_ids = {row[0] for row in validation_results}

    if not booking_ids:  # Empty set means all campaigns are valid
        return f"{parent_group_id}.media_spend_campaign_validate.check_media_spend_data"
    else:  # Invalid booking IDs found, skip to alert
        return f"{parent_group_id}.campaign_skip_alert_booking_item_cd.prepare_alert_message"


def task_group(parent_group_id: str = 'campaign_validations') -> TaskGroup:
    with TaskGroup('booking_item_cd_list_validate', ui_color="ff7f00") as tg:
        campaign_check = MeasurementSnowflakeOperator(
            task_id="check_booking_item_cd_list",
            sql="validate_campaign_data/check_booking_item_cd_list.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign()
            },
            doc_md="""
                This task validates whether the campaigns provided have valid booking item cd lists
                """,
        )
        decide = BranchPythonOperator(
            task_id='campaigns_qualification_check',
            python_callable=_decide_to_continue_or_skip,
            op_kwargs={'parent_group_id': parent_group_id},
            doc_md="""
                This task decides whether to continue or skip the pipeline based on campaign validation results
                """,
        )
        campaign_check >> decide
        return tg
