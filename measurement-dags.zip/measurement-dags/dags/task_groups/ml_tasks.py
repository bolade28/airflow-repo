from airflow.sdk import TaskGroup
from steps.feature_prioritisation import feature_prioritisation
from steps.baseline_modelling_output import baseline_modelling_output
from steps.incremental_shrinkage import incremental_shrinkage
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('ml_tasks', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'incremental_shrinkage_dtp'
        pollen_task_name = 'incremental_shrinkage_pollen'
        task_group_name = 'ml_tasks'

        feature_prioritisation_task = feature_prioritisation.tasks()
        baseline_modelling_output_task = baseline_modelling_output.tasks()

        incremental_shrinkage_dtp = incremental_shrinkage.tasks(
            step_name=dtp_task_name,
            pipeline_run_type=DTP_RUN_TYPE
        )
        incremental_shrinkage_pollen = incremental_shrinkage.tasks(
            step_name=pollen_task_name,
            pipeline_run_type=POLLEN_RUN_TYPE
        )

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_campaign_selection",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> feature_prioritisation_task >> baseline_modelling_output_task >> decide
        decide >> [incremental_shrinkage_dtp, incremental_shrinkage_pollen] >> finish

    return tg
