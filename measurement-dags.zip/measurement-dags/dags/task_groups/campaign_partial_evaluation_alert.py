import pendulum
from airflow.sdk import TaskGroup, task
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.providers.standard.operators.python import get_current_context
from typing import Any

from helpers.setup import get_environment
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE, SLACK_MESSAGE_TABLE_DISPLAY_LIMIT
from helpers.xcom import get_ci, get_configured_campaign
from helpers.snowflake import MeasurementSnowflakeOperator
from task_groups.validation_slack_alerts import unified_format_table_rows

tz = pendulum.timezone('Europe/London')


def create_mismatch_check_and_alert(group_id: str) -> TaskGroup:
    """
    Helper function to create campaign mismatch check task and alert task group.
    Returns a TaskGroup containing mismatch check and alert tasks.
    """
    with TaskGroup(group_id=group_id) as tg:

        # SQL task that checks for campaign mismatches between booking and unified tables and pushes results to XCom
        mismatch_check = MeasurementSnowflakeOperator(
            task_id="check_campaign_mismatch",
            sql="validate_campaign_data/check_campaign_mismatch.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            do_xcom_push=True,
            params={
                "correlation_id": get_ci(),
                'configured_campaign_id': get_configured_campaign(),
            },
        )

        # Alerts task group for campaign mismatch
        mismatch_alert = campaign_mismatch_evaluation_alert(
            group_id="campaign_mismatch_alert",
            source_task_id=f"{group_id}.check_campaign_mismatch",
        )

        # Sets task dependencies
        mismatch_check >> mismatch_alert

    return tg


def format_campaign_mismatch_alert_table(rows: list[tuple[Any, ...]], limit: int = SLACK_MESSAGE_TABLE_DISPLAY_LIMIT) -> str:
    """
    Formats the mismatch rows to be displayed as a table
    Args:
        rows: List of tuples containing mismatch details
        limit: Maximum number of rows to include in the table set to 10 with the use of SLACK_MESSAGE_TABLE_DISPLAY_LIMIT
    Returns:
        A string formatted as a table for Slack messages
    """

    if not rows:
        return ""

    # Converts tuples to dictionaries for unified formatting
    records = []
    for row in rows:
        records.append({
            "booking_id": str(row[0] if row[0] else "Unknown"),
            "booking_name": str(row[1] if row[1] else "Unknown"),
            "subchannel_name": str(row[3] if len(row) > 3 and row[3] else "Unknown"),
            "campaign_end_dt": str(row[6] if len(row) >= 7 and row[6] else "Unknown"),
        })

    # Defines headers and keys for the table
    headers = ["Booking ID", "Booking Name", "Sub-channel Name", "Campaign End Date"]
    keys = ["booking_id", "booking_name", "subchannel_name", "campaign_end_dt"]

    # Uses unified table function to format the rows into a table string
    table = unified_format_table_rows(headers, keys, records, limit)

    # Creates additional information sections
    additional_info = []
    if len(rows) > limit:
        additional_info.append(f"\n_Showing top {limit} of {len(rows)} campaigns_")

    additional_info.extend([
        "",
        f"*Total campaigns with mismatches:* {len(rows)}",
        "",
        "*Action Required:*",
        "Please investigate why this has occurred. You can find the missing campaigns in the table `ADW_UNIFIED_PLATFORM_TACTICAL.CHECK_CAMPAIGN_MISMATCH`."
    ])

    return table + "\n" + "\n".join(additional_info)


def create_mismatch_alert_message(rows: list[tuple[Any, ...]], limit: int = SLACK_MESSAGE_TABLE_DISPLAY_LIMIT) -> str:
    """
    Creates a slack alert message based on the result of a mismatch in the amount of campaigns between CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR and MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN tables
    """

    if not rows or len(rows) == 0:
        return ""

    # Header for the alert message
    sections = [
        ":warning: *Campaign Only Partially Evaluated*",
        "This campaign is only partially evaluated!",
        "",
        format_campaign_mismatch_alert_table(rows, limit),
    ]

    if len(rows) > limit:
        sections.append(f"\n_({len(rows) - limit} more campaigns not shown. Check `ADW_UNIFIED_PLATFORM_TACTICAL.CHECK_CAMPAIGN_MISMATCH` for the full list.)_")

    return "\n".join(sections)


def campaign_mismatch_evaluation_alert(group_id: str, source_task_id: str, limit: int = SLACK_MESSAGE_TABLE_DISPLAY_LIMIT) -> TaskGroup:
    """
    This task group prepares for a the slack alert and sends it depending on whether the message is empty or not.
    If there are more campaigns in the bdv table than in the unified table, it sends a Slack alert.

    Args:
        group_id: The task group ID
        source_task_id: The task ID to pull XCom data from
        limit: Maximum number of campaigns that are shown in the Slack table set to 10 with the use of SLACK_MESSAGE_TABLE_DISPLAY_LIMIT
    """
    with TaskGroup(group_id=group_id) as alert_tg:
        env = get_environment()

        # Retrieves campaign mismatch data from XCom and formats complete Slack alert message (including success case)
        @task(task_id="prepare_campaign_evaluation_alert_message")
        def prepare_campaign_evaluation_alert_message() -> str:
            """Prepares the complete alert message - either mismatch warning or success notification."""
            context = get_current_context()
            task_instance = context["task_instance"]
            # Resolve the full task_id by prepending any outer group prefix from the current task's id
            source_group = source_task_id.split(".")[0]
            current_task_id = task_instance.task_id
            idx = current_task_id.find(source_group + ".")
            resolved_source_task_id = current_task_id[:idx] + source_task_id if idx > 0 else source_task_id
            rows = task_instance.xcom_pull(task_ids=resolved_source_task_id)
            if rows is None:
                return ":x: *Campaign Mismatch Check Failed*\n\nNo results returned from the mismatch check query. The task may have failed or returned no data. Please check the task logs."
            return create_mismatch_alert_message(rows, limit)

        prepared_message = prepare_campaign_evaluation_alert_message()

        @task(task_id="send_campaign_mismatch_alert")
        def send_alert_if_needed(message: str):
            """Send Slack alert for campaign validation results."""
            context = get_current_context()
            campaign_id = context["task_instance"].xcom_pull(task_ids="setup_tasks.configure_campaigns", key="return_value") or "unknown"

            # Prepare message - either mismatch warning or success notification
            if not message:
                alert_message = f":white_check_mark: *Campaign Validation Successful*\n\nNo mismatches found for campaign `{campaign_id}`. All campaigns are properly evaluated."
            else:
                alert_message = message

            # Always send Slack alert
            alert_op = SlackAPIPostOperator(
                task_id="slack_alert_internal",
                channel=f'#measurement-ops-{env}',
                text=alert_message,
            )
            alert_op.execute(context=get_current_context())
            return f"Alert sent to #measurement-ops-{env} for campaign `{campaign_id}`"

        send_alert = send_alert_if_needed(prepared_message)

        prepared_message >> send_alert

    return alert_tg
