from __future__ import annotations

import pendulum
from datetime import date, datetime, timedelta
from typing import Any

from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from helpers.setup import get_airflow_platform, get_environment, get_build_hash
from helpers.constants import PROD, EvaluationPhase
from helpers.xcom import (
    get_ci,
    get_manual_campaigns_list,
    get_pipelines_version,
    get_post_period_end_date,
    pipeline_run_type_name,
    get_git_hash,
    get_campaign_end_date,
    get_configured_campaign,
    get_during_correlation_id,
    get_current_aws_user
)
from helpers.utils import get_current_timestamp

tz = pendulum.timezone('Europe/London')


def task_group_started(pipeline_stage: str, period: EvaluationPhase = EvaluationPhase.DURING) -> TaskGroup:

    with TaskGroup("pipeline_start_alerts") as alert_tg:
        """
        This task group sends alerts to notify measurement team that baseline pipeline has completed
        """
        env = get_environment()
        text_msg = f"""Baseline MTA pipeline started at {get_current_timestamp()} with correlation id {get_ci()}"""

        notify_measurement = SlackAPIPostOperator(
            task_id="slack_alert_mta_started",
            channel=f'#measurement-{env}-alerts',
            text=text_msg,
        )

        notify_measurement_ops = SlackAPIPostOperator(
            task_id="slack_alert_mta_started_ops",
            channel=f'#measurement-ops-{env}',
            text=text_msg,
        )

        notify_measurement_uat = SlackAPIPostOperator(
            task_id="slack_alert_mta_started_uat",
            channel=f'#measurement-{env}-uat',
            text=get_start_alert_message(ci=get_ci(), period=period.value, pipeline_stage=pipeline_stage)
        )

        notify_measurement >> notify_measurement_ops >> notify_measurement_uat

    return alert_tg


def task_group_completed(pipeline_stage: str, period: EvaluationPhase = EvaluationPhase.DURING) -> TaskGroup:

    with TaskGroup("pipeline_completed_alerts") as alert_tg:
        """
        This task group sends alerts to notify measurement team that baseline pipeline has completed
        """
        env = get_environment()
        text_msg = f"""MTA pipeline completed at {get_current_timestamp()} with correlation id {get_ci()}"""

        notify_measurement = SlackAPIPostOperator(
            task_id="slack_alert_mta_done",
            channel=f'#measurement-{env}-alerts',
            text=text_msg,
        )

        notify_measurement_ops = SlackAPIPostOperator(
            task_id="slack_alert_mta_done_ops",
            channel=f'#measurement-ops-{env}',
            text=text_msg,
        )

        notify_measurement_uat = SlackAPIPostOperator(
            task_id="slack_alert_mta_uat",
            channel=f'#measurement-{env}-uat',
            text=get_uat_alert_message(pipeline_stage=pipeline_stage, ci=get_ci(), period=period.value)
        )

        notify_measurement >> notify_measurement_ops >> notify_measurement_uat

    return alert_tg


def get_start_alert_message(ci: str, period: EvaluationPhase, pipeline_stage: str) -> str:
    """Returns text for start pipeline alert"""
    return f""":rocket: Measurement pipeline run started. Details below:

*Run details:*
Correlation ID: {ci}
Configured booking ID/Job bag number: {get_configured_campaign()}
Validated: booking ID/Job bag number: {get_manual_campaigns_list()}
Campaign/post period end date: {get_campaign_end_date() if period == EvaluationPhase.DURING.value else get_post_period_end_date()}
Pipelines hash: {get_pipelines_version()}
Started by: {get_current_aws_user()}
Type: {pipeline_run_type_name()}
Evaluation phase: {period}
{"During correlation id: " + get_during_correlation_id() if period == EvaluationPhase.POST.value else ""}

*Code & Platform:*
Base pipelines git commit: `{get_git_hash(pipeline_stage=pipeline_stage, type='pipelines_base')}`
Base dags git commit: `{get_git_hash(pipeline_stage=pipeline_stage, type='dags_base')}`
Airflow platform: `{get_airflow_platform()}`
{build_hash_info()}
"""


def get_uat_alert_message(pipeline_stage: str, ci: str, period: str) -> str:
    """Returns text for UAT alert"""
    return f""":white_check_mark: Pipeline completed successfully. Results ready for UAT:

Correlation ID: {ci}
Configured booking ID/Job bag number: {get_configured_campaign()}
Validated: booking ID/Job bag number: {get_manual_campaigns_list()}
Campaign/post period end date: {get_campaign_end_date() if period == EvaluationPhase.DURING.value else get_post_period_end_date()}
Pipelines hash: {get_pipelines_version()}
Completed by: {get_current_aws_user()}
Type: {pipeline_run_type_name()}
Evaluation phase: {period}

*Code & Platform:*
Base pipelines git commit: `{get_git_hash(pipeline_stage=pipeline_stage, type='pipelines_base')}`
Base dags git commit: `{get_git_hash(pipeline_stage=pipeline_stage, type='dags_base')}`
Airflow platform: `{get_airflow_platform()}`
{build_hash_info()}

Monitoring Service: <{get_monitoring_service_link(ci=ci, env=get_environment())}|dashboard link>
"""


def get_monitoring_service_link(ci: str, env: str) -> str:
    """Returns link to monitoring service dashboard"""
    if env == PROD:
        return f"https://metrics.measurementprod.com/d/298c3ddd-419a-4989-b833-8c713e643845/measurement-reporting?orgId=1&from=now-6h&to=now&timezone=browser&var-correlation_id={ci}&var-job_bag_number=$__all&var-channel_name=$__all"
    else:
        return f"https://metrics.measurementdev.com/d/298c3ddd-419a-4989-b833-8c713e643845/measurement-reporting?orgId=1&from=now-6h&to=now&timezone=browser&var-correlation_id={ci}&var-job_bag_number=$__all&var-channel_name=$__all"


def build_hash_info() -> str:
    build_hash = get_build_hash()
    return f"Build hash: `{build_hash}`" if build_hash else "Build hash: :red_circle: unavailable (run `make airflow`)"


# ---------------------------------------------------------------------------
# Blacklist alert helpers
# ---------------------------------------------------------------------------

def _parse_end_date(raw: Any) -> date | None:
    if raw is None:
        return None
    try:
        return datetime.strptime(str(raw)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _format_reason(reason: Any) -> str:
    return str(reason).replace("|", "/").replace("\n", " ").strip()


def build_blacklist_alert_message(
    rows: list[tuple[Any, ...]] | None,
    execution_date: str,
    correlation_id: str = "",
) -> str:
    """
    Builds a Slack alert message summarising blacklisted bookings.

    Rows are expected in the format:
        (booking_id, cid, channel, booking_name, status, reason, end_date)

    The message includes:
    - Count of bookings finishing today
    - Count of distinct bookings finishing in the next 10 and 30 days
    - Detailed records for bookings within the next 30 days (capped at 30)
    """
    safe_rows = list(rows or [])
    if not safe_rows:
        return ":white_check_mark: No blacklist records found in this validation run."

    exec_date = datetime.strptime(execution_date[:10], "%Y-%m-%d").date()
    next_10 = exec_date + timedelta(days=10)
    next_30 = exec_date + timedelta(days=30)
    display_limit = 30

    today_ids: list[str] = []
    next_10_ids: set[str] = set()
    next_30_ids: set[str] = set()
    upcoming_records: list[dict[str, str]] = []
    seen: set[str] = set()

    for row in safe_rows:
        if not row:
            continue
        booking_id = str(row[0]) if row[0] is not None else ""
        end_date = _parse_end_date(row[-1] if len(row) > 0 else None)
        if not booking_id or end_date is None:
            continue

        if end_date == exec_date:
            today_ids.append(booking_id)
        if exec_date <= end_date <= next_10:
            next_10_ids.add(booking_id)
        if exec_date <= end_date <= next_30:
            next_30_ids.add(booking_id)
            if booking_id not in seen:
                seen.add(booking_id)
                upcoming_records.append({
                    "booking_id": booking_id,
                    "booking_name": str(row[3]) if len(row) > 3 and row[3] is not None else "",
                    "status": str(row[4]) if len(row) > 4 and row[4] is not None else "",
                    "reason": _format_reason(row[-2] if len(row) > 1 else ""),
                    "end_date": end_date.isoformat(),
                })

    if not upcoming_records:
        return ":white_check_mark: No blacklist records found in this validation run."

    sections: list[str] = [":warning: *Data issue detected:*", ""]

    if today_ids:
        for bid in today_ids:
            sections.append(f"- Finishing today: {bid}")
    sections.append(f"- Finishing in next 10 days (distinct bookings): {len(next_10_ids)}")
    sections.append(f"- Finishing in next 30 days (distinct bookings): {len(next_30_ids)}")
    sections.append("")

    display = upcoming_records[:display_limit]
    for record in display:
        sections.append(f"-> *Booking ID:* {record['booking_id']}")
        sections.append(f"   *Booking Name:* {record['booking_name']}")
        sections.append(f"   *Status:* {record['status']}")
        sections.append(f"   *Reason:* {record['reason']}")
        sections.append(f"   *End Date:* {record['end_date']}")
        sections.append("")

    if len(upcoming_records) > display_limit:
        sections.append(f"_Showing first {display_limit} of {len(upcoming_records)} upcoming records._")

    if correlation_id:
        sections.append(f"_Correlation ID: {correlation_id}_")

    return "\n".join(sections)


# ---------------------------------------------------------------------------
# Campaign evaluation alert helpers
# ---------------------------------------------------------------------------

def _format_campaign_table(
    records: list[dict[str, Any]],
    date_field: str,
    days_field: str,
    limit: int = 10,
) -> str:
    """
    Formats campaign records as a fixed-width Slack-friendly table.

    Args:
        records: List of campaign record dicts
        date_field: Key for the date column (e.g. "campaign_end_dt")
        days_field: Key for the days-remaining column (e.g. "days_until_end")
        limit: Maximum number of rows to display

    Returns:
        Formatted table string wrapped in triple-backticks, or "" if records is empty
    """
    if not records:
        return ""

    display = records[:limit]

    header = "Booking ID                 | Booking Name                                | Marketing Type  | Channel                     | Evaluation Due In"
    separator = "---------------------------|---------------------------------------------|-----------------|-----------------------------|-----------------"

    lines = ["```", header, separator]
    for record in display:
        booking_id = str(record.get("booking_id", ""))[:26].ljust(26)
        booking_name = str(record.get("booking_name", "") or "N/A")[:43].ljust(43)
        marketing_type = str(record.get("marketing_type", ""))[:15].ljust(15)
        channel = str(record.get("channel_name", ""))[:27].ljust(27)
        days_val = (str(record.get(days_field, "")) + "d").rjust(16)
        lines.append(f"{booking_id} | {booking_name} | {marketing_type} | {channel} | {days_val}")

    lines.append("```")

    if len(records) > limit:
        lines.append(f"\n_Showing top {limit} of {len(records)} campaigns_")

    return "\n".join(lines)


def _build_evaluation_alert_message(
    rows: list[tuple[Any, ...]] | None,
    execution_date: str,
    days_threshold: int,
    date_field: str,
    days_field: str,
    title: str,
    empty_message: str,
) -> str:
    records = []
    unique_campaigns: set[str] = set()

    for row in rows or []:
        if not row or len(row) < 6:
            continue
        booking_id = str(row[0] or "")
        booking_name = str(row[1] or "")
        if booking_id:
            unique_campaigns.add(booking_id)
        records.append({
            "booking_id": booking_id,
            "booking_name": booking_name,
            date_field: str(row[2] or "")[:10],
            "marketing_type": str(row[3] or ""),
            "channel_name": str(row[4] or ""),
            days_field: int(row[5]) if row[5] is not None else 0,
        })

    if not records:
        return empty_message

    sections = [
        f"📊 *{title}*",
        "",
        _format_campaign_table(records, date_field, days_field, 10),
        "",
        f"_{len(unique_campaigns)} unique campaigns active in {days_threshold} days_",
    ]
    return "\n".join(sections)


def build_campaign_end_alert_message(
    rows: list[tuple[Any, ...]] | None,
    execution_date: str,
    days_threshold: int,
) -> str:
    """Builds a Slack alert for ongoing campaigns ending within days_threshold days."""
    return _build_evaluation_alert_message(
        rows=rows,
        execution_date=execution_date,
        days_threshold=days_threshold,
        date_field="campaign_end_dt",
        days_field="days_until_end",
        title="Booking Evaluation - During",
        empty_message=f":white_check_mark: No ongoing campaigns ending in the next {days_threshold} days.",
    )


def build_post_period_end_alert_message(
    rows: list[tuple[Any, ...]] | None,
    execution_date: str,
    days_threshold: int,
) -> str:
    """Builds a Slack alert for post-period campaigns ending within days_threshold days."""
    return _build_evaluation_alert_message(
        rows=rows,
        execution_date=execution_date,
        days_threshold=days_threshold,
        date_field="post_campaign_dt",
        days_field="days_until_post_end",
        title="Booking Evaluation - Post",
        empty_message=f":white_check_mark: No post-period campaigns ending in the next {days_threshold} days.",
    )
