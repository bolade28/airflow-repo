from airflow.providers.standard.operators.python import BranchPythonOperator, PythonOperator
from airflow.sdk import TaskGroup

from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_configured_campaign
from helpers.dag_param import DagParams
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE


def _check_campaign_validation(**context):
    """
    Check the campaign validation results and decide whether to continue or skip pipeline
    """
    # Get the results from the previous task
    task_instance = context['task_instance']
    validation_results = task_instance.xcom_pull(task_ids='campaign_validations_post.campaign_validation.validate_campaigns')
    # Check if any campaigns exist (have exist = true)
    campaigns_exist = False

    if validation_results:
        campaigns_exist = any(row[1] for row in validation_results)  # row[1] is the 'exist' column

    if campaigns_exist:
        return 'campaign_validations_post.campaign_continue_alert.slack_alert_campaign_post_period_run'
    else:
        return 'campaign_validations_post.campaign_skip_alert.slack_alert_campaign_skip'


def _filter_manual_campaigns(**context):
    """
    Filter the manual campaigns list to only include campaigns that exist in the validation
    Returns a comma-separated string of existing campaigns
    """
    task_instance = context['task_instance']

    # Get validation results
    validation_results = task_instance.xcom_pull(task_ids='campaign_validations_post.campaign_validation.validate_campaigns')

    # Get original manual campaigns list
    original_campaigns = task_instance.xcom_pull(task_ids='setup_tasks.configure_campaigns', key='return_value')

    if not validation_results or not original_campaigns:
        return ""

    # Create a set of existing campaigns for quick lookup
    existing_campaigns = {row[0] for row in validation_results if row[1]}  # row[0] is campaign_id, row[1] is exist flag

    # Filter original campaigns to only include existing ones
    # filtered_campaigns = [campaign for campaign in original_campaigns if campaign in existing_campaigns]

    # Return as comma-separated string to match the format expected by SQL templates
    return ','.join(existing_campaigns)


def task_group() -> TaskGroup:
    """
    Campaign validation task group that checks if campaigns exist with 'During' status
    """
    with TaskGroup("campaign_validation") as tg:
        # Task to validate campaigns exist in measurement_campaign_reporting_aws with During status
        validate_campaigns = MeasurementSnowflakeOperator(
            task_id="validate_campaigns",
            sql="validate_campaign_data/check_campaign_existence.sql",
            params={
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': get_configured_campaign()
            },
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="Validates that campaign IDs exist with 'During' status in measurement_campaign_reporting_aws table"
        )

        # Task to filter manual campaigns list to only include existing campaigns
        filter_manual_campaigns = PythonOperator(
            task_id="filter_manual_campaigns",
            python_callable=_filter_manual_campaigns,
            doc_md="Filters manual campaigns list to only include campaigns that exist with 'During' status"
        )

        # Branch task to decide whether to continue or skip
        branch_decision = BranchPythonOperator(
            task_id="check_validation_results",
            python_callable=_check_campaign_validation,
        )

        validate_campaigns >> filter_manual_campaigns >> branch_decision
    return tg
