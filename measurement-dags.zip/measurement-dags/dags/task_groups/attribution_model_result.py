from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from steps.attribution_model_results import attribution_model_results
from steps.attribution_model_results import attribution_model_results_pollen
from helpers.constants import JOURNEY_TYPE, INCLUDE_AISLE_SKUS, DTP_RUN_TYPE, POLLEN_RUN_TYPE
from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        # determine which pipeline is running to route to correct aisle task
        run_type = pipeline_run_type()
        if run_type == DTP_RUN_TYPE:
            return "model_result.attribution_model_result_aisle_dtp"
        elif run_type == POLLEN_RUN_TYPE:
            return "model_result.attribution_model_result_aisle_pollen"
        else:
            return "model_result.skip"
    else:
        return "model_result.skip"


def task_group() -> TaskGroup:

    with TaskGroup('model_result', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        # Task names for DTP and Pollen
        dtp_brand_task_name = 'AttributionModelResultBrand'
        dtp_offer_task_name = 'AttributionModelResultOffer'
        dtp_aisle_task_name = 'AttributionModelResultAisle'

        pollen_brand_task_name = 'AttributionModelResultBrandPollen'
        pollen_offer_task_name = 'AttributionModelResultOfferPollen'
        pollen_aisle_task_name = 'AttributionModelResultAislePollen'

        task_group_name = 'model_result'

        # DTP Attribution Model Tasks
        attribution_model_result_brand_dtp = attribution_model_results.tasks(
            dtp_brand_task_name,
            JOURNEY_TYPE["brand"],
            "attribution_pre_requisite_brand",
            "attribution_model_result_brand"
        )

        attribution_model_result_offer_dtp = attribution_model_results.tasks(
            dtp_offer_task_name,
            JOURNEY_TYPE["offer"],
            "attribution_pre_requisite_offer",
            "attribution_model_result_offer",
            synergy_output="attribution_synergy_results"
        )

        attribution_model_result_aisle_dtp = attribution_model_results.tasks(
            dtp_aisle_task_name,
            JOURNEY_TYPE["aisle"],
            "attribution_pre_requisite_aisle",
            "attribution_model_result_aisle"
        )

        # Pollen Attribution Model Tasks
        attribution_model_result_brand_pollen = attribution_model_results_pollen.tasks(
            pollen_brand_task_name,
            JOURNEY_TYPE["brand"],
            "attribution_pre_requisite_brand",
            "attribution_model_result_brand"
        )

        attribution_model_result_offer_pollen = attribution_model_results_pollen.tasks(
            pollen_offer_task_name,
            JOURNEY_TYPE["offer"],
            "attribution_pre_requisite_offer",
            "attribution_model_result_offer",
            synergy_output="attribution_synergy_results"
        )

        attribution_model_result_aisle_pollen = attribution_model_results_pollen.tasks(
            pollen_aisle_task_name,
            JOURNEY_TYPE["aisle"],
            "attribution_pre_requisite_aisle",
            "attribution_model_result_aisle"
        )

        # Decision operator for pipeline branching
        decide_pipeline = BranchPythonOperator(
            task_id="run_dtp_or_pollen_pipeline",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_offer_task_name,
                pollen_offer_task_name,
                task_group_name
            ],
        )

        # Aisle decision operator
        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        # Pipeline Dependencies
        start >> decide_pipeline

        # DTP Pipeline Path
        decide_pipeline >> attribution_model_result_offer_dtp >> attribution_model_result_brand_dtp >> aisle_decision

        # Pollen Pipeline Path
        decide_pipeline >> attribution_model_result_offer_pollen >> attribution_model_result_brand_pollen >> aisle_decision

        # Aisle processing
        aisle_decision >> [attribution_model_result_aisle_dtp, attribution_model_result_aisle_pollen, skip]

        [attribution_model_result_aisle_dtp, attribution_model_result_aisle_pollen, skip] >> finish
        [attribution_model_result_brand_dtp, attribution_model_result_brand_pollen] >> finish

    return tg
