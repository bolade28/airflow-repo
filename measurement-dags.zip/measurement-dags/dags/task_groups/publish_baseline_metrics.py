from airflow.sdk import TaskGroup
from steps.metrics import baseline_metrics
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('baseline_baseline_metrics', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'BaselineMetrics'
        pollen_task_name = 'BaselineMetricsPollen'
        task_group_name = 'baseline_baseline_metrics'

        dtp_baseline_metrics = baseline_metrics.tasks(step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE, executors=8)
        pollen_baseline_metrics = baseline_metrics.tasks(step_name=pollen_task_name, pipeline_run_type=POLLEN_RUN_TYPE, executors=8)

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_baseline_metrics",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_baseline_metrics >> finish
        start >> decide >> pollen_baseline_metrics >> finish

    return tg
