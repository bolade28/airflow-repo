from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import ShortCircuitOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from steps.normalisation import dv360_normalise, dv360_normalise_pollen, fb_campaign_normalized, fb_campaign_normalized_pollen, youtube_normalise_pollen
from helpers.xcom import pipeline_run_type
import logging

from helpers.utils import is_dtp, is_pollen
from airflow.task.trigger_rule import TriggerRule

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def task_group() -> TaskGroup:

    with TaskGroup('data_normalisation', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        buffer = EmptyOperator(
            task_id="buffer",
            trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS
        )
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        is_this_dtp = ShortCircuitOperator(
            task_id='is_dtp',
            python_callable=is_dtp,
            op_kwargs=dict(
                run_type=pipeline_run_type(),
            ),
            trigger_rule='none_failed_min_one_success',
            ignore_downstream_trigger_rules=False,
        )

        is_this_pollen = ShortCircuitOperator(
            task_id='is_pollen',
            python_callable=is_pollen,
            op_kwargs=dict(
                run_type=pipeline_run_type(),
            ),
            trigger_rule='none_failed_min_one_success',
            ignore_downstream_trigger_rules=False,
        )

        fb_normalise_dtp = fb_campaign_normalized.tasks(executors=8)
        dv360_normalise_dtp = dv360_normalise.tasks(executors=8)

        fb_normalise_pollen_task = fb_campaign_normalized_pollen.tasks(executors=8)
        dv360_normalise_pollen_task = dv360_normalise_pollen.tasks(executors=8)
        youtube_norm_pollen_task = youtube_normalise_pollen.tasks(executors=8)

        pollen_tasks = [
            dv360_normalise_pollen_task,
            fb_normalise_pollen_task,
            youtube_norm_pollen_task
        ]

        # Branching logic
        start >> dv360_normalise_dtp >> fb_normalise_dtp

        # DTP branch
        fb_normalise_dtp >> is_this_dtp

        # Pollen branch
        fb_normalise_dtp >> is_this_pollen >> pollen_tasks

        is_this_dtp >> buffer
        buffer >> finish

        pollen_tasks >> finish

    return tg
