import pendulum

from airflow.sdk import Variable
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from helpers.xcom import get_ci

tz = pendulum.timezone('Europe/London')


def task_group() -> TaskGroup:

    with TaskGroup("campaign_continue_alert") as alert_tg:
        """
        This task group sends alerts to notify measurement team about campaign processing status
        """
        SlackAPIPostOperator(
            task_id="slack_alert_campaign_post_period_run",
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=get_post_campaign_alert_message(ci=get_ci()),
        )
    return alert_tg


def get_post_campaign_alert_message(ci: str) -> str:
    """Returns text for campaign continue alert"""
    return f""":white_check_mark: Pipeline Starting

Valid campaigns found with 'During' status in measurement_campaign_reporting_aws table.

Correlation ID: {ci}
Pipeline Hash: {{{{ task_instance.xcom_pull(task_ids="setup_tasks.configure_pipelines_version", key="return_value") }}}}

Existing campaigns that will be processed: {{{{
    task_instance.xcom_pull(task_ids='campaign_validation.validate_campaigns')
    | selectattr('1')
    | map(attribute='0')
    | join(', ') or 'None'
}}}}

Missing campaigns (skipping): {{{{
    task_instance.xcom_pull(task_ids='campaign_validation.validate_campaigns')
    | rejectattr('1')
    | map(attribute='0')
    | join(', ') or 'None'
}}}}
The missing campaigns are the ones that they have no 'During' status in measurement_campaign_reporting_aws table. please run the main( with During campaign duration) pipeline first.

The baseline MTA pipeline is proceeding with campaign validation completed."""
