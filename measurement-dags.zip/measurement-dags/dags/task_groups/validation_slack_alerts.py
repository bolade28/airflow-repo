from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

from airflow.sdk import TaskGroup, task
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.providers.standard.operators.python import get_current_context

from helpers.setup import get_environment
from helpers.constants import SLACK_MESSAGE_TABLE_DISPLAY_LIMIT, CAMPAIGN_VALIDATION_FAILURE_CODES
from helpers.xcom import (
    get_ci,
    get_validation_check_details
)


@dataclass
class BlacklistStats:
    total_count: int
    upcoming_records: list[dict[str, str]]


def collect_blacklist_stats(rows: list[tuple[Any, ...]], execution_date: date) -> BlacklistStats:
    seen: set[str] = set()
    upcoming_records: list[dict[str, str]] = []

    for row in rows:
        booking_id = str(row[0]) if row and row[0] is not None else ""
        end_date = parse_end_date(row[-1] if row else None)
        if not booking_id or not end_date:
            continue

        if booking_id not in seen:
            seen.add(booking_id)
            upcoming_records.append(
                {
                    "booking_id": booking_id,
                    "end_date": end_date.isoformat(),
                    "booking_name": str(row[3]) if len(row) > 3 and row[3] is not None else "",
                    "booking_status": str(row[4]) if len(row) > 4 and row[4] is not None else "",
                    "reason": format_reason(row[-2] if len(row) > 1 else ""),
                }
            )

    return BlacklistStats(
        total_count=len(rows),
        upcoming_records=upcoming_records,
    )


def unified_format_table_rows(headers, keys, records: list[dict[str, str]], display_limit: int) -> str:
    limited = records[:display_limit]

    col_widths = [len(h) for h in headers]
    for record in limited:
        for i, key in enumerate(keys):
            col_widths[i] = max(col_widths[i], len(str(record.get(key, ""))))

    def format_row(values: list[str]) -> str:
        return "| " + " | ".join(v.ljust(w) for v, w in zip(values, col_widths)) + " |"

    separator = "+-" + "-+-".join("-" * w for w in col_widths) + "-+"
    lines = [separator, format_row(headers), separator]
    for record in limited:
        lines.append(format_row([str(record.get(k, "")) for k in keys]))
    lines.append(separator)

    return "```\n" + "\n".join(lines) + "\n```"


def extract_failure_codes(records: list[dict[str, str]], display_limit: int) -> dict[str, str]:
    found: dict[str, str] = {}
    for record in records[:display_limit]:
        reason = record.get("reason", "")
        for code, description in CAMPAIGN_VALIDATION_FAILURE_CODES.items():
            if code in reason:
                found[code] = description
    return dict(sorted(found.items()))


def build_blacklist_alert_message(rows: list[tuple[Any, ...]] | None, execution_date: str, correlation_id: str = "") -> str:
    parsed_execution_date = datetime.strptime(execution_date[:10], "%Y-%m-%d").date()
    safe_rows = list(rows or [])
    stats = collect_blacklist_stats(safe_rows, parsed_execution_date)
    display_limit = SLACK_MESSAGE_TABLE_DISPLAY_LIMIT
    env = get_environment()

    if stats.total_count == 0:
        return ":white_check_mark: No blacklist records found in this validation run."

    sections: list[str] = []

    if stats.upcoming_records:
        sections.append(":warning: *Issues detected in bookings finishing within the next 30 days. Details below.*")
        shown = min(display_limit, len(stats.upcoming_records))
        total = len(stats.upcoming_records)
        headers = ["Booking ID", "Booking Name", "End Date", "Status", "Reason"]
        keys = ["booking_id", "booking_name", "end_date", "booking_status", "reason"]
        sections.append(unified_format_table_rows(headers, keys, stats.upcoming_records, display_limit))
        sections.append(f"_Showing {shown} of {total} records._")

        failure_codes = extract_failure_codes(stats.upcoming_records, display_limit)
        if failure_codes:
            sections.append("")
            sections.append("*Failure Codes:*")
            for code, description in failure_codes.items():
                sections.append(f"  {code} - {description}")
    else:
        sections.append("No blacklist records are finishing in the next 30 days.")

    sections.append(
        f"\nFull details can be found in *unified_platform_{env}.adw_unified_platform_tactical.campaign_validation_issues*"
        f"\n_Correlation ID: {correlation_id}_"
    )
    return "\n".join(sections)


def parse_end_date(raw_end_date: Any) -> date | None:
    if raw_end_date is None:
        return None
    raw = str(raw_end_date)[:10]
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        return None


def format_reason(reason: Any) -> str:
    return str(reason).replace("invalid_", "").replace("_", " ").replace("|", "/").replace("\n", " ").strip()


def build_end_alert_message(
    rows: list[tuple[Any, ...]] | None,
    days_threshold: int,
    date_key: str,
    days_key: str,
    empty_label: str,
    header: str,
) -> str:
    records = []
    unique_campaigns = set()

    for row in rows or []:
        if not row or len(row) < 6:
            continue

        booking_id = str(row[0] or "")
        booking_name = str(row[1] or "")

        # Count unique campaigns by booking_id only (primary key)
        if booking_id:
            unique_campaigns.add(booking_id)

        records.append({
            "booking_id": booking_id,
            "booking_name": booking_name,
            date_key: str(row[2] or "")[:10],
            "marketing_type": str(row[3] or ""),
            "channel_name": str(row[4] or ""),
            days_key: int(row[5]) if row[5] is not None else 0,
        })

    if not records:
        return f":white_check_mark: No {empty_label} campaigns ending in the next {days_threshold} days."

    headers = ["Booking ID", "Booking Name", "Marketing Type", "Channel", "Evaluation Due In"]
    keys = ["booking_id", "booking_name", "marketing_type", "channel_name", days_key]
    sections = [
        f"📊 *Booking Evaluation - {header}*",
        "",
        unified_format_table_rows(headers, keys, records, SLACK_MESSAGE_TABLE_DISPLAY_LIMIT),
        "",
        f"_{len(unique_campaigns)} unique campaigns active in {days_threshold} days_",
    ]

    return "\n".join(sections)


def validation_blacklist_report_alerts(group_id: str, source_task_id: str) -> TaskGroup:
    with TaskGroup(group_id=group_id) as alert_tg:
        env = get_environment()

        @task(task_id="prepare_blacklist_alert_message")
        def prepare_blacklist_alert_message(rows=None, correlation_id=None) -> str:
            context = get_current_context()
            execution_date = str(context["ds"])
            return build_blacklist_alert_message(rows=rows, execution_date=execution_date, correlation_id=correlation_id or "")

        prepared_message = prepare_blacklist_alert_message(
            rows=get_validation_check_details(source_task_id),
            correlation_id=get_ci(),
        )

        SlackAPIPostOperator(
            task_id="send_blacklist_table_alert",
            channel=f'#measurement-data-{env}',
            text=prepared_message,
        )

    return alert_tg
