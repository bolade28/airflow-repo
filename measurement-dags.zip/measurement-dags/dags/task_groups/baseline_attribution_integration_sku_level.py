from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from steps.baseline_attribution_integration_sku_level import baseline_attribution_integration_sku_level, unified_baseline_attribution_integration
from helpers.constants import PRODUCT_TYPE, INCLUDE_AISLE_SKUS


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        return "mta_baseline_attribution_integration_sku_level.baseline_attribution_integration_sku_level_aisle"
    else:
        return "mta_baseline_attribution_integration_sku_level.skip"


def task_group() -> TaskGroup:

    with TaskGroup('mta_baseline_attribution_integration_sku_level', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        baseline_attribution_integration_sku_level_offer = (
            baseline_attribution_integration_sku_level
            .tasks(
                'BaselineAttributionIntegrationSKULevelOffer',
                "sku_level_attributed_sales_and_units_offer",
                PRODUCT_TYPE["offer"],
                "baseline_attribution_integration_sku_level_offer",
                "mta_baseline_integration_missing_data_offer",
                "mta_baseline_integration_zero_or_incrementality_offer"
            )
        )
        baseline_attribution_integration_sku_level_brand = (
            baseline_attribution_integration_sku_level
            .tasks(
                'BaselineAttributionIntegrationSKULevelBrand',
                "sku_level_attributed_sales_and_units_brand",
                PRODUCT_TYPE["brand"],
                "baseline_attribution_integration_sku_level_brand",
                "mta_baseline_integration_missing_data_brand",
                "mta_baseline_integration_zero_or_incrementality_brand"
            )
        )
        baseline_attribution_integration_sku_level_aisle = (
            baseline_attribution_integration_sku_level
            .tasks(
                'BaselineAttributionIntegrationSKULevelAisle',
                'sku_level_attributed_sales_and_units_aisle',
                PRODUCT_TYPE["aisle"],
                "baseline_attribution_integration_sku_level_aisle",
                "mta_baseline_integration_missing_data_aisle",
                "mta_baseline_integration_zero_or_incrementality_aisle"
            )
        )

        unified_baseline_attribution = unified_baseline_attribution_integration.tasks()

        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        #  explicitly defined sequential dependencies
        start >> baseline_attribution_integration_sku_level_offer >> baseline_attribution_integration_sku_level_brand >> aisle_decision >> baseline_attribution_integration_sku_level_aisle >> finish
        aisle_decision >> skip >> finish >> unified_baseline_attribution

    return tg
