from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('persist_customer_data_to_snowflake', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="persist_customer_data_collection",
            sql="load_to_snowflake/customer_data_collection.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task loads customer data collection dataset to Snowflake
                """,
        )

    return tg
