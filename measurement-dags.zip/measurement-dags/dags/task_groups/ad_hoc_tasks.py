from airflow.sdk import TaskGroup

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('snowflake_unload', ui_color="ff7f00") as tg:

        # MeasurementSnowflakeOperator(
        #     task_id="unload_clustering_temp_data",
        #     sql="temp_unload/unload_clustering_data.sql",
        #     hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
        #     doc_md="""
        #                This task unloads clustering data to S3 to unblock team to work on downstream tasks.
        #                """,
        # )

        MeasurementSnowflakeOperator(
            task_id="unload_unified_campaign_temp_data",
            sql="temp_unload/unload_unified_campaign_data.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                       This task unloads unified campaign data to S3 to unblock team to work on downstream tasks.
                       """,
        )

    return tg
