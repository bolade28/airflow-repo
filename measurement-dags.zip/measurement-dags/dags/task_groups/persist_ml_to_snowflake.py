from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('persist_ml_to_snowflake', ui_color="ff7f00") as tg:

        a = MeasurementSnowflakeOperator(
            task_id="persist_sku_cluster_mapping",
            sql="load_to_snowflake/persist_sku_cluster_mapping.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               This task persists SKU cluster mapping data, freshly calculated, into Snowflake
                """,
        )
        b = MeasurementSnowflakeOperator(
            task_id="persist_refactoring_to_sku_cluster",
            sql="load_to_snowflake/refactoring_to_sku_cluster.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               This task persists refactoring data into Snowflake
                """,
        )
        c = MeasurementSnowflakeOperator(
            task_id="persist_forecasting_to_baseline_modelling",
            sql="load_to_snowflake/forecasting_to_baseline_modelling.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               This task persists baseline forecasting data into Snowflake
                """,
        )
        d = MeasurementSnowflakeOperator(
            task_id="persist_ucm_to_baseline_modelling",
            sql="load_to_snowflake/ucm_unload_to_baseline_modelling_output.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
               This task persists the latest ucm results into Snowflake
            """,
        )

        a >> [b, c] >> d

    return tg
