from airflow.sdk import TaskGroup, task
from helpers.aws import FileExistsOperator
from helpers.setup import get_environment
from helpers.xcom import get_pipelines_version
from helpers.constants import FileExists


def task_group() -> TaskGroup:
    """
    Combined validation task group that checks:
    1. whether Pipelines commit hash value provided as DAG config exists in the
    S3 bucket where pipelines deployment artefacts are stored
    2. Breaks the pipeline if the provided pipelines commit hash value doesn't exist
    This is to ennsure we don't unload snowflake data and spin up EMR for our pipeline run and waste resources.

    """

    with TaskGroup('validate_setup') as check_setup:

        env = get_environment()

        are_files_deployed = FileExistsOperator(
            task_id='check_pipelines_hash_exists',
            bucket=f"measurement-{env}-artefacts",
            prefix=f"pipelines/{get_pipelines_version()}"
        )

        validate = validate_artifact_exists(
            file_exists_result=are_files_deployed.output,
            pipelines_version=get_pipelines_version(),
            env=env
        )

        are_files_deployed >> validate

    return check_setup


@task
def validate_artifact_exists(file_exists_result: str, pipelines_version: str, env: str):
    """
    Fail the pipeline if the required artifact doesn't exist.
    """
    if file_exists_result == FileExists.NO.value:
        raise ValueError(
            f"Pipelines deployment not found for configured pipelines hash value: {pipelines_version}\n"
            f"Please ensure that you have deployed pipelines scripts using dev_deploy.sh shell script with the correct pipelines hash value before running this pipeline."
        )
    print(f"Pipelines deployment exists for version: {pipelines_version}")
