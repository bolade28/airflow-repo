from airflow.sdk import TaskGroup

from helpers.constants import (
    DEFAULT_MODEL_START_DATE,
    EvaluationPhase
)
from helpers import setup


def task_group(type: str = EvaluationPhase.DURING) -> TaskGroup:

    start = setup.job_flow_start_time()

    with TaskGroup('setup_tasks') as tg:

        ci = setup.configure_correlation_id()

        setup.configure_compute_units()
        setup.configure_pipelines_version()
        setup.configure_paths(ci, '{{data_interval_end | ds }}')
        setup.configure_snowflake_tables(ci)
        setup.configure_campaign_start_date()
        setup.configure_sns()
        setup.configure_campaigns()
        setup.configure_mlflow()
        setup.configure_dag_version()
        setup.configure_aws_user()
        setup.configure_master_instance_type()
        setup.configure_model_start_end_dates(
            '{{data_interval_end | ds }}',
            DEFAULT_MODEL_START_DATE
        )
        setup.configure_run_type()
        if type == EvaluationPhase.DURING:
            setup.configure_campaign_end_date()
        else:
            setup.configure_post_period_end_date()
            setup.configure_ci_of_during_run()

    return start >> tg
