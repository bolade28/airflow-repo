from airflow.providers.standard.operators.python import ShortCircuitOperator, BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from airflow.sdk import TaskGroup

from helpers.utils import is_dtp, is_pollen, decide_pollen_dtp
from helpers.xcom import pipeline_run_type

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from steps.timeseries_data import (
    meta_processed_data,
    meta_processed_data_pollen,
    promotional_discount_processed_data,
    value_index_processed_data,
    coupon_at_till_processed_data,
    coupon_at_till_processed_data_pollen,
    dv360_processed_data,
    dv360_processed_data_pollen,
    citrus_processed_data,
    channel_processed_data,
    sales_processed_data,
    base_price_data,
    youtube_processed_data,
    youtube_processed_data_pollen,
    instore_processed_data,
    instore_processed_data_pollen,
    ecoupon_processed_data,
    ecoupon_processed_data_pollen,
    secondary_space_data,
)


def task_group() -> TaskGroup:
    with TaskGroup("timeseries_data", ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        buffer = EmptyOperator(task_id="buffer", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        # Branch checks
        is_this_dtp = ShortCircuitOperator(
            task_id="is_dtp",
            python_callable=is_dtp,
            op_kwargs=dict(run_type=pipeline_run_type()),
            trigger_rule="none_failed_min_one_success",
            ignore_downstream_trigger_rules=False,
        )

        is_this_pollen = ShortCircuitOperator(
            task_id="is_pollen",
            python_callable=is_pollen,
            op_kwargs=dict(run_type=pipeline_run_type()),
            trigger_rule="none_failed_min_one_success",
            ignore_downstream_trigger_rules=False,
        )

        branch_gate = EmptyOperator(task_id="branch_gate")

        # Shared tasks executed after both dtp and pollen branches
        promotional_discount = promotional_discount_processed_data.tasks(executors=48)
        base_price = base_price_data.tasks(executors=48)
        # ToDo: setup override for S3 buckets so we don't need the pollen branch logic here
        all_channels_dtp = channel_processed_data.tasks(step_name='ChannelProcessedDataDTP', executors=8, pipeline_run_type=DTP_RUN_TYPE)
        all_channels_pollen = channel_processed_data.tasks(step_name='ChannelProcessedDataPollen', executors=8, pipeline_run_type=POLLEN_RUN_TYPE)

        # Choose which channel processed data to run based on pipeline run type
        select_channel_processed_data = BranchPythonOperator(
            task_id="run_dtp_or_pollen_channel_processed_data",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                'ChannelProcessedDataDTP',
                'ChannelProcessedDataPollen',
                'timeseries_data'
            ],
        )

        # DTP baseline tasks (this must always run first)
        with TaskGroup("timeseries_data_dtp") as tg_dtp:
            meta_dtp = meta_processed_data.tasks(executors=8)
            value_index_dtp = value_index_processed_data.tasks(executors=8)
            coupon_at_till_dtp = coupon_at_till_processed_data.tasks(executors=8)
            dv360_dtp = dv360_processed_data.tasks(executors=8)
            citrus_dtp = citrus_processed_data.tasks(executors=8)
            sales_dtp = sales_processed_data.tasks(executors=8)
            youtube_dtp = youtube_processed_data.tasks(executors=8)
            instore_dtp = instore_processed_data.tasks(executors=8)
            ecoupon_dtp = ecoupon_processed_data.tasks(executors=8)
            secondary_space_dtp = secondary_space_data.tasks(executors=8)

            # All parallel
            [meta_dtp, value_index_dtp, coupon_at_till_dtp, dv360_dtp, citrus_dtp, sales_dtp, youtube_dtp, instore_dtp, ecoupon_dtp, secondary_space_dtp]

        # Pollen branch
        with TaskGroup("timeseries_data_pollen") as tg_pollen:
            meta_pollen = meta_processed_data_pollen.tasks(executors=8)
            dv360_pollen = dv360_processed_data_pollen.tasks(executors=8)
            youtube_pollen = youtube_processed_data_pollen.tasks(executors=8)
            instore_pollen = instore_processed_data_pollen.tasks(executors=8)
            coupon_at_till_pollen = coupon_at_till_processed_data_pollen.tasks(executors=8)
            ecoupon_pollen = ecoupon_processed_data_pollen.tasks(executors=8)
            # All parallel
            [meta_pollen, dv360_pollen, youtube_pollen, instore_pollen, coupon_at_till_pollen, ecoupon_pollen]

        # Branching logic
        start >> tg_dtp >> branch_gate
        branch_gate >> [is_this_dtp, is_this_pollen]

        is_this_dtp >> skip
        is_this_pollen >> tg_pollen >> buffer

        skip >> buffer
        buffer >> promotional_discount >> base_price >> select_channel_processed_data

        select_channel_processed_data >> all_channels_dtp >> finish
        select_channel_processed_data >> all_channels_pollen >> finish

    return tg
