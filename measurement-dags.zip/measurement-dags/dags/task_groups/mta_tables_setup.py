from airflow.providers.standard.operators.python import ShortCircuitOperator
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from helpers.constants import (
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    SALES_TRANSACTION_CODES,
    SALES_ORIGINATION_INSTORE_CODES,
    SALES_ORIGINATION_ALL_CODES,
    SALES_ORIGINATION_ONLINE_CODES,
    ECOUPON_TARGETED,
    MIN_IMPRESSION_VALUE,
    DTP_RUN_TYPE,
    POLLEN_RUN_TYPE,
    EMULATE_PROD_CAMPAIGN_IN_DEV,
    USER_JOURNEY_CHANNEL,
    USER_JOURNEY_SUBCHANNEL
)
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import get_ci, get_manual_campaigns_list, pipeline_run_type, get_manual_campaigns_list_filtered
from helpers.dag_param import DagParams
from helpers.utils import is_dtp, is_pollen

from helpers.channel_hierarchy import SUBCHANNELS_CODE, MARKETING_TYPE


def create_pipeline_conditions():
    """Create the pipeline condition operators for DTP and Pollen"""
    is_this_dtp = ShortCircuitOperator(
        task_id='is_dtp',
        python_callable=is_dtp,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
        ignore_downstream_trigger_rules=False,
    )

    is_this_pollen = ShortCircuitOperator(
        task_id='is_pollen',
        python_callable=is_pollen,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
        ignore_downstream_trigger_rules=False,
    )

    return is_this_dtp, is_this_pollen


def create_pipeline_type_conditionals():

    is_this_dtp = ShortCircuitOperator(
        task_id='is_dtp',
        python_callable=is_dtp,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule='none_failed_min_one_success',
        ignore_downstream_trigger_rules=False,
    )

    is_this_pollen = ShortCircuitOperator(
        task_id='is_pollen',
        python_callable=is_pollen,
        op_kwargs=dict(
            run_type=pipeline_run_type(),
        ),
        trigger_rule='none_failed_min_one_success',
        ignore_downstream_trigger_rules=False,
    )

    return is_this_dtp, is_this_pollen


def task_group(campaign_duration: str = 'During') -> TaskGroup:
    with TaskGroup('setup_mta_tables', ui_color="ff7f00") as tg:
        campaign_execution_status = MeasurementSnowflakeOperator(
            task_id="get_campaign_execution_status",
            sql="mta_tables_setup/campaign_execution_table_status.sql",
            params={
                'correlation_id': get_ci(),
                'campaign_id_default': DagParams.pipelines_manual_campaign_list,
                'campaign_id_manual': f'\"{get_manual_campaigns_list()}"',
                'run_type': pipeline_run_type(),
                'dtp_run': DTP_RUN_TYPE,
                'pollen_run': POLLEN_RUN_TYPE,
                "campaign_duration": campaign_duration,
                'post_campaign_list': f'\"{get_manual_campaigns_list_filtered()}"',
                "post_run_type": 'Post',
                "during_run_type": 'During',
                'emulate_prod_env': EMULATE_PROD_CAMPAIGN_IN_DEV
            },
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task upserts data into mta table measurement_campaign_execution_v2
                """,
        )

        update_campaign_execution_table = MeasurementSnowflakeOperator(
            task_id="update_campaign_execution_table",
            sql="mta_tables_setup/update_campaign_execution_table.sql",
            params={
                    'correlation_id': get_ci()
            },
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task upserts data into mta table measurement_campaign_execution_v2
                """,
        )

        is_this_dtp, is_this_pollen = create_pipeline_conditions()

        campaign_decay_rate = MeasurementSnowflakeOperator(
            task_id="unload_campaign_decay_rate",
            sql="mta_tables_setup/campaign_decay_rate.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci()
            },
            doc_md="""
                This task unloads campaign decay rate data into s3.
                """,
        )

        campaign_decay_rate_pollen = MeasurementSnowflakeOperator(
            task_id="unload_campaign_decay_rate_pollen",
            sql="mta_tables_setup/campaign_decay_rate_pollen.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                'correlation_id': get_ci(),
                'marketing_type': MARKETING_TYPE["offsite"],
                'min_impression_value': MIN_IMPRESSION_VALUE,
                'meta_subchannel_list': SUBCHANNELS_CODE['meta'],
                'dv360_subchannel_list': SUBCHANNELS_CODE['dv360'],
                'youtube_subchannel_list': SUBCHANNELS_CODE['youtube']
            },
            doc_md="""
                This task unloads campaign decay rate data for pollen into s3.
                """,
        )

        customer_campaign_engagement = campaign_engagement()
        # post_camp_period = post_campaign_period()

        # post_camp_period
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        # Dependencies
        campaign_execution_status >> update_campaign_execution_table >> [customer_campaign_engagement, is_this_dtp, is_this_pollen]

        is_this_dtp >> campaign_decay_rate >> finish
        is_this_pollen >> campaign_decay_rate_pollen >> finish

    return tg


def campaign_engagement() -> TaskGroup:
    with TaskGroup('unload_customer_campaign_engagement', ui_color="ff7f00") as tg:

        b1 = EmptyOperator(task_id='start')
        b2 = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
        is_this_dtp, is_this_pollen = create_pipeline_type_conditionals()

        # DTP customer engagement tasks grouped
        with TaskGroup('dtp_engagement') as dtp_engagement:
            ecoupon = MeasurementSnowflakeOperator(
                task_id="ecoupon_data",
                sql="mta_tables_setup/customer_campaign_engagement/ecoupon_data.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES,
                    'sales_origination_online_codes': SALES_ORIGINATION_ONLINE_CODES,
                    'ecoupon_targeted': ECOUPON_TARGETED
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            coupon_at_till = MeasurementSnowflakeOperator(
                task_id="coupon_at_till_data",
                sql="mta_tables_setup/customer_campaign_engagement/coupon_at_till.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                    'sales_origination_instore_codes': [14, 16],
                    'job_status': 'Completed'
                },
            )
            magazine = MeasurementSnowflakeOperator(
                task_id="magazine_data",
                sql="mta_tables_setup/customer_campaign_engagement/magazine_data.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                    'sales_origination_instore_codes': [14, 16, 17, 19, 20, 21, 29],
                    'channel_type': 'Sainburys Magazine',
                    'job_status': 'Not Started'
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            meta = MeasurementSnowflakeOperator(
                task_id="meta_data",
                sql="mta_tables_setup/customer_campaign_engagement/meta_data.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            dv360 = MeasurementSnowflakeOperator(
                task_id="dv360_data",
                sql="mta_tables_setup/customer_campaign_engagement/dv360_data.sql",
                params={
                        'transaction_codes': SALES_TRANSACTION_CODES,
                        'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                        'sales_origination_instore_codes': [14, 16],
                        'correlation_id': get_ci()
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            instore = MeasurementSnowflakeOperator(
                task_id="instore_data",
                sql="mta_tables_setup/customer_campaign_engagement/instore_data.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES,
                    'sales_origination_online_codes': SALES_ORIGINATION_ONLINE_CODES
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            citrus = MeasurementSnowflakeOperator(
                task_id="citrus_data",
                sql="mta_tables_setup/customer_campaign_engagement/citrus_data.sql",
                params={
                        'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                        'sales_origination_instore_codes': [14, 16],
                        'correlation_id': get_ci()
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            youtube = MeasurementSnowflakeOperator(
                task_id="youtube_data",
                sql="mta_tables_setup/customer_campaign_engagement/youtube_data.sql",
                params={
                        'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                        'sales_origination_instore_codes': [14, 16],
                        'correlation_id': get_ci()
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )

            [ecoupon, coupon_at_till, magazine, meta, dv360, instore, citrus, youtube]

        # Pollen customer engagement tasks grouped
        with TaskGroup('pollen_engagement') as pollen_engagement:
            ecoupon_pollen = MeasurementSnowflakeOperator(
                task_id="ecoupon_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/ecoupon_data_pollen.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES,
                    'sales_origination_online_codes': SALES_ORIGINATION_ONLINE_CODES,
                    'ecoupon_targeted': ECOUPON_TARGETED,
                    'ecoupon_hierarchy_codes': SUBCHANNELS_CODE['ecoupons']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            coupon_at_till_pollen = MeasurementSnowflakeOperator(
                task_id="coupon_at_till_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/coupon_at_till_pollen.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                    'sales_origination_instore_codes': [14, 16],
                    'job_status': 'Completed',
                    'coupon_at_till_subchannel_code': SUBCHANNELS_CODE['coupon_at_till']
                },
            )
            citrus_pollen = MeasurementSnowflakeOperator(
                task_id="citrus_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/citrus_data_pollen.sql",
                params={
                        'transaction_codes': SALES_TRANSACTION_CODES,
                        'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                        'sales_origination_instore_codes': [14, 16],
                        'correlation_id': get_ci(),
                        'ecoupon_hierarchy_codes': SUBCHANNELS_CODE['ecoupons']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            meta_pollen = MeasurementSnowflakeOperator(
                task_id="meta_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/meta_data_pollen.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES,
                    "meta_subchannel_list": SUBCHANNELS_CODE['meta']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            dv360_pollen = MeasurementSnowflakeOperator(
                task_id="dv360_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/dv360_data_pollen.sql",
                params={
                        'transaction_codes': SALES_TRANSACTION_CODES,
                        'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                        'sales_origination_instore_codes': [14, 16],
                        'correlation_id': get_ci(),
                        'dv360_subchannel_list': SUBCHANNELS_CODE['dv360']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            youtube_pollen = MeasurementSnowflakeOperator(
                task_id="youtube_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/youtube_data_pollen.sql",
                params={
                    'transaction_codes': SALES_TRANSACTION_CODES,
                    'sales_origination_all_codes': [14, 16, 17, 19, 20, 21, 29],
                    'sales_origination_instore_codes': [14, 16],
                    'correlation_id': get_ci(),
                    'youtube_subchannel_list': SUBCHANNELS_CODE['youtube']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            )
            instore_pollen = MeasurementSnowflakeOperator(
                task_id="instore_data_pollen",
                sql="mta_tables_setup/customer_campaign_engagement/instore_data_pollen.sql",
                params={
                    'correlation_id': get_ci(),
                    'sales_origination_all_codes': SALES_ORIGINATION_ALL_CODES,
                    'sales_origination_instore_codes': SALES_ORIGINATION_INSTORE_CODES,
                    'sales_origination_online_codes': SALES_ORIGINATION_ONLINE_CODES,
                    'channel_name_instore': USER_JOURNEY_CHANNEL['In-store'],
                    'channel_name_online': USER_JOURNEY_CHANNEL['Online'],
                    'subchannel_name': USER_JOURNEY_SUBCHANNEL,
                    'instore_hierarchy_codes': SUBCHANNELS_CODE['instore']
                },
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                doc_md="""
                    This task dumps instore customer pollen data into s3.
                    """,
            )
            [ecoupon_pollen, coupon_at_till_pollen, meta_pollen, dv360_pollen, youtube_pollen, instore_pollen, citrus_pollen]

        # TODO: we need to optimise citrus data task - currently it's taking too long
        # once optimisation is done, we can remove the EmptyOperator

        # Modified workflow with conditional execution
        b1 >> [is_this_dtp, is_this_pollen]
        is_this_dtp >> dtp_engagement >> b2
        is_this_pollen >> pollen_engagement >> b2

    return tg
