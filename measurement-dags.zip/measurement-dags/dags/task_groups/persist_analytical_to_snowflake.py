from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('persist_analytical_to_snowflake', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="persist_baseline_modelling_dataset",
            sql="load_to_snowflake/persist_baseline_modelling_dataset.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task updates the baseline modelling dataset
                """
        )
        MeasurementSnowflakeOperator(
            task_id="persist_new_launch_to_baseline_modelling",
            sql="load_to_snowflake/new_launch_to_baseline_modelling.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task updates the baseline modelling output
                """,
        )
        MeasurementSnowflakeOperator(
            task_id="persist_new_launch_to_sku_cluster",
            sql="load_to_snowflake/new_launch_to_sku_cluster.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task updates the SKU cluster mapping table for new launches in snowflake
                """,
        )

    return tg
