from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.task.trigger_rule import TriggerRule
from steps.attribution_pre_requisite import attribution_pre_requisite
from helpers.constants import JOURNEY_TYPE, INCLUDE_AISLE_SKUS


def decide_aisle_processing():
    """Decide whether to process aisle SKUs or skip."""
    if INCLUDE_AISLE_SKUS:
        return "mta_attribution_pre_requisite.attribution_pre_requisite_aisle"
    else:
        return "mta_attribution_pre_requisite.skip"


def task_group() -> TaskGroup:

    with TaskGroup('mta_attribution_pre_requisite', ui_color="ff7f00") as tg:

        start = EmptyOperator(task_id="start")
        skip = EmptyOperator(task_id="skip")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        attribution_pre_requisite_offer = attribution_pre_requisite.tasks('AttributionPreRequisiteOffer', "user_journey_offer", JOURNEY_TYPE["offer"], "attribution_pre_requisite_offer")
        attribution_pre_requisite_brand = attribution_pre_requisite.tasks('AttributionPreRequisiteBrand', "user_journey_brand", JOURNEY_TYPE["brand"], "attribution_pre_requisite_brand")
        attribution_pre_requisite_aisle = attribution_pre_requisite.tasks('AttributionPreRequisiteAisle', "user_journey_aisle", JOURNEY_TYPE["aisle"], "attribution_pre_requisite_aisle")

        aisle_decision = BranchPythonOperator(
            task_id="decide_aisle_run",
            python_callable=decide_aisle_processing,
        )

        # explicitly define sequential format

        start >> attribution_pre_requisite_offer >> attribution_pre_requisite_brand >> aisle_decision >> attribution_pre_requisite_aisle >> finish
        aisle_decision >> skip >> finish

    return tg
