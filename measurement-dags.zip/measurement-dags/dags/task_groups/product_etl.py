from airflow.sdk import TaskGroup
from steps.product import campaign_product_type
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('product_etl', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'CampaignProductType'
        pollen_task_name = 'CampaignProductTypePollen'
        task_group_name = 'product_etl'

        dtp_campaign_product_type = campaign_product_type.tasks(step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE, executors=8)
        pollen_campaign_product_type = campaign_product_type.tasks(step_name=pollen_task_name, pipeline_run_type=POLLEN_RUN_TYPE, executors=8)

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_campaign_product_type",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_campaign_product_type >> finish
        start >> decide >> pollen_campaign_product_type >> finish
    return tg
