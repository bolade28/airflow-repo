from airflow.sdk import TaskGroup

from steps.sku_cluster_mapping import sku_cluster_mapping
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.constants import DTP_RUN_TYPE, POLLEN_RUN_TYPE

from helpers.xcom import pipeline_run_type
from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup("sku_cluster_mapping", ui_color="ff7f00") as tg_logic:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'sku_cluster_mapping'
        pollen_task_name = 'sku_cluster_mapping_pollen'
        task_group_name = 'sku_cluster_mapping'

        dtp_sku_cluster_mapping = sku_cluster_mapping.tasks(step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE, executors=8)
        pollen_sku_cluster_mapping = sku_cluster_mapping.tasks(step_name=pollen_task_name, pipeline_run_type=POLLEN_RUN_TYPE, executors=8)

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_sku_cluster_mapping",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_sku_cluster_mapping >> finish
        start >> decide >> pollen_sku_cluster_mapping >> finish

    return tg_logic
