from airflow.sdk import TaskGroup
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE
from helpers.snowflake import MeasurementSnowflakeOperator


def task_group() -> TaskGroup:

    with TaskGroup('load_campaign_prod_type_to_snowflake', ui_color="ff7f00") as tg:
        MeasurementSnowflakeOperator(
            task_id="load_campaign_product_type",
            sql="load_to_snowflake/load_campaign_product_type.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task loads campaign product type data to Snowflake table.
                """,
        )

    return tg
