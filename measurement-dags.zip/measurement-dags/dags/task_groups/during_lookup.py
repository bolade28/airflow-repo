from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import PythonOperator

from helpers.xcom import (
    get_during_correlation_id,
    get_table,
    get_configured_campaign,
    pipeline_run_type,
)
from helpers.snowflake import resolve_during_correlation_id


def task_group() -> TaskGroup:
    """
    Taskgroup to fetch needed info from a relevant during run and push it to xcom for later use in the post pipeline.

    """
    # TODO: we will need to tweak this if we dicide to do post run with multiple campaign IDs.

    with TaskGroup('during_lookup') as tg:

        PythonOperator(
            task_id='during_correlation_id',
            python_callable=resolve_during_correlation_id,
            op_kwargs={
                'configured_during_cid': get_during_correlation_id(),
                'configured_campaign_id': get_configured_campaign(),
                'table': get_table('measurement_campaign_reporting_aws'),
                'run_type': pipeline_run_type(),
            }
        )

    return tg
