from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import BranchPythonOperator
from airflow.task.trigger_rule import TriggerRule
from helpers.xcom import pipeline_run_type
from steps.reach_engagement import reach_engagement
from steps.reach_engagement import reach_engagement_pollen
# from steps.reach_engagement import reach_engagement_reporting

from helpers.constants import DTP_RUN_TYPE

from helpers.utils import decide_pollen_dtp


def task_group() -> TaskGroup:

    with TaskGroup('mta_reach_engagement', ui_color="ff7f00") as tg:
        start = EmptyOperator(task_id="start")
        finish = EmptyOperator(task_id="finish", trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)

        dtp_task_name = 'ReachEngagement'
        pollen_task_name = 'ReachEngagementPollen'
        task_group_name = 'mta_reach_engagement'

        dtp_reach_engagement = reach_engagement.tasks(step_name=dtp_task_name, pipeline_run_type=DTP_RUN_TYPE)
        pollen_reach_engagement = reach_engagement_pollen.tasks()
        # report_reach_engagement_reporting = reach_engagement_reporting.tasks()

        decide = BranchPythonOperator(
            task_id="run_dtp_or_pollen_reach_engagement",
            python_callable=decide_pollen_dtp,
            op_args=[
                pipeline_run_type(),
                dtp_task_name,
                pollen_task_name,
                task_group_name
            ],
        )

        start >> decide >> dtp_reach_engagement >> finish
        start >> decide >> pollen_reach_engagement >> finish
    return tg
