import pendulum

from airflow.sdk import Variable
from airflow.providers.standard.operators.python import PythonOperator
from airflow.sdk import TaskGroup
from airflow.providers.slack.operators.slack import SlackAPIPostOperator

from helpers.xcom import get_ci, get_during_correlation_id, get_configured_campaign, get_pipelines_version

tz = pendulum.timezone('Europe/London')


def task_group() -> TaskGroup:

    with TaskGroup("campaign_skip_alert") as alert_tg:
        """
        This task group sends alerts to notify measurement team that pipeline was skipped due to no valid campaigns
        """

        send_alert = SlackAPIPostOperator(
            task_id="slack_alert_campaign_skip",
            channel=f'#measurement-ops-{Variable.get("MEASUREMENT_ENVIRONMENT")}',
            text=get_post_campaign_alert_message(ci=get_ci()),
        )

        skip_downstream = PythonOperator(
            task_id="skip_pipeline",
            python_callable=_mark_validation_failed,
        )

        send_alert >> skip_downstream

    return alert_tg


def get_post_campaign_alert_message(ci: str) -> str:
    """Returns text for post-campaign runs alert"""
    return f""":red_circle: pipeline skipped
No campaigns found with 'During' status in measurement_campaign_reporting_aws table.
Correlation id: {get_ci()}
Job bag number(s): {get_configured_campaign()}
Pipeline hash: {get_pipelines_version()}
Correlation id for the during run: {get_during_correlation_id()}
The baseline MTA pipeline has been stopped because no valid campaigns were found to process post campaigns.
Please check that you provided correct job bag number/booking id and that the correlation id for the during run is correct.
"""


def _mark_validation_failed(**context):
    """Mark that validation failed"""
    context['task_instance'].xcom_push(key='validation_failed', value=True)
