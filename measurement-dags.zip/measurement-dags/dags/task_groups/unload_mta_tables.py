from airflow.sdk import TaskGroup
from helpers.constants import (
    SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE,
    CAMPAIGN_DURATION_POST,
)
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.xcom import (
    get_resolved_during_correlation_id,
)


def task_group(campaign_duration: str) -> TaskGroup:
    with TaskGroup('unload_mta_tables', ui_color="ff7f00") as tg:

        MeasurementSnowflakeOperator(
            task_id="unload_campaign_execution",
            sql="mta_tables_unload/campaign_execution.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "campaign_duration": campaign_duration
            },
            doc_md="""This task unloads the campaign execution data to S3.""",
        )

        MeasurementSnowflakeOperator(
            task_id="unload_advertising_campaign_citcam_sat",
            sql="mta_tables_unload/advertising_campaign_citcam_sat.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_link",
            sql="mta_tables_unload/digital_trading_campaign_link.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_insight_link",
            sql="mta_tables_unload/digital_trading_campaign_insight_link.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                    This task contains de-duplicated reach data from Meta
                    """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_campaign_sat",
            sql="mta_tables_unload/digital_trading_campaign_sat.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_digital_trading_lineitem_fb_insight",
            sql="mta_tables_unload/digital_trading_lineitem_fb_insight.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unloads fb_insight data to s3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_floodlight_report",
            sql="mta_tables_unload/floodlight_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task unload floodlight report to s3.
                """,
        )

        MeasurementSnowflakeOperator(
            task_id="unload_unique_reach_lineitem_report_sat",
            sql="mta_tables_unload/unique_reach_lineitem_report.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            doc_md="""
                This task creates initial dv360 customer data table.
                """,
        )

        if campaign_duration == CAMPAIGN_DURATION_POST:
            MeasurementSnowflakeOperator(
                task_id="unload_measurement_campaign_reporting",
                sql="measurement_campaign_reporting/unload_reporting.sql",
                hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
                params={
                    "during_correlation_id": get_resolved_during_correlation_id(),
                },
                doc_md="""
                    This task reads reporting table for campaigns in the post period.
                    """,
            )

    return tg
