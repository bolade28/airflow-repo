import pendulum
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import PythonOperator

from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE, EvaluationPhase, DAGSMetrics
from helpers.setup import Dict, get_environment, get_airflow_platform, get_build_hash
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.metrics import PipelineMetadata
from helpers.utils import MetricsPublisher, get_current_iso_timestamp
from helpers.sns import SNS
from helpers.xcom import (
    get_ci,
    get_git_hash,
    get_job_flow_start_time,
    get_all_paths_for_meta_data,
    pipeline_run_type,
    get_manual_campaigns_list,
    get_git_commits,
    get_campaign_dates,
    get_configured_campaign,
    get_during_correlation_id,
    get_campaign_end_date,
    get_post_period_end_date,
    get_resolved_during_correlation_id,
    get_current_aws_user
)


tz = pendulum.timezone('Europe/London')

topic_arns = SNS()


def commit_metadata(pipeline_stage: str, evaluation_phase: EvaluationPhase = EvaluationPhase.DURING) -> TaskGroup:
    """
    Creates a TaskGroup that commits pipeline metadata to Snowflake and publishes it to metrics service.

    This function collects git commit information, pipeline run details and other relevant metadata,
    then stores them in the Snowflake metadata table and publishes them to the metrics as well.

    Args:
        pipeline_stage (str): The stage of the pipeline execution. Expected values:
            - 'start': Marks the beginning of pipeline execution
            - 'completed': Marks the end of pipeline execution
        evaluation_phase (EvaluationPhase, optional): The evaluation phase of the campaign.
            Defaults to EvaluationPhase.DURING. Can be:
            - EvaluationPhase.DURING: During campaign period
            - EvaluationPhase.POST: Post-campaign period

    Returns:
        TaskGroup: An Airflow TaskGroup containing three tasks:
            1. get_git_commits: Retrieves git commit hashes for dags and pipelines
            2. commit_metadata: Writes metadata to Snowflake
            3. publish_to_metrics: Publishes metadata to SNS metrics topic

    Note:
        - For POST phase, additional metadata includes during correlation IDs
        - The task group name is dynamically generated as 'commit_metadata_{pipeline_stage}'
        - All tasks are executed sequentially in the order: git_commits >> snowflake >> metrics
    """
    task_group_name = f'commit_metadata_{pipeline_stage}'

    with TaskGroup(task_group_name, ui_color="ff7f00") as tg:
        git_commits = get_git_commits(environment=get_environment())
        commont_params = {
            'run_date': '{{data_interval_end | ds }}',
            'correlation_id': get_ci(),
            'configured_end_date': get_campaign_end_date() if evaluation_phase == EvaluationPhase.DURING else get_post_period_end_date(),
            'run_by': get_current_aws_user(),
            'dags_base_commit': get_git_hash(pipeline_stage=pipeline_stage, type='dags_base'),
            'pipelines_base_commit': get_git_hash(pipeline_stage=pipeline_stage, type='pipelines_base'),
            'pipelines_git_commits': get_git_hash(pipeline_stage=pipeline_stage, type='pipelines'),
            'dags_git_commits': get_git_hash(pipeline_stage=pipeline_stage, type='dags'),
            'airflow_platform': get_airflow_platform(),
            'start_time': get_job_flow_start_time(),
            'pipeline_status': 'started' if pipeline_stage == 'start' else 'completed',
            'deployment_status': 'approved',
            'end_time': get_current_iso_timestamp() if pipeline_stage == 'completed' else None,
            'run_type': pipeline_run_type(),
            'paths': get_all_paths_for_meta_data(),
            'booking_id': get_configured_campaign(),
            'validated_booking_ids': get_manual_campaigns_list("meta_data"),
            'campaign_date': get_campaign_dates(),
            'evaluation_period': evaluation_phase.value,
            'during_cid': get_during_correlation_id() if evaluation_phase == EvaluationPhase.POST else None,
            'additional_info': additional_metadata(evaluation_phase)
        }
        snowflake_commit = MeasurementSnowflakeOperator(
            task_id='commit_metadata',
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            sql='metadata/commit_metadata.sql',
            params=commont_params
        )

        publish_to_metrics = PythonOperator(
            task_id='publish_to_metrics',
            python_callable=metrics_metadata_commit,
            op_kwargs=commont_params
        )

        git_commits >> snowflake_commit >> publish_to_metrics
    return tg


def additional_metadata(evaluation_phase: EvaluationPhase) -> Dict[str, str]:

    build_hash = get_build_hash()

    if evaluation_phase == EvaluationPhase.DURING.value:
        return f"""
        {{
            "build_hash": "{build_hash}"
        }}
        """

    configured_cid = get_during_correlation_id()
    resolved_cid = get_resolved_during_correlation_id()

    if evaluation_phase == EvaluationPhase.POST.value:
        return f"""
        {{
            "configured_during_cid": "{configured_cid}",
            "resolved_during_cid": "{resolved_cid}",
            "build_hash": "{build_hash}"
        }}
        """


def metrics_metadata_commit(
    correlation_id,
    run_date,
    run_by,
    dags_base_commit,
    pipelines_base_commit,
    pipelines_git_commits,
    dags_git_commits,
    start_time,
    end_time,
    pipeline_status,
    deployment_status,
    run_type,
    booking_id,
    validated_booking_ids,
    paths,
    campaign_date,
    evaluation_period,
    during_cid,
    configured_end_date,
    airflow_platform,
    additional_info
):
    """
    Publishes pipeline metadata to the metrics service.

    Creates a PipelineMetadata event with all run details and publishes it to the
    metrics service for monitoring and tracking purposes.

    Args:
        correlation_id (str): Unique identifier for the pipeline run
        run_date (str): Date of the pipeline execution
        run_by (str): AWS user who initiated the pipeline
        dags_base_commit (str): Base git commit hash for DAGs (first 7 chars)
        pipelines_base_commit (str): Base git commit hash for pipelines (first 7 chars)
        pipelines_git_commits (str): JSON list of all pipelines git commit hashes
        dags_git_commits (str): JSON list of all DAGs git commit hashes
        start_time (str): Pipeline start timestamp
        end_time (str): Pipeline end timestamp (None if still running)
        pipeline_status (str): Status of the pipeline ('started' or 'completed')
        deployment_status (str): Deployment approval status
        run_type (str): Type of pipeline run (e.g., 'DTP', 'Pollen')
        booking_id (str): Configured campaign booking ID or job bag number
        validated_booking_ids (str): JSON list of validated booking IDs that passed validation
        paths (str): JSON object containing all S3 paths used in the pipeline
        campaign_date (str): JSON object with campaign start and end dates
        evaluation_period (str): Evaluation phase ('during' or 'post')
        during_cid (str): Correlation ID from the during-period run (for post-period runs only)
        configured_end_date (str): Campaign or post-period end date
        airflow_platform (str): Platform where Airflow is running ('docker' or 'ec2')
        additional_info (str): JSON string with additional metadata (for post-period runs)

    Returns:
        str: Success message indicating metadata was published to metrics

    """

    publisher = MetricsPublisher(topic_arn=topic_arns.metrics_topic_arn())

    metrics_commit = PipelineMetadata(
        correlation_id=correlation_id,  # Already rendered!
        name=DAGSMetrics.PIPELINES_METADATA.value,
        run_date=run_date,
        run_by=run_by,
        dags_base_commit=dags_base_commit,
        pipelines_base_commit=pipelines_base_commit,
        pipelines_git_hashes=pipelines_git_commits,
        dags_git_hashes=dags_git_commits,
        start_time=start_time,
        end_time=end_time,
        pipeline_status=pipeline_status,
        deployment_status=deployment_status,
        run_type=run_type,
        booking_id=booking_id,
        validated_booking_id=validated_booking_ids,
        paths=paths,
        campaign_date=campaign_date,
        evaluation_period=evaluation_period,
        during_correlation_id=during_cid,
        campaign_end_date=configured_end_date,
        airflow_platform=airflow_platform,
        additional_metadata=additional_info
    )

    publisher.publish_event(
        message_subject="Metadata Commit Event",
        event=metrics_commit
    )

    return "published metadata to metrics"
