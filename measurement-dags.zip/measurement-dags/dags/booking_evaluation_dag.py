from datetime import datetime
from airflow.sdk import dag, task
from airflow.sdk import TaskGroup
from airflow.providers.standard.operators.python import get_current_context
from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.task.trigger_rule import TriggerRule

from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, get_ci
from helpers.setup import get_environment
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE, BOOKING_EVALUATION_DAYS_THRESHOLD
from helpers.snowflake import MeasurementSnowflakeOperator
from task_groups import baseline_setup
from task_groups.validation_slack_alerts import build_end_alert_message


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule="00 11 * * *",  # Run daily at 11:00 AM
    start_date=datetime(2024, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    }
)
def booking_evaluation_dag():
    """
    Booking Evaluation DAG - Monitors campaign evaluation deadlines
    Runs daily at 11:00 AM to alert engineers about campaigns approaching their evaluation deadlines
    """

    # Setup tasks
    setup = baseline_setup.task_group()

    # Task group for booking evaluation alerts
    with TaskGroup('booking_evaluation_alerts', ui_color="#ff7f00") as evaluation_alerts:

        # Query ongoing campaigns (both future-ending AND past-unevaluated)
        query_ongoing = MeasurementSnowflakeOperator(
            task_id="query_ongoing_campaigns",
            sql="unified_campaign/ongoing_campaigns.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": get_ci(),
                "days_threshold": BOOKING_EVALUATION_DAYS_THRESHOLD
            },
            trigger_rule=TriggerRule.ALL_DONE,
            doc_md=f"""
                Queries for campaigns that need evaluation:
                1. Ongoing campaigns ending in next {BOOKING_EVALUATION_DAYS_THRESHOLD} days
                2. Campaigns that ended in last {BOOKING_EVALUATION_DAYS_THRESHOLD} days but NOT in metadata (unevaluated)
            """,
        )

        # Query post-period deadlines in next N days
        query_post_period = MeasurementSnowflakeOperator(
            task_id="query_post_period_deadlines",
            sql="unified_campaign/post_period_deadlines.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": get_ci(),
                "days_threshold": BOOKING_EVALUATION_DAYS_THRESHOLD
            },
            trigger_rule=TriggerRule.ALL_DONE,
            doc_md=f"""
                Queries for campaigns with post-period evaluation windows closing in next {BOOKING_EVALUATION_DAYS_THRESHOLD} days.
                Only includes campaigns that have completed 'during' evaluation.
            """,
        )

        # Prepare Slack alert messages
        @task(task_id="prepare_ongoing_alert", trigger_rule=TriggerRule.ALL_DONE)
        def prepare_ongoing_message() -> str:
            """Prepares alert message for ongoing campaigns (both future-ending and past-unevaluated)."""
            context = get_current_context()
            ti = context["task_instance"]
            rows = ti.xcom_pull(task_ids="booking_evaluation_alerts.query_ongoing_campaigns")
            return build_end_alert_message(
                rows=rows,
                days_threshold=BOOKING_EVALUATION_DAYS_THRESHOLD,
                date_key="campaign_end_dt",
                days_key="days_until_end",
                empty_label="ongoing",
                header="During",
            )

        @task(task_id="prepare_post_period_alert", trigger_rule=TriggerRule.ALL_DONE)
        def prepare_post_period_message() -> str:
            """Prepares alert message for post-period evaluation deadlines."""
            context = get_current_context()
            ti = context["task_instance"]
            rows = ti.xcom_pull(task_ids="booking_evaluation_alerts.query_post_period_deadlines")
            return build_end_alert_message(
                rows=rows,
                days_threshold=BOOKING_EVALUATION_DAYS_THRESHOLD,
                date_key="post_campaign_dt",
                days_key="days_until_post_end",
                empty_label="post-period",
                header="Post",
            )

        # Send alerts to Slack
        @task(task_id="send_ongoing_alert", trigger_rule=TriggerRule.ALL_DONE)
        def send_ongoing_alert(message: str) -> None:
            """Sends ongoing campaigns alert to #measurement-data-{env} channel."""
            env = get_environment()
            slack_alert = SlackAPIPostOperator(
                task_id="post_ongoing_to_slack",
                channel=f'#measurement-data-{env}',
                text=message,
            )
            context = get_current_context()
            slack_alert.execute(context=context)

        @task(task_id="send_post_period_alert", trigger_rule=TriggerRule.ALL_DONE)
        def send_post_period_alert(message: str) -> None:
            """Sends post-period deadlines alert to #measurement-data-{env} channel."""
            env = get_environment()
            slack_alert = SlackAPIPostOperator(
                task_id="post_post_period_to_slack",
                channel=f'#measurement-data-{env}',
                text=message,
            )
            context = get_current_context()
            slack_alert.execute(context=context)

        # Task dependencies within the group
        ongoing_msg = prepare_ongoing_message()
        post_period_msg = prepare_post_period_message()

        # Query both in parallel, then prepare and send alerts
        [query_ongoing, query_post_period]
        query_ongoing >> ongoing_msg >> send_ongoing_alert(ongoing_msg)
        query_post_period >> post_period_msg >> send_post_period_alert(post_period_msg)

    # DAG-level dependencies
    setup >> evaluation_alerts


booking_evaluation_dag()
