from datetime import datetime

from airflow.sdk import dag
from airflow.providers.standard.operators.python import BranchPythonOperator

from helpers.dag_args import DEFAULT_DAG_ARGS
from airflow.providers.standard.operators.empty import EmptyOperator
from helpers.xcom import get_stage, get_table, get_cluster_id, resolve_pipelines_version
from task_groups import (
    baseline_snowflake_unload,
    baseline_setup,
    load_campaign_product_type_to_sf,
    mta_tables_setup,
    normalisations,
    product_etl,
    campaign_selection,
    publish_baseline_metrics,
    publish_mta_metrics,
    timeseries_data,
    analytical_pipeline,
    ml_tasks,
    persist_analytical_to_snowflake,
    persist_ml_to_snowflake,
    sku_cluster_mapping,
    user_journey,
    attribution_pre_requisite,
    unload_mta_tables,
    unload_reach_engagement,
    sku_level_attributed_sales_and_units,
    attribution_model_result,
    customer_data_collection,
    persist_customer_data_collection,
    tables_cleanup,
    baseline_attribution_integration_sku_level,
    measurement_campaign_reporting,
    persist_campaign_reporting_to_snowflake,
    slack_alert,
    persist_baseline_attribution_integration,
    validations,
    during_lookup,
    config_validation
)
from helpers.emr import launch_cluster, terminate_cluster
from helpers.dag_param import DagParams
from helpers.constants import CAMPAIGN_DURATION_POST, EvaluationPhase
from tasks.metadata import publish_metadata


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    },
    params={
        "pipelines_hash": DagParams.pipelines_hash_param,
        "manual_run_campaign_list": DagParams.pipelines_manual_campaign_list,
        "pipeline_run_type": DagParams.pipeline_run_type,
        "post_period_end_date": DagParams.post_period_end_date,
        "ci_of_during_run": DagParams.ci_of_during_run,
    }
)
def baseline_mta_post_period_dag():
    """
    Measurement Baseline and MTA DAG
    Designed to measure true incremental sales at cluster level
    and multitouch attribution for campaigns.
    """

    setup = baseline_setup.task_group(type=EvaluationPhase.POST)

    start_cluster = launch_cluster('baseline-mta-post-period')
    stop_cluster = terminate_cluster(get_cluster_id())

    # Validation task groups
    campaign_validations = validations.task_group_post()
    config_validations = config_validation.task_group()

    # Branch operator to check validation results
    validation_check = BranchPythonOperator(
        task_id='check_validation_result',
        python_callable=validations.check_validation_status,
        op_kwargs={
            'parent_group_id': 'campaign_validations_post',
            'evaluation_phase': EvaluationPhase.POST.value
        },
    )

    validation_failed = EmptyOperator(task_id='validation_failed')

    # Slack alerts
    start_alerts = slack_alert.task_group_started(pipeline_stage='start', period=EvaluationPhase.POST)
    completion_alerts = slack_alert.task_group_completed(pipeline_stage='completed', period=EvaluationPhase.POST)

    # Metadata
    start_metadata = publish_metadata.commit_metadata(pipeline_stage='start', evaluation_phase=EvaluationPhase.POST)
    end_metadata = publish_metadata.commit_metadata(pipeline_stage='completed', evaluation_phase=EvaluationPhase.POST)

    # This task group is used to unload baseline data from Snowflake to S3
    data_from_snowflake = baseline_snowflake_unload.task_group()
    during_lookup_tg = during_lookup.task_group()
    load_baseline_attribution_integration_to_snowflake = persist_baseline_attribution_integration.task_group()

    # Baseline task groups
    product_tg = product_etl.task_group()
    load_campaign_product_type = load_campaign_product_type_to_sf.task_group()
    normalisations_tg = normalisations.task_group()
    campaign_selection_tg = campaign_selection.task_group()
    sku_cluster_mapping_tg = sku_cluster_mapping.task_group()
    timeseries_data_tg = timeseries_data.task_group()
    analytical_pipeline_tg = analytical_pipeline.task_group()
    analytical_to_snowflake = persist_analytical_to_snowflake.task_group()
    ml_to_snowflake = persist_ml_to_snowflake.task_group()
    baseline_metrics = publish_baseline_metrics.task_group()
    ml_tasks_tg = ml_tasks.task_group()

    # MTA task groups
    setup_mta_tables = mta_tables_setup.task_group(campaign_duration=CAMPAIGN_DURATION_POST)
    mta_tables_unload = unload_mta_tables.task_group(campaign_duration=CAMPAIGN_DURATION_POST)
    mta_user_journey_tg = user_journey.task_group()
    mta_attribution_pre_requisite_tg = attribution_pre_requisite.task_group()
    mta_reach_engagement_tg = unload_reach_engagement.task_group()
    sku_level_attributed_sales_and_units_tg = sku_level_attributed_sales_and_units.task_group()
    attribution_model_result_tg = attribution_model_result.task_group()
    mta_measurement_campaign_reporting_tg = measurement_campaign_reporting.task_group(campaign_duration=CAMPAIGN_DURATION_POST)
    customer_data_collection_tg = customer_data_collection.task_group()
    load_customer_data_collection_to_snowflake = persist_customer_data_collection.task_group()
    remove_temp_tables = tables_cleanup.task_group()
    baseline_attribution_integration_sku_level_tg = baseline_attribution_integration_sku_level.task_group()
    deploy_measurement_reporting = persist_campaign_reporting_to_snowflake.task_group()
    mta_metrics = publish_mta_metrics.task_group()

    # Baseline task dependencies - campaign validation happens after setup but before snowflake unload
    campaign_validations >> validation_check >> validation_failed
    data_from_snowflake >> start_cluster >> normalisations_tg >> product_tg >> campaign_selection_tg >> sku_cluster_mapping_tg >> timeseries_data_tg >> analytical_pipeline_tg >> ml_tasks_tg

    config_validations.set_upstream(setup)
    campaign_validations.set_upstream(config_validations)
    start_alerts.set_upstream(start_metadata)
    data_from_snowflake.set_upstream(start_alerts)
    during_lookup_tg.set_upstream(validation_check)
    start_metadata.set_upstream(during_lookup_tg)
    load_campaign_product_type.set_upstream(product_tg)
    ml_to_snowflake.set_upstream(ml_tasks_tg)
    analytical_to_snowflake.set_upstream(analytical_pipeline_tg)
    baseline_metrics.set_upstream(ml_tasks_tg)
    mta_attribution_pre_requisite_tg.set_upstream(mta_user_journey_tg)
    attribution_model_result_tg.set_upstream(mta_attribution_pre_requisite_tg)
    mta_reach_engagement_tg.set_upstream(attribution_model_result_tg)
    mta_reach_engagement_tg.set_upstream(baseline_metrics)
    sku_level_attributed_sales_and_units_tg.set_upstream(mta_reach_engagement_tg)
    ml_tasks_tg.set_upstream(analytical_pipeline_tg)

    baseline_attribution_integration_sku_level_tg.set_upstream(sku_level_attributed_sales_and_units_tg)
    baseline_attribution_integration_sku_level_tg.set_downstream(mta_measurement_campaign_reporting_tg)

    # MTA task dependencies
    mta_tables_unload.set_upstream(setup_mta_tables)
    remove_temp_tables.set_upstream(mta_tables_unload)
    setup_mta_tables.set_upstream(load_campaign_product_type)
    customer_data_collection_tg.set_upstream(mta_tables_unload)
    load_customer_data_collection_to_snowflake.set_upstream(customer_data_collection_tg)
    mta_user_journey_tg.set_upstream(customer_data_collection_tg)
    deploy_measurement_reporting.set_upstream(mta_measurement_campaign_reporting_tg)
    load_baseline_attribution_integration_to_snowflake.set_upstream(baseline_attribution_integration_sku_level_tg)
    mta_metrics.set_upstream(mta_measurement_campaign_reporting_tg)
    stop_cluster.set_upstream(mta_metrics)
    completion_alerts.set_upstream(deploy_measurement_reporting)
    completion_alerts.set_upstream(mta_metrics)
    end_metadata.set_upstream(mta_metrics)
    completion_alerts.set_upstream(end_metadata)


baseline_mta_post_period_dag()
