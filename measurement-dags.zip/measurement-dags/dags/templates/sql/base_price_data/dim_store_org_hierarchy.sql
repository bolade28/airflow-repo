COPY INTO {{ get_stage('dim_store_org_hierarchy') }}
FROM (
    SELECT
        store_cd,
        site_type
    FROM
        {{ get_table('dim_store_org_hierarchy') }}
)
include_query_id = true
header = true;
