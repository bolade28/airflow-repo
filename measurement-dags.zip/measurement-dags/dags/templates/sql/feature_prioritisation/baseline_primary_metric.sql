COPY INTO {{ get_stage('baseline_primary_metric') }}
FROM (
    SELECT
        marketing_type_name,
        marketing_channel_name,
        marketing_sub_channel_name,
        metric_name,
        primary_metric_cd,
        investment_metric_cd,
        load_ts
    FROM
        {{ get_table('baseline_primary_metric') }}
)
include_query_id = true
header = true;
