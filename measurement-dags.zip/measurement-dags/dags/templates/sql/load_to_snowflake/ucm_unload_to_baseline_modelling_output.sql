INSERT INTO {{ get_table('measurement_baseline_modelling_output') }} (
    week_start_dt,
    super_category_name,
    unique_brand_name,
    cluster_num,
    iteration,
    modelling_type,
    best_iteration,
    metric_name,
    metric_value,
    rsq,
    wsmape,
    baseline_perc,
    job_run_id,
    load_ts
)
SELECT
    $1:week_start_dt::DATE,
    $1:super_category_name::VARCHAR(900),
    $1:unique_brand_name::VARCHAR(3456),
    $1:cluster_num::VARCHAR(1000),
    $1:iteration::VARCHAR(1000),
    $1:modelling_type::VARCHAR(1000),
    $1:best_iteration::VARCHAR(1000),
    $1:metric_name::VARCHAR(1000),
    $1:metric_value::NUMBER(38,10),
    -- Handle any NaNs from New Launch by checking the string representation before casting ToDo remove NaN values from new launch logic
    NULLIF($1:rsq::VARCHAR, 'NaN')::NUMBER(38,10),
    NULLIF($1:wsmape::VARCHAR, 'NaN')::NUMBER(38,10),
    NULLIF($1:baseline_perc::VARCHAR, 'NaN')::NUMBER(38,10),
    $1:job_run_id::VARCHAR(36),
    $1:load_ts::TIMESTAMP_NTZ
FROM
    {{ get_stage('ucm_output_data') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' );
