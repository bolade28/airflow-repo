-- Delete old data for this same run, if any
DELETE FROM {{ get_table('measurement_booking_reach_engagement_aws') }}
WHERE (correlation_id, booking_id) IN (
    SELECT
        $1:job_run_id::VARCHAR(50),
        $1:booking_id::VARCHAR(1000)
    FROM {{ get_stage('reach_engagement_reporting') }}
    ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
);
-- Insert latest data, keeping only the latest load_ts for each unique combination of business keys
INSERT INTO {{ get_table('measurement_booking_reach_engagement_aws') }} (
    correlation_id,
    booking_id,
    reach_count,
    clicks_count,
    load_ts,
    run_type,
    dag_run_ts
)
SELECT
    $1:job_run_id::VARCHAR(50) AS correlation_id,
    $1:booking_id::VARCHAR(1000) AS booking_id,
    CASE 
    WHEN sum($1:reach_cnt::NUMBER(38,2)) <= avg($1:dedup_campaign_reach::NUMBER(38,2))
        THEN sum($1:reach_cnt::NUMBER(38,2))
    ELSE avg($1:dedup_campaign_reach::NUMBER(38,2))
    END AS reach_count,
    SUM($1:clicks_cnt::NUMBER(38,2)) AS clicks_count,
    MAX($1:load_ts::TIMESTAMP_LTZ(9)) AS load_ts,
    $1:run_type::TEXT AS run_type,
    $1:dag_run_ts::TIMESTAMP_LTZ AS dag_run_ts
FROM
    {{ get_stage('reach_engagement_reporting') }} (
        FILE_FORMAT => 'measurement_parquet_file_format',
        PATTERN => '^.+.parquet$'
    )
GROUP BY
    $1:job_run_id::VARCHAR(50),
    $1:booking_id::VARCHAR(1000),
    $1:run_type::TEXT,
    $1:dag_run_ts::TIMESTAMP_LTZ
;