MERGE INTO {{ get_table('measurement_baseline_modelling_dataset') }} AS target
USING (
    SELECT
        $1:week_start_dt::DATE AS week_start_dt,
        $1:super_category_name::VARCHAR(900) AS super_category_name,
        $1:unique_brand_name::VARCHAR(3456) AS unique_brand_name,
        $1:cluster_num::VARCHAR(1000) AS cluster_num,
        $1:marketing_type_name::VARCHAR(72) AS marketing_type_name,
        $1:marketing_channel_name::VARCHAR(126) AS marketing_channel_name,
        $1:marketing_sub_channel_name::VARCHAR(1000) AS marketing_sub_channel_name,
        $1:metric_name::VARCHAR(1000) AS metric_name,
        $1:metric_value::NUMBER(38,10) AS metric_value,
        $1:variable_cd::VARCHAR(1000) AS variable_cd,
        $1:load_ts::TIMESTAMP_NTZ AS load_ts,
        $1:correlation_id::VARCHAR(36) AS job_run_id
    FROM
        {{ get_stage('baseline_modelling_dataset_output') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
) AS src
-- TODO - we should check if we really need to merge into this table for every pipeline run
ON
    target.week_start_dt = src.week_start_dt AND
    target.super_category_name = src.super_category_name AND
    target.unique_brand_name = src.unique_brand_name AND
    target.cluster_num = src.cluster_num AND
    target.marketing_type_name = src.marketing_type_name AND
    target.marketing_channel_name = src.marketing_channel_name AND
    target.marketing_sub_channel_name = src.marketing_sub_channel_name AND
    target.metric_name = src.metric_name AND
    target.variable_cd = src.variable_cd
WHEN MATCHED THEN UPDATE SET
    target.metric_name = src.metric_name,
    target.metric_value = src.metric_value,
    target.variable_cd = src.variable_cd
WHEN NOT MATCHED THEN INSERT (
    week_start_dt,
    super_category_name,
    unique_brand_name,
    cluster_num,
    marketing_type_name,
    marketing_channel_name,
    marketing_sub_channel_name,
    metric_name,
    metric_value,
    variable_cd,
    job_run_id,
    load_ts
) VALUES (
    src.week_start_dt,
    src.super_category_name,
    src.unique_brand_name,
    src.cluster_num,
    src.marketing_type_name,
    src.marketing_channel_name,
    src.marketing_sub_channel_name,
    src.metric_name,
    src.metric_value,
    src.variable_cd,
    src.job_run_id,
    src.load_ts
);
