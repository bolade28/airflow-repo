MERGE INTO {{ get_table('measurement_sku_cluster_mapping') }} AS target
USING (
    SELECT
        $1:item_cd::VARCHAR(1000) AS item_cd,
        $1:super_category_name::VARCHAR(900) AS super_category_name,
        $1:unique_brand_name::VARCHAR(3456) AS unique_brand_name,
        $1:cluster_num::VARCHAR(1000) AS cluster_num,
        $1:modelling_type::VARCHAR(126) AS modelling_type,
        $1:job_run_id::VARCHAR(1000) AS job_run_id,
        $1:load_ts::TIMESTAMP_NTZ AS load_ts
    FROM
        {{ get_stage('sku_cluster_mapping_new_launch') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
) AS source
-- TODO - we should check if we really need to merge into this table for every pipeline run
ON
    target.item_cd = source.item_cd AND
    target.super_category_name = source.super_category_name AND
    target.unique_brand_name = source.unique_brand_name AND
    target.load_ts < source.load_ts
WHEN MATCHED THEN UPDATE SET
    target.cluster_num = source.cluster_num,
    target.job_run_id = source.job_run_id,
    target.load_ts = source.load_ts,
    target.modelling_type = source.modelling_type
WHEN NOT MATCHED THEN
INSERT (
    item_cd,
    super_category_name,
    unique_brand_name,
    cluster_num,
    job_run_id,
    load_ts,
    modelling_type
)
VALUES (
    source.item_cd,
    source.super_category_name,
    source.unique_brand_name,
    source.cluster_num,
    source.job_run_id,
    source.load_ts,
    source.modelling_type
);
