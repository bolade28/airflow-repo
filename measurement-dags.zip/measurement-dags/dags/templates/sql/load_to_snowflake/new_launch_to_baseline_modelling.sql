MERGE INTO {{ get_table('measurement_baseline_modelling_output') }} AS target
USING (
    SELECT
        $1:week_start_dt::DATE AS week_start_dt,
        $1:super_category_name::VARCHAR(900) AS super_category_name,
        $1:unique_brand_name::VARCHAR(3456) AS unique_brand_name,
        $1:cluster_num::VARCHAR(1000) AS cluster_num,
        $1:iteration::VARCHAR(72) AS iteration,
        $1:modelling_type::VARCHAR(126) AS modelling_type,
        $1:job_run_id::VARCHAR(1000) AS job_run_id,
        $1:metric_name::VARCHAR(1000) AS metric_name,
        $1:load_ts::TIMESTAMP_NTZ AS load_ts,
        $1:cluster_type::VARCHAR(1000) AS cluster_type,
        $1:best_iteration::VARCHAR(1000) AS best_iteration,
        $1:metric_value::NUMBER(38,9) AS metric_value,
        $1:rsq::NUMBER(38,9) AS rsq,
        $1:wsmape::NUMBER(38,9) AS wsmape,
        $1:baseline_perc::NUMBER(38,9) AS baseline_perc

    FROM
        {{ get_stage('new_launch_estimation') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
) AS source
-- TODO - we should check if we really need to merge into this table for every pipeline run
ON
    target.week_start_dt = source.week_start_dt AND
    target.super_category_name = source.super_category_name AND
    target.unique_brand_name = source.unique_brand_name AND
    target.cluster_num = source.cluster_num AND
    target.iteration = source.iteration AND
    target.modelling_type = source.modelling_type AND
    target.metric_name = source.metric_name
WHEN MATCHED THEN UPDATE SET
    target.job_run_id      = source.job_run_id,
    target.load_ts         = source.load_ts,
    target.cluster_type    = source.cluster_type,
    target.best_iteration  = source.best_iteration,
    target.metric_value    = source.metric_value,
    target.rsq             = source.rsq,
    target.wsmape          = source.wsmape,
    target.baseline_perc   = source.baseline_perc
WHEN NOT MATCHED THEN INSERT (
    week_start_dt,
    super_category_name,
    unique_brand_name,
    cluster_num,
    iteration,
    modelling_type,
    job_run_id,
    metric_name,
    load_ts,
    cluster_type,
    best_iteration,
    metric_value,
    rsq,
    wsmape,
    baseline_perc
) VALUES (
    source.week_start_dt,
    source.super_category_name,
    source.unique_brand_name,
    source.cluster_num,
    source.iteration,
    source.modelling_type,
    source.job_run_id,
    source.metric_name,
    source.load_ts,
    source.cluster_type,
    source.best_iteration,
    source.metric_value,
    source.rsq,
    source.wsmape,
    source.baseline_perc
);
