INSERT INTO {{ get_table('measurement_sku_cluster_mapping') }} (
    unique_brand_name,
    super_category_name,
    item_cd,
    cluster_num,
    job_run_id,
    load_ts,
    modelling_type
)
SELECT
    $1:unique_brand_name::VARCHAR(3456) AS unique_brand_name,
    $1:super_category_name::VARCHAR(900) AS super_category_name,
    $1:item_cd::NUMBER(38,0) AS item_cd,
    $1:cluster_num::VARCHAR(1000) AS cluster_num,
    $1:job_run_id::VARCHAR(1000) AS job_run_id,
    $1:load_ts::TIMESTAMP_NTZ AS load_ts,
    $1:modelling_type::VARCHAR(126) AS modelling_type
FROM
    {{ get_stage('sku_cluster_mapping_final_output') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
;
