CREATE OR REPLACE TRANSIENT TABLE {{ get_table('campaign_product_type_aws') }} COPY GRANTS AS (
    select
        $1:item_cd::NUMBER(38,0) AS item_cd,
        $1:product_type::VARCHAR(16777216) AS product_type,
        $1:channel_name::VARCHAR(16777216) AS channel_name,
        $1:subchannel_name::VARCHAR(16777216) AS subchannel_name,
        $1:booking_id::VARCHAR(16777216) AS booking_id,
        $1:campaign_id::VARCHAR(16777216) AS campaign_id,
        $1:sku_name::VARCHAR(16777216) AS sku_name,
        $1:sub_cat_name::VARCHAR(16777216) AS sub_cat_name,
        $1:brand_name::VARCHAR(16777216) AS brand_name,
        $1:brand_owner_name::VARCHAR(16777216) AS brand_owner_name,
        $1:unique_brand_name::VARCHAR(16777216) AS unique_brand_name,
        $1:job_run_id::VARCHAR(16777216) AS job_run_id,
        $1:load_ts::TIMESTAMP AS load_ts
    from {{ get_stage('campaign_product_type') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
)
