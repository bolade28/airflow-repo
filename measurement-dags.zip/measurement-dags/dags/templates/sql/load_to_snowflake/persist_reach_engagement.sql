-- Delete old data for this same run, if any
DELETE FROM {{ get_table('measurement_reach_engagement_aws') }}
WHERE (correlation_id, campaign_id, booking_id) IN (
    SELECT
        $1:job_run_id::VARCHAR(50),
        $1:campaign_id::VARCHAR(1000),
        $1:booking_id::VARCHAR(1000)
    FROM {{ get_stage('reach_engagement') }}
    ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
);

-- Insert latest data, keeping only the latest load_ts for each unique combination of all other columns
INSERT INTO {{ get_table('measurement_reach_engagement_aws') }} (
    correlation_id,
    campaign_id,
    booking_id,
    marketing_type,
    channel_name,
    subchannel_name,
    reach_count,
    clicks_count,
    impressions_count,
    sales_amount,
    conversions_count,
    media_spend_amount,
    engagement_click_through_rate_percent,
    marketing_hierarchy_cd,
    load_ts,
    run_type,
    dag_run_ts
)
    SELECT
        $1:job_run_id::VARCHAR(50) AS correlation_id,
        $1:campaign_id::VARCHAR(1000) AS campaign_id,
        $1:booking_id::VARCHAR(1000) AS booking_id,
        $1:marketing_type::VARCHAR(1000) AS marketing_type,
        $1:channel_name::VARCHAR(1000) AS channel_name,
        $1:subchannel_name::VARCHAR(1000) AS subchannel_name,
        $1:reach_cnt::NUMBER(38,2) AS reach_count,
        $1:clicks_cnt::NUMBER(38,2) AS clicks_count,
        $1:impressions_cnt::NUMBER(38,2) AS impressions_count,
        $1:sales_amt::NUMBER(38,4) AS sales_amount,
        $1:conversions_cnt::NUMBER(38,2) AS conversions_count,
        $1:media_spend_amt::NUMBER(38,4) AS media_spend_amount,
        $1:engagement_ctr_pct::NUMBER(38,4) AS engagement_click_through_rate_percent,
        $1:marketing_hierarchy_cd::VARCHAR(1000) AS marketing_hierarchy_cd,
        $1:load_ts::TIMESTAMP_LTZ(9) AS load_ts,
        $1:run_type::TEXT AS run_type,
        $1:dag_run_ts::TIMESTAMP_LTZ AS dag_run_ts
    FROM
        {{ get_stage('reach_engagement') }} (
            FILE_FORMAT => 'measurement_parquet_file_format',
            PATTERN => '^.+.parquet$'
        )
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY
        $1:job_run_id::VARCHAR(50),
        $1:campaign_id::VARCHAR(1000),
        $1:booking_id::VARCHAR(1000),
        $1:marketing_type::VARCHAR(1000),
        $1:channel_name::VARCHAR(1000),
        $1:subchannel_name::VARCHAR(1000),
        $1:marketing_hierarchy_cd::VARCHAR(1000),
        $1:reach_cnt::NUMBER(38,2),
        $1:clicks_cnt::NUMBER(38,2),
        $1:impressions_cnt::NUMBER(38,2),
        $1:sales_amt::NUMBER(38,4),
        $1:conversions_cnt::NUMBER(38,2),
        $1:media_spend_amt::NUMBER(38,4),
        $1:engagement_ctr_pct::NUMBER(38,4),
        $1:run_type::TEXT
    ORDER BY $1:load_ts::TIMESTAMP_LTZ(9) DESC
) = 1
;
