MERGE INTO {{ get_table('unified_products_aws') }} AS target
USING (
SELECT
        $1:ITEM_CD::NUMBER(38,0) AS item_cd,
        $1:ITEM_NAME::VARCHAR(100) AS item_name,
        $1:SEGMENT_NAME::VARCHAR(100) AS segment_name,
        $1:SUB_CAT_NAME::VARCHAR(100) AS sub_cat_name,
        $1:CAT_NAME::VARCHAR(100) AS cat_name,
        $1:SUPER_CAT_NAME::VARCHAR(300) AS super_cat_name,
        $1:ITEM_WEIGHT_OR_VOL_UOM_CD::VARCHAR(128) AS item_weight_or_vol_uom_cd,
        $1:UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY::NUMBER(18,4) AS unit_or_item_weight_or_vol_qty,
        $1:ITEM_TOTAL_WEIGHT_OR_VOL_QTY::NUMBER(18,4) AS item_total_weight_or_vol_qty,
        $1:STD_ITEM_WGT_OR_VOL_QTY_UOM_CD::VARCHAR(128) AS std_item_wgt_or_vol_qty_uom_cd,
        $1:STD_ITEM_TOTAL_WGT_OR_VOL_QTY::NUMBER(18,4) AS std_item_total_wgt_or_vol_qty,
        $1:BASE_PRICE_AMT::NUMBER(18,4) AS base_price_amt,
        $1:UNIQUE_BRAND_NAME::VARCHAR(300) AS unique_brand_name,
        $1:RAW_UNIQUE_BRAND_NAME::VARCHAR(300) AS raw_unique_brand_name,
        $1:JOB_RUN_ID::VARCHAR(16777216) AS job_run_id,
        $1:LOAD_TS::TIMESTAMP_NTZ(9) AS load_ts,
        '{{ params.run_type }}' AS run_type,
        CURRENT_TIMESTAMP() AS dag_run_ts
    FROM {{ get_stage('unified_product') }} ( FILE_FORMAT => 'measurement_parquet_file_format', PATTERN => '^.+.parquet$' )
) AS source
ON target.item_cd = source.item_cd
WHEN NOT MATCHED THEN
    INSERT (
        item_cd,
        item_name,
        segment_name,
        sub_cat_name,
        cat_name,
        super_cat_name,
        item_weight_or_vol_uom_cd,
        unit_or_item_weight_or_vol_qty,
        item_total_weight_or_vol_qty,
        std_item_wgt_or_vol_qty_uom_cd,
        std_item_total_wgt_or_vol_qty,
        base_price_amt,
        unique_brand_name,
        raw_unique_brand_name,
        job_run_id,
        load_ts,
        run_type,
        dag_run_ts
    ) VALUES (
        source.item_cd,
        source.item_name,
        source.segment_name,
        source.sub_cat_name,
        source.cat_name,
        source.super_cat_name,
        source.item_weight_or_vol_uom_cd,
        source.unit_or_item_weight_or_vol_qty,
        source.item_total_weight_or_vol_qty,
        source.std_item_wgt_or_vol_qty_uom_cd,
        source.std_item_total_wgt_or_vol_qty,
        source.base_price_amt,
        source.unique_brand_name,
        source.raw_unique_brand_name,
        source.job_run_id,
        source.load_ts,
        source.run_type,
        source.dag_run_ts
    )
WHEN MATCHED THEN
    UPDATE SET
        target.item_name = source.item_name,
        target.segment_name = source.segment_name,
        target.sub_cat_name = source.sub_cat_name,
        target.cat_name = source.cat_name,
        target.super_cat_name = source.super_cat_name,
        target.item_weight_or_vol_uom_cd = source.item_weight_or_vol_uom_cd,
        target.unit_or_item_weight_or_vol_qty = source.unit_or_item_weight_or_vol_qty,
        target.item_total_weight_or_vol_qty = source.item_total_weight_or_vol_qty,
        target.std_item_wgt_or_vol_qty_uom_cd = source.std_item_wgt_or_vol_qty_uom_cd,
        target.std_item_total_wgt_or_vol_qty = source.std_item_total_wgt_or_vol_qty,
        target.base_price_amt = source.base_price_amt,
        target.unique_brand_name = source.unique_brand_name,
        target.raw_unique_brand_name = source.raw_unique_brand_name,
        target.run_type = source.run_type,
        target.dag_run_ts = source.dag_run_ts
;
