COPY INTO {{ get_stage('campaign_product_type_dim_item') }}
FROM (
    SELECT
        item_cd,
        item_name,
        sub_cat_name
    FROM
        {{ get_table('dim_item') }}
)
include_query_id = true
header = true;
