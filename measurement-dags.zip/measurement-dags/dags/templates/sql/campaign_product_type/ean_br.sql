COPY INTO {{ get_stage('campaign_product_type_ean_br') }}
FROM (
    SELECT
        item_nk1,
        brand_name,
        brand_owner_name,
        load_ts,
        valid_from_dt,
        record_deleted_flag
    FROM
        {{ get_table('ean_br') }}
)
include_query_id = true
header = true;
