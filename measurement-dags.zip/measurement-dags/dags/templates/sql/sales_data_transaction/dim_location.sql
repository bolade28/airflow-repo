COPY INTO {{ get_stage('processed_dim_location') }}
FROM (
    select
        location_cd,
        site_type
    from {{ get_table('dim_location') }}
)
include_query_id = true
header = true;
