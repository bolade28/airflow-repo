COPY INTO {{ get_stage('processed_fact_sales_transaction_item_agg') }}
FROM(
-- Retrieve Transaction Data from FACT_SALE_TRANSACTION_ITEM. Business Context - Tagging Item Sales and Item Returns separately using filters. Also Filtering transactions between select dates
    select
        MIN(transaction_dt) AS transaction_dt,
        item_cd,
       
    from {{ get_table('fact_sale_transaction_item') }}
    GROUP BY
        item_cd
)
include_query_id = true
header = true;