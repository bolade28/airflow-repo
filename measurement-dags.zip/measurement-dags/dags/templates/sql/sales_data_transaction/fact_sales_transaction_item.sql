COPY INTO {{ get_stage('processed_fact_sales_transaction_item') }}
FROM(
-- Retrieve Transaction Data from FACT_SALE_TRANSACTION_ITEM. Business Context - Tagging Item Sales and Item Returns separately using filters. Also Filtering transactions between select dates
    select
        transaction_id,
        transaction_dt,
        net_retail_sales_amt,
        pre_promotional_sale_amt,
        item_cd,
        store_cd,
        uom_cd,
        item_qty,
        item_type_sale_or_return,
        base_unit_price_amt
    from {{ get_table('fact_sale_transaction_item') }}
    where transaction_dt >= '{{ params.start_date }}' AND transaction_dt <= '{{ params.end_date }}'
)
include_query_id = true
header = true;
