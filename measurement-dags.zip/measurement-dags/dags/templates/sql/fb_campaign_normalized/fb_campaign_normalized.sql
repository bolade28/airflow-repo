COPY INTO {{ get_stage('fb_campaign') }}
FROM (
-- This SQL replicates the PySpark function logic for the input datasource.
WITH 
-- Step 1: Preprocess linked data (equivalent to fb_link_reqd)
fb_link_reqd AS (
    SELECT DISTINCT 
        DIGITAL_TRADING_CAMPAIGN_NK1,
        DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1
    FROM {{ get_table('digital_trading_campaign_channel_dmfbca_link') }}
),

-- Step 2: Preprocess IO data (equivalent to fb_io_reqd)
fb_io_reqd AS (
    SELECT DISTINCT
        CAMPAIGN_START_TS,
        CAMPAIGN_END_TS,
        CAMPAIGN_NAME,
        DIGITAL_TRADING_CAMPAIGN_NK1,
        MEASUREMENT_SKU_LIST,
        JOB_BAG_ID
    FROM {{ get_table('digital_trading_campaign_dmfbca_sat') }}
),

-- Step 3: Join and transform data (equivalent to fb_joined)
fb_joined_intermediate AS (
    SELECT 
        link.DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1 AS CAMPAIGN_ID,
        io.CAMPAIGN_START_TS,
        io.CAMPAIGN_END_TS,
        io.CAMPAIGN_NAME,
        io.MEASUREMENT_SKU_LIST,
        io.JOB_BAG_ID
    FROM fb_io_reqd io
    LEFT JOIN fb_link_reqd link 
        ON io.DIGITAL_TRADING_CAMPAIGN_NK1 = link.DIGITAL_TRADING_CAMPAIGN_NK1
  )

  -- Creation of output intermediate fb data for s3 bucket.
  SELECT CAMPAIGN_ID,
         CAMPAIGN_START_TS,
         CAMPAIGN_END_TS,
         CAMPAIGN_NAME,
         MEASUREMENT_SKU_LIST,
         JOB_BAG_ID
    FROM fb_joined_intermediate
)
include_query_id = true
header = true;
