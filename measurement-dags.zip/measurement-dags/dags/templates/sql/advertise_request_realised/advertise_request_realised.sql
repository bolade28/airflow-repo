COPY INTO {{ get_stage('advertise_request_realised') }}
FROM (
    SELECT
        ingressed_at_dt,
        advertising_campaign_nk1,
        advertising_revenue_amt,
        advertising_spend_amt,
        sales_revenue_amt,
        unit_sales_cnt,
        conversions_cnt,
        impressions_cnt,
        clicks_cnt,
        item_id
    FROM
        {{ get_table('advertise_request_realised') }}
    WHERE ingressed_at_dt BETWEEN '{{ params.start_date }}' AND '{{ params.end_date }}'
    QUALIFY ROW_NUMBER() OVER
        (PARTITION BY
            advertising_campaign_nk1,
            advertising_campaign_nk2,
            advertising_campaign_nk3,
            advertising_wallet_nk1,
            advertising_wallet_nk2,
            advertising_wallet_nk3,
            catalog_id,
            placement,
            ingressed_at_dt,
            content_standard_id,
            category_id,
            item_id,
            target_item_id,
            search_term,
            generic_search_term,
            advertising_type
        ORDER BY record_arrival_ts DESC) = 1
)
include_query_id = true
header = true;
