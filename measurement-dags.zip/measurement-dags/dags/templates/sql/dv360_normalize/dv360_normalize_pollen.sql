COPY INTO {{ get_stage('dv360_pollen_campaign') }}
FROM (
    -- Select only the columns needed for DV360 normalization
    SELECT
        booking_id,
        campaign_id,
        booking_media_live_start_dt,
        booking_media_live_end_dt,
        booking_media_budget_amt,
        channel_type,
        media_provider,
        booking_status,
        media_business_group,
        replace(replace(f.value,'{"skuId":',''),'}','')::VARCHAR as sku_id
    FROM {{ get_table('campaign_booking_media_channel') }},
    LATERAL FLATTEN(input => booking_item_cd_list) f
    WHERE booking_item_cd_list IS NOT NULL
    AND json_extract_path_text(f.value,'skuId') IS NOT NULL
)
include_query_id = true
header = true;