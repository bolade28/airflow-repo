COPY INTO {{ get_stage('dv360_campaign') }}
FROM (
    -- Select only the columns needed for DV360 normalization
    SELECT
        DTP_INPUT,
        CAMPAIGN_START_DT,
        CAMPAIGN_END_DT
    FROM
        {{ get_table('digital_trading_campaign_dmdvio_sat') }}
)
include_query_id = true
header = true;
