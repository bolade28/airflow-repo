MERGE INTO {{ get_table('measurement_campaign_execution_aws') }} AS target
USING (
    SELECT
        campaign_id,
        booking_id,
        job_bag_number,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_duration,
        job_status,
        load_ts,
        job_run_id,
        overlapping_campaign_flag,
        marketing_hierarchy_cd
    FROM {{ get_table('measurement_campaign_execution_status') }}
    ) AS src
ON
  target.campaign_id = src.campaign_id
  AND target.booking_id = src.booking_id
  AND target.job_bag_number = src.job_bag_number
  AND target.channel_name = src.channel_name
  AND target.subchannel_name = src.subchannel_name
  AND target.campaign_duration = src.campaign_duration
  AND target.campaign_start_dt = src.campaign_start_dt
  AND target.campaign_end_dt = src.campaign_end_dt
  AND target.overlapping_campaign_flag = src.overlapping_campaign_flag
WHEN MATCHED THEN UPDATE SET
  target.campaign_name = src.campaign_name,
  target.marketing_type = src.marketing_type,
  target.job_status = src.job_status,
  target.load_ts = src.load_ts,
  target.job_run_id = src.job_run_id,
  target.marketing_hierarchy_cd = src.marketing_hierarchy_cd
WHEN NOT MATCHED THEN INSERT (
  campaign_id,
  booking_id,
  job_bag_number,
  marketing_type,
  channel_name,
  subchannel_name,
  campaign_name,
  campaign_start_dt,
  campaign_end_dt,
  campaign_duration,
  job_status,
  load_ts,
  job_run_id,
  overlapping_campaign_flag,
  marketing_hierarchy_cd
) VALUES (
  src.campaign_id,
  src.booking_id,
  src.job_bag_number,
  src.marketing_type,
  src.channel_name,
  src.subchannel_name,
  src.campaign_name,
  src.campaign_start_dt,
  src.campaign_end_dt,
  src.campaign_duration,
  src.job_status,
  src.load_ts,
  src.job_run_id,
  src.overlapping_campaign_flag,
  src.marketing_hierarchy_cd
);
