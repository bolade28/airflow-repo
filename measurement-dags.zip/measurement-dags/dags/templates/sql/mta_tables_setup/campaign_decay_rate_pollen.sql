COPY INTO {{ get_stage('campaign_decay_rate') }}
FROM (
with measurement_data as (
    select distinct
        campaign_id,
        channel_name,
        campaign_start_dt,
        campaign_end_dt,
        subchannel_name,
        marketing_type,
        marketing_hierarchy_cd
    from {{ get_table('measurement_campaign_execution_aws') }}
    where
        lower(marketing_type) = '{{params.marketing_type}}'
        -- and job_status = 'In-progress'
        and campaign_duration = 'During'
),
-- Generate a sequence of dates for each campaign's duration.
-- Create a daily timeline for each campaign to track impressions over time.
date_explosion as (
    select
        md.campaign_id,
        md.channel_name,
        md.campaign_start_dt,
        md.campaign_end_dt,
        md.subchannel_name,
        dateadd('day', row_number()
            over (partition by md.campaign_id, channel_name, subchannel_name order by seq4())
        - 1, md.campaign_start_dt) as exploded_date
    from measurement_data as md
    , table(generator(rowcount => 150))
),
-- Create a raw span of campaign dates for each campaign_id.
-- Establish a baseline timeline for each campaign.
campaign_span_raw as (
    select
        campaign_id,
        channel_name,
        exploded_date,
        subchannel_name
    from date_explosion
    order by campaign_id, exploded_date
),
-- We get the impression data on daily level so we are filtering the campaign span.
-- This ensures that we only include dates that fall within the campaign's active period.
-- Ensure the timeline aligns with the actual campaign duration.
get_campaign_span_offsite as (
    select
        md.campaign_id,
        md.channel_name,
        csr.exploded_date,
        md.subchannel_name,
        md.marketing_hierarchy_cd
    from measurement_data as md
    inner join campaign_span_raw as csr
        on
            md.campaign_id = csr.campaign_id
            and
            md.channel_name = csr.channel_name
            and md.subchannel_name = csr.subchannel_name
    where csr.exploded_date <= md.campaign_end_dt
),
-- Retrieve the latest record for each campaign from the DMFBIN table for channel Meta.
-- Use the most recent data to ensure accuracy in impression calculations.
get_max_dmfbin as (
    select
        digital_trading_campaign_nk1,
        reporting_start_dt,
        reporting_end_dt,
        max(record_arrival_ts) as record_arrival_ts
    from {{ get_table('digital_trading_campaign_insight_link') }}
    where reporting_start_dt = reporting_end_dt
    group by digital_trading_campaign_nk1, reporting_start_dt, reporting_end_dt
),
-- Filter DMFBIN data to include only the latest records for each campaign for Meta
-- Ensure only the most up-to-date data is used for analysis.
get_dmfbin_filtered as (
    select
        digital_trading_campaign_nk1,
        reporting_start_dt,
        reporting_end_dt,
        record_arrival_ts,
        measures
    from {{ get_table('digital_trading_campaign_insight_link') }}
    where
        (digital_trading_campaign_nk1, reporting_start_dt, reporting_end_dt, record_arrival_ts)
        in (
            select distinct
                digital_trading_campaign_nk1,
                reporting_start_dt,
                reporting_end_dt,
                record_arrival_ts
            from get_max_dmfbin
        )
        and reporting_start_dt = reporting_end_dt
),
-- Retrieve the latest record for each job bag and campaign from the DMFBCA table.
-- Link job bags to campaigns for accurate impression mapping.
get_max_dtcds as (
    select
        job_bag_id,
        digital_trading_campaign_nk1,
        max(record_arrival_ts) as record_arrival_ts
    from  {{ get_table('digital_trading_campaign_dmfbca_sat') }}
    group by job_bag_id, digital_trading_campaign_nk1
),
-- Filter DMFBCA data to include only the latest records for each job bag and campaign for Meta.
-- Ensure data consistency and accuracy in campaign mapping.
get_dtcds_filtered as (
    select
        job_bag_id,
        digital_trading_campaign_nk1
    from  {{ get_table('digital_trading_campaign_dmfbca_sat') }}
    where
        (job_bag_id, digital_trading_campaign_nk1, record_arrival_ts)
        in (
            select distinct
                job_bag_id,
                digital_trading_campaign_nk1,
                record_arrival_ts
            from get_max_dtcds
        )
),
-- Retrieve the latest record for each campaign and channel from the DMFBCA_LINK table for Meta
-- Map campaigns to their respective channels for accurate attribution.
get_max_dtccdl as (
    select
        digital_trading_campaign_nk1,
        digital_trading_campaign_channel_nk1,
        max(record_arrival_ts) as record_arrival_ts
    from {{ get_table('digital_trading_campaign_channel_dmfbca_link') }}
    group by digital_trading_campaign_nk1, digital_trading_campaign_channel_nk1
),
-- Filter DMFBCA_LINK data to include only the latest records for each campaign and channel.
-- Ensure accurate mapping of campaigns to channels.
get_dtccdl_filtered as (
    select
        digital_trading_campaign_nk1,
        digital_trading_campaign_channel_nk1
    from {{ get_table('digital_trading_campaign_channel_dmfbca_link') }}
    where
        (digital_trading_campaign_nk1, digital_trading_campaign_channel_nk1, record_arrival_ts)
        in (
            select distinct
                digital_trading_campaign_nk1,
                digital_trading_campaign_channel_nk1,
                record_arrival_ts
            from get_max_dtccdl
        )
),
-- We get the impression data on daily level so we are filtering the campaign span.
-- This ensures that we only include dates that fall within the campaign's active period.
-- Extract Meta impressions data by joining filtered datasets and measurement data.
-- Calculate impressions for Meta campaigns to track their performance.
get_meta_impressions as (
    select distinct
        dtcds.job_bag_id,
        gdf.reporting_start_dt,
        gdf.reporting_end_dt,
        gdf.record_arrival_ts,
        gdf.digital_trading_campaign_nk1,
        md.channel_name,
        json_extract_path_text(gdf.measures, 'summary.impressions') as impressions
    from get_dtcds_filtered as dtcds
    inner join get_dtccdl_filtered as dtccdl
        on dtcds.digital_trading_campaign_nk1 = dtccdl.digital_trading_campaign_nk1
    inner join get_dmfbin_filtered as gdf
        on dtccdl.digital_trading_campaign_channel_nk1 = gdf.digital_trading_campaign_nk1
    inner join measurement_data as md
        on dtcds.job_bag_id = md.campaign_id
    where
        gdf.reporting_start_dt >= md.campaign_start_dt
        and gdf.reporting_end_dt <= md.campaign_end_dt
        and gdf.reporting_end_dt = gdf.reporting_start_dt
    order by gdf.reporting_start_dt
),
-- Map Meta impressions to the campaign span dates.
-- Align impressions data with the campaign timeline for Meta.
get_span_impression as (
    select distinct
        gcso.campaign_id,
        gcso.subchannel_name,
        gcso.channel_name,
        gcso.exploded_date as reporting_dt,
        coalesce(gmi.impressions, 0) as impressions
    from get_campaign_span_offsite as gcso
    left join get_meta_impressions as gmi
        on
            gcso.campaign_id = gmi.job_bag_id
            and gcso.channel_name = gmi.channel_name
            and gcso.exploded_date = gmi.reporting_start_dt
    where gcso.marketing_hierarchy_cd in ({{ params.meta_subchannel_list | join(', ') }})
),
-- Calculate cumulative impressions for Meta campaigns.
-- Track the total impressions delivered over time for Meta campaigns.
get_cumulative_meta as (
    select distinct
        md.marketing_type,
        gcsi.subchannel_name,
        gcsi.channel_name,
        gcsi.campaign_id,
        reporting_dt as campaign_date,
        impressions,
        sum(impressions) over (partition by gcsi.campaign_id order by reporting_dt) as cumulative_impressions
    from get_span_impression as gcsi
    inner join measurement_data as md
    on
        gcsi.campaign_id = md.campaign_id
        and gcsi.subchannel_name = md.subchannel_name
),
-- Retrieve the maximum cumulative impressions for each Meta campaign.
-- Identify the total impressions delivered for each Meta campaign.
get_cumulative_meta_max as (
    select
        campaign_id,
        max(cumulative_impressions) as max_cnt
    from get_cumulative_meta
    group by campaign_id
),
-- Calculate the offsite impressions percentage for Meta campaigns.
-- Offsite impressions are calculated as a percentage of cumulative impressions / total impressions.
-- Determine the percentage of impressions delivered over time for Meta.
get_meta_offsite_impressions as (
    select
        gcm.*,
        case
            when gcm.cumulative_impressions = 0 then 0.001
            else gcm.cumulative_impressions / gcmm.max_cnt
        end as offsite_impressions
    from get_cumulative_meta as gcm
    inner join get_cumulative_meta_max as gcmm
        on gcm.campaign_id = gcmm.campaign_id
),
-- Extract DV360 and YouTube impressions data from the MEDIA_REPORT table.
-- Calculate impressions for DV360 and YouTube campaigns to track their performance.
get_dv_impression as (
    select
        md.campaign_id,
        mr.campaign_date,
        mr.impressions,
        md.channel_name,
        md.subchannel_name
    from {{ get_table('dv360_media_report') }} as mr
    inner join measurement_data as md
        on mr.insertion_order_id = md.campaign_id
    where
        mr.campaign_date >= md.campaign_start_dt
        and mr.campaign_date <= md.campaign_end_dt
    order by md.campaign_id, mr.campaign_date
),

get_yt_impression as (
    select
        md.campaign_id,
        mr.campaign_date,
        mr.impressions,
        md.channel_name,
        md.subchannel_name
    from {{ get_table('dv360_media_report') }} as mr
    inner join measurement_data as md
        on mr.campaign_id = md.campaign_id
    where
        mr.campaign_date >= md.campaign_start_dt
        and mr.campaign_date <= md.campaign_end_dt
    order by md.campaign_id, mr.campaign_date
),

get_dvyt_impression as (
    select
        campaign_id,
        campaign_date,
        impressions,
        channel_name,
        subchannel_name,
    from get_dv_impression
    union all
    select
        campaign_id,
        campaign_date,
        impressions,
        channel_name,
        subchannel_name,
    from get_yt_impression
),

-- Map DV360 and YouTube impressions to the campaign span dates.
-- Align impressions data with the campaign timeline for DV360 and YouTube.
get_dvyt_span_impressions as (
    select
        gcso.campaign_id,
        gdi.campaign_date,
        gcso.channel_name,
        gcso.subchannel_name,
        coalesce(gdi.impressions, 0) as impressions
    from get_campaign_span_offsite as gcso
    left join get_dvyt_impression as gdi
        on
            gcso.campaign_id = gdi.campaign_id
            and gcso.channel_name = gdi.channel_name
            and gcso.exploded_date = gdi.campaign_date
    where gcso.marketing_hierarchy_cd in ({{ params.dv360_subchannel_list | join(', ') }}, {{ params.youtube_subchannel_list | join(', ') }})
),
-- Aggregate total impressions for DV360 and YouTube campaigns.
-- Summarize impressions data for DV360 and YouTube campaigns.
get_total_impression_dvyt as (
    select
        channel_name,
        campaign_id,
        campaign_date,
        subchannel_name,
        sum(impressions) as impressions
    from get_dvyt_span_impressions
    group by channel_name, subchannel_name, campaign_id, campaign_date
),
-- Calculate cumulative impressions for DV360 and YouTube campaigns.
-- Track the total impressions delivered over time for DV360 and YouTube campaigns.
get_dvyt_cumulative_impressions as (
    select
        'OFFSITE' as marketing_type,
        subchannel_name,
        channel_name,
        campaign_id,
        campaign_date,
        impressions,
        sum(impressions) over (partition by campaign_id order by campaign_date)
            as cumulative_impressions
    from get_total_impression_dvyt
    order by campaign_date
),
-- Retrieve the maximum cumulative impressions for DV360 and YouTube campaigns.
-- Identify the total impressions delivered for each DV360 and YouTube campaign.
get_cumulative_dv360_max as (
    select
        campaign_id,
        max(cumulative_impressions) as max_cumulative_impression
    from get_dvyt_cumulative_impressions
    group by campaign_id
),
-- Calculate the offsite impressions percentage for DV360 and YouTube campaigns.
-- Offsite impressions are calculated as a percentage of cumulative impressions / total impressions.
-- Determine the percentage of impressions delivered over time for DV360 and YouTube.
get_dvyt_offsite_impressions as (
    select
        gdci.*,
        case
            when gdci.cumulative_impressions = 0 then {{params.min_impression_value}}
            else gdci.cumulative_impressions / gcdm.max_cumulative_impression
        end as offsite_impressions
    from get_dvyt_cumulative_impressions as gdci
    inner join get_cumulative_dv360_max as gcdm
        on gdci.campaign_id = gcdm.campaign_id
),
-- Combine offsite impressions data for Meta, DV360, and YouTube campaigns.
-- Create a unified dataset for all platforms to enable cross-platform analysis.
get_total_offsite_impressions as (
    select * from get_meta_offsite_impressions
    union all
    select * from get_dvyt_offsite_impressions
),
-- Final table that calculates the campaign decay rate with all required metrics.
-- Provide a comprehensive view of campaign performance across platforms.
campaign_decay_rate as (
    select distinct
        marketing_type,
        channel_name,
        'NA' as job_bag_number,
        campaign_date as reporting_dt,
        to_number(impressions) as impressions_cnt,
        cumulative_impressions::integer as cumulative_impressions_cnt,
        offsite_impressions as offsite_impressions_pct,
        current_timestamp::timestamp_ntz as load_ts,
        '{{ params.correlation_id }}' as job_run_id,
        campaign_id,
        subchannel_name
    from get_total_offsite_impressions
    order by channel_name, subchannel_name, campaign_id, reporting_dt
)
-- Select the final output from the campaign_decay_rate table.
select marketing_type,
       channel_name,
       subchannel_name,
       campaign_id,
       reporting_dt,
       impressions_cnt,
       cumulative_impressions_cnt,
       offsite_impressions_pct,
       load_ts,
       job_run_id
 from campaign_decay_rate
)
include_query_id = true
header = true;