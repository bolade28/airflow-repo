CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_campaign_execution_status') }} COPY GRANTS AS (
WITH media_campaign_list AS (
    SELECT trim(table1.value) AS campaign_id
        FROM TABLE(SPLIT_TO_TABLE(
            CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN REPLACE('{{params.campaign_id_manual}}','"','')
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
post_campaign_filtered_list AS (
    SELECT trim(table1.value) AS campaign_id
    FROM TABLE(SPLIT_TO_TABLE(
    CASE 
    WHEN '{{params.campaign_duration}}' = 'During' AND NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN REPLACE('{{params.campaign_id_manual}}','"','')
    WHEN '{{params.campaign_duration}}' = 'Post' AND NOT(REPLACE('{{params.post_campaign_list}}','[]','') = '') THEN REPLACE('{{params.post_campaign_list}}','"','')
    ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
manual_campaign_list1 AS (
    SELECT campa.campaign_id
    FROM media_campaign_list campa JOIN post_campaign_filtered_list campab 
    USING (campaign_id)
),


measurement_unified_campaign AS (
    SELECT
        campaign_id,
        campaign_name,
        booking_id,
        load_ts,
        post_campaign_dt,
        job_bag_number,
        channel_name,
        marketing_type,
        subchannel_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_status,
        NULL AS marketing_hierarchy_cd
    FROM {{ get_table('measurement_unified_campaign') }}
    WHERE '{{params.run_type}}' = '{{params.dtp_run}}'
    UNION ALL
    SELECT
       campaign_id,
       campaign_name,
        booking_id,
        load_ts,
        post_campaign_dt,
        job_bag_number,
        channel_name,
        marketing_type,
        subchannel_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_status,
        marketing_hierarchy_cd
    FROM {{ get_table('measurement_unified_campaign_pollen') }}
    WHERE '{{params.run_type}}' = '{{params.pollen_run}}'
    AND load_ts = (SELECT MAX(load_ts) FROM {{ get_table('measurement_unified_campaign_pollen') }})
),
-- TODO : Remove the filter on Booking id once the pollen unified campaign snapshot load is merged.
 /* getting booking ids which has completed the whole mta pipeline once */
 booking_date_filter AS (
 select min(campaign_start_dt) as min_start_date
    ,   max(campaign_end_dt) as max_end_date
from measurement_unified_campaign muc
join manual_campaign_list1 mcl on muc.job_bag_number = mcl.campaign_id
 ),
-- TODO : Remove the filter on Booking id once the pollen unified campaign snapshot load is merged.
 /* getting booking ids which has completed the whole mta pipeline once */
post_booking_id AS (
    SELECT booking_id
    FROM {{ get_table('measurement_campaign_execution_aws') }} mce
    JOIN manual_campaign_list1 mc
    ON
    CASE WHEN mc.campaign_ID = '' THEN True
    ELSE mc.campaign_id = mce.campaign_id OR mc.campaign_id = mce.job_bag_number OR mc.campaign_id = mce.booking_id END
    WHERE '{{params.post_run_type}}' = '{{params.campaign_duration}}'
    GROUP BY booking_id
)

 /* getting booking ids which has completed the whole mta pipeline once */
, get_completed_booking_id AS (
    SELECT DISTINCT booking_id
    FROM {{ get_table('measurement_campaign_execution_aws') }} mce
    JOIN manual_campaign_list1 mc
    ON
    CASE WHEN mc.campaign_ID = '' THEN True
    ELSE mc.campaign_id = mce.campaign_id OR mc.campaign_id = mce.job_bag_number OR mc.campaign_id = mce.booking_id END
    WHERE booking_id in (SELECT booking_id FROM post_booking_id)
)

 /* getting the max_load_ts for the given booking id to fetch the latest records for post campaign period. */
, get_post_load_ts AS (
    SELECT
        mce.campaign_id
        , MAX(load_ts) AS load_ts
    FROM measurement_unified_campaign mce
    JOIN manual_campaign_list1 mc
    ON
    CASE WHEN mc.campaign_ID = '' THEN True
    ELSE (mc.campaign_id = mce.campaign_id OR mc.campaign_id = mce.job_bag_number OR mc.campaign_id = mce.booking_id) END
    WHERE (booking_id in (SELECT booking_id FROM get_completed_booking_id)
    OR job_bag_number in (SELECT booking_id FROM get_completed_booking_id))
    GROUP BY mce.campaign_id
)

/**********************
1. The post campaign_execution is used to get the campaign details for the post campaign period.
2. For a given booking id, there would be multiple campaigns,so there will be multiple post_campaign_dt.
We are extracting the MAX post_campaign_dt for each booking id.
***********************/
, get_post_campaign_execution AS (
    SELECT
        mce.campaign_id,
        mce.booking_id,
        mce.job_bag_number,
        mce.marketing_type,
        mce.channel_name,
        mce.subchannel_name,
        mce.campaign_start_dt,
        LEAST(uc.post_campaign_dt, current_date()) AS campaign_end_dt,
        regexp_replace(uc.campaign_name, '[^A-Za-z0-9 ]', '') AS campaign_name,
        'Post' AS campaign_duration,
        uc.marketing_hierarchy_cd,
        MAX(LEAST(uc.post_campaign_dt, current_date())) OVER (partition by mce.booking_id) AS max_end_date
    FROM measurement_unified_campaign AS uc
    INNER JOIN {{ get_table('measurement_campaign_execution_aws') }} AS mce
        ON
            (uc.campaign_id = mce.campaign_id OR uc.job_bag_number = mce.campaign_id) 
            AND (uc.booking_id = mce.booking_id OR uc.job_bag_number = mce.booking_id)
            AND uc.channel_name = mce.channel_name
    JOIN manual_campaign_list1 mc
    ON
    CASE WHEN mc.campaign_ID = '' THEN True
    ELSE (mc.campaign_id = mce.campaign_id OR mc.campaign_id = mce.job_bag_number OR mc.campaign_id = mce.booking_id) END
    WHERE mce.booking_id in (SELECT booking_id FROM get_completed_booking_id)
    AND (uc.campaign_id, uc.load_ts) in (SELECT campaign_id, load_ts FROM get_post_load_ts)
)


 /*filtering out booking_id which has post campaign date before the presesnt
data as we are supposed to process those campaigns
which have ended. */
, get_single_post AS (
    SELECT  DISTINCT booking_id , ROW_NUMBER() OVER (partition by campaign_id order by max_end_date desc) AS rn
    FROM get_post_campaign_execution
    WHERE max_end_date <= current_date()
    qualify rn=1
)

/**********************
1. The post_campaign is used to get the campaign details for the post campaign period.
2. We are replacing the special characters in the campaign name with empty string as this will
create issues while customer_data collection
scripts fetch this value.
***********************/
, get_post_campaign AS (
    SELECT distinct
        campaign_id,
        booking_id,
        job_bag_number,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_duration,
        regexp_replace(campaign_name, '[^A-Za-z0-9 ]', '') AS campaign_name,
        marketing_hierarchy_cd
    FROM get_post_campaign_execution
    WHERE booking_id in (SELECT booking_id FROM get_single_post)
)
/**********************
1. From unified campaign table, we are getting the booking ids which has not started yet.
2. This means it has no records in the mta tables.
3. So it can be run fot the during period.
***********************/

, get_during_loads AS (
    SELECT
        booking_id,
        uc.campaign_id,
        MAX(load_ts) AS load_ts
    FROM measurement_unified_campaign uc
    JOIN manual_campaign_list1 mc
    ON
    CASE WHEN mc.campaign_ID = '' THEN True
    ELSE (mc.campaign_id = uc.campaign_id OR mc.campaign_id = uc.job_bag_number OR mc.campaign_id = uc.booking_id) END
    WHERE (campaign_status is null or campaign_status = 'Not Started'
    or campaign_status = 'Completed' or campaign_status = 'no_exec')-- # TODO: Including completed campaigns as we need to continue evaluating and not skip them
    AND '{{params.during_run_type}}' = '{{params.campaign_duration}}'
    GROUP BY 1, 2
)

/* filtering out bookingids whose campaigns which has campaign end date after the
current date for atleast one campaign */
, get_during_res AS (
    SELECT
        booking_id,
        campaign_id,
        MAX(campaign_end_dt) AS campaign_end_dt,
        MAX(load_ts) AS load_ts
    FROM
        measurement_unified_campaign muc
    CROSS JOIN booking_date_filter bdf 
    WHERE
        (campaign_status is null or campaign_status = 'Not Started'
         or campaign_status = 'Completed' or campaign_status = 'no_exec' -- # TODO: Including completed and no_exec campaigns as we need to continue evaluating and not skip them
         -- we need to decide how best to handle the status of campaigns
         )
        and (booking_id, load_ts) IN
        (SELECT
            booking_id,
            load_ts
        FROM get_during_loads)
        and (muc.campaign_start_dt between bdf.min_start_date and bdf.max_end_date 
            or muc.campaign_end_dt between bdf.min_start_date and bdf.max_end_date)
    GROUP BY booking_id, campaign_id
    {% if not params.emulate_prod_env %}
    HAVING MAX(campaign_end_dt) < current_date()
    {% endif %}
)

 /* getting campaign specific details for the selected booking ids and replacing special characters
in the campaign name with empty string as this will create issues while running
customer_data collection scripts. */
, get_during_execution AS (
    SELECT
        uc.campaign_id,
        uc.booking_id AS booking_id,
        uc.job_bag_number AS job_bag_number,
        uc.marketing_type,
        uc.channel_name,
        uc.subchannel_name,
        uc.campaign_start_dt,
        uc.campaign_end_dt,
        'During' AS campaign_duration,
        regexp_replace(campaign_name, '[^A-Za-z0-9 ]', '') AS campaign_name,
        uc.marketing_hierarchy_cd
    FROM measurement_unified_campaign uc
    WHERE campaign_id in (SELECT campaign_id FROM get_during_res)
)

/*combining selected campaigns FROM post and during */
, get_measurement_campaign_execution AS (
    SELECT 
        gpc.campaign_id,
        gpc.booking_id,
        gpc.job_bag_number,
        gpc.marketing_type,
        gpc.channel_name,
        gpc.subchannel_name,
        gpc.campaign_start_dt,
        gpc.campaign_end_dt,
        gpc.campaign_duration,
        gpc.campaign_name,
        gpc.marketing_hierarchy_cd,
        IFF(mc.campaign_id IS NOT NULL, False, True) AS overlapping_campaign_flag
    FROM get_post_campaign gpc
    LEFT JOIN manual_campaign_list1 mc ON ( gpc.booking_id = mc.campaign_id OR  gpc.job_bag_number = mc.campaign_id)
    UNION ALL
    SELECT 
        gde.campaign_id,
        gde.booking_id,
        gde.job_bag_number,
        gde.marketing_type,
        gde.channel_name,
        gde.subchannel_name,
        gde.campaign_start_dt,
        gde.campaign_end_dt,
        gde.campaign_duration,
        gde.campaign_name,
        gde.marketing_hierarchy_cd,
        IFF(mc.campaign_id IS NOT NULL, False, True) AS overlapping_campaign_flag
    FROM get_during_execution gde
    LEFT JOIN manual_campaign_list1 mc ON ( gde.booking_id = mc.campaign_id OR gde.job_bag_number = mc.campaign_id)
)

/**********************
1. Getting single booking id as at a time there could be one bookingid running in the measurement campaign execution.
2. We are getting the booking id which has the latest campaign end date.
***********************/

, get_single_booking_id AS (
    SELECT DISTINCT
        booking_id,
        ROW_NUMBER() OVER (partition by campaign_id order by campaign_end_dt desc) AS rn
    FROM get_measurement_campaign_execution
    qualify rn = 1
)

/**********************
1. Typecasting to appropriate data type.
2. Load_ts is the timestamp when the record was loaded into the table and it is set to current timestamp.
3. Job_run_id is the unique id for the job run and it is set to the invocation id.
4. Job_status is set to 'Not Started' as the campaign has not started yet.
5. We are running this query fo the selected booking id in the previous step.
***********************/

SELECT
    DISTINCT
    mce.campaign_id::varchar(1000) AS campaign_id,
    -- For Pollen: job_bag_number becomes booking_id, booking_id becomes job_bag_number
    CASE WHEN '{{params.during_run_type}}' = '{{params.campaign_duration}}' THEN mce.job_bag_number::varchar(1000)
        ELSE mce.booking_id::varchar(1000) END AS booking_id,
    CASE WHEN '{{params.during_run_type}}' = '{{params.campaign_duration}}' THEN mce.booking_id::varchar(1000)
        ELSE mce.job_bag_number::varchar(1000) END AS job_bag_number,
    mce.marketing_type::varchar(14) AS marketing_type,
    mce.channel_name::varchar(1000) AS channel_name,
    mce.subchannel_name::varchar(1000) AS subchannel_name,
    mce.campaign_name::varchar(1000) AS campaign_name,
    mce.campaign_start_dt::date AS campaign_start_dt,
    mce.campaign_end_dt::date AS campaign_end_dt,
    mce.campaign_duration::varchar(6) AS campaign_duration,
    'Not Started'::varchar(11) AS job_status,
    current_timestamp::timestamp_ntz(9) AS load_ts,
    cast('{{params.correlation_id}}' AS varchar(36)) AS job_run_id,
    mce.overlapping_campaign_flag::BOOLEAN AS overlapping_campaign_flag,
    mce.marketing_hierarchy_cd::varchar(100) AS marketing_hierarchy_cd
FROM get_measurement_campaign_execution mce
WHERE mce.booking_id IN (SELECT booking_id FROM get_single_booking_id)
    AND '{{params.run_type}}' = '{{params.pollen_run}}'

UNION ALL

SELECT
    DISTINCT
    mce.campaign_id::varchar(1000) AS campaign_id,
    -- For DTP: keep original mapping (booking_id stays as booking_id, job_bag_number stays as job_bag_number)
    mce.booking_id::varchar(1000) AS booking_id,
    mce.job_bag_number::varchar(1000) AS job_bag_number,
    mce.marketing_type::varchar(14) AS marketing_type,
    mce.channel_name::varchar(1000) AS channel_name,
    mce.subchannel_name::varchar(1000) AS subchannel_name,
    mce.campaign_name::varchar(1000) AS campaign_name,
    mce.campaign_start_dt::date AS campaign_start_dt,
    mce.campaign_end_dt::date AS campaign_end_dt,
    mce.campaign_duration::varchar(6) AS campaign_duration,
    'Not Started'::varchar(11) AS job_status,
    current_timestamp::timestamp_ntz(9) AS load_ts,
    cast('{{params.correlation_id}}' AS varchar(36)) AS job_run_id,
    mce.overlapping_campaign_flag::BOOLEAN AS overlapping_campaign_flag,
    NULL AS marketing_hierarchy_cd
FROM get_measurement_campaign_execution mce
WHERE mce.booking_id IN (SELECT booking_id FROM get_single_booking_id)
    AND '{{params.run_type}}' = '{{params.dtp_run}}'
);