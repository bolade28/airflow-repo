CREATE TEMP TABLE {{ get_table('instore_campaign_date_range_temp') }} AS
(
    SELECT DISTINCT
        MIN(mce.campaign_start_dt) as min_campaign_start_dt,
        MAX(mce.campaign_end_dt) as max_campaign_end_dt
    FROM {{ get_table('measurement_campaign_execution_status') }} AS mce
    WHERE mce.marketing_type = 'In-store'
    AND (mce.job_status = 'Not Started' OR mce.job_status IS NULL)
);

CREATE TEMP TABLE {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }}
CLUSTER BY(transaction_dt)
AS(
    SELECT
        fstb.transaction_end_ts,
        fstb.nectar_card_num_hash,
        fstb.transaction_id,
        fstb.transaction_dt,
        fstb.sales_origination_channel_cd
    FROM {{ get_table('fact_sale_transaction_basket') }} fstb
    CROSS JOIN {{ get_table('instore_campaign_date_range_temp') }} icdr
    WHERE fstb.nectar_card_num_hash IS NOT NULL
    AND fstb.transaction_dt BETWEEN icdr.min_campaign_start_dt AND icdr.max_campaign_end_dt
    AND fstb.sales_origination_channel_cd IN {{params.sales_origination_all_codes}}
);

CREATE TEMP TABLE {{ get_table('fact_sale_transaction_item_instore_performant_temp') }}
CLUSTER BY(transaction_dt)
AS(
    SELECT
        fsti.transaction_id,
        fsti.transaction_dt,
        fsti.item_cd,
        fsti.net_retail_sales_amt,
        fsti.item_qty,
        fsti.item_sequence_num,
        fsti.store_cd
    FROM {{ get_table('fact_sale_transaction_item') }} fsti
    CROSS JOIN {{ get_table('instore_campaign_date_range_temp') }} icdr
    WHERE fsti.transaction_dt BETWEEN icdr.min_campaign_start_dt AND icdr.max_campaign_end_dt
    AND fsti.net_retail_sales_amt > 0
);

COPY INTO {{ get_stage('instore_data') }}
FROM
(
    WITH
    -- Get ALL available in-store campaigns
    campaign_details AS (
        SELECT
            mce.campaign_name,
            mce.channel_name,
            mce.subchannel_name,
            mce.campaign_start_dt,
            mce.campaign_end_dt,
            mce.campaign_id,
            mce.booking_id,
            mce.campaign_duration,
            mce.job_bag_number,
            mce.marketing_type
        FROM {{ get_table('measurement_campaign_execution_status') }} mce
        WHERE mce.marketing_type = 'In-store'
        AND (mce.job_status = 'Not Started' OR mce.job_status IS NULL)
    ),
    -- Handle POST campaign period logic for all campaigns
    unified_data AS (
        SELECT
            uc.campaign_id AS uc_campaign_id,
            uc.channel_name AS uc_channel_name,
            uc.subchannel_name AS uc_subchannel_name,
            uc.marketing_type AS uc_marketing_type,
            uc.campaign_start_dt AS uc_campaign_start_dt,
            uc.campaign_end_dt AS uc_campaign_end_dt,
            cd.booking_id AS cd_booking_id,
            cd.campaign_duration AS cd_campaign_duration
        FROM {{ get_table('measurement_unified_campaign') }} uc
        INNER JOIN campaign_details cd
            ON uc.booking_id = cd.booking_id
            AND uc.channel_name = cd.channel_name
            AND uc.subchannel_name = cd.subchannel_name
            AND uc.marketing_type = cd.marketing_type
            AND uc.campaign_start_dt = cd.campaign_start_dt
            AND uc.post_campaign_dt = cd.campaign_end_dt
            AND cd.campaign_duration = 'POST'
    ),
    -- Get loyalty IDs from previous 'During' period (for POST campaigns only)
    instore_customer_data_post_period AS (
        SELECT DISTINCT
            cdc.loyalty_id AS post_loyalty_id,
            ud.uc_campaign_id AS post_campaign_id,
            ud.uc_channel_name AS post_channel_name,
            ud.uc_subchannel_name AS post_subchannel_name,
            ud.uc_marketing_type AS post_marketing_type
        FROM {{ get_table('customer_data_collection_aws') }} cdc
        INNER JOIN unified_data ud
            ON cdc.campaign_id = ud.uc_campaign_id
            AND cdc.channel_name = ud.uc_channel_name
            AND cdc.subchannel_name = ud.uc_subchannel_name
            AND cdc.marketing_type = ud.uc_marketing_type
            AND cdc.event_dt BETWEEN ud.uc_campaign_start_dt AND ud.uc_campaign_end_dt
    ),
    -- Get the set of media numbers and targeted IDs for our campaign set to join to location data
    ie_media_data AS (
        SELECT DISTINCT
            imd.master_campaign_id,
            imd.media_no,
            imd.targeted_id
        FROM {{ get_table('ie_media') }} imd
        INNER JOIN campaign_details cd
            ON imd.master_campaign_id = cd.campaign_id
    ),
    -- Get max timeid for base finance assets to avoid scalar subqueries
    max_timeid_cte AS (
        SELECT MAX(bfa_max.timeid) AS max_timeid
        FROM {{ get_table('base_finance_assets') }} bfa_max
    ),
    -- Get targeted store locations from finance assets data for all campaigns
    base_data AS (
        SELECT DISTINCT
            SPLIT_PART(bfa.asset_unique_id,'-',-1) AS targeted_id,
            cd.campaign_id AS base_campaign_id,
            cd.channel_name AS base_channel_name,
            cd.subchannel_name AS base_subchannel_name,
            cd.job_bag_number AS base_job_bag_number
        FROM {{ get_table('base_finance_assets') }} bfa
        INNER JOIN campaign_details cd
            ON bfa.job_bag_number = cd.job_bag_number
            AND bfa.service_type = cd.channel_name
            AND bfa.asset_name_media_host_prf_name = cd.subchannel_name
        INNER JOIN max_timeid_cte mt
            ON bfa.timeid = mt.max_timeid
        WHERE LOWER(bfa.campaign_status) IN ('campaign completed', 'hfss unknown')
          AND LOWER(bfa.media_host_name) LIKE 'sainsbur%'
    ),
    -- Match media data with finance assets to get store locations
    base_media_numbers AS (
        SELECT DISTINCT
            imd.media_no,
            bd.base_campaign_id,
            bd.base_channel_name,
            bd.base_subchannel_name
        FROM base_data bd
        INNER JOIN ie_media_data imd
            ON bd.targeted_id = imd.targeted_id
            AND bd.base_campaign_id = imd.master_campaign_id
    ),
    -- Get store locations for all campaigns
    store_location AS (
        SELECT DISTINCT
            il.location_key AS store_location_key,
            cd.campaign_id AS store_campaign_id,
            cd.channel_name AS store_channel_name,
            cd.subchannel_name AS store_subchannel_name
        FROM {{ get_table('ie_location') }} il
        INNER JOIN base_media_numbers bmn
            ON il.media_no = bmn.media_no
            AND il.master_campaign_id = bmn.base_campaign_id
        INNER JOIN campaign_details cd
            ON il.master_campaign_id = cd.campaign_id
            AND bmn.base_channel_name = cd.channel_name
            AND bmn.base_subchannel_name = cd.subchannel_name
    ),
    -- Get max load timestamp for campaign products across all campaigns
    max_load_ts AS (
        SELECT
            cpt.campaign_id AS max_campaign_id,
            cpt.channel_name AS max_channel_name,
            cpt.subchannel_name AS max_subchannel_name,
            MAX(cpt.load_ts) as max_load_ts_value
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN campaign_details cd
            ON cpt.campaign_id = cd.campaign_id
            AND cpt.channel_name = cd.channel_name
            AND cpt.subchannel_name = cd.subchannel_name
        GROUP BY cpt.campaign_id, cpt.channel_name, cpt.subchannel_name
    ),
    -- Get targeted SKUs for all campaigns
    get_targeted_skus AS (
        SELECT DISTINCT
            cpt.product_type AS sku_product_type,
            cpt.unique_brand_name AS sku_brand_name,
            cpt.item_cd AS sku_item_cd,
            cpt.campaign_id AS sku_campaign_id,
            cpt.channel_name AS sku_channel_name,
            cpt.subchannel_name AS sku_subchannel_name
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN max_load_ts mlt
            ON cpt.campaign_id = mlt.max_campaign_id
            AND cpt.channel_name = mlt.max_channel_name
            AND cpt.subchannel_name = mlt.max_subchannel_name
            AND cpt.load_ts = mlt.max_load_ts_value
    ),
    -- Get in-store relevant transactions for all campaigns using optimized tables
    get_instore_relevant_transaction_distinct AS (
        SELECT
            dcl.nectar_collector_card_num as loyalty_id,
            gfsti.transaction_id as transaction_key,
            gfsti.transaction_dt as event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts as event_time,
            'NA' as marketing_type,
            'In-store' as channel,
            cd.subchannel_name,
            cd.campaign_name,
            cd.campaign_id,
            'Purchase Transaction' as event_name,
            cd.booking_id,
            gts.sku_product_type as product_type,
            gts.sku_brand_name as unique_brand_name,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty,
            gfsti.item_sequence_num,
            cd.campaign_duration
        FROM {{ get_table('dim_customer_loyalty') }} dcl
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt
        INNER JOIN get_targeted_skus gts
            ON gts.sku_item_cd = gfsti.item_cd
        INNER JOIN campaign_details cd
            ON gts.sku_campaign_id = cd.campaign_id
            AND gts.sku_channel_name = cd.channel_name
            AND gts.sku_subchannel_name = cd.subchannel_name
            AND gfsti.transaction_dt BETWEEN cd.campaign_start_dt AND cd.campaign_end_dt
        INNER JOIN store_location sl
            ON gfsti.store_cd = sl.store_location_key
            AND sl.store_campaign_id = cd.campaign_id
            AND sl.store_channel_name = cd.channel_name
            AND sl.store_subchannel_name = cd.subchannel_name
        LEFT JOIN instore_customer_data_post_period icd
            ON dcl.nectar_collector_card_num = icd.post_loyalty_id
            AND icd.post_campaign_id = cd.campaign_id
            AND icd.post_channel_name = cd.channel_name
            AND icd.post_subchannel_name = cd.subchannel_name
            AND icd.post_marketing_type = cd.marketing_type
        WHERE dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
        AND (
            cd.campaign_duration != 'POST'
            OR icd.post_loyalty_id IS NOT NULL
        )
    ),
    -- Aggregate in-store relevant transactions
    instore_relevant_transaction AS (
        SELECT
            girtd.loyalty_id,
            girtd.event_date,
            girtd.event_time,
            girtd.transaction_key,
            girtd.item_cd,
            girtd.unique_brand_name,
            girtd.marketing_type,
            girtd.channel,
            girtd.subchannel_name,
            girtd.campaign_name,
            girtd.campaign_id,
            girtd.event_name,
            girtd.booking_id,
            girtd.product_type,
            SUM(girtd.net_retail_sales_amt) as net_targetted_sales,
            SUM(girtd.item_qty) as units
        FROM get_instore_relevant_transaction_distinct girtd
        GROUP BY girtd.loyalty_id, girtd.event_date, girtd.event_time, girtd.transaction_key, girtd.item_cd,
                 girtd.unique_brand_name, girtd.marketing_type, girtd.channel, girtd.subchannel_name,
                girtd.campaign_name, girtd.campaign_id, girtd.event_name, girtd.booking_id, girtd.product_type
    ),
    -- Create touchpoints for converted transactions across all campaigns
    instore_converted_touchpoint AS (
        SELECT DISTINCT
            irt.loyalty_id,
            irt.transaction_key,
            irt.event_date,
            DATEADD(millisecond, -100, irt.event_time) as event_time,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            irt.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM instore_relevant_transaction irt
        INNER JOIN campaign_details cd
            ON irt.campaign_id = cd.campaign_id
            AND irt.subchannel_name = cd.subchannel_name
    ),
    -- Create touchpoints for non-converted transactions using optimized tables
    instore_nonconverted_touchpoint AS (
        SELECT DISTINCT
            dcl.nectar_collector_card_num as loyalty_id,
            NULL as transaction_key,
            gfsti.transaction_dt as event_date,
            DATEADD(millisecond, -100, gfstb.transaction_end_ts) as event_time,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            cd.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM {{ get_table('dim_customer_loyalty') }} dcl
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt  -- Additional join condition for clustering
        INNER JOIN campaign_details cd
            ON gfsti.transaction_dt BETWEEN cd.campaign_start_dt AND cd.campaign_end_dt
        INNER JOIN store_location sl
            ON gfsti.store_cd = sl.store_location_key
            AND sl.store_campaign_id = cd.campaign_id
            AND sl.store_channel_name = cd.channel_name
            AND sl.store_subchannel_name = cd.subchannel_name
        LEFT JOIN instore_customer_data_post_period icd
            ON dcl.nectar_collector_card_num = icd.post_loyalty_id
            AND icd.post_campaign_id = cd.campaign_id
            AND icd.post_channel_name = cd.channel_name
            AND icd.post_subchannel_name = cd.subchannel_name
            AND icd.post_marketing_type = cd.marketing_type
        -- Use LEFT JOINs to exclude instead of NOT IN subqueries
        LEFT JOIN get_targeted_skus gts_exclude
            ON gts_exclude.sku_item_cd = gfsti.item_cd
            AND gts_exclude.sku_campaign_id = cd.campaign_id
            AND gts_exclude.sku_channel_name = cd.channel_name
            AND gts_exclude.sku_subchannel_name = cd.subchannel_name
        LEFT JOIN instore_converted_touchpoint ict_exclude
            ON ict_exclude.transaction_key = gfsti.transaction_id
            AND ict_exclude.campaign_id = cd.campaign_id
            AND ict_exclude.channel = cd.channel_name
            AND ict_exclude.subchannel = cd.subchannel_name
        WHERE dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
        -- Use LEFT JOIN results to exclude
        AND gts_exclude.sku_item_cd IS NULL
        AND ict_exclude.transaction_key IS NULL
        AND (
            cd.campaign_duration != 'POST'
            OR icd.post_loyalty_id IS NOT NULL
        )
    ),
    -- Get all loyalty IDs with their earliest interaction timestamp per campaign
    get_all_loyalty_ts AS (
        SELECT irt.loyalty_id, irt.campaign_id, irt.channel, irt.subchannel_name, irt.event_time
        FROM instore_relevant_transaction irt
        UNION ALL
        SELECT int1.loyalty_id, int1.campaign_id, int1.channel, int1.subchannel, int1.event_time
        FROM instore_nonconverted_touchpoint int1
    ),
    -- Get the minimum timestamp of interaction for every loyalty id as it would be used in the touchpoint for online tranasactions
    get_min_timestamp AS (
        SELECT galt.loyalty_id, galt.campaign_id, MIN(galt.event_time) as event_ts
        FROM get_all_loyalty_ts galt
        GROUP BY galt.loyalty_id, galt.campaign_id
    ),
    -- Get online transactions after the in-store interaction for every loyalty id
    get_online_transaction_distinct AS (
        SELECT
            gmt.loyalty_id,
            gfsti.transaction_id as transaction_key,
            gfsti.transaction_dt as event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts as event_time,
            'NA' as marketing_type,
            'Online' as channel,
            cd.subchannel_name,
            cd.campaign_name,
            gmt.campaign_id,
            'Purchase Transaction' as event_name,
            cd.booking_id,
            gts.sku_product_type as product_type,
            gts.sku_brand_name as unique_brand_name,
            gfsti.item_sequence_num,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty
        FROM get_min_timestamp gmt
        INNER JOIN {{ get_table('dim_customer_loyalty') }} dcl
            ON dcl.nectar_collector_card_num = gmt.loyalty_id
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt
        INNER JOIN get_targeted_skus gts
            ON gts.sku_item_cd = gfsti.item_cd
            AND gts.sku_campaign_id = gmt.campaign_id
        INNER JOIN campaign_details cd
            ON  gts.sku_campaign_id = cd.campaign_id
            AND gts.sku_channel_name = cd.channel_name
            AND gts.sku_subchannel_name = cd.subchannel_name
        WHERE gfsti.transaction_dt <= cd.campaign_end_dt
        AND gfstb.transaction_end_ts > gmt.event_ts
        AND dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_online_codes}}
    ),
    -- Aggregate online transactions
    get_online_transaction AS (
        SELECT
            gotd.loyalty_id, gotd.event_date, gotd.event_time, gotd.transaction_key, gotd.item_cd,
            gotd.unique_brand_name, gotd.marketing_type, gotd.channel, gotd.subchannel_name, gotd.campaign_name, gotd.campaign_id,
            gotd.event_name, gotd.booking_id, gotd.product_type,
            SUM(gotd.net_retail_sales_amt) as net_targetted_sales,
            SUM(gotd.item_qty) as units
        FROM get_online_transaction_distinct gotd
        GROUP BY gotd.loyalty_id, gotd.event_date, gotd.event_time, gotd.transaction_key, gotd.item_cd,
                 gotd.unique_brand_name, gotd.marketing_type, gotd.channel, gotd.subchannel_name, gotd.campaign_name, gotd.campaign_id,
                 gotd.event_name, gotd.booking_id, gotd.product_type
    ),
    -- Create online touchpoints (using in-store visit time as touchpoint)
    get_online_touchpoint AS (
        SELECT DISTINCT
            got.loyalty_id,
            got.transaction_key,
            DATE(gmt.event_ts) as event_date,
            gmt.event_ts,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            got.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM get_online_transaction got
        INNER JOIN get_min_timestamp gmt
            ON got.loyalty_id = gmt.loyalty_id
            AND got.campaign_id = gmt.campaign_id
        INNER JOIN campaign_details cd
            ON got.campaign_id = cd.campaign_id
            AND got.subchannel_name = cd.subchannel_name
    ),
    -- Combine all data
    instore_data_collection AS (
        -- In-store transaction data
        SELECT
            irt.loyalty_id,
            irt.transaction_key,
            irt.event_date as event_dt,
            irt.event_time as event_ts,
            irt.marketing_type,
            irt.channel as channel_name,
            'TXN' as subchannel_name,
            irt.campaign_name,
            irt.campaign_id,
            irt.event_name,
            irt.booking_id,
            irt.item_cd,
            irt.product_type,
            irt.unique_brand_name,
            irt.net_targetted_sales as net_sales_amt,
            irt.units as units_qty
        FROM instore_relevant_transaction irt

        UNION ALL

        -- In-store converted touchpoint data
        SELECT
            ict.loyalty_id,
            ict.transaction_key,
            ict.event_date as event_dt,
            ict.event_time as event_ts,
            ict.marketing_type,
            ict.channel as channel_name,
            ict.subchannel as subchannel_name,
            ict.campaign_name,
            ict.campaign_id,
            ict.event_name,
            ict.booking_id,
            NULL as item_cd,
            NULL as product_type,
            NULL as unique_brand_name,
            NULL as net_sales_amt,
            NULL as units_qty
        FROM instore_converted_touchpoint ict

        UNION ALL

        -- In-store non-converted touchpoint data
        SELECT
            int2.loyalty_id,
            NULL as transaction_key,
            int2.event_date as event_dt,
            int2.event_time as event_ts,
            int2.marketing_type,
            int2.channel as channel_name,
            int2.subchannel as subchannel_name,
            int2.campaign_name,
            int2.campaign_id,
            int2.event_name,
            int2.booking_id,
            NULL as item_cd,
            NULL as product_type,
            NULL as unique_brand_name,
            NULL as net_sales_amt,
            NULL as units_qty
        FROM instore_nonconverted_touchpoint int2

        UNION ALL

        -- Online transaction data (cross-channel attribution)
        SELECT
            got2.loyalty_id,
            got2.transaction_key,
            got2.event_date as event_dt,
            got2.event_time as event_ts,
            got2.marketing_type,
            got2.channel as channel_name,
            'TXN' as subchannel_name,
            got2.campaign_name,
            got2.campaign_id,
            got2.event_name,
            got2.booking_id,
            got2.item_cd,
            got2.product_type,
            got2.unique_brand_name,
            got2.net_targetted_sales as net_sales_amt,
            got2.units as units_qty
        FROM get_online_transaction got2

        UNION ALL

        -- Online touchpoint data
        SELECT
            gotp.loyalty_id,
            gotp.transaction_key,
            gotp.event_date as event_dt,
            gotp.event_ts,
            gotp.marketing_type,
            gotp.channel as channel_name,
            gotp.subchannel as subchannel_name,
            gotp.campaign_name,
            gotp.campaign_id,
            gotp.event_name,
            gotp.booking_id,
            NULL as item_cd,
            NULL as product_type,
            NULL as unique_brand_name,
            NULL as net_sales_amt,
            NULL as units_qty
        FROM get_online_touchpoint gotp
    )
    -- Final output
    SELECT
        idc.loyalty_id::VARCHAR(1000) as loyalty_id,
        COALESCE(idc.transaction_key::VARCHAR(1000), 'NA') as transaction_key,
        idc.event_dt::DATE as event_dt,
        idc.event_ts::TIMESTAMP_NTZ(9) as event_ts,
        idc.marketing_type::VARCHAR(1000) as marketing_type,
        idc.channel_name::VARCHAR(1000) as channel_name,
        idc.subchannel_name::VARCHAR(1000) as subchannel_name,
        idc.campaign_name::VARCHAR(1000) as campaign_name,
        idc.campaign_id::VARCHAR(1000) as campaign_id,
        idc.event_name::VARCHAR(1000) as event_name,
        idc.booking_id::VARCHAR(1000) as booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) as load_ts,
        COALESCE(idc.item_cd::NUMBER(18, 0), 0) as item_cd,
        COALESCE(idc.product_type::VARCHAR(1000), 'NA') as product_type,
        COALESCE(idc.unique_brand_name::VARCHAR(1000), 'NA') as unique_brand_name,
        COALESCE(idc.net_sales_amt::NUMBER(30, 4), 0) as net_sales_amt,
        COALESCE(idc.units_qty::NUMBER(30, 4), 0) as units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) as job_run_id
    FROM instore_data_collection idc
)
include_query_id = true
header = true;
