COPY INTO {{ get_stage('youtube_data') }}
FROM
(
WITH
youtube_channel_list AS (
    SELECT
        ces.campaign_id,
        ces.booking_id,
        ces.job_bag_number,
        ces.marketing_type,
        ces.channel_name,
        ces.subchannel_name,
        ces.campaign_name,
        ces.campaign_start_dt,
        ces.campaign_end_dt,
        ces.campaign_duration,
        ces.job_status,
        ces.marketing_hierarchy_cd
    FROM {{ get_table('measurement_campaign_execution_status') }} ces
    INNER JOIN {{ get_table('measurement_marketing_channel_hierarchy') }} mh
        ON ces.channel_name = mh.marketing_channel
        AND ces.subchannel_name = mh.marketing_subchannel
    WHERE ces.marketing_hierarchy_cd IN ({{ params.youtube_subchannel_list | join(', ') }})
       AND mh.in_scope_flag = TRUE
       AND mh.measurement_campaign_ready = TRUE
)
, yt_campaign_data AS (
    SELECT
        digital_trading_campaign_nk1,
        max (record_arrival_ts) AS record_arrival_ts
    FROM {{ get_table('digital_trading_campaign_channel_dmytio_link') }}
    JOIN youtube_channel_list AS yt
    ON digital_trading_campaign_channel_nk1 = yt.campaign_id
    GROUP BY digital_trading_campaign_nk1
)

, latest_data AS (
    SELECT
        digital_trading_campaign_nk1
    FROM {{ get_table('digital_trading_campaign_sat_youtube_table') }}
    WHERE
        (digital_trading_campaign_nk1, record_arrival_ts) IN
    (
        SELECT
            digital_trading_campaign_nk1,
            record_arrival_ts
        FROM yt_campaign_data
    )
)

, max_yt_sat_data AS (
    SELECT
        digital_trading_campaign_nk1
        , MAX(record_arrival_ts) AS record_arrival_ts
    FROM {{ get_table('digital_trading_campaign_sat_youtube_table') }}
    WHERE  digital_trading_campaign_nk1 IN (SELECT digital_trading_campaign_nk1 FROM latest_data)
    GROUP BY digital_trading_campaign_nk1
)

, job_bag_details AS (
    SELECT
        json_extract_path_text(DTP_INPUT, 'integrationDetails.jobBagId') AS job_bag_id
    FROM {{ get_table('digital_trading_campaign_sat_youtube_table') }}
    WHERE
        (digital_trading_campaign_nk1, record_arrival_ts) IN
    (
        SELECT
            digital_trading_campaign_nk1,
            record_arrival_ts
        FROM max_yt_sat_data
    )
)

, ab_audience_group AS (
    SELECT
        dtagds.job_bag_id,
        json_extract_path_text(audience.value, '_id') AS audience_id,
        MAX(dtagds.record_arrival_ts) AS max_time
    FROM {{ get_table('digital_trading_audience_group_dmabag_sat') }} AS dtagds,
    LATERAL flatten(INPUT => dtagds.audiences_data, OUTER => TRUE) AS audience
    WHERE
        json_extract_path_text(audience.value, 'name') NOT ilike '%do not use%'
        AND dtagds.job_bag_id IN (SELECT job_bag_id FROM job_bag_details)
    GROUP BY 1, 2
    UNION
    SELECT
        dtagds.job_bag_id,
        json_extract_path_text(model_audience.value, '_id') AS audience_id,
        MAX(dtagds.record_arrival_ts) AS max_time
    FROM {{ get_table('digital_trading_audience_group_dmabag_sat') }} AS dtagds,
    LATERAL flatten(INPUT => dtagds.modelled_audiences_data, OUTER => TRUE) AS model_audience
    WHERE
        json_extract_path_text(model_audience.value, 'name') NOT ilike '%do not use%'
        AND dtagds.job_bag_id IN (SELECT job_bag_id FROM job_bag_details)
    GROUP BY 1, 2
)

, get_target_audience AS (
    SELECT DISTINCT
        asd.loyalty_id
    FROM ab_audience_group AS aag join
    {{ get_table('audience_snapshot_deduped') }} AS asd USING (audience_id)
)

, max_load_ts AS (
    SELECT
        max(cpt.load_ts) AS load_ts,
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
    FROM {{ get_table('campaign_product_type_aws') }} cpt
    join (
        SELECT DISTINCT
            campaign_id,
            channel_name,
            subchannel_name,
            campaign_start_dt,
            campaign_end_dt
        FROM youtube_channel_list
        ) yt
    USING (campaign_id, channel_name, subchannel_name)
    GROUP BY
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
)

, get_targeted_skus AS (
    SELECT DISTINCT
        cpt.product_type,
        cpt.unique_brand_name,
        cpt.item_cd,
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
    FROM {{ get_table('campaign_product_type_aws') }} cpt JOIN
    max_load_ts ts USING (campaign_id, channel_name, subchannel_name, load_ts)
)

, get_start_date AS (
        SELECT
            min(mr.campaign_date) AS start_dt,
            yt.campaign_id AS campaign_id
        FROM {{ get_table('media_report') }} AS mr
        JOIN youtube_channel_list yt
        ON mr.insertion_order_id = yt.campaign_id
            and campaign_date >= yt.campaign_start_dt
            and campaign_date <= yt.campaign_end_dt
        group by yt.campaign_id
)

, get_fact_sale_transaction_basket AS (
    SELECT
        sales_origination_channel_cd,
        transaction_id,
        transaction_dt,
        nectar_card_num_hash,
        transaction_end_ts
    FROM {{ get_table('fact_sale_transaction_basket') }}
    where
        nectar_card_num_hash is not null
        and sales_origination_channel_cd in  (
            SELECT upper(value)::string AS codes
            FROM LATERAL FLATTEN(input => parse_json('{{ params.sales_origination_all_codes | tojson }}')))
         AND EXISTS (SELECT COUNT(1) FROM get_targeted_skus HAVING COUNT(1) > 0)
        AND transaction_dt BETWEEN (SELECT MIN(start_dt) FROM get_start_date) AND (SELECT MAX(campaign_end_dt) FROM youtube_channel_list)
)

-- {# /* getting relevant details FROM fact_sale_transaction_item. This cte is created to reduce read time FROM transaction_item table
-- AS it is reference multiple time. */ #}
, get_fact_sale_transaction_item AS (
        SELECT
            transaction_id,
            transaction_dt,
            item_cd,
            net_retail_sales_amt,
            item_qty,
            item_sequence_num,
            store_cd
        FROM {{ get_table('fact_sale_transaction_item') }}
        where
            net_retail_sales_amt > 0
        AND EXISTS (SELECT COUNT(1) FROM get_targeted_skus HAVING COUNT(1) > 0)
        AND transaction_dt BETWEEN (SELECT MIN(start_dt) FROM get_start_date) AND (SELECT MAX(campaign_end_dt) FROM youtube_channel_list)
)

-- /**********************
-- 1. Getting the transaction data FROM the fact_sale_transaction_basket and fact_sale_transaction_item tables
-- 2. Applying sales origination channel codes filters to find the channel name.
-- 3. Joining the get_target_audience cte to get the audience name and loyalty id. Audience name will be used AS subchannel
-- 4. Joining the get_targeted_skus cte to get the product type and unique brand name.
-- 5. Joining the get_fact_sale_transaction_item cte to get the transaction id, transaction DATE, item code, net retail sales amount, item quantity and item sequence number.
-- 6. Joining the get_fact_sale_transaction_basket cte to get the transaction end timestamp, nectar card number hash, transaction id and transaction DATE.
-- 7. Applying filters to get the transaction data for the given DATE range and sales origination channel codes.
-- ***********************
, get_transaction_data_distinct AS (
    SELECT DISTINCT
        gfstb.nectar_card_num_hash AS loyalty_id,
        gfsti.transaction_id AS transaction_key,
        gfsti.transaction_dt AS event_DATE,
        gfsti.item_cd,
        gfstb.transaction_end_ts AS event_time,
        'NA' AS marketing_type,
        case when
            gfstb.sales_origination_channel_cd in  (
                SELECT upper(value)::string AS codes
                FROM LATERAL FLATTEN(input => parse_json('{{ params.sales_origination_instore_codes | tojson }}'))
            )
            then 'In-store'
            else 'Online' end AS channel,
        yt.campaign_name,
        yt.campaign_id,
        'Purchase Transaction' AS event_name,
        yt.booking_id,
        gts.product_type,
        gts.unique_brand_name,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    FROM get_fact_sale_transaction_basket AS gfstb
    INNER JOIN get_target_audience AS gta
        ON gfstb.nectar_card_num_hash = gta.loyalty_id
    INNER JOIN get_fact_sale_transaction_item AS gfsti
        ON gfstb.transaction_id = gfsti.transaction_id
    INNER JOIN get_targeted_skus AS gts
        ON gts.item_cd = gfsti.item_cd
    INNER JOIN get_start_date gsd
        ON gts.campaign_id = gsd.campaign_id
    INNER JOIN youtube_channel_list yt
        ON gfsti.transaction_dt between gsd.start_dt and yt.campaign_end_dt
        AND gfstb.transaction_dt between gsd.start_dt and yt.campaign_end_dt
        AND gts.campaign_id = yt.campaign_id
        AND gts.channel_name = yt.channel_name
        AND gts.subchannel_name = yt.subchannel_name
)

-- {# /* Getting total sales amount and units for each loyalty id, transaction key, item code, unique brand name,
-- marketing type, channel, audience name, campaign name, campaign id, event name and booking id */ #}
, get_transaction_data AS (
    SELECT
        loyalty_id,
        event_DATE,
        event_time,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) AS net_targetted_sales,
        sum(item_qty) AS units
    FROM get_transaction_data_distinct
    group by
    loyalty_id,
        event_DATE,
        event_time,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type
)

-- {#
-- /**********************
-- 1. Adding touchpoint for loyalty ids who bought targetted skus
-- 2. Event_DATE for touchpoints is set to campaign start DATE AS it is the DATE when the touchpoint is created.
-- ***********************/
-- #}
, create_txn_touchpoint_data AS (
    SELECT DISTINCT
        loyalty_id,
        transaction_key,
        yt.campaign_start_dt AS event_DATE,
        to_timestamp(yt.campaign_start_dt|| ' 00:00:00') AS event_time,
        yt.marketing_type,
        yt.channel_name AS channel,
        yt.subchannel_name AS subchannel,
        yt.campaign_name,
        yt.campaign_id,
        'Touchpoint' AS event_name,
        yt.booking_id
    FROM get_transaction_data gtd
    JOIN youtube_channel_list yt USING (campaign_id, booking_id)
)

-- {#
-- /**********************
-- 1. The non_transaction_touchpoint is getting the touchpoint data for loyalty ids who did not buy targetted skus
-- 2. The event_DATE for touchpoints is set to campaign start DATE AS it is the DATE when the touchpoint is created.
-- ***********************/
-- #}
, non_transaction_touchpoint AS (
    SELECT DISTINCT
        loyalty_id,
        yt.campaign_start_dt AS event_DATE,
        to_timestamp(yt.campaign_start_dt|| ' 00:00:00') AS event_time,
        yt.marketing_type,
        yt.channel_name AS channel,
        yt.subchannel_name AS subchannel,
        yt.campaign_name,
        yt.campaign_id,
        'Touchpoint' AS event_name,
        yt.booking_id
    FROM get_target_audience
    cross join youtube_channel_list yt
    where
        loyalty_id not in
        (
            SELECT DISTINCT loyalty_id
            FROM create_txn_touchpoint_data
        )
)

-- {#
-- /**********************
-- 1. Getting transaction and touchpoint data for all the targeted loyalty_ids
-- 2. For touchpoints item_cd, product_type, unique_brand_name, net_sales_amt and units_qty are set to null AS these are not relevant for touchpoints.
-- 3. For non conversion transaction is set to null AS no relevant transaction was made.
-- ***********************/
-- #}
, yt_data_collection AS (
    SELECT
        loyalty_id,
        transaction_key,
        event_DATE AS event_dt,
        event_time AS event_ts,
        marketing_type,
        channel AS channel_name,
        'TXN' AS subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_targetted_sales AS net_sales_amt,
        units AS units_qty
    FROM get_transaction_data
    union all
    SELECT
        loyalty_id,
        transaction_key,
        event_DATE AS event_dt,
        event_time AS event_ts,
        marketing_type,
        channel AS channel_name,
        subchannel AS subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null AS item_cd,
        null AS product_type,
        null AS unique_brand_name,
        null AS net_sales_amt,
        null AS units_qty
    FROM create_txn_touchpoint_data
    union all
    SELECT
        loyalty_id,
        null AS transaction_key,
        event_DATE AS event_dt,
        event_time AS event_ts,
        marketing_type,
        channel AS channel_name,
        subchannel AS subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null AS item_cd,
        null AS product_type,
        null AS unique_brand_name,
        null AS net_sales_amt,
        null AS units_qty
    FROM non_transaction_touchpoint
)
-- {#
-- /**********************
-- 1. As touchpoints might contain null values we are using the coalesce function to replace null values with 'NA' or 0
-- 2. The load_ts is set to current timestamp and job_run_id is set to the invocation id
-- 3. This is a consoliDATEd data collection for all the touchpoints and transactions.
-- ***********************/
-- #}
SELECT
    loyalty_id::VARCHAR(1000) AS loyalty_id,
    COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
    event_dt::DATE AS event_dt,
    event_ts::TIMESTAMP_NTZ(9) AS event_ts,
    marketing_type::VARCHAR(1000) AS marketing_type,
    channel_name::VARCHAR(1000) AS channel_name,
    subchannel_name::VARCHAR(1000) AS subchannel_name,
    campaign_name::VARCHAR(1000) AS campaign_name,
    campaign_id::VARCHAR(1000) AS campaign_id,
    event_name::VARCHAR(1000) AS event_name,
    booking_id::VARCHAR(1000) AS booking_id,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
    COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
    COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
    COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
    COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
    COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
    CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
FROM yt_data_collection
)
include_query_id = true
header = true;
