CREATE OR REPLACE TEMP TABLE {{ get_table('instore_campaign_date_range_temp') }} AS
(
    SELECT DISTINCT
        MIN(mce.campaign_start_dt) as min_campaign_start_dt,
        MAX(mce.campaign_end_dt) as max_campaign_end_dt
    FROM {{ get_table('measurement_campaign_execution_status') }} AS mce
    WHERE mce.marketing_hierarchy_cd IN ({{ params.instore_hierarchy_codes | join(', ') }})
    AND (mce.job_status = 'Not Started' OR mce.job_status IS NULL)
);

CREATE OR REPLACE TEMP TABLE {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }}
CLUSTER BY(transaction_dt)
AS(
    SELECT
        fstb.transaction_end_ts,
        fstb.nectar_card_num_hash,
        fstb.transaction_id,
        fstb.transaction_dt,
        fstb.sales_origination_channel_cd
    FROM {{ get_table('fact_sale_transaction_basket') }} fstb
    CROSS JOIN {{ get_table('instore_campaign_date_range_temp') }} icdr
    WHERE fstb.nectar_card_num_hash IS NOT NULL
    AND fstb.transaction_dt BETWEEN icdr.min_campaign_start_dt AND icdr.max_campaign_end_dt
    AND fstb.sales_origination_channel_cd IN {{params.sales_origination_all_codes}}
);

CREATE OR REPLACE TEMP TABLE {{ get_table('fact_sale_transaction_item_instore_performant_temp') }}
CLUSTER BY(transaction_dt)
AS(
    SELECT
        fsti.transaction_id,
        fsti.transaction_dt,
        fsti.item_cd,
        fsti.net_retail_sales_amt,
        fsti.item_qty,
        fsti.item_sequence_num,
        fsti.store_cd
    FROM {{ get_table('fact_sale_transaction_item') }} fsti
    CROSS JOIN {{ get_table('instore_campaign_date_range_temp') }} icdr
    WHERE fsti.transaction_dt BETWEEN icdr.min_campaign_start_dt AND icdr.max_campaign_end_dt
    AND fsti.net_retail_sales_amt > 0
);

CREATE OR REPLACE TEMP TABLE store_location_temp
CLUSTER BY(campaign_id)
AS 
(
    WITH campaign_filters AS (
        SELECT DISTINCT
            job_bag_number,
            booking_id,
            campaign_id
        FROM {{ get_table('measurement_campaign_execution_status') }}
    )
    SELECT
        st_loc.campaign_id,
        f.value AS location_key,
        st_loc.booking_id
    FROM {{ get_table('campaign_booking_media_channel') }} st_loc
    INNER JOIN campaign_filters cf
        ON st_loc.booking_id = cf.job_bag_number
        OR st_loc.campaign_id = cf.job_bag_number
        OR st_loc.booking_id = cf.booking_id
        OR st_loc.campaign_id = cf.campaign_id
    CROSS JOIN LATERAL FLATTEN(INPUT => st_loc.store_cd_list) f
    GROUP BY 1, 2, 3
);

COPY INTO {{ get_stage('instore_data') }}
FROM
(
    WITH
    -- Get ALL available in-store campaigns
    campaign_details AS (
        SELECT
            mce.campaign_name,
            mce.channel_name,
            mce.subchannel_name,
            mce.campaign_start_dt,
            mce.campaign_end_dt,
            mce.campaign_id,
            mce.booking_id,
            mce.campaign_duration,
            mce.job_bag_number,
            mce.marketing_type, 
            mce.marketing_hierarchy_cd
        FROM {{ get_table('measurement_campaign_execution_status') }} mce
        WHERE mce.marketing_hierarchy_cd IN ({{ params.instore_hierarchy_codes | join(', ') }})
        AND (mce.job_status = 'Not Started' OR mce.job_status IS NULL)
    ),

    -- Handle POST campaign period logic for all campaigns
    unified_data AS (
        SELECT
            uc.campaign_id AS uc_campaign_id,
            uc.channel_name AS uc_channel_name,
            uc.subchannel_name AS uc_subchannel_name,
            uc.marketing_type AS uc_marketing_type,
            uc.campaign_start_dt AS uc_campaign_start_dt,
            uc.campaign_end_dt AS uc_campaign_end_dt,
            cd.booking_id AS cd_booking_id,
            cd.campaign_duration AS cd_campaign_duration
        FROM {{ get_table('measurement_unified_campaign_pollen') }} uc
        INNER JOIN campaign_details cd
            ON uc.job_bag_number = cd.booking_id
            AND uc.channel_name = cd.channel_name
            AND uc.subchannel_name = cd.subchannel_name
            AND uc.marketing_type = cd.marketing_type
            AND uc.campaign_start_dt = cd.campaign_start_dt
            AND LEAST(uc.post_campaign_dt, current_date()) <= cd.campaign_end_dt
    ),

    -- Get loyalty IDs from previous 'During' period (for POST campaigns only)
    instore_customer_data_post_period AS (
        SELECT DISTINCT
            cdc.loyalty_id AS post_loyalty_id,
            ud.uc_campaign_id AS post_campaign_id,
            ud.uc_channel_name AS post_channel_name,
            ud.uc_subchannel_name AS post_subchannel_name,
            ud.uc_marketing_type AS post_marketing_type
        FROM {{ get_table('customer_data_collection_aws') }} cdc
        LEFT JOIN unified_data ud
            ON cdc.campaign_id = ud.uc_campaign_id
            AND cdc.channel_name = ud.uc_channel_name
            AND cdc.subchannel_name = ud.uc_subchannel_name
            AND cdc.marketing_type = ud.uc_marketing_type
            AND cdc.event_dt BETWEEN ud.uc_campaign_start_dt AND ud.uc_campaign_end_dt
    ),

    store_location as (
        SELECT DISTINCT
             location_key, st_loc.campaign_id AS campaign_id
        FROM store_location_temp st_loc
        INNER JOIN campaign_details cd 
            ON st_loc.campaign_id = cd.campaign_id 
    ),

  -- Get max load timestamp for campaign products across all campaigns
    max_load_ts AS (
        SELECT
            cpt.campaign_id AS max_campaign_id,
            cpt.channel_name AS max_channel_name,
            cpt.subchannel_name AS max_subchannel_name,
            MAX(cpt.load_ts) as max_load_ts_value
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN campaign_details cd
            ON cpt.campaign_id = cd.campaign_id
            AND cpt.channel_name = cd.channel_name
            AND cpt.subchannel_name = cd.subchannel_name
        GROUP BY cpt.campaign_id, cpt.channel_name, cpt.subchannel_name
    ),

    -- Get targeted SKUs for all campaigns
    get_targeted_skus AS (
        SELECT DISTINCT
            cpt.product_type AS sku_product_type,
            cpt.unique_brand_name AS sku_brand_name,
            cpt.item_cd AS sku_item_cd,
            cpt.campaign_id AS sku_campaign_id,
            cpt.channel_name AS sku_channel_name,
            cpt.subchannel_name AS sku_subchannel_name
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN max_load_ts mlt
            ON cpt.campaign_id = mlt.max_campaign_id
            AND cpt.channel_name = mlt.max_channel_name
            AND cpt.subchannel_name = mlt.max_subchannel_name
            AND cpt.load_ts = mlt.max_load_ts_value
    ),

        -- Pre-calculate campaign date bounds for filtering
    campaign_bounds AS (
        SELECT 
            MIN(campaign_start_dt) AS min_campaign_start,
            MAX(campaign_end_dt) AS max_campaign_end
        FROM campaign_details
    ),

   -- Get in-store relevant transactions for all campaigns using optimized tables
    get_instore_relevant_transaction_distinct AS (
        SELECT
            dcl.nectar_collector_card_num as loyalty_id,
            gfsti.transaction_id as transaction_key,
            gfsti.transaction_dt as event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts as event_time,
            'NA' as marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            cd.campaign_id,
            'Purchase Transaction' as event_name,
            cd.booking_id,
            gts.sku_product_type as product_type,
            gts.sku_brand_name as unique_brand_name,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty,
            gfsti.item_sequence_num
        FROM {{ get_table('dim_customer_loyalty') }} dcl
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt
        INNER JOIN get_targeted_skus gts
            ON gts.sku_item_cd = gfsti.item_cd
        INNER JOIN campaign_details cd
            ON gts.sku_campaign_id = cd.campaign_id
            AND gts.sku_channel_name = cd.channel_name
            AND gts.sku_subchannel_name = cd.subchannel_name
            AND gfsti.transaction_dt BETWEEN cd.campaign_start_dt AND cd.campaign_end_dt
        INNER JOIN store_location sl
            ON gfsti.store_cd = sl.location_key
            AND cd.campaign_id = sl.campaign_id
        LEFT JOIN instore_customer_data_post_period icd
            ON dcl.nectar_collector_card_num = icd.post_loyalty_id
            AND icd.post_campaign_id = cd.campaign_id
            AND icd.post_channel_name = cd.channel_name
            AND icd.post_subchannel_name = cd.subchannel_name
            AND icd.post_marketing_type = cd.marketing_type
        WHERE dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
        AND CASE 
            WHEN cd.campaign_duration = 'Post' THEN icd.post_loyalty_id is not null
            ELSE true
        end
    ),

    -- Aggregate in-store relevant transactions
    instore_relevant_transaction AS (
        SELECT
            girtd.loyalty_id,
            girtd.event_date,
            girtd.event_time,
            girtd.transaction_key,
            girtd.item_cd,
            girtd.unique_brand_name,
            girtd.marketing_type,
            girtd.channel,
            girtd.subchannel,
            girtd.campaign_name,
            girtd.campaign_id,
            girtd.event_name,
            girtd.booking_id,
            girtd.product_type,
            SUM(girtd.net_retail_sales_amt) as net_targetted_sales,
            SUM(girtd.item_qty) as units
        FROM get_instore_relevant_transaction_distinct girtd
        GROUP BY girtd.loyalty_id, girtd.event_date, girtd.event_time, girtd.transaction_key, girtd.item_cd,
                 girtd.unique_brand_name, girtd.marketing_type, girtd.channel, girtd.subchannel, girtd.campaign_name, girtd.campaign_id,
                 girtd.event_name, girtd.booking_id, girtd.product_type
    ),
    -- Create touchpoints for converted transactions across all campaigns
    instore_converted_touchpoint AS (
        SELECT DISTINCT
            irt.loyalty_id,
            irt.transaction_key,
            irt.event_date,
            TIMEADD(millisecond, -100, irt.event_time) as event_time,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            irt.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM instore_relevant_transaction irt
        INNER JOIN campaign_details cd
            ON irt.campaign_id = cd.campaign_id
    ),
    -- Create touchpoints for non-converted transactions using optimized tables
    instore_nonconverted_touchpoint AS (
        SELECT DISTINCT
            dcl.nectar_collector_card_num as loyalty_id,
            NULL as transaction_key,
            gfsti.transaction_dt as event_date,
            TIMEADD(millisecond, -100, gfstb.transaction_end_ts) as event_time,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            cd.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM {{ get_table('dim_customer_loyalty') }} dcl
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt  -- Additional join condition for clustering
        INNER JOIN campaign_details cd
            ON gfsti.transaction_dt BETWEEN cd.campaign_start_dt AND cd.campaign_end_dt
        INNER JOIN store_location sl
            ON gfsti.store_cd = sl.location_key
            AND cd.campaign_id = sl.campaign_id
        LEFT JOIN instore_customer_data_post_period icd
            ON dcl.nectar_collector_card_num = icd.post_loyalty_id
            AND icd.post_campaign_id = cd.campaign_id
            AND icd.post_channel_name = cd.channel_name
            AND icd.post_subchannel_name = cd.subchannel_name
            AND icd.post_marketing_type = cd.marketing_type
        -- Use LEFT JOINs to exclude instead of NOT IN subqueries
        LEFT JOIN get_targeted_skus gts_exclude
            ON gts_exclude.sku_item_cd = gfsti.item_cd
            AND gts_exclude.sku_campaign_id = cd.campaign_id
            AND gts_exclude.sku_channel_name = cd.channel_name
            AND gts_exclude.sku_subchannel_name = cd.subchannel_name
        LEFT JOIN instore_converted_touchpoint ict_exclude
            ON ict_exclude.transaction_key = gfsti.transaction_id
            AND ict_exclude.campaign_id = cd.campaign_id
        WHERE dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
        -- Use LEFT JOIN results to exclude
        AND gts_exclude.sku_item_cd IS NULL
        AND ict_exclude.transaction_key IS NULL
        AND CASE
            WHEN cd.campaign_duration = 'Post' then icd.post_loyalty_id is not null
            ELSE true
        END
    ),
    -- Get all loyalty IDs with their earliest interaction timestamp per campaign
    get_all_loyalty_ts AS (
        SELECT irt.loyalty_id, irt.campaign_id, irt.event_time
        FROM instore_relevant_transaction irt
        UNION ALL
        SELECT int1.loyalty_id, int1.campaign_id, int1.event_time
        FROM instore_nonconverted_touchpoint int1
    ),
    get_min_timestamp AS (
        SELECT galt.loyalty_id, 
               galt.campaign_id,
               MIN(galt.event_time) as event_ts
        FROM get_all_loyalty_ts galt
        GROUP BY galt.loyalty_id, galt.campaign_id
    ),
    -- Get online transactions for cross-channel attribution using optimized tables
    get_online_transaction_distinct AS (
        SELECT
            gmt.loyalty_id,
            gfsti.transaction_id as transaction_key,
            gfsti.transaction_dt as event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts as event_time,
            'NA' as marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            gmt.campaign_id,
            'Purchase Transaction' as event_name,
            cd.booking_id,
            gts.sku_product_type as product_type,
            gts.sku_brand_name as unique_brand_name,
            gfsti.item_sequence_num,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty
        FROM get_min_timestamp gmt
        INNER JOIN {{ get_table('dim_customer_loyalty') }} dcl
            ON dcl.nectar_collector_card_num = gmt.loyalty_id
        INNER JOIN {{ get_table('fact_sale_transaction_basket_instore_performant_temp') }} gfstb
            ON gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        INNER JOIN {{ get_table('fact_sale_transaction_item_instore_performant_temp') }} gfsti
            ON gfsti.transaction_id = gfstb.transaction_id
            AND gfsti.transaction_dt = gfstb.transaction_dt
        INNER JOIN get_targeted_skus gts
            ON gts.sku_item_cd = gfsti.item_cd
            AND gts.sku_campaign_id = gmt.campaign_id
        INNER JOIN campaign_details cd
            ON cd.campaign_id = gmt.campaign_id
        WHERE gfsti.transaction_dt <= cd.campaign_end_dt
        AND gfstb.transaction_end_ts > gmt.event_ts
        AND dcl.nectar_collector_card_num != '~~'
        AND dcl.household_num != '0'
        AND UPPER(dcl.customer_account_type_name) = 'NECTAR'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_online_codes}}
    ),
    -- Aggregate online transactions
    get_online_transaction AS (
        SELECT
            gotd.loyalty_id, gotd.event_date, gotd.event_time, gotd.transaction_key, gotd.item_cd,
            gotd.unique_brand_name, gotd.marketing_type, gotd.channel, gotd.subchannel, gotd.campaign_name, gotd.campaign_id,
            gotd.event_name, gotd.booking_id, gotd.product_type,
            SUM(gotd.net_retail_sales_amt) as net_targetted_sales,
            SUM(gotd.item_qty) as units
        FROM get_online_transaction_distinct gotd
        GROUP BY gotd.loyalty_id, gotd.event_date, gotd.event_time, gotd.transaction_key, gotd.item_cd,
                 gotd.unique_brand_name, gotd.marketing_type, gotd.channel, gotd.subchannel, gotd.campaign_name, gotd.campaign_id,
                 gotd.event_name, gotd.booking_id, gotd.product_type
    ),
    -- Create online touchpoints (using in-store visit time as touchpoint)
    get_online_touchpoint AS (
        SELECT DISTINCT
            got.loyalty_id,
            got.transaction_key,
            DATE(gmt.event_ts) as event_date,
            gmt.event_ts,
            cd.marketing_type,
            cd.channel_name as channel,
            cd.subchannel_name as subchannel,
            cd.campaign_name,
            got.campaign_id,
            'Touchpoint' as event_name,
            cd.booking_id
        FROM get_online_transaction got
        INNER JOIN get_min_timestamp gmt
            ON got.loyalty_id = gmt.loyalty_id
            AND got.campaign_id = gmt.campaign_id
        INNER JOIN campaign_details cd
            ON cd.campaign_id = got.campaign_id
    ),
        -- -------------------
    instore_data_collection as (
        SELECT
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            '{{params.channel_name_instore}}' as channel_name,
            '{{params.subchannel_name}}' as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            item_cd,
            product_type,
            unique_brand_name,
            net_targetted_sales as net_sales_amt,
            units as units_qty
        FROM instore_relevant_transaction
        UNION ALL
        SELECT
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            channel as channel_name,
            subchannel as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM instore_converted_touchpoint
        UNION ALL
        SELECT
            loyalty_id,
            NULL AS transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            channel as channel_name,
            subchannel as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM instore_nonconverted_touchpoint
        UNION ALL
        SELECT
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            '{{params.channel_name_online}}' as channel_name,
            '{{params.subchannel_name}}' as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            item_cd,
            product_type,
            unique_brand_name,
            net_targetted_sales as net_sales_amt,
            units as units_qty
        FROM get_online_transaction
        UNION ALL
        SELECT
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_ts,
            marketing_type,
            channel as channel_name,
            subchannel as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM  get_online_touchpoint
    )


    -- Final optimized output
    SELECT
        loyalty_id::VARCHAR(1000) AS loyalty_id,
        COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
        event_dt::DATE AS event_dt,
        event_ts::TIMESTAMP_NTZ(9) AS event_ts,
        marketing_type::VARCHAR(1000) AS marketing_type,
        channel_name::VARCHAR(1000) AS channel_name,
        subchannel_name::VARCHAR(1000) AS subchannel_name,
        campaign_name::VARCHAR(1000) AS campaign_name,
        campaign_id::VARCHAR(1000) AS campaign_id,
        event_name::VARCHAR(1000) AS event_name,
        booking_id::VARCHAR(1000) AS booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
        COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
        COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
        COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
        COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
        COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
    FROM instore_data_collection


)
include_query_id = true
header = true;
