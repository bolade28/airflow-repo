CREATE TEMP TABLE {{ get_table('magazine_campaign_date_range_temp') }}
AS
(
    SELECT DISTINCT
        min(campaign_start_dt) as min_campaign_start_dt,
        max(campaign_end_dt) as max_campaign_end_dt
    FROM {{ get_table('measurement_campaign_execution_status') }} AS mce
    WHERE channel_name = 'Sainburys Magazine'
    AND(mce.job_status = 'Not Started' OR mce.job_status IS NULL)
    );

CREATE TEMP TABLE {{ get_table('mag_fact_sale_transaction_basket_performant_temp') }}
CLUSTER BY(transaction_dt)
AS
(
    SELECT
       transaction_end_ts,
       nectar_card_num_hash,
       transaction_id,
       transaction_dt,
       sales_origination_channel_cd,
       transaction_key
    FROM {{ get_table('fact_sale_transaction_basket') }}
    CROSS JOIN {{ get_table('magazine_campaign_date_range_temp') }} AS catdr
    WHERE transaction_dt BETWEEN catdr.min_campaign_start_dt AND catdr.max_campaign_end_dt
);

CREATE TEMP TABLE {{ get_table('mag_fact_sale_transaction_item_performant_temp') }}
CLUSTER BY(transaction_dt)
AS
(
    SELECT
        transaction_id,
        transaction_dt,
        item_cd,
        net_retail_sales_amt,
        item_qty,
        item_sequence_num,
        store_cd
    FROM {{ get_table('fact_sale_transaction_item') }}
    CROSS JOIN {{ get_table('magazine_campaign_date_range_temp') }} AS catdr
    WHERE transaction_dt BETWEEN catdr.min_campaign_start_dt AND catdr.max_campaign_end_dt
);

COPY INTO {{ get_stage('magazine_data') }}
FROM
(
    WITH campaign_details AS (
            SELECT
                mce.campaign_name,
                mce.channel_name,
                mce.subchannel_name,
                mce.campaign_start_dt as start_date,
                mce.campaign_end_dt as end_date,
                mce.campaign_id,
                mce.booking_id,
                mce.campaign_duration,
                mce.job_bag_number as job_bag_id,
                mce.marketing_type
            FROM {{ get_table('measurement_campaign_execution_status') }} as mce
            WHERE mce.channel_name = '{{ params.channel_type }}' --'Magazine'
            AND (mce.job_status = '{{ params.job_status }}' OR mce.job_status IS NULL)
        ),

    -- This CTE now effectively replaces `campaignData` FROM the Jinja macro
    -- It flattens all relevant campaign details for subsequent joins
    campaign_details_flattened as (
        SELECT
            campaign_name,
            channel_name,
            start_date,
            end_date,
            campaign_id,
            subchannel_name,
            booking_id,
            campaign_duration,
            job_bag_id,
            marketing_type
        FROM campaign_details
    ),

    -- Common CTEs that are used by both 'During' and 'Post' scenarios
    max_load_ts as (
        SELECT
            ccd.campaign_id,
            ccd.channel_name,
            ccd.subchannel_name,
            max(cpt.load_ts) as load_ts
        FROM {{ get_table('campaign_product_type_aws') }} as cpt
        INNER JOIN campaign_details_flattened as ccd
            ON cpt.campaign_id = ccd.campaign_id
            AND cpt.channel_name = ccd.channel_name
            AND cpt.subchannel_name = ccd.subchannel_name
        GROUP BY 1, 2, 3
    ),

    get_targeted_skus as (
        SELECT DISTINCT
            cpt.product_type,
            cpt.unique_brand_name,
            cpt.item_cd,
            ccd.campaign_id,   -- Add campaign_id to join on later
            ccd.channel_name,   -- Add channel_name to join on later
            ccd.subchannel_name -- Add subchannel_name to join on later
        FROM {{ get_table('campaign_product_type_aws') }} as cpt
        INNER JOIN campaign_details_flattened as ccd -- Join to filter by current campaign context
            ON cpt.campaign_id = ccd.campaign_id
            AND cpt.channel_name = ccd.channel_name
            AND cpt.subchannel_name = ccd.subchannel_name
        INNER JOIN max_load_ts as mlt
            ON cpt.campaign_id = mlt.campaign_id
            AND cpt.channel_name = mlt.channel_name
            AND cpt.subchannel_name = mlt.subchannel_name
            AND cpt.load_ts = mlt.load_ts
    ),

    -- Common transaction tables (filters are now based on individual campaign ranges)
    get_fact_sale_transaction_basket as (
        SELECT
            transaction_end_ts,
            nectar_card_num_hash,
            transaction_id,
            transaction_dt,
            sales_origination_channel_cd
        FROM {{ get_table('mag_fact_sale_transaction_basket_performant_temp') }} as gfstb
        CROSS JOIN campaign_details_flattened as ccd
        WHERE
            gfstb.nectar_card_num_hash is not null
            -- Date filter needs to be broad enough to cover all campaigns, or apply per-campaign
            -- For a combined query, this should be the union of all campaign date ranges
            AND gfstb.transaction_dt between ccd.start_date AND ccd.end_date
            AND gfstb.sales_origination_channel_cd in (
                SELECT all_codes.value
                FROM table(flatten(input => {{ params.sales_origination_all_codes }}::array)) as all_codes
            )
    ),

    get_fact_sale_transaction_item as (
        SELECT
            transaction_id,
            transaction_dt,
            item_cd,
            net_retail_sales_amt,
            item_qty,
            item_sequence_num,
            store_cd
        FROM {{ get_table('mag_fact_sale_transaction_item_performant_temp') }} as gfsti
        CROSS JOIN campaign_details_flattened as ccd
        WHERE
            gfsti.transaction_dt between ccd.start_date AND ccd.end_date
            AND gfsti.net_retail_sales_amt > 0
    ),

    dim_customer_loyalty as (
        SELECT
            nectar_collector_card_num,
            customer_loyalty_cd
        FROM {{ get_table('dim_customer_loyalty') }}
        WHERE nectar_collector_card_num != '~~'
    ),

    --- DURING CAMPAIGN LOGIC ---
    magazine_date_lookup_during as (
        SELECT distinct
            start_date,
            end_date,
            sku_no
        FROM {{ get_table('magazine_date_lookup') }}
    ),

    magazine_transaction_data_during as (
        SELECT distinct
            dcl.nectar_collector_card_num as loyalty_id,
            gfstb.transaction_end_ts as event_time,
            date(gfstb.transaction_end_ts) as event_date,
            ccd.campaign_id -- Keep campaign context
        FROM get_fact_sale_transaction_item as gfsti
        INNER JOIN get_fact_sale_transaction_basket as gfstb
            on gfsti.transaction_id = gfstb.transaction_id
        INNER JOIN dim_customer_loyalty as dcl
            on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
        INNER JOIN magazine_date_lookup_during as mdl
            on gfsti.item_cd = mdl.sku_no
        INNER JOIN campaign_details_flattened as ccd
            on mdl.start_date = ccd.start_date
            AND mdl.end_date = ccd.end_date
            AND ccd.campaign_duration = 'During' -- Filter for 'During' campaigns
        WHERE
            gfstb.transaction_end_ts >= mdl.start_date
            AND gfstb.transaction_end_ts <= mdl.end_date
            AND gfstb.sales_origination_channel_cd in (
                SELECT instore_codes.value
                FROM table(flatten(input => {{ params.sales_origination_instore_codes }}::array)) as instore_codes
            )
    ),

    magazine_loyalty_data_during as (
        SELECT
            loyalty_id,
            min(event_time) as event_time,
            min(event_date) as event_date,
            campaign_id
        FROM magazine_transaction_data_during
        group by loyalty_id, campaign_id
    ),

    --- POST CAMPAIGN LOGIC ---
    unified_campaign_post as (
        SELECT
            campaign_id,
            booking_id,
            channel_name,
            subchannel_name,
            marketing_type,
            campaign_start_dt,
            campaign_end_dt, -- This is the original campaign end date, not the post_campaign_dt
            post_campaign_dt,
            load_ts
        FROM {{ get_table('measurement_unified_campaign') }}
        WHERE load_ts = (SELECT max(load_ts) FROM {{ get_table('measurement_unified_campaign') }})
    ),

    magazine_loyalty_data_post as (
        SELECT
            cdc.loyalty_id,
            min(cdc.event_ts) as event_time,
            min(cdc.event_dt) as event_date,
            ccd.campaign_id -- Keep campaign context
        FROM {{ get_table('customer_data_collection') }} as cdc
        INNER JOIN unified_campaign_post as ucp
            on cdc.campaign_id = ucp.campaign_id
            AND cdc.channel_name = ucp.channel_name
            AND cdc.subchannel_name = ucp.subchannel_name
            AND cdc.marketing_type = ucp.marketing_type
        INNER JOIN campaign_details_flattened as ccd
            on cdc.campaign_id = ccd.campaign_id
            AND ccd.campaign_duration = 'POST' -- Filter for 'Post' campaigns
            AND ccd.booking_id = ucp.booking_id -- Assuming booking_id matches
        WHERE
            cdc.event_dt between ucp.campaign_start_dt AND ucp.campaign_end_dt -- Using the original campaign end date
        group by cdc.loyalty_id, ccd.campaign_id
    ),

    -- Combine loyalty data for 'During' AND 'Post'
    magazine_loyalty_data_all as (
        SELECT
            loyalty_id,
            event_time,
            event_date,
            campaign_id
        FROM magazine_loyalty_data_during
        union all
        SELECT
            loyalty_id,
            event_time,
            event_date,
            campaign_id
        FROM magazine_loyalty_data_post
    ),

    get_magazine_sku_transaction_data_distinct as (
        SELECT distinct
            dcl.nectar_collector_card_num as loyalty_id,
            gfsti.transaction_id as transaction_key,
            gfsti.transaction_dt as event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts as event_time,
            ccd.marketing_type, -- Now dynamic
            case when gfstb.sales_origination_channel_cd in (
                SELECT instore_codes.value
                FROM table(flatten(input => {{ params.sales_origination_instore_codes }}::array)) as instore_codes
            ) then 'In-store'
            else 'Online' end as channel_name,
            ccd.campaign_name, -- Now dynamic
            ccd.campaign_id,   -- Now dynamic
            'Purchase Transaction' as event_name,
            ccd.booking_id,    -- Now dynamic
            gts.product_type,
            gts.unique_brand_name,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty,
            gfsti.item_sequence_num,
            ccd.subchannel_name -- Include subchannel for consistency if needed later
        FROM get_fact_sale_transaction_item as gfsti
        INNER JOIN get_fact_sale_transaction_basket as gfstb
            on gfsti.transaction_id = gfstb.transaction_id
        INNER JOIN magazine_loyalty_data_all as mld
            on gfstb.nectar_card_num_hash = mld.loyalty_id
            AND gfstb.transaction_end_ts >= mld.event_time -- This condition is critical
        INNER JOIN dim_customer_loyalty as dcl
            on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
        INNER JOIN get_targeted_skus as gts
            on gfsti.item_cd = gts.item_cd
            AND gts.campaign_id = mld.campaign_id -- Join on campaign_id
        INNER JOIN campaign_details_flattened as ccd
            on mld.campaign_id = ccd.campaign_id
        WHERE
            gfstb.sales_origination_channel_cd in (
                SELECT magazine_codes.value
                FROM table(flatten(input => {{ params.sales_origination_all_codes }}::array)) as magazine_codes
            )
    ),

    magazine_sku_transaction_data as (
        SELECT
            loyalty_id,
            event_date,
            event_time,
            transaction_key,
            item_cd,
            unique_brand_name,
            marketing_type,
            channel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            product_type,
            sum(net_retail_sales_amt) as net_targetted_sales,
            sum(item_qty) as units
        FROM get_magazine_sku_transaction_data_distinct
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
    ),

    magazine_targetted_sku_touchpoint_data as (
        SELECT distinct
            mst.loyalty_id,
            mst.unique_brand_name,
            mst.marketing_type,
            mst.channel_name,
            ccd.subchannel_name, -- FROM campaign details
            mst.campaign_name,
            mst.campaign_id,
            mld.event_date,
            mld.event_time,
            mst.transaction_key,
            'Touchpoint' as event_name,
            mst.booking_id
        FROM magazine_sku_transaction_data as mst
        INNER JOIN magazine_loyalty_data_all as mld
            on mst.loyalty_id = mld.loyalty_id
            AND mst.campaign_id = mld.campaign_id
        INNER JOIN campaign_details_flattened as ccd
            on mst.campaign_id = ccd.campaign_id
    ),

    magazine_non_targetted_sku_touchpoint_data as (
        SELECT distinct
            mld.loyalty_id,
            ccd.marketing_type,
            ccd.channel_name,
            ccd.subchannel_name,
            ccd.campaign_name,
            ccd.campaign_id,
            mld.event_date,
            mld.event_time,
            null as transaction_key,
            'Touchpoint' as event_name,
            ccd.booking_id
        FROM magazine_loyalty_data_all as mld
        CROSS JOIN campaign_details_flattened as ccd -- Use CROSS JOIN if a loyalty_id can only belong to one campaign in this context,
                                                    -- or adjust to INNER JOIN if mld already implies a specific campaign.
                                                    -- Given mld now has campaign_id, an INNER JOIN is better here.
        WHERE
            mld.campaign_id = ccd.campaign_id -- Join mld to ccd on campaign_id
            AND mld.loyalty_id not in (
                SELECT distinct loyalty_id
                FROM magazine_sku_transaction_data
                WHERE campaign_id = mld.campaign_id -- Exclude specific to this campaign
            )
    ),

    magazine_data_collection as (
        SELECT distinct
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            channel_name,
            'TXN' as subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            item_cd,
            product_type,
            unique_brand_name,
            net_targetted_sales as net_sales_amt,
            units as units_qty
        FROM magazine_sku_transaction_data
        union all
        SELECT distinct
            loyalty_id,
            transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            channel_name,
            subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id, -- Corrected
            null as item_cd,
            null as product_type,
            null as unique_brand_name,
            null as net_sales_amt,
            null as units_qty
        FROM magazine_targetted_sku_touchpoint_data
        union all
        SELECT distinct
            loyalty_id,
            null as transaction_key,
            event_date as event_dt,
            event_time as event_ts,
            marketing_type,
            channel_name,
            subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            null as item_cd,
            null as product_type,
            null as unique_brand_name,
            null as net_sales_amt,
            null as units_qty
        FROM magazine_non_targetted_sku_touchpoint_data
    )

    SELECT
        loyalty_id::varchar(1000) as loyalty_id,
        coalesce(transaction_key::varchar(1000), 'NA') as transaction_key,
        event_dt::date as event_dt,
        event_ts::timestamp_ntz(9) as event_ts,
        marketing_type::varchar(1000) as marketing_type,
        channel_name::varchar(1000) as channel_name,
        subchannel_name::varchar(1000) as subchannel_name,
        campaign_name::varchar(1000) as campaign_name,
        campaign_id::varchar(1000) as campaign_id,
        event_name::varchar(1000) as event_name,
        booking_id::varchar(1000) as booking_id,
        current_timestamp::timestamp_ntz(9) as load_ts,
        coalesce(item_cd::number(18, 0), 0) as item_cd,
        coalesce(product_type::varchar(1000), 'NA') as product_type,
        coalesce(unique_brand_name::varchar(1000), 'NA') as unique_brand_name,
        coalesce(net_sales_amt::number(30, 4), 0) as net_sales_amt,
        coalesce(units_qty::number(30, 4), 0) as units_qty,
        '{{ params.correlation_id }}'::varchar(36) as job_run_id
    FROM magazine_data_collection
)
include_query_id = true
header = true;
