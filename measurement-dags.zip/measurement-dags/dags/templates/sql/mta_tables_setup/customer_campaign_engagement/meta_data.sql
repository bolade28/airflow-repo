COPY INTO {{ get_stage('meta_data') }}
FROM
(
    WITH
        -- Get ALL available Meta campaigns with early date filtering
        campaign_details AS (
            SELECT
                campaign_name,
                channel_name,
                subchannel_name,
                campaign_start_dt,
                campaign_end_dt,
                campaign_id,
                booking_id,
                campaign_duration,
                job_bag_number,
                marketing_type
            FROM {{ get_table('measurement_campaign_execution_status') }}
            WHERE channel_name = 'Meta'
            AND (job_status = 'Not Started' OR job_status IS NULL)
        ),

        -- Pre-calculate campaign date bounds for filtering
        campaign_bounds AS (
            SELECT 
                MIN(campaign_start_dt) AS min_campaign_start,
                MAX(campaign_end_dt) AS max_campaign_end
            FROM campaign_details
        ),

        -- Get max record arrival timestamp for audience groups
        ab_audience_max AS (
            SELECT
                digital_trading_audience_group_nk1,
                MAX(record_arrival_ts) AS record_arrival_ts
            FROM {{ get_table('digital_trading_audience_group_dmabag_sat') }}
            WHERE job_bag_id ILIKE '%nec%' OR job_bag_id IS NULL
            GROUP BY digital_trading_audience_group_nk1
        ),

        -- Get latest audience group records with pre-parsed JSON
        ab_audience_latest AS (
            SELECT
                digital_trading_audience_group_nk1,
                TRY_PARSE_JSON(audiences_data) as parsed_audiences_data,
                TRY_PARSE_JSON(modelled_audiences_data) as parsed_modelled_audiences_data
            FROM {{ get_table('digital_trading_audience_group_dmabag_sat') }} agl
            WHERE EXISTS (
                SELECT 1 FROM ab_audience_max aam 
                WHERE aam.digital_trading_audience_group_nk1 = agl.digital_trading_audience_group_nk1
                AND aam.record_arrival_ts = agl.record_arrival_ts
            )
        ),

        -- Combined audience data extraction (both regular and modelled)
        -- Changed UNION ALL to UNION to prevent duplicate audiences
        ab_audience_union AS (
            -- Regular audience data
            SELECT DISTINCT
                aal.digital_trading_audience_group_nk1,
                JSON_EXTRACT_PATH_TEXT(audience_data.value, 'channels') AS docids_raw,
                JSON_EXTRACT_PATH_TEXT(audience_data.value, '_id') AS aud_id,
                JSON_EXTRACT_PATH_TEXT(audience_data.value, 'name') AS subchannel_name
            FROM ab_audience_latest AS aal,
            LATERAL FLATTEN(input => aal.parsed_audiences_data) AS audience_data
            
            UNION
            
            -- Modelled audience data
            SELECT DISTINCT
                aal.digital_trading_audience_group_nk1,
                JSON_EXTRACT_PATH_TEXT(modelled_audience.value, 'channels') AS docids_raw,
                JSON_EXTRACT_PATH_TEXT(modelled_audience.value, '_id') AS aud_id,
                JSON_EXTRACT_PATH_TEXT(modelled_audience.value, 'name') AS subchannel_name
            FROM ab_audience_latest AS aal,
            LATERAL FLATTEN(input => aal.parsed_modelled_audiences_data) AS modelled_audience
        ),

        -- Extract document IDs from audience data
        ab_audience_filtered AS (
            SELECT DISTINCT
                aau.digital_trading_audience_group_nk1,
                aau.aud_id,
                aau.subchannel_name,
                JSON_EXTRACT_PATH_TEXT(docids.value, 'documentId') AS docid
            FROM ab_audience_union AS aau,
            LATERAL FLATTEN(input => TRY_PARSE_JSON(aau.docids_raw)) AS docids
            WHERE aau.docids_raw != '[]'
            AND aau.docids_raw IS NOT NULL
        ),

        -- Optimized adset link processing
        adset_link_latest AS (
            SELECT DISTINCT
                digital_trading_lineitem_channel_nk1,
                digital_trading_lineitem_nk1,
                digital_trading_campaign_nk1
            FROM {{ get_table('digital_trading_lineitem_channel_dmfbas_link') }} all_links
            WHERE (digital_trading_lineitem_channel_nk1, digital_trading_lineitem_nk1,
                digital_trading_campaign_nk1, record_arrival_ts) IN (
                SELECT 
                    digital_trading_lineitem_channel_nk1,
                    digital_trading_lineitem_nk1,
                    digital_trading_campaign_nk1,
                    MAX(record_arrival_ts) AS record_arrival_ts
                FROM {{ get_table('digital_trading_lineitem_channel_dmfbas_link') }}
                GROUP BY digital_trading_lineitem_channel_nk1, digital_trading_lineitem_nk1, digital_trading_campaign_nk1
            )
        ),

        -- Optimized adset processing
        adset_latest AS (
            SELECT DISTINCT
                al.digital_trading_lineitem_nk1,
                JSON_EXTRACT_PATH_TEXT(audience_list.value, 'id') AS adset_document_id
            FROM (
                SELECT DISTINCT
                    digital_trading_lineitem_nk1,
                    target_custom_audience_list
                FROM {{ get_table('digital_trading_lineitem_dmfbas_sat') }} all_adsets
                WHERE (digital_trading_lineitem_nk1, adset_name, record_arrival_ts) IN (
                    SELECT 
                        digital_trading_lineitem_nk1,
                        adset_name,
                        MAX(record_arrival_ts) AS record_arrival_ts
                    FROM {{ get_table('digital_trading_lineitem_dmfbas_sat') }}
                    GROUP BY digital_trading_lineitem_nk1, adset_name
                )
            ) AS al,
            LATERAL FLATTEN(input => al.target_custom_audience_list) AS audience_list
            WHERE audience_list.index = 0
        ),

        -- Optimized FB campaign processing
        fb_campaign_latest AS (
            SELECT DISTINCT
                digital_trading_campaign_nk1,
                job_bag_id
            FROM {{ get_table('digital_trading_campaign_sat') }} fc
            WHERE EXISTS (
                SELECT 1 FROM campaign_details cd 
                WHERE fc.job_bag_id = cd.campaign_id
            )
            AND (digital_trading_campaign_nk1, record_arrival_ts) IN (
                SELECT 
                    digital_trading_campaign_nk1,
                    MAX(record_arrival_ts) AS record_arrival_ts
                FROM {{ get_table('digital_trading_campaign_sat') }} fc2
                WHERE EXISTS (
                    SELECT 1 FROM campaign_details cd2 
                    WHERE fc2.job_bag_id = cd2.campaign_id
                )
                GROUP BY digital_trading_campaign_nk1
            )
        ),

        -- Optimized FB audience processing
        fb_audience_latest AS (
            SELECT DISTINCT
                digital_trading_audience_channel_nk1,
                digital_trading_audience_nk1
            FROM {{ get_table('digital_trading_audience_channel_dmfbau_link') }} all_audiences
            WHERE (digital_trading_audience_nk1, digital_trading_audience_channel_nk1, record_arrival_ts) IN (
                SELECT 
                    digital_trading_audience_nk1,
                    digital_trading_audience_channel_nk1,
                    MAX(record_arrival_ts) AS record_arrival_ts
                FROM {{ get_table('digital_trading_audience_channel_dmfbau_link') }}
                GROUP BY digital_trading_audience_nk1, digital_trading_audience_channel_nk1
            )
        ),

        -- Get FB loyal customers with campaign attribution
        fb_loyal AS (
            SELECT DISTINCT
                asd.loyalty_id,
                aaf.aud_id,
                fcl.job_bag_id AS campaign_id
            FROM fb_campaign_latest AS fcl
            INNER JOIN adset_link_latest AS adl
                ON fcl.digital_trading_campaign_nk1 = adl.digital_trading_campaign_nk1
            INNER JOIN adset_latest AS ad
                ON adl.digital_trading_lineitem_nk1 = ad.digital_trading_lineitem_nk1
            INNER JOIN fb_audience_latest AS fal
                ON ad.adset_document_id = fal.digital_trading_audience_channel_nk1
            INNER JOIN ab_audience_filtered AS aaf
                ON fal.digital_trading_audience_nk1 = aaf.docid
            INNER JOIN {{ get_table('audience_snapshot_deduped') }} AS asd
                ON aaf.aud_id = asd.audience_id
        ),

        -- Combined and optimized transaction data (basket + item in single CTE)
        filtered_transactions AS (
            SELECT
                gfstb.transaction_end_ts,
                gfstb.nectar_card_num_hash,
                gfsti.transaction_id,
                gfsti.transaction_dt,
                gfstb.sales_origination_channel_cd,
                gfsti.item_cd,
                gfsti.net_retail_sales_amt,
                gfsti.item_qty,
                gfsti.item_sequence_num,
                gfsti.store_cd
            FROM {{ get_table('fact_sale_transaction_basket') }} gfstb
            INNER JOIN {{ get_table('fact_sale_transaction_item') }} gfsti
                ON gfstb.transaction_id = gfsti.transaction_id
                AND gfstb.transaction_dt = gfsti.transaction_dt
            CROSS JOIN campaign_bounds cb
            WHERE gfstb.nectar_card_num_hash IS NOT NULL
            AND gfstb.transaction_dt BETWEEN cb.min_campaign_start AND cb.max_campaign_end
            AND gfsti.transaction_dt BETWEEN cb.min_campaign_start AND cb.max_campaign_end
            AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_all_codes}}
            AND gfsti.net_retail_sales_amt > 0
        ),

        -- Optimized targeted SKUs processing
        get_targeted_skus AS (
            SELECT DISTINCT
                cpt.product_type,
                cpt.unique_brand_name,
                cpt.item_cd,
                cpt.campaign_id,
                cpt.channel_name,
                cpt.subchannel_name
            FROM {{ get_table('campaign_product_type_aws') }} cpt
            WHERE EXISTS (
                SELECT 1 FROM campaign_details cd
                WHERE cpt.campaign_id = cd.campaign_id
                AND cpt.channel_name = cd.channel_name
                AND cpt.subchannel_name = cd.subchannel_name
            )
            AND cpt.load_ts = (
                SELECT MAX(cpt2.load_ts)
                FROM {{ get_table('campaign_product_type_aws') }} cpt2
                WHERE cpt2.campaign_id = cpt.campaign_id
                AND cpt2.channel_name = cpt.channel_name
                AND cpt2.subchannel_name = cpt.subchannel_name
            )
        ),

        -- Optimized Meta transaction data
        -- Changed marketing_type from 'NA' to cd.marketing_type
        fb_txn AS (
            SELECT
                dcl.nectar_collector_card_num AS loyalty_id,
                ft.transaction_id AS transaction_key,
                ft.transaction_dt AS event_date,
                ft.item_cd,
                ft.transaction_end_ts AS event_time,
                CASE
                    WHEN ft.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
                    THEN 'In-store'
                    ELSE 'Online'
                END AS channel_name,
                cd.marketing_type,  -- CHANGED FROM 'NA'
                cd.campaign_name,
                cd.campaign_id,
                'Purchase Transaction' AS event_name,
                cd.booking_id,
                gts.product_type,
                gts.unique_brand_name,
                SUM(ft.net_retail_sales_amt) AS net_targetted_sales,
                SUM(ft.item_qty) AS units
            FROM filtered_transactions AS ft
            INNER JOIN {{ get_table('dim_customer_loyalty') }} AS dcl
                ON dcl.customer_loyalty_cd = ft.nectar_card_num_hash
            INNER JOIN get_targeted_skus AS gts
                ON ft.item_cd = gts.item_cd
            INNER JOIN campaign_details cd
                ON gts.campaign_id = cd.campaign_id
                AND gts.channel_name = cd.channel_name
                AND gts.subchannel_name = cd.subchannel_name
                AND ft.transaction_dt BETWEEN cd.campaign_start_dt AND cd.campaign_end_dt
            INNER JOIN fb_loyal fbl
                ON dcl.nectar_collector_card_num = fbl.loyalty_id
                AND fbl.campaign_id = cd.campaign_id
            GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13 -- Group by all non-aggregated columns
        ),

        -- Split into separate CTEs for converted and non-converted touchpoints
        -- Touchpoints for customers who converted (purchased)
        fb_transaction_touchpoint AS (
            SELECT DISTINCT
                fb_txn.loyalty_id,
                cd.marketing_type,
                cd.channel_name,
                cd.subchannel_name,
                cd.campaign_name,
                cd.campaign_id,
                cd.campaign_start_dt AS event_date,
                TO_TIMESTAMP(CONCAT(cd.campaign_start_dt, ' 00:00:00')) AS event_time,
                fb_txn.transaction_key,  -- Link to transaction
                'Touchpoint' AS event_name,
                cd.booking_id
            FROM fb_txn
            INNER JOIN campaign_details cd
                ON fb_txn.campaign_id = cd.campaign_id
        ),

        -- Touchpoints for customers who did NOT convert
        fb_non_converted_touchpoint AS (
            SELECT DISTINCT
                fbl.loyalty_id,
                cd.marketing_type,
                cd.channel_name,
                cd.subchannel_name,
                cd.campaign_name,
                cd.campaign_id,
                cd.campaign_start_dt AS event_date,
                TO_TIMESTAMP(CONCAT(cd.campaign_start_dt, ' 00:00:00')) AS event_time,
                NULL AS transaction_key,  -- No transaction
                'Touchpoint' AS event_name,
                cd.booking_id
            FROM fb_loyal AS fbl
            CROSS JOIN campaign_details cd
            WHERE fbl.loyalty_id NOT IN (
                SELECT DISTINCT loyalty_id FROM fb_txn
            )
        ),

        -- Final combined Meta data collection
        meta_data_collection AS (
            -- Meta transaction data
            SELECT
                loyalty_id,
                transaction_key,
                event_date AS event_dt,
                event_time AS event_ts,
                marketing_type,
                channel_name,
                'TXN' AS subchannel_name,
                campaign_name,
                campaign_id,
                event_name,
                booking_id,
                item_cd,
                product_type,
                unique_brand_name,
                net_targetted_sales AS net_sales_amt,
                units AS units_qty
            FROM fb_txn

            UNION ALL

            -- Touchpoint data for converted customers
            SELECT
                loyalty_id,
                transaction_key,
                event_date AS event_dt,
                event_time AS event_ts,
                marketing_type,
                channel_name,
                subchannel_name,
                campaign_name,
                campaign_id,
                event_name,
                booking_id,
                NULL AS item_cd,
                NULL AS product_type,
                NULL AS unique_brand_name,
                NULL AS net_sales_amt,
                NULL AS units_qty
            FROM fb_transaction_touchpoint

            UNION ALL

            -- Touchpoint data for non-converted customers
            SELECT
                loyalty_id,
                transaction_key,
                event_date AS event_dt,
                event_time AS event_ts,
                marketing_type,
                channel_name,
                subchannel_name,
                campaign_name,
                campaign_id,
                event_name,
                booking_id,
                NULL AS item_cd,
                NULL AS product_type,
                NULL AS unique_brand_name,
                NULL AS net_sales_amt,
                NULL AS units_qty
            FROM fb_non_converted_touchpoint
        )

    -- Final optimized output
    SELECT
        loyalty_id::VARCHAR(1000) AS loyalty_id,
        COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
        event_dt::DATE AS event_dt,
        event_ts::TIMESTAMP_NTZ(9) AS event_ts,
        marketing_type::VARCHAR(1000) AS marketing_type,
        channel_name::VARCHAR(1000) AS channel_name,
        subchannel_name::VARCHAR(1000) AS subchannel_name,
        campaign_name::VARCHAR(1000) AS campaign_name,
        campaign_id::VARCHAR(1000) AS campaign_id,
        event_name::VARCHAR(1000) AS event_name,
        booking_id::VARCHAR(1000) AS booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
        COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
        COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
        COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
        COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
        COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
    FROM meta_data_collection
)
include_query_id = true
header = true;
