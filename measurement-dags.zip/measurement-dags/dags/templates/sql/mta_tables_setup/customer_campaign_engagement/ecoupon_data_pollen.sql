-- Main processing script
COPY INTO {{ get_stage('ecoupon_data') }}
FROM
(
    WITH
    -- Get ALL available eCoupon campaigns
    campaign_details AS (
        SELECT
            mce.campaign_name,
            mce.channel_name,
            mce.subchannel_name,
            mce.campaign_start_dt,
            mce.campaign_end_dt,
            mce.campaign_id,
            mce.booking_id,
            mce.campaign_duration,
            mce.job_bag_number,
            mce.marketing_type
        FROM {{ get_table('measurement_campaign_execution_status') }} mce
        WHERE mce.marketing_hierarchy_cd IN ({{ params.ecoupon_hierarchy_codes | join(', ') }})
        AND job_status = 'Not Started'
    ),

    -- Get campaign date ranges to avoid scalar subqueries
    campaign_date_range AS (
        SELECT
            MIN(cd_range.campaign_start_dt) as min_start_dt,
            MAX(cd_range.campaign_end_dt) as max_end_dt
        FROM campaign_details cd_range
    ),

    -- Get loyalty service campaign IDs for all campaigns
    ecoupon_loyalty_service_data AS (
        SELECT DISTINCT
            dc.loyalty_service_campaign_id AS loyalty_service_campaign_id,
            cd.campaign_id AS els_campaign_id,
            cd.campaign_name AS els_campaign_name,
            cd.channel_name AS els_channel_name,
            cd.subchannel_name AS els_subchannel_name,
            cd.booking_id AS els_booking_id,
            cd.marketing_type AS els_marketing_type,
            cd.campaign_start_dt AS els_campaign_start_dt,
            cd.campaign_end_dt AS els_campaign_end_dt
        FROM {{ get_table('oc_campaign') }} AS occ
        INNER JOIN {{ get_table('oc_customer_selection') }} AS ocs
            ON occ.campaign_id = ocs.campaign_id
        INNER JOIN {{ get_table('dim_campaign') }} AS dc
            ON dc.barcode = ocs.coupon_id
        INNER JOIN campaign_details cd
            ON occ.base_asset_id = cd.campaign_id
        WHERE ocs.status = {{params.ecoupon_targeted}}
    ),

    -- Get eCoupon loyalty data for all campaigns
    ecoupoun_loyalty_data AS (
        SELECT DISTINCT
            fce.loyalty_id AS eld_loyalty_id,
            fce.applied_state AS eld_applied_state,
            fce.event_utc_ts AS eld_event_utc_ts,
            fce.online_order_num AS eld_online_order_num,
            elsd.els_campaign_id AS eld_campaign_id,
            elsd.els_campaign_name AS eld_campaign_name,
            elsd.els_channel_name AS eld_channel_name,
            elsd.els_subchannel_name AS eld_subchannel_name,
            elsd.els_booking_id AS eld_booking_id,
            elsd.els_marketing_type AS eld_marketing_type,
            elsd.els_campaign_start_dt AS eld_campaign_start_dt,
            elsd.els_campaign_end_dt AS eld_campaign_end_dt
        FROM ecoupon_loyalty_service_data AS elsd
        INNER JOIN {{ get_table('flf_campaign_event') }} AS fce
            ON elsd.loyalty_service_campaign_id = fce.loyalty_service_campaign_id
            AND YEAR(fce.event_utc_ts) >= YEAR(TO_DATE(elsd.els_campaign_start_dt))
    ),

    -- Get minimum event timestamp for each loyalty_id per campaign
    ecoupon_loaded_loyalty AS (
        SELECT
            eld.eld_loyalty_id AS ell_loyalty_id,
            eld.eld_campaign_id AS ell_campaign_id,
            MIN(eld.eld_event_utc_ts) AS ell_event_utc_ts
        FROM ecoupoun_loyalty_data eld
        WHERE LOWER(eld.eld_applied_state) IN ('created', 'loaded')
                AND eld.eld_loyalty_id IS NOT NULL
        AND date(eld.eld_event_utc_ts) BETWEEN eld.eld_campaign_start_dt AND eld.eld_campaign_end_dt
        GROUP BY 
            eld.eld_loyalty_id, 
            eld.eld_campaign_id
    ),

    -- Get transaction basket data for all campaign periods
    get_fact_sale_transaction_basket AS (
        SELECT
            fstb.transaction_end_ts,
            fstb.nectar_card_num_hash,
            fstb.transaction_id,
            fstb.transaction_dt,
            fstb.sales_origination_channel_cd,
            fstb.order_number
        FROM {{ get_table('fact_sale_transaction_basket') }} fstb
        CROSS JOIN campaign_date_range cdr
        WHERE fstb.nectar_card_num_hash IS NOT NULL
        AND fstb.transaction_dt BETWEEN cdr.min_start_dt AND cdr.max_end_dt
        AND fstb.sales_origination_channel_cd IN {{params.sales_origination_all_codes}}
    ),

    -- Get transaction item data for all campaign periods
    get_fact_sale_transaction_item AS (
        SELECT
            fsti.transaction_id,
            fsti.transaction_dt,
            fsti.item_cd,
            fsti.net_retail_sales_amt,
            fsti.item_qty,
            fsti.item_sequence_num,
            fsti.store_cd
        FROM {{ get_table('fact_sale_transaction_item') }} fsti
        CROSS JOIN campaign_date_range cdr
        WHERE fsti.transaction_dt BETWEEN cdr.min_start_dt AND cdr.max_end_dt
        AND fsti.net_retail_sales_amt > 0
    ),

    -- Get max load timestamp for campaign products across all campaigns
    max_load_ts AS (
        SELECT
            cpt.campaign_id AS max_campaign_id,
            cpt.channel_name AS max_channel_name,
            cpt.subchannel_name AS max_subchannel_name,
            MAX(cpt.load_ts) AS max_load_ts_value
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN campaign_details cd
            ON cpt.campaign_id = cd.campaign_id
            AND cpt.channel_name = cd.channel_name
            AND cpt.subchannel_name = cd.subchannel_name
        GROUP BY cpt.campaign_id, cpt.channel_name, cpt.subchannel_name
    ),

    -- Get targeted SKUs for all campaigns
    get_targeted_skus AS (
        SELECT DISTINCT
            cpt.product_type AS sku_product_type,
            cpt.unique_brand_name AS sku_brand_name,
            cpt.item_cd AS sku_item_cd,
            cpt.campaign_id AS sku_campaign_id,
            cpt.channel_name AS sku_channel_name,
            cpt.subchannel_name AS sku_subchannel_name
        FROM {{ get_table('campaign_product_type_aws') }} cpt
        INNER JOIN max_load_ts mlt
            ON cpt.campaign_id = mlt.max_campaign_id
            AND cpt.channel_name = mlt.max_channel_name
            AND cpt.subchannel_name = mlt.max_subchannel_name
            AND cpt.load_ts = mlt.max_load_ts_value
    ),

    -- Get eCoupon redeemed transaction data (distinct)
    get_ecoupon_redeem_transaction_distinct AS (
        SELECT DISTINCT
            dcl.nectar_collector_card_num AS loyalty_id,
            gfsti.transaction_id AS transaction_key,
            gfsti.transaction_dt AS event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts AS event_time,
            'NA' AS marketing_type,
            'Online' AS channel_name,
            eld.eld_campaign_name AS campaign_name,
            eld.eld_campaign_id AS campaign_id,
            'Purchase Transaction' AS event_name,
            eld.eld_booking_id AS booking_id,
            gts.sku_product_type AS product_type,
            gts.sku_brand_name AS unique_brand_name,
            gfsti.net_retail_sales_amt,
            gfsti.item_qty,
            gfsti.item_sequence_num
        FROM ecoupoun_loyalty_data AS eld
        INNER JOIN {{ get_table('dim_customer_loyalty') }} AS dcl
            ON eld.eld_loyalty_id = dcl.nectar_collector_card_num
        INNER JOIN get_fact_sale_transaction_basket AS gfstb
            ON gfstb.nectar_card_num_hash = dcl.nectar_collector_card_num
            AND eld.eld_online_order_num = gfstb.order_number
        INNER JOIN get_fact_sale_transaction_item AS gfsti
            ON gfstb.transaction_id = gfsti.transaction_id
        INNER JOIN get_targeted_skus AS gts
            ON gfsti.item_cd = gts.sku_item_cd
            AND gts.sku_campaign_id = eld.eld_campaign_id
        WHERE LOWER(eld.eld_applied_state) = 'redeemed'
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_online_codes}}
        AND gfsti.transaction_dt BETWEEN eld.eld_campaign_start_dt AND eld.eld_campaign_end_dt
    ),

    -- Aggregate eCoupon redeemed transaction data
    ecoupon_redeem_transaction AS (
        SELECT
            gertd.loyalty_id,
            gertd.event_date,
            gertd.event_time,
            gertd.transaction_key,
            gertd.item_cd,
            gertd.unique_brand_name,
            gertd.marketing_type,
            gertd.channel_name,
            gertd.campaign_name,
            gertd.campaign_id,
            gertd.event_name,
            gertd.booking_id,
            gertd.product_type,
            SUM(gertd.net_retail_sales_amt) AS net_targetted_sales,
            SUM(gertd.item_qty) AS units
        FROM get_ecoupon_redeem_transaction_distinct gertd
        WHERE gertd.loyalty_id IN (SELECT DISTINCT ell_loyalty_id FROM ecoupon_loaded_loyalty)
        GROUP BY 
            gertd.loyalty_id,
            gertd.event_date,
            gertd.event_time,
            gertd.transaction_key,
            gertd.item_cd,
            gertd.unique_brand_name, 
            gertd.marketing_type, 
            gertd.channel_name, 
            gertd.campaign_name,
            gertd.campaign_id, 
            gertd.event_name, 
            gertd.booking_id, 
            gertd.product_type
    ),

    -- Get eCoupon loaded transaction data
    get_ecoupon_loaded_transaction_distinct AS (
        SELECT DISTINCT
            dcl.nectar_collector_card_num AS loyalty_id,
            gfsti.transaction_id AS transaction_key,
            gfsti.transaction_dt AS event_date,
            gfsti.item_cd,
            gfstb.transaction_end_ts AS event_time,
            'NA' AS marketing_type,
            CASE
                WHEN gfstb.sales_origination_channel_cd IN {{params.sales_origination_instore_codes}}
                THEN 'In-store'
                ELSE 'Online'
            END AS channel_name,
            eld.eld_campaign_name AS campaign_name,
            eld.eld_campaign_id AS campaign_id,
            'Purchase Transaction' AS event_name,
            eld.eld_booking_id AS booking_id,
            gts.sku_product_type AS product_type,
            gts.sku_brand_name AS unique_brand_name,
            gfsti.net_retail_sales_amt,
            gfsti.item_sequence_num,
            gfsti.item_qty
        FROM ecoupoun_loyalty_data AS eld
        INNER JOIN {{ get_table('dim_customer_loyalty') }} AS dcl
            ON eld.eld_loyalty_id = dcl.nectar_collector_card_num
        INNER JOIN get_fact_sale_transaction_basket AS gfstb
            ON gfstb.nectar_card_num_hash = dcl.nectar_collector_card_num
            AND eld.eld_online_order_num = gfstb.order_number
        INNER JOIN get_fact_sale_transaction_item AS gfsti
            ON gfstb.transaction_id = gfsti.transaction_id
        INNER JOIN get_targeted_skus AS gts
            ON gfsti.item_cd = gts.sku_item_cd
            AND gts.sku_campaign_id = eld.eld_campaign_id
        LEFT JOIN ecoupon_redeem_transaction ert_exclude
            ON dcl.nectar_collector_card_num = ert_exclude.loyalty_id
            AND eld.eld_campaign_id = ert_exclude.campaign_id
        WHERE LOWER(eld.eld_applied_state) IN ('loaded', 'created')
        AND gfstb.sales_origination_channel_cd IN {{params.sales_origination_all_codes}}
        AND gfsti.transaction_dt BETWEEN eld.eld_campaign_start_dt AND eld.eld_campaign_end_dt
        AND ert_exclude.loyalty_id IS NULL
    ),

    -- Aggregate eCoupon loaded transaction data
    ecoupon_loaded_transaction AS (
        SELECT
            geltd.loyalty_id,
            geltd.event_date,
            geltd.event_time,
            geltd.transaction_key,
            geltd.item_cd,
            geltd.unique_brand_name,
            geltd.marketing_type,
            geltd.channel_name,
            geltd.campaign_name,
            geltd.campaign_id,
            geltd.event_name,
            geltd.booking_id,
            geltd.product_type,
            SUM(geltd.net_retail_sales_amt) AS net_targetted_sales,
            SUM(geltd.item_qty) AS units
        FROM get_ecoupon_loaded_transaction_distinct geltd
        GROUP BY geltd.loyalty_id, geltd.event_date, geltd.event_time, geltd.transaction_key, geltd.item_cd,
                 geltd.unique_brand_name, geltd.marketing_type, geltd.channel_name, geltd.campaign_name,
                 geltd.campaign_id, geltd.event_name, geltd.booking_id, geltd.product_type
    ),

    -- Create touchpoints for non-targeted SKU customers
    ecoupon_non_targeted_sku_touchpoint_data AS (
        SELECT DISTINCT
            ell.ell_loyalty_id AS loyalty_id,
            cd.marketing_type,
            cd.channel_name,
            cd.subchannel_name,
            cd.campaign_name,
            ell.ell_campaign_id AS campaign_id,
            DATE(ell.ell_event_utc_ts) AS event_date,
            ell.ell_event_utc_ts AS event_time,
            NULL AS transaction_key,
            'Touchpoint' AS event_name,
            cd.booking_id
        FROM ecoupon_loaded_loyalty ell
        INNER JOIN campaign_details cd
            ON ell.ell_campaign_id = cd.campaign_id
        LEFT JOIN ecoupon_redeem_transaction ert_exclude2
            ON ell.ell_loyalty_id = ert_exclude2.loyalty_id
            AND ell.ell_campaign_id = ert_exclude2.campaign_id
        LEFT JOIN ecoupon_loaded_transaction elt_exclude
            ON ell.ell_loyalty_id = elt_exclude.loyalty_id
            AND ell.ell_campaign_id = elt_exclude.campaign_id
        WHERE ert_exclude2.loyalty_id IS NULL
        AND elt_exclude.loyalty_id IS NULL
    ),

    -- Create touchpoints for loaded customers
    ecoupon_loaded_touchpoint_data AS (
        SELECT DISTINCT
            ert.loyalty_id,
            cd.marketing_type,
            cd.channel_name,
            cd.subchannel_name,
            ert.campaign_name,
            ert.campaign_id,
            DATE(ell.ell_event_utc_ts) AS event_date,
            ell.ell_event_utc_ts AS event_time,
            ert.transaction_key,
            'Touchpoint' AS event_name,
            ert.booking_id
        FROM ecoupon_redeem_transaction AS ert
        INNER JOIN ecoupon_loaded_loyalty AS ell
            ON ert.loyalty_id = ell.ell_loyalty_id
            AND ert.campaign_id = ell.ell_campaign_id
        INNER JOIN campaign_details cd
            ON ert.campaign_id = cd.campaign_id

        UNION ALL

        SELECT DISTINCT
            elt.loyalty_id,
            cd.marketing_type,
            cd.channel_name,
            cd.subchannel_name,
            elt.campaign_name,
            elt.campaign_id,
            DATE(ell.ell_event_utc_ts) AS event_date,
            ell.ell_event_utc_ts AS event_time,
            elt.transaction_key,
            'Touchpoint' AS event_name,
            elt.booking_id
        FROM ecoupon_loaded_transaction AS elt
        INNER JOIN ecoupon_loaded_loyalty AS ell
            ON elt.loyalty_id = ell.ell_loyalty_id
            AND elt.campaign_id = ell.ell_campaign_id
        INNER JOIN campaign_details cd
            ON elt.campaign_id = cd.campaign_id
    ),

    -- Combine all eCoupon data
    ecoupon_data_collection AS (
        -- eCoupon loaded transaction data
        SELECT DISTINCT
            elt.loyalty_id,
            elt.transaction_key,
            elt.event_date AS event_dt,
            elt.event_time AS event_ts,
            elt.marketing_type,
            elt.channel_name,
            'TXN' AS subchannel_name,
            elt.campaign_name,
            elt.campaign_id,
            elt.event_name,
            elt.booking_id,
            elt.item_cd,
            elt.product_type,
            elt.unique_brand_name,
            elt.net_targetted_sales AS net_sales_amt,
            elt.units AS units_qty
        FROM ecoupon_loaded_transaction elt

        UNION ALL

        -- eCoupon redeemed transaction data
        SELECT DISTINCT
            ert.loyalty_id,
            ert.transaction_key,
            ert.event_date AS event_dt,
            ert.event_time AS event_ts,
            ert.marketing_type,
            ert.channel_name,
            'TXN' AS subchannel_name,
            ert.campaign_name,
            ert.campaign_id,
            ert.event_name,
            ert.booking_id,
            ert.item_cd,
            ert.product_type,
            ert.unique_brand_name,
            ert.net_targetted_sales AS net_sales_amt,
            ert.units AS units_qty
        FROM ecoupon_redeem_transaction ert

        UNION ALL

        -- eCoupon loaded touchpoint data
        SELECT DISTINCT
            eltd.loyalty_id,
            eltd.transaction_key,
            eltd.event_date AS event_dt,
            eltd.event_time AS event_ts,
            eltd.marketing_type,
            eltd.channel_name,
            eltd.subchannel_name,
            eltd.campaign_name,
            eltd.campaign_id,
            eltd.event_name,
            eltd.booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM ecoupon_loaded_touchpoint_data eltd

        UNION ALL

        -- eCoupon non-targeted SKU touchpoint data
        SELECT DISTINCT
            entstd.loyalty_id,
            NULL AS transaction_key,
            entstd.event_date AS event_dt,
            entstd.event_time AS event_ts,
            entstd.marketing_type,
            entstd.channel_name,
            entstd.subchannel_name,
            entstd.campaign_name,
            entstd.campaign_id,
            entstd.event_name,
            entstd.booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM ecoupon_non_targeted_sku_touchpoint_data entstd
    )

    -- Final output
    SELECT
        edc.loyalty_id::VARCHAR(1000) AS loyalty_id,
        COALESCE(edc.transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
        edc.event_dt::DATE AS event_dt,
        edc.event_ts::TIMESTAMP_NTZ(9) AS event_ts,
        edc.marketing_type::VARCHAR(1000) AS marketing_type,
        edc.channel_name::VARCHAR(1000) AS channel_name,
        edc.subchannel_name::VARCHAR(1000) AS subchannel_name,
        edc.campaign_name::VARCHAR(1000) AS campaign_name,
        edc.campaign_id::VARCHAR(1000) AS campaign_id,
        edc.event_name::VARCHAR(1000) AS event_name,
        edc.booking_id::VARCHAR(1000) AS booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
        COALESCE(edc.item_cd::NUMBER(18, 0), 0) AS item_cd,
        COALESCE(edc.product_type::VARCHAR(1000), 'NA') AS product_type,
        COALESCE(edc.unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
        COALESCE(edc.net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
        COALESCE(edc.units_qty::NUMBER(30, 4), 0) AS units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
    FROM ecoupon_data_collection edc
)
include_query_id = true
header = true;
