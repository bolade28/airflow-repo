COPY INTO {{ get_stage('youtube_data') }}
FROM
(
WITH
youtube_channel_list AS (
    SELECT
    campaign_id,
    booking_id,
    job_bag_number,
    marketing_type,
    channel_name,
    subchannel_name,
    campaign_name,
    campaign_start_dt,
    campaign_end_dt,
    campaign_duration,
    job_status
    FROM {{ get_table('measurement_campaign_execution_status') }}
    WHERE CHANNEL_NAME = 'YouTube'
        AND (job_status = 'Not Started' or job_status is null)
)
, ab_audience_group as (
    select
        dtagds.job_bag_id,
        json_extract_path_text(audience.value, '_id') as audience_id,
        json_extract_path_text(audience.value, 'name') as audience_name,
        max(dtagds.record_arrival_ts) as max_time
    from {{ get_table('digital_trading_audience_group_dmabag_sat') }}  as dtagds
    , lateral flatten(input => dtagds.audiences_data, outer => true) as audience
    ,   (SELECT DISTINCT campaign_id from youtube_channel_list) yc
    where
        dtagds.job_bag_id = yc.campaign_id
        and json_extract_path_text(audience.value, 'name') not ilike '%do not use%'
    group by 1, 2, 3
    union
    select
        dtagds.job_bag_id,
        json_extract_path_text(model_audience.value, '_id') as audience_id,
        json_extract_path_text(model_audience.value, 'name') as audience_name,
        max(dtagds.record_arrival_ts) as max_time
    from {{ get_table('digital_trading_audience_group_dmabag_sat') }} as dtagds
    , lateral flatten(input => dtagds.modelled_audiences_data, outer => true) as model_audience
    ,   (SELECT DISTINCT campaign_id from youtube_channel_list) yc
    where
        dtagds.job_bag_id = yc.campaign_id
        and json_extract_path_text(model_audience.value, 'name') not ilike '%do not use%'
    group by 1, 2, 3
)
, get_target_audience as (
    select distinct
        aag.audience_name,
        asd.loyalty_id,
        aag.job_bag_id
    from ab_audience_group as aag join
    {{ get_table('audience_snapshot_deduped') }} as asd USING (audience_id)
)
, max_load_ts as (
    select
        max(cpt.load_ts) as load_ts,
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
    from {{ get_table('campaign_product_type_aws') }}  cpt
    join (select distinct campaign_id,channel_name,subchannel_name, campaign_start_dt, campaign_end_dt FROM youtube_channel_list) yc
    USING (campaign_id, channel_name, subchannel_name)
    GROUP BY
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
)
, get_targeted_skus as (
    select distinct
        cpt.product_type,
        cpt.unique_brand_name,
        cpt.item_cd,
        cpt.campaign_id,
        cpt.channel_name,
        cpt.subchannel_name
    from {{ get_table('campaign_product_type_aws') }}  cpt JOIN
    max_load_ts ts USING (campaign_id, channel_name, subchannel_name, load_ts)
)
, get_start_date as (
        select
            min(mr.campaign_date) as start_dt,
            mr.jobbag_id as campaign_id
        from {{ get_table('media_report') }} as mr
        JOIN youtube_channel_list yc
        ON mr.jobbag_id = yc.campaign_id
            and campaign_date >= yc.campaign_start_dt
            and campaign_date <= yc.campaign_end_dt
        group by mr.jobbag_id
)

, get_fact_sale_transaction_basket as (
     select
    sales_origination_channel_cd,
    transaction_id,
    transaction_dt,
    nectar_card_num_hash,
    transaction_end_ts
    from {{ get_table('fact_sale_transaction_basket') }}
    where
        nectar_card_num_hash is not null
        and sales_origination_channel_cd in  (
            select upper(value)::string as codes
            from lateral flatten(input => parse_json('{{ params.sales_origination_all_codes | tojson }}')))
         AND EXISTS (SELECT COUNT(1) FROM get_targeted_skus HAVING COUNT(1) > 0)
        AND transaction_dt BETWEEN (SELECT MIN(start_dt) FROM get_start_date) AND (SELECT MAX(campaign_end_dt) FROM youtube_channel_list)
)
-- {# /* getting relevant details from fact_sale_transaction_item. This cte is created to reduce read time from transaction_item table
-- as it is reference multiple time. */ #}
, get_fact_sale_transaction_item AS (
        select
            transaction_id,
            transaction_dt,
            item_cd,
            net_retail_sales_amt,
            item_qty,
            item_sequence_num,
            store_cd
        from {{ get_table('fact_sale_transaction_item') }}
        where
            net_retail_sales_amt > 0
        AND EXISTS (SELECT COUNT(1) FROM get_targeted_skus HAVING COUNT(1) > 0)
        AND transaction_dt BETWEEN (SELECT MIN(start_dt) FROM get_start_date) AND (SELECT MAX(campaign_end_dt) FROM youtube_channel_list)
)
-- /**********************
-- 1. Getting the transaction data from the fact_sale_transaction_basket and fact_sale_transaction_item tables
-- 2. Applying sales origination channel codes filters to find the channel name.
-- 3. Joining the get_target_audience cte to get the audience name and loyalty id. Audience name will be used as subchannel
-- 4. Joining the get_targeted_skus cte to get the product type and unique brand name.
-- 5. Joining the get_fact_sale_transaction_item cte to get the transaction id, transaction DATE, item code, net retail sales amount, item quantity and item sequence number.
-- 6. Joining the get_fact_sale_transaction_basket cte to get the transaction end timestamp, nectar card number hash, transaction id and transaction DATE.
-- 7. Applying filters to get the transaction data for the given DATE range and sales origination channel codes.
-- ***********************
, get_transaction_data_distinct as (
    select distinct
        gfstb.nectar_card_num_hash as loyalty_id,
        gfsti.transaction_id as transaction_key,
        gfsti.transaction_dt as event_DATE,
        gfsti.item_cd,
        gfstb.transaction_end_ts as event_time,
        'NA' as marketing_type,
        case when
            gfstb.sales_origination_channel_cd in  (
                select upper(value)::string as codes
                from lateral flatten(input => parse_json('{{ params.sales_origination_instore_codes | tojson }}'))
            )
            then 'In-store'
            else 'Online' end as channel,
        gta.audience_name,
        yc.campaign_name,
        yc.campaign_id,
        'Purchase Transaction' as event_name,
        yc.booking_id,
        gts.product_type,
        gts.unique_brand_name,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    from get_fact_sale_transaction_basket as gfstb
    inner join get_target_audience as gta
        on gfstb.nectar_card_num_hash = gta.loyalty_id
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gts.item_cd = gfsti.item_cd
    inner join get_start_date gsd
        on gts.campaign_id = gsd.campaign_id
    inner join youtube_channel_list yc
        on gfsti.transaction_dt between gsd.start_dt and yc.campaign_end_dt
        AND gfstb.transaction_dt between gsd.start_dt and yc.campaign_end_dt
        AND gts.campaign_id = yc.campaign_id
        AND gts.channel_name = yc.channel_name
        AND gts.subchannel_name = yc.subchannel_name
)
-- {# /* Getting total sales amount and units for each loyalty id, transaction key, item code, unique brand name,
-- marketing type, channel, audience name, campaign name, campaign id, event name and booking id */ #}
, get_transaction_data as (
    select
        loyalty_id,
        event_DATE,
        event_time,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel,
        audience_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_targetted_sales,
        sum(item_qty) as units
    from get_transaction_data_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
)
-- {#
-- /**********************
-- 1. Adding touchpoint for loyalty ids who bought targetted skus
-- 2. Event_DATE for touchpoints is set to campaign start DATE as it is the DATE when the touchpoint is created.
-- ***********************/
-- #}
, create_txn_touchpoint_data as (
    select distinct
        loyalty_id,
        transaction_key,
        yc.campaign_start_dt as event_DATE,
        to_timestamp(yc.campaign_start_dt|| ' 00:00:00') as event_time,
        yc.marketing_type,
        yc.channel_name AS channel,
        yc.subchannel_name as subchannel,
        yc.campaign_name,
        yc.campaign_id,
        'Touchpoint' as event_name,
         yc.booking_id
    from get_transaction_data
    join youtube_channel_list yc USING (campaign_id, campaign_name, booking_id)
)

-- {#
-- /**********************
-- 1. The non_transaction_touchpoint is getting the touchpoint data for loyalty ids who did not buy targetted skus
-- 2. The event_DATE for touchpoints is set to campaign start DATE as it is the DATE when the touchpoint is created.
-- ***********************/
-- #}
, non_transaction_touchpoint as (
    select distinct
        loyalty_id,
        yc.campaign_start_dt as event_DATE,
        to_timestamp(yc.campaign_start_dt|| ' 00:00:00') as event_time,
        yc.marketing_type,
        yc.channel_name as channel,
        yc.subchannel_name as subchannel,
        yc.campaign_name,
        yc.campaign_id,
        'Touchpoint' as event_name,
        yc.booking_id
    from get_target_audience
    cross join youtube_channel_list yc
    where
        loyalty_id not in
        (
            select distinct loyalty_id
            from create_txn_touchpoint_data
        )
)

-- {#
-- /**********************
-- 1. Getting transaction and touchpoint data for all the targeted loyalty_ids
-- 2. For touchpoints item_cd, product_type, unique_brand_name, net_sales_amt and units_qty are set to null as these are not relevant for touchpoints.
-- 3. For non conversion transaction is set to null as no relevant transaction was made.
-- ***********************/
-- #}
, yc_data_collection as (
    select
        loyalty_id,
        transaction_key,
        event_DATE as event_dt,
        event_time as event_ts,
        marketing_type,
        channel as channel_name,
        'TXN' as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_targetted_sales as net_sales_amt,
        units as units_qty
    from get_transaction_data
    union all
    select
        loyalty_id,
        transaction_key,
        event_DATE as event_dt,
        event_time as event_ts,
        marketing_type,
        channel as channel_name,
        subchannel as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null as item_cd,
        null as product_type,
        null as unique_brand_name,
        null as net_sales_amt,
        null as units_qty
    from create_txn_touchpoint_data
    union all
    select
        loyalty_id,
        null as transaction_key,
        event_DATE as event_dt,
        event_time as event_ts,
        marketing_type,
        channel as channel_name,
        subchannel as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null as item_cd,
        null as product_type,
        null as unique_brand_name,
        null as net_sales_amt,
        null as units_qty
    from non_transaction_touchpoint
)
-- {#
-- /**********************
-- 1. As touchpoints might contain null values we are using the coalesce function to replace null values with 'NA' or 0
-- 2. The load_ts is set to current timestamp and job_run_id is set to the invocation id
-- 3. This is a consoliDATEd data collection for all the touchpoints and transactions.
-- ***********************/
-- #}
select
    loyalty_id::VARCHAR(1000) AS loyalty_id,
    COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
    event_dt::DATE AS event_dt,
    event_ts::TIMESTAMP_NTZ(9) AS event_ts,
    marketing_type::VARCHAR(1000) AS marketing_type,
    channel_name::VARCHAR(1000) AS channel_name,
    subchannel_name::VARCHAR(1000) AS subchannel_name,
    campaign_name::VARCHAR(1000) AS campaign_name,
    campaign_id::VARCHAR(1000) AS campaign_id,
    event_name::VARCHAR(1000) AS event_name,
    booking_id::VARCHAR(1000) AS booking_id,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
    COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
    COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
    COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
    COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
    COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
    CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
from yc_data_collection
)
include_query_id = true
header = true;
