COPY INTO {{ get_stage('citrus_data') }}
FROM
(
    with
    citrus_channel_list AS (
        SELECT
        ces.campaign_id,
        ces.booking_id,
        ces.job_bag_number,
        ces.marketing_type,
        ces.channel_name,
        ces.campaign_duration,
        ces.subchannel_name,
        ces.campaign_name,
        ces.campaign_start_dt,
        ces.campaign_end_dt,
        ces.job_status,
        ces.marketing_hierarchy_cd
        FROM {{ get_table('measurement_campaign_execution_status') }} ces
        INNER JOIN {{ get_table('measurement_marketing_channel_hierarchy') }} mh
            ON ces.channel_name = mh.marketing_channel
            AND ces.subchannel_name = mh.marketing_subchannel
        WHERE 
            LOWER(ces.marketing_type) = 'onsite' 
            AND ces.marketing_hierarchy_cd NOT IN ({{ params.ecoupon_hierarchy_codes | join(', ') }})
            AND mh.in_scope_flag = TRUE
            AND mh.measurement_campaign_ready = TRUE
            AND mh.mapping_type = 'INTERACTION_EVENT'
    )

    , get_media as (
        select
            advertising_campaign_nk1,
            campaign_placements,
            load_ts
        from {{ get_table('advertising_campaign_citcam_sat') }}
        where advertising_campaign_nk1 in (select campaign_id from citrus_channel_list)
    )

    , get_media_max as (
        select
            advertising_campaign_nk1
            , max(load_ts) as load_ts
        from get_media
        group by advertising_campaign_nk1
    )

    , get_citcam_res as (
        select
            advertising_campaign_nk1
            , campaign_placements
        from get_media
        where (advertising_campaign_nk1, load_ts)
        in (select advertising_campaign_nk1,load_ts from get_media_max)
    )

    , mapping_result as (SELECT media_placement, marketing_subchannel, mapping_type

    FROM {{ get_table('marketing_media_hierarchy_mkthrc_ref') }}

        QUALIFY 

        ROW_NUMBER() OVER (

        PARTITION BY MAPPING_TYPE, CHANNEL_TYPE, MEDIA_PROVIDER, MEDIA_TYPE, MEDIA_SUBTYPE,

                     STORE_TYPE, STORE_LOCATION, TEMPLATE_TYPE, MEDIA_PLACEMENT

        ORDER BY LOAD_TS DESC

    ) = 1

    AND NVL(TECHNICAL_METADATA:RECORD_DELETED_FLAG, 'N') = 'N')

    , get_mapping as (
        select
            distinct lower(trim(substr(media_placement, (position('-', media_placement, 1) + 1)))) as media_placement
            , marketing_subchannel
        from mapping_result
        where
            
            mapping_type = 'INTERACTION_EVENT'
            and media_placement in (select campaign_placements from get_citcam_res)

    )
    , max_load_ts as (
        select
            max(cpt.load_ts) as load_ts,
            cpt.campaign_id,
            cpt.channel_name,
            cpt.subchannel_name
        from {{ get_table('campaign_product_type_aws') }}  cpt
        join (select distinct campaign_id,channel_name,subchannel_name, campaign_start_dt, campaign_end_dt FROM citrus_channel_list) ccl
        USING (campaign_id, channel_name, subchannel_name)
        GROUP BY
            cpt.campaign_id,
            cpt.channel_name,
            cpt.subchannel_name
    )
    , get_targeted_skus as (
        select distinct
            cpt.product_type,
            cpt.unique_brand_name,
            cpt.item_cd,
            cpt.campaign_id,
            channel_name,
            subchannel_name
        from {{ get_table('campaign_product_type_aws') }}  cpt JOIN
        max_load_ts ts USING (campaign_id, channel_name, subchannel_name, load_ts)
    )
    , get_search_terms_init AS (
        SELECT distinct
            campaign_id,
            value
        FROM (
            SELECT
                DISTINCT REPLACE(CASE WHEN len(search_terms)<1 or search_terms=',' THEN '' ELSE search_terms END , '''','"') AS search_terms,
                campaign_id
            FROM (
                SELECT
                    array_to_string(array_construct_compact(search_term_list,
                    CASE WHEN suggested_search_term_list = '' THEN NULL ELSE suggested_search_term_list END ), ',') AS search_terms,
                    ccl.campaign_id
                FROM {{ get_table('advertising_campaign_citcam_sat') }} sat JOIN (SELECT DISTINCT campaign_id FROM citrus_channel_list) ccl
                ON advertising_campaign_nk1 = campaign_id
            )
        )
         , lateral split_to_table(search_terms, ',')
    )
    , get_search_terms AS (
        SELECT DISTINCT
            campaign_id,
            value
        FROM get_search_terms_init
        JOIN (SELECT DISTINCT campaign_id FROM get_targeted_skus) tsku
        USING (campaign_id)
    )
    , campaign_end_dt AS (
        SELECT
            ccl. campaign_id,
            ccl. channel_name,
            ccl. subchannel_name as pollen_subchannel,
            gmp.media_placement as subchannel_name,
            ccl. campaign_start_dt AS start_date,
            CASE WHEN ccl.campaign_duration = 'Post' THEN  uc.campaign_end_dt ELSE ccl.campaign_end_dt END AS end_date
        FROM citrus_channel_list ccl
        JOIN (SELECT DISTINCT campaign_id, channel_name, subchannel_name from get_targeted_skus) tsu
        USING (campaign_id, channel_name, subchannel_name)
        JOIN get_mapping as gmp
        on gmp.marketing_subchannel= ccl.subchannel_name
        left JOIN
            (SELECT * FROM {{ get_table('measurement_unified_campaign_pollen') }} uc where exists ( SELECT * FROM citrus_channel_list where campaign_duration = 'Post')) uc ON
            ccl.booking_id= uc.job_bag_number and
            ccl.channel_name=uc.channel_name and
            ccl.subchannel_name=uc.subchannel_name and
            ccl.marketing_type= uc.marketing_type and
            ccl.campaign_start_dt=uc.campaign_start_dt and
            ccl.campaign_end_dt = LEAST(uc.Post_campaign_dt, current_date())
        where CASE WHEN ccl.campaign_duration = 'Post' THEN uc.channel_name IS not NULL ELSE true END
    )
    , gol_data_init AS (
        SELECT
             dcl.nectar_collector_card_num AS loyalty_id,
            fgoei.event_ts ,
            lower(fgoe.search_term) AS value,
            ARRAY_AGG(DISTINCT a.subchannel_name) AS subchannel_name
        FROM {{ get_table('flf_golweb_online_event_item') }} fgoei
                 JOIN {{ get_table('flf_golweb_online_event') }}  fgoe
                    ON fgoei.event_id = fgoe.event_id
                    and fgoe.event_ts <= fgoei.event_ts
                JOIN {{ get_table('dim_customer_loyalty') }}  dcl
                    ON dcl.customer_loyalty_cd = fgoei.hash_online_account_num
                JOIN  (
                        SELECT DISTINCT to_varchar(item_cd) AS item_cd , campaign_id , channel_name, subchannel_name
                        FROM {{ get_table('campaign_product_type_aws') }}
                        JOIN citrus_channel_list ccl
                        USING (campaign_id, channel_name, subchannel_name)
                        WHERE product_type = 'Offer'
                ) a
               USING (item_cd)
               JOIN campaign_end_dt ced ON
               ced.campaign_id = a.campaign_id
               and ced.channel_name = a.channel_name
               and ced.pollen_subchannel = a.subchannel_name
               and fgoei.event_ts between ced.start_date and ced.end_date
               and fgoe.event_ts between ced.start_date and ced.end_date
               JOIN get_search_terms st ON
               st.campaign_id = a.campaign_id
               and
        CASE lower(ced.subchannel_name) WHEN 'search below grid' THEN fgoe.item_prod_finding_method ilike '%citrus_search_ads_below_grid%' and lower(fgoe.search_term) in (st.value)
                                      WHEN 'search' THEN  fgoe.item_prod_finding_method ilike '%search%' and  lower(fgoe.search_term) in (st.value)
                                      WHEN 'checkout before you go' THEN fgoe.item_prod_finding_method ilike 'checkout_%' and fgoe.page_section = 'checkout before you go'
                                      WHEN 'favourites' THEN fgoe.item_prod_finding_method ilike '%favourites%'
                                      WHEN 'browse' THEN fgoe.item_prod_finding_method ilike '%citrus%' and lower(fgoe.search_category_match_flag) = 'categorymatch'
                                      WHEN 'offers' THEN fgoe.item_prod_finding_method ilike '%citrus_offers%'
                                      WHEN 'zone' THEN fgoe.item_prod_finding_method ilike '%citrus_offers>zone%'
                                      WHEN 'cross-sell' THEN (fgoe.item_prod_finding_method ilike '%citrus_xsell_ad_pdp%' or fgoe.item_prod_finding_method ilike '%citrus_xsell_ad_favourites%')
                                      WHEN 'homepage' THEN fgoe.item_prod_finding_method ilike '%citrus_search_ads%'
                                      ELSE false
                                      END

    where
                    fgoei.item_top_level_pfm ilike '%citrus%'
                    and fgoe.ga_item_pfm_cat = 'Citrus'
                    and lower(a.subchannel_name) <> 'search - app'
                    and dcl.nectar_collector_card_num IS not NULL
                    and dcl.nectar_collector_card_num != '~~'
                    and fgoei.hash_online_account_num != '~~'
    GROUP BY
            dcl.nectar_collector_card_num,
            fgoei.event_ts,
            lower(fgoe.search_term)
    union
                SELECT
                    dcl.nectar_collector_card_num AS loyalty_id,
                    ga1.online_event_ts AS event_ts,
                    value,
                    ARRAY_AGG(DISTINCT subchannel_name) AS subchannel_name
                FROM (
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT  pollen_subchannel as subchannel_name , MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'search below grid'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%golapp:searchresults%'
                        AND lower(search_keyword) in (SELECT DISTINCT value FROM get_search_terms)
                        where
                        experiments like '%SponsoredProductsCount%'
                        UNION ALL
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT pollen_subchannel as subchannel_name , MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'search'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%search%'
                        AND lower(search_keyword) in (SELECT DISTINCT value FROM get_search_terms)
                        where
                        experiments like '%SponsoredProductsCount%'
                        UNION ALL
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT pollen_subchannel as subchannel_name, MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'checkout before you go'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%before you go%'
                        where
                        experiments like '%SponsoredProductsCount%'
                        UNION ALL
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT pollen_subchannel as subchannel_name , MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'favourites'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%favourites%'
                        where
                        experiments like '%SponsoredProductsCount%'
                        UNION ALL
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT pollen_subchannel as subchannel_name , MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'offers'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%offer%'
                        where
                        experiments like '%SponsoredProductsCount%'
                        UNION ALL
                        SELECT
                            online_account_num
                            , online_event_ts
                            , subchannel_name
                            , lower(search_keyword) AS value
                        FROM {{ get_table('flf_online_event_gol_app') }}
                        JOIN (SELECT pollen_subchannel as subchannel_name , MIN(start_date) as start_date , MAX(end_date) as end_date from  campaign_end_dt
                        where lower(subchannel_name) = 'search - app'
                        group by pollen_subchannel) ced
                        ON
                        event_dt between ced.start_date and ced.end_date
                        AND page_name ilike '%search%'
                        and lower(search_keyword) in (SELECT DISTINCT value FROM get_search_terms)
                        WHERE
                        experiments like '%SponsoredProductsCount%'
)  ga1
                            JOIN {{ get_table('dim_customer_loyalty') }}  AS dcl
                                ON ga1.online_account_num=dcl.customer_loyalty_cd
                        where
                            dcl.nectar_collector_card_num IS not NULL
                            and dcl.nectar_collector_card_num != '~~'
                            and ga1.online_account_num != '~~'
                GROUP BY
                    dcl.nectar_collector_card_num,
                    ga1.online_event_ts,
                    value
    )
    , gol_data_campaign_id AS (
        SELECT DISTINCT
                CASE WHEN ST.VALUE IS NOT NULL THEN gd.loyalty_id ELSE
                CASE WHEN CED.SUBCHANNEL_NAME IN (
                'browse',
                'offers',
                'zone',
                'checkout before you go',
                'favourites',
                'cross-sell',
                'homepage'
                ) THEN gd.loyalty_id ELSE NULL
                END
                END AS loyalty_id,
                gd.event_ts,
                ced.pollen_subchannel as subchannel_name,
                ced.campaign_id
        FROM gol_data_init gd
        join campaign_end_dt ced
        ON ARRAY_CONTAINS(ced.pollen_subchannel::VARIANT, gd.subchannel_name)
        AND TO_DATE(gd.event_ts) BETWEEN ced.start_date AND ced.end_date
       LEFT JOIN get_search_terms_init st
        ON gd.value = st.value
        AND ced.campaign_id = st.campaign_id
    )
    , gol_data AS (
        SELECT DISTINCT loyalty_id, event_ts, subchannel_name, campaign_id
        FROM gol_data_campaign_id
        WHERE loyalty_id IS NOT NULL
        ORDER BY loyalty_id
    )
    , get_fact_sale_transaction_basket as (
         select
        sales_origination_channel_cd,
        transaction_id,
        transaction_dt,
        nectar_card_num_hash,
        transaction_end_ts
        from {{ get_table('fact_sale_transaction_basket') }}
        where
            nectar_card_num_hash is not null
            and sales_origination_channel_cd in  (
                select upper(value)::string as codes
                from lateral flatten(input => parse_json('{{ params.sales_origination_all_codes | tojson }}')))
            AND EXISTS (SELECT COUNT(1) FROM get_targeted_skus HAVING COUNT(1) > 0)
            AND transaction_dt BETWEEN (SELECT MIN(campaign_start_dt) FROM citrus_channel_list) AND (SELECT MAX(campaign_end_dt) FROM citrus_channel_list)
            ORDER BY nectar_card_num_hash
    )
    -- {# /* getting relevant details from fact_sale_transaction_item. This cte is created to reduce read time from transaction_item table
    -- as it is reference multiple time. */ #}
    , get_fact_sale_transaction_item AS (
            select
                transaction_id,
                transaction_dt,
                item_cd,
                net_retail_sales_amt,
                item_qty,
                item_sequence_num,
                store_cd
            from {{ get_table('fact_sale_transaction_item') }}
            JOIN (SELECT distinct item_cd FROM get_targeted_skus) ts USING (item_cd)
            where
                net_retail_sales_amt > 0
            AND transaction_dt BETWEEN (SELECT MIN(campaign_start_dt) FROM citrus_channel_list) AND (SELECT MAX(campaign_end_dt) FROM citrus_channel_list)
    )
    , transaction_data_filtered AS (
         SELECT DISTINCT
            gd.loyalty_id,
            gfstb.transaction_dt as event_dt,
            gfstb.transaction_end_ts as event_ts,
            gfstb.transaction_id as transaction_key,
            gfsti.item_cd,
            gts.unique_brand_name,
            'NA' as marketing_type,
            CASE WHEN gfstb.sales_origination_channel_cd IN (
                SELECT instore_codes.value
                FROM TABLE(flatten(input => {{ params.sales_origination_instore_codes }}::ARRAY)) AS instore_codes
            ) THEN 'In-store'
            ELSE 'Online' END AS channel_name,

            ccl.campaign_name,
            ccl.campaign_id,
            ccl.subchannel_name,
            'Purchase Transaction' as event_name,
            ccl.booking_id,
            gts.product_type,
            gfsti.net_retail_sales_amt as net_sales_amt,
            gfsti.item_qty as units_qty,
            gfsti.item_sequence_num
        FROM get_fact_sale_transaction_item AS gfsti
        inner JOIN get_fact_sale_transaction_basket AS gfstb
            ON gfsti.transaction_id=gfstb.transaction_id
        inner JOIN get_targeted_skus AS gts
            ON gfsti.item_cd = gts.item_cd
        JOIN citrus_channel_list ccl
            ON gfsti.transaction_dt between ccl.campaign_start_dt and ccl.campaign_end_dt
            AND gfstb.transaction_dt between ccl.campaign_start_dt and ccl.campaign_end_dt
            AND gts.campaign_id = ccl.campaign_id
            AND gts.channel_name = ccl.channel_name
            AND gts.subchannel_name = ccl.subchannel_name
        inner JOIN gol_data AS gd
            ON gd.loyalty_id = gfstb.nectar_card_num_hash
            AND ccl.subchannel_name = gd.subchannel_name
            AND ccl.campaign_id = gd.campaign_id
            AND gd.event_ts <= gfstb.transaction_end_ts
    )
    , grouped_transaction_data AS (
        SELECT
            loyalty_id,
            event_dt,
            event_ts,
            transaction_key,
            item_cd,
            unique_brand_name,
            marketing_type,
            channel_name,
            campaign_name,
            campaign_id,
            subchannel_name,
            event_name,
            booking_id,
            product_type,
            sum(net_sales_amt) AS net_sales_amt,
            sum(units_qty) AS units_qty
        FROM transaction_data_filtered
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
    )
    , transaction_touchpoint_data AS (
        SELECT
            td.loyalty_id,
            ccl.marketing_type,
            ccl.channel_name,
            ccl.campaign_name,
            ccl.campaign_id,
            ccl.subchannel_name,
            td.transaction_key,
            'Touchpoint' AS event_name,
            ccl.booking_id,
            date(MIN(gd.event_ts)) AS event_dt,
            MIN(gd.event_ts) AS event_ts
            FROM (
            SELECT
            *
            , DENSE_RANK() over (PARTITION BY loyalty_id, campaign_id, subchannel_name ORDER BY  event_dt) AS dr_num
            FROM grouped_transaction_data) AS td
            inner JOIN (
                            SELECT
                                *
                                , DENSE_RANK() over (PARTITION BY loyalty_id, campaign_id, subchannel_name ORDER BY  date(event_ts)) AS dr_num
                            FROM gol_data) AS gd
                ON td.loyalty_id = gd.loyalty_id
                AND td.campaign_id = gd.campaign_id
                AND td.subchannel_name = gd.subchannel_name
                and td.event_ts >= gd.event_ts
                and td.dr_num = gd.dr_num
            JOIN citrus_channel_list ccl
            ON
                td.campaign_name = ccl.campaign_name
            AND td.campaign_id = ccl.campaign_id
            AND td.subchannel_name = ccl.subchannel_name
            AND td.booking_id = ccl.booking_id
            group by 1, 2, 3, 4, 5, 6, 7, 8, 9
    )
    /**************************
        1. this block defines a common table expression (cte) called get_initial_touchpoint_data
        which identifies initial touchpoints for transactions that have not yet been associated with a touchpoint.
        2. the purpose of this cte IS to ensure that transactions without previously identified
        touchpoints are linked to the earliest
        possible touchpoint event for the same customer (loyalty_id). this ensures comprehensive data alignment
        between transactions and touchpoints for accurate campaign tracking and analysis.
        *************************/
    , get_initial_touchpoint_data AS (
        SELECT
            sq.loyalty_id,
            ccl.marketing_type,
            ccl.channel_name,
            ccl.campaign_name,
            ccl.campaign_id,
            ccl.subchannel_name,
            sq.transaction_key,
            'Touchpoint' AS event_name,
            ccl.booking_id,
            date(MIN(gd.event_ts)) AS event_dt,
            MIN(gd.event_ts) AS event_ts
        FROM (
                SELECT DISTINCT
                    gtd.transaction_key,
                    gtd.loyalty_id,
                    gtd.event_ts,
                    gtd.campaign_name,
                    gtd.campaign_id,
                    gtd.subchannel_name,
                    gtd.booking_id
                FROM grouped_transaction_data AS gtd
                left JOIN transaction_touchpoint_data AS ttd
                USING (transaction_key, campaign_id, subchannel_name, booking_id)
                where ttd.transaction_key IS NULL
            ) AS sq
        inner JOIN gol_data AS gd
        ON sq.loyalty_id = gd.loyalty_id
        AND sq.campaign_id = gd.campaign_id
        AND sq.subchannel_name = gd.subchannel_name
        and sq.event_ts >= gd.event_ts
       JOIN citrus_channel_list ccl
             on   sq.campaign_name = ccl.campaign_name
            AND sq.campaign_id = ccl.campaign_id
            AND sq.subchannel_name = ccl.subchannel_name
            AND sq.booking_id = ccl.booking_id
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9
    )
           /**************************
            1. the purpose of this block IS to capture non-transactional touchpoints—interactions where customers engaged
            with the campaign (e.g., viewed an ad) but did not complete a purchase. this data IS essential for
            analyzing overall campaign engagement,
            including cases where no transactions occurred, which helps understand customer
            behavior beyond just purchases.
            2. the where gtd.loyalty_id IS NULL condition filters records to include only
            those touchpoints in gol_data that do not have a
            matching loyalty_id in grouped_transaction_data. this identifies customers who interacted with
            the campaign but did not make a transaction.
            **************************/
    , get_non_transactional_touchpoint AS (
        SELECT
            gd.loyalty_id,
            ccl.marketing_type,
            ccl.channel_name,
            ccl.campaign_name,
            ccl.campaign_id,
            ccl.subchannel_name,
            NULL AS transaction_key,
            'Touchpoint' AS event_name,
            ccl.booking_id,
            date(MIN(gd.event_ts)) AS event_dt,
            MIN(gd.event_ts) AS event_ts
        FROM gol_data AS gd
        JOIN citrus_channel_list ccl
        ON
        gd.campaign_id = ccl.campaign_id and
        gd.subchannel_name = ccl.subchannel_name
        left JOIN grouped_transaction_data AS gtd
        ON gd.loyalty_id = gtd.loyalty_id
        AND gd.campaign_id = gtd.campaign_id
        AND gd.subchannel_name = gtd.subchannel_name
        WHERE gtd.loyalty_id IS NULL
        group by 1, 2, 3, 4, 5, 6, 7, 8, 9
    )


            /**************************
            1. this block creates the union of all the transaction and touchpoint data.
            2. the union includes transaction data, touchpoint data, and non-transactional touchpoints.
            3. the final result set IS aliased AS citrus_collection, which contains all
            relevant customer interactions during the campaign period.
            ****************************/

    , citrus_collection AS (
        SELECT
            loyalty_id,
            transaction_key,
            event_dt,
            event_ts,
            marketing_type,
            channel_name,
            'TXN' AS subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            item_cd,
            product_type,
            unique_brand_name,
            net_sales_amt,
            units_qty
        FROM grouped_transaction_data
        union all
        SELECT
            loyalty_id,
            transaction_key,
            event_dt,
            event_ts,
            marketing_type,
            channel_name,
            subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM transaction_touchpoint_data
        union all
        SELECT
            loyalty_id,
            transaction_key,
            event_dt,
            event_ts,
            marketing_type,
            channel_name,
            subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM get_initial_touchpoint_data
        union all
        SELECT
            loyalty_id,
            NULL AS transaction_key,
            event_dt,
            event_ts,
            marketing_type,
            channel_name,
            subchannel_name,
            campaign_name,
            campaign_id,
            event_name,
            booking_id,
            NULL AS item_cd,
            NULL AS product_type,
            NULL AS unique_brand_name,
            NULL AS net_sales_amt,
            NULL AS units_qty
        FROM get_non_transactional_touchpoint
    )
        /****************************
        1. this block selects the final data FROM the citrus_collection cte.
        2. it includes various fields such AS loyalty_id, transaction_key, event_dt, event_ts,
        marketing_type, channel_name, subchannel_name, campaign_name, campaign_id, event_name,
        booking_id, item_cd, product_type, unique_brand_name, net_sales_amt, units_qty.
        and setting default values.
        4. the final result set IS returned AS the output of the macro.
        *****************************/

    SELECT
        loyalty_id::VARCHAR(1000) AS loyalty_id,
        COALESCE(transaction_key::VARCHAR(1000), 'NA') AS transaction_key,
        event_dt::DATE AS event_dt,
        event_ts::TIMESTAMP_NTZ(9) AS event_ts,
        marketing_type::VARCHAR(1000) AS marketing_type,
        channel_name::VARCHAR(1000) AS channel_name,
        subchannel_name::VARCHAR(1000) AS subchannel_name,
        campaign_name::VARCHAR(1000) AS campaign_name,
        campaign_id::VARCHAR(1000) AS campaign_id,
        event_name::VARCHAR(1000) AS event_name,
        booking_id::VARCHAR(1000) AS booking_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ(9) AS load_ts,
        COALESCE(item_cd::NUMBER(18, 0), 0) AS item_cd,
        COALESCE(product_type::VARCHAR(1000), 'NA') AS product_type,
        COALESCE(unique_brand_name::VARCHAR(1000), 'NA') AS unique_brand_name,
        COALESCE(net_sales_amt::NUMBER(30, 4), 0) AS net_sales_amt,
        COALESCE(units_qty::NUMBER(30, 4), 0) AS units_qty,
        CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS job_run_id
    FROM citrus_collection
)

include_query_id = true
header = true;
