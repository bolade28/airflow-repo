COPY INTO {{ get_stage('fb_insight_normalize') }}
FROM (
    SELECT
        start_dt
    ,   end_dt
    ,   campaign_id
    ,   adset_id
    ,   record_arrival_ts
    ,   SUM(total_sales) AS total_sales
    ,   SUM(sales_online) AS sales_online
    ,   SUM(sales_instore) AS sales_instore
    ,   SUM(internals_media_spend) AS internals_media_spend
    ,   SUM(externals_media_spend) AS externals_media_spend
    ,   SUM(impressions) AS impressions
    ,   SUM(clicks) AS clicks
    FROM
    (
        SELECT
            reporting_start_dt AS start_dt
        ,   reporting_end_dt AS end_dt
        ,   digital_trading_campaign_nk1 AS campaign_id
        ,   digital_trading_lineitem_nk1 AS adset_id
        ,   record_arrival_ts
        ,   measures:sales.total::FLOAT AS total_sales
        ,   measures:sales.online::FLOAT AS sales_online
        ,   measures:sales.instore::FLOAT AS sales_instore
        ,   measures:internals.media_spend::FLOAT AS internals_media_spend
        ,   measures:externals.media_spend::FLOAT AS externals_media_spend
        ,   measures:summary.impressions::FLOAT AS impressions
        ,   measures:summary.clicks::FLOAT AS clicks
        ,   MAX(record_arrival_ts) OVER (PARTITION BY start_dt, end_dt, campaign_id, adset_id ORDER BY NULL) AS max_record_arrival_ts
        FROM {{ get_table('digital_trading_lineitem_facebook_insight') }}
        WHERE reporting_start_dt = reporting_end_dt
    )
    WHERE record_arrival_ts = max_record_arrival_ts
    GROUP BY
        start_dt
    ,   end_dt
    ,   campaign_id
    ,   adset_id
    ,   record_arrival_ts

)
include_query_id = true
header = true;
