MERGE INTO {{ get_table('measurement_marketing_channel_hierarchy') }} AS target
USING (
    WITH latest_records AS (
        SELECT 
            MARKETING_HIERARCHY_CD,
            MAPPING_TYPE,
            MARKETING_CHANNEL,
            MARKETING_SUBCHANNEL,
            MEDIA_TYPE,
            CHANNEL_TYPE,
            LOAD_TS,
            ROW_NUMBER() OVER (
                PARTITION BY MARKETING_HIERARCHY_CD, MAPPING_TYPE 
                ORDER BY LOAD_TS DESC
            ) AS rn
        FROM {{ get_table('marketing_media_hierarchy_mkthrc_ref') }}
        WHERE MARKETING_HIERARCHY_CD IS NOT NULL
    )
    -- Primary identifier
    SELECT 
        MARKETING_HIERARCHY_CD AS marketing_hierarchy_cd,
        -- Hierarchy details
        MAPPING_TYPE AS mapping_type,
        MARKETING_CHANNEL AS marketing_channel,
        MARKETING_SUBCHANNEL AS marketing_subchannel,
        MEDIA_TYPE AS media_type,
        CHANNEL_TYPE AS channel_type,
        -- Apply in-scope logic
        CASE 
            WHEN MARKETING_HIERARCHY_CD IN ({{ params.inscope_hierarchy_cd }})
            THEN TRUE 
            ELSE FALSE 
        END AS in_scope_flag,
        -- Apply readiness logic
        CASE 
            WHEN MARKETING_HIERARCHY_CD IN ({{ params.measurement_ready_cd }})
            THEN TRUE 
            ELSE FALSE 
        END AS measurement_campaign_ready,
        
        '{{ params.correlation_id }}'::VARCHAR(36) AS correlation_id,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ AS load_ts
        
    FROM latest_records
    WHERE rn = 1
        
) AS source
ON target.marketing_hierarchy_cd = source.marketing_hierarchy_cd
   AND target.mapping_type = source.mapping_type
  
-- When record exists AND data has changed: UPDATE fields
WHEN MATCHED 
    AND (target.marketing_channel != source.marketing_channel 
        OR target.marketing_subchannel != source.marketing_subchannel 
        OR target.media_type != source.media_type 
        OR target.channel_type != source.channel_type 
        OR target.in_scope_flag != source.in_scope_flag 
        OR target.measurement_campaign_ready != source.measurement_campaign_ready)
THEN UPDATE SET
    target.marketing_channel = source.marketing_channel,
    target.marketing_subchannel = source.marketing_subchannel,
    target.media_type = source.media_type,
    target.channel_type = source.channel_type,
    target.in_scope_flag = source.in_scope_flag,
    target.measurement_campaign_ready = source.measurement_campaign_ready,
    target.correlation_id = source.correlation_id,
    target.last_modified_ts = source.load_ts

-- When record doesn't exist: INSERT new record
WHEN NOT MATCHED THEN INSERT (
    marketing_hierarchy_cd,
    mapping_type,
    marketing_channel,
    marketing_subchannel,
    media_type,
    channel_type,
    in_scope_flag,
    measurement_campaign_ready,
    correlation_id,
    load_ts,
    last_modified_ts
) VALUES (
    source.marketing_hierarchy_cd,
    source.mapping_type,
    source.marketing_channel,
    source.marketing_subchannel,
    source.media_type,
    source.channel_type,
    source.in_scope_flag,
    source.measurement_campaign_ready,
    source.correlation_id,
    source.load_ts,
    source.load_ts
);