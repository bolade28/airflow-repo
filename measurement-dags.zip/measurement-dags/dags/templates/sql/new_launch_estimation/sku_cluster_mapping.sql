COPY INTO {{ get_stage('previous_sku_cluster_mapping') }}
FROM (
    SELECT
    item_cd,
    super_category_name,
    unique_brand_name,
    cluster_num,
    job_run_id,
    load_ts,
    modelling_type
    FROM {{ get_table('measurement_sku_cluster_mapping') }}
)
include_query_id = true
header = true;
