COPY INTO {{ get_stage('cs_baseline_modelling_output') }}
FROM (
    SELECT
        super_category_name,
        unique_brand_name,
        load_ts
    FROM
        {{ get_table('baseline_modelling_output') }}
    WHERE
        best_iteration = 'Y'
        AND modelling_type = 'BASELINE_MODELLING'
)
include_query_id = true
header = true;