COPY INTO {{ get_stage('cs_sales_data') }}
FROM (
    SELECT
        week_start_dt,
        item_cd,
        unique_brand_name,
        super_category_name,
        total_sales_amt,
    FROM
        {{ get_table('transactions') }}
    WHERE
        unique_brand_name != ''
        AND unique_brand_name IS NOT NULL
)
include_query_id = true
header = true;