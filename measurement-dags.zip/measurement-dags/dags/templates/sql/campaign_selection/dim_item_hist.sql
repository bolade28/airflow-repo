COPY INTO {{ get_stage('dim_item_hist') }}
FROM (
    SELECT
        item_cd,
        valid_from_dt,
        valid_until_dt,
        super_cat_name, 
        item_stat_cd, 
    FROM
        {{ get_table('dim_item_hist') }}
)
include_query_id = true
header = true;
