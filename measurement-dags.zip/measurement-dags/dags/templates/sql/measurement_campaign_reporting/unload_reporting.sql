COPY INTO {{ get_stage('previous_measurement_campaign_reporting') }}
FROM (
    SELECT
        correlation_id,
        campaign_id,
        booking_id,
        campaign_duration,
        journey_type,
        marketing_type,
        channel_name,
        subchannel_name,
        sub_category_name,
        attributed_conversions,
        incremental_sales_amt_exposed,
        super_category_name,
        campaign_name,
        attributed_recalibrated_sales_amt,
        attributed_recalibrated_units_qty,
        incremental_units_qty_exposed,
        attributed_units_qty,
        attributed_sales_amt,
        conversions_recalibrated,
        recalibration_factor,
        job_bag_number,
        nectar_sales_amt,
        non_nectar_sales_amt,
        media_spend_amt,
        campaign_type,
        roas_exposed,
        iroas_exposed,
        base_sales_amt_exposed,
        uplift_exposed_sales_amt,
        uplift_exposed_units_qty,
        num_user_journeys,
        num_conversions,
        attributed_recalibrated_sales_amt_per_uj,
        attributed_recalibrated_sales_amt_per_conversion,
        conversion_per_uj,
        conversion_rate,
        CAST(load_ts AS TIMESTAMP_NTZ) AS load_ts,
        modelling_weight,
        marketing_hierarchy_cd,
        overlapping_campaign_flag,
    FROM
        {{ get_table('measurement_campaign_reporting_aws') }}
    WHERE
        correlation_id = '{{ params.during_correlation_id }}'
)
include_query_id = true
header = true;