COPY INTO {{ get_stage('sales_data_transaction') }}
FROM (
    SELECT DISTINCT
        week_start_dt,
        super_category_name,
        unique_brand_name,
        item_cd,
        total_sales_amt,
        nectar_sales_amt,
        non_nectar_sales_amt,
        frequency_of_purchase,
        distinct_customer_cnt,
        avg_purchase_per_customer_cnt,
        online_sales_pct,
        supermarket_sales_pct,
        convenience_sales_pct,
        pack_size,
        price_per_point,
        base_price_amt
    FROM {{ get_table('transactions') }}
    -- Filter to ensure all our transaction data is within the weekly date range
    -- Extended the lower week boundary by 2 weeks so data includes the additional pre-period needed for downstream processing
    WHERE week_start_dt >= (SELECT DATEADD(week, -2, MIN(week_start_dt))  FROM {{ get_table('weekly_start_dates') }})
    AND week_start_dt <= (SELECT MAX(WEEK_START_DT) FROM {{ get_table('weekly_start_dates') }})
)
include_query_id = true
header = true;