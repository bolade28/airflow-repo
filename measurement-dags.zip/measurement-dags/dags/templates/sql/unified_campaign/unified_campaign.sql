{#
/*********************************************************************************************************************************************
* Objective -  The script processes and combines data from multiple sources to create a clean, filtered, and enriched dataset of the campaigns. The final dataset includes:
* campaign details, brand information, and spend data and a unique booking id that is assigned to campaigns which have overlapping skus and campaign period.
* The script uses various CTEs to filter, join, and aggregate data from different tables, ensuring that only relevant and valid records are included.
* The final output is a comprehensive view of campaign data from all the channels
* Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/838116003/Unified+Campaign
* Upstream: CITRUS_CAMPAIGNS, DV360_CAMPAIGNS, MAGAZINE_CAMPAIGNS, COUPON_AT_TILL_CAMPAIGNS, INSTORES_CAMPAIGNS,META_CAMPAIGNS, ECOUPONS_CAMPAIGNS
* Downstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION,MEASUREMENT_CAMPAIGN_REPORTING
*
* This script will return all the campaigns and related information for the channels.


* Owner : Divya Jain
* Date :
*
* Change Log
* ----------------------------
1. Initial Version
********/
#}

CREATE OR REPLACE TABLE {{ get_table('measurement_unified_campaign') }} COPY GRANTS AS
(
{#
/*****************************************************
The combined raw campaign data is created by unioning all the individual campaign data sources.
****************************************************/
#}

{# /*The combined_unified_campaign_raw CTE combines all the campaign data all previous ctes */ #}
with combined_unified_campaign_raw as (
    select *
    from
        (
            select * from {{ get_table('measurement_coupon_at_till_campaigns') }}
            union all
            select * from {{ get_table('measurement_instore_campaigns') }}
            union all
            select * from {{ get_table('measurement_magazine_campaigns') }}
            union all
            select * from {{ get_table('measurement_ecoupons_campaigns') }}
            union all
            select * from {{ get_table('measurement_dv360_campaigns') }}
            union all
            select * from {{ get_table('measurement_meta_campaigns') }}
            union all
            select * from {{ get_table('measurement_citrus_campaigns') }}
        )
)

{# /*  Explode the raw data to retrieve the individual SKUs in order to assess post campaign period at a campaign level */ #}
, get_skus_for_post_campaign as (
    SELECT
        gnr.campaign_id,
        gnr.job_bag_number,
        gnr.item_cd_list,
        gnr.channel_name,
        gnr.subchannel_name,
        sku_list.value::INTEGER AS item
    FROM combined_unified_campaign_raw AS gnr,
    LATERAL FLATTEN(input => split(gnr.item_cd_list, ',')) AS sku_list
)

{# /* Join on the post_campaign_period table which tells us per SKU, how long we would expect for a post campaign period. Aggregate to take max period */ #}
, get_post_campaign_period as (
    SELECT
        gns.campaign_id,
        gns.channel_name,
        gns.subchannel_name,
        MAX(pcp.median_proposed_bucket_wk) AS post_campaign_wk
    FROM get_skus_for_post_campaign AS gns
    INNER JOIN {{ get_table('post_campaign_period') }} AS pcp
        ON gns.item = pcp.item_cd
    WHERE pcp.year_of_transaction = (SELECT YEAR(CURRENT_DATE()) - 1)
    GROUP BY 1, 2, 3
)

{# /* This post camaign period is joined back onto the campaign-level data and post_campaign_dt is assigned  */ #}
, combined_unified_campaign as (
    SELECT
    gnr.job_bag_number,
    gnr.campaign_id,
    gnr.media_spend_amt,
    gnr.campaign_start_dt,
    gnr.campaign_end_dt,
    gnr.subchannel_name,
    gnr.item_cd_list,
    gnr.super_category_name,
    gnr.sub_category_name,
    gnr.channel_name,
    gnr.campaign_name,
    gnr.marketing_type,
    gnr.unique_brand_name,
    CASE
        WHEN gpcp.post_campaign_wk IS NULL THEN DATEADD('DAY', 42, gnr.campaign_end_dt)
        ELSE DATEADD('DAY', gpcp.post_campaign_wk * 7, gnr.campaign_end_dt)
    END AS post_campaign_dt
FROM combined_unified_campaign_raw AS gnr
LEFT JOIN get_post_campaign_period AS gpcp
    ON gnr.campaign_id = gpcp.campaign_id
    AND gnr.channel_name = gpcp.channel_name
    AND gnr.subchannel_name = gpcp.subchannel_name
)

{# /* Run a count of distinct brands per campaign to filter out any multi-brand campaigns  */ #}
, multi_brand_campaigns as (
    SELECT  sku.campaign_id
        ,   count(distinct eb.brand_name) as brand_count
    FROM get_skus_for_post_campaign sku
    inner join {{ get_table('ean_br') }} as eb
        on
            sku.item = eb.item_nk1
    GROUP BY 1
    HAVING brand_count > 1
)
{# /* The multi-brand campaigns are filtered, row_numer is set on campaign_id to make sure that we have unique campaign_ids */ #}
, new_campaign_data as (
    SELECT DISTINCT
        job_bag_number,
        a.campaign_id,
        media_spend_amt,
        campaign_start_dt,
        campaign_end_dt,
        subchannel_name,
        item_cd_list,
        super_category_name,
        sub_category_name,
        channel_name,
        campaign_name,
        marketing_type,
        unique_brand_name,
        post_campaign_dt,
        strtok_to_array(item_cd_list, ',') AS item_list,
        DENSE_RANK() OVER (PARTITION BY a.campaign_id ORDER BY campaign_start_dt) AS id, -- In future, work out best field for order by
    FROM combined_unified_campaign a
    LEFT JOIN multi_brand_campaigns b ON a.campaign_id = b.campaign_id
    WHERE b.campaign_id IS NULL  -- Exclude campaigns with multiple brands
    QUALIFY id = 1
)
, historic_campaign_data as (
    SELECT DISTINCT
        job_bag_number,
        a.campaign_id,
        media_spend_amt,
        campaign_start_dt,
        campaign_end_dt,
        subchannel_name,
        item_cd_list,
        super_category_name,
        sub_category_name,
        channel_name,
        campaign_name,
        marketing_type,
        unique_brand_name,
        post_campaign_dt,
        strtok_to_array(item_cd_list, ',') AS item_list,
        DENSE_RANK() OVER (PARTITION BY a.campaign_id ORDER BY load_ts desc) AS id, -- In future, work out best field for order by
    FROM {{ get_table('measurement_unified_campaign') }} a 
    WHERE CAMPAIGN_ID NOT IN (SELECT campaign_id FROM new_campaign_data)
    QUALIFY id = 1
)
, campaign_data as (
    SELECT 
        job_bag_number,
        campaign_id,
        media_spend_amt,
        campaign_start_dt,
        campaign_end_dt,
        subchannel_name,
        item_cd_list,
        super_category_name,
        sub_category_name,
        channel_name,
        campaign_name,
        marketing_type,
        unique_brand_name,
        post_campaign_dt, 
        item_list,
        id
    FROM new_campaign_data
    UNION ALL
    SELECT 
        job_bag_number,
        campaign_id,
        media_spend_amt,
        campaign_start_dt,
        campaign_end_dt,
        subchannel_name,
        item_cd_list,
        super_category_name,
        sub_category_name,
        channel_name,
        campaign_name,
        marketing_type,
        unique_brand_name,
        post_campaign_dt, 
        item_list,
        id
    FROM historic_campaign_data
)
{# /* Find directly overlapping campaigns, based on whether they share SKUs over the same time window */ #}
, direct_overlaps AS (
    SELECT DISTINCT
        LEAST(a.campaign_id, b.campaign_id) AS source_campaign_id,
        GREATEST(a.campaign_id, b.campaign_id) AS target_campaign_id
    FROM campaign_data a
    JOIN campaign_data b
        ON (
           a.campaign_start_dt BETWEEN b.campaign_start_dt AND b.campaign_end_dt OR
           b.campaign_start_dt BETWEEN a.campaign_start_dt AND a.campaign_end_dt
       )
       AND ARRAY_SIZE(ARRAY_INTERSECTION(a.item_list, b.item_list)) > 0
)
{# /* We join the overlapping nodes together to find the minimal root_campaign_id which is the basis for our booking_id */ #}
, overlapping_booking_ids AS (
    SELECT  a.target_campaign_id,
         MIN(COALESCE( d.source_campaign_id ,c.source_campaign_id, b.source_campaign_id, a.source_campaign_id)) AS root_campaign_id
    FROM direct_overlaps a
    LEFT JOIN direct_overlaps b ON a.source_campaign_id = b.target_campaign_id
    LEFT JOIN direct_overlaps c ON b.source_campaign_id = c.target_campaign_id
    LEFT JOIN direct_overlaps d ON c.source_campaign_id = d.target_campaign_id
    GROUP BY 1
)

{# /* Union together the overlapping and non-overlapping campaigns */ #}
, initial_booking_ids AS (
    SELECT  root_campaign_id
        ,   a.target_campaign_id AS Campaign_id
    FROM overlapping_booking_ids a
    UNION ALL
    SELECT
        campaign_id AS booking_id,
        campaign_id
    FROM campaign_data
    WHERE campaign_id NOT IN (SELECT target_campaign_id FROM direct_overlaps)
)

{# /* Take minimum root_id to group campaigns together and collate all associated campaigns to the root. Build booking string as encoded representation of campaigns */ #}
, campaign_booking_map AS (
    SELECT
        root_campaign_id,
        LISTAGG(DISTINCT a.campaign_id, ',') WITHIN GROUP (ORDER BY a.campaign_id) AS booking_string,
        SHA2(booking_string, 256) AS booking_id
    FROM campaign_data a
    LEFT JOIN initial_booking_ids b ON a.campaign_id = b.campaign_id
    GROUP BY root_campaign_id
)

{# /* Create labels and flag for number of channels and subchannels. Also add mapped Booking_ID to base data  */ #}

, campaign_booking_channels AS (
    SELECT
        cd.*,
        cbm.booking_id AS booking_id,
        COUNT(DISTINCT channel_name) OVER (PARTITION BY booking_id) AS channel_count,
        COUNT(DISTINCT subchannel_name) OVER (PARTITION BY booking_id) AS subchannel_count,
        CASE
            WHEN channel_count > 1 THEN true
            WHEN channel_count = 1 AND subchannel_count > 1 THEN true
            WHEN channel_count = 1 AND channel_name NOT IN ('Onsite-GOL') THEN false
            WHEN channel_count = 1 AND channel_name = 'In-store'
                 AND ARRAY_SIZE(SPLIT(subchannel_name, ',')) > 1 THEN true
            ELSE false
        END AS is_multi_channel
    FROM campaign_data cd
    LEFT JOIN initial_booking_ids ib on ib.campaign_id = cd.campaign_id
    LEFT JOIN campaign_booking_map cbm
        ON cbm.root_campaign_id = ib.root_campaign_id)
{#
/*****************************
1. The unified_campaign CTE creates a final dataset that includes all the campaign data.
2. It selects relevant columns from the apply_booking_id CTE and assigns a load timestamp and job run ID.
3. Set campaign status to be null for any campaigns that finished their campaign or post-campaign period yesterday
*******************************/
#}
, unified_campaign_output as (
    select
        job_bag_number::varchar(1000) as job_bag_number
        , campaign_id::varchar(1000) as campaign_id
        , media_spend_amt::float as media_spend_amt
        , campaign_start_dt::date as campaign_start_dt
        , campaign_end_dt::date as campaign_end_dt
        , subchannel_name::varchar(1000) as subchannel_name
        , item_cd_list::varchar(16777216) as item_cd_list
        , super_category_name::varchar(1000) as super_category_name
        , sub_category_name::varchar(1000) as sub_category_name
        , channel_name::varchar(1000) as channel_name
        , campaign_name::varchar(1000) as campaign_name
        , booking_id::varchar(1000) as booking_id
        , CASE  WHEN DATE_TRUNC('day',campaign_end_dt) = DATE_TRUNC('day', DATEADD('day', -1, CURRENT_DATE))
                OR DATE_TRUNC('day',post_campaign_dt) = DATE_TRUNC('day', DATEADD('day', -1, CURRENT_DATE)) THEN NULL
                ELSE 'no exec'
                END::varchar(1000) as campaign_status
        , is_multi_channel::boolean as is_multi_channel
        , current_timestamp::timestamp_ntz as load_ts
        , '{{ params.correlation_id }}'::varchar(36) as job_run_id
        , marketing_type::varchar(100) as marketing_type
        , unique_brand_name::varchar(1000) as unique_brand_name
        , post_campaign_dt::date as post_campaign_dt
    from campaign_booking_channels
)

{#
/*********************************
1. The final select statement retrieves all columns from the unified_campaign CTE.
*********************************/
#}
select
    job_bag_number
    , campaign_id
    , media_spend_amt
    , campaign_start_dt
    , campaign_end_dt
    , subchannel_name
    , item_cd_list
    , super_category_name
    , sub_category_name
    , channel_name
    , campaign_name
    , booking_id
    , campaign_status
    , is_multi_channel
    , load_ts
    , job_run_id
    , marketing_type
    , unique_brand_name
    , post_campaign_dt
from unified_campaign_output
);

UPDATE {{ get_table('measurement_unified_campaign') }}
SET campaign_status = NULL;

