-- Only includes campaigns that have completed the 'during' evaluation period
SELECT
    u.JOB_BAG_NUMBER AS BOOKING_ID,
    b.BOOKING_NAME,
    u.POST_CAMPAIGN_DT,
    LISTAGG(DISTINCT u.MARKETING_TYPE, ', ') WITHIN GROUP (ORDER BY u.MARKETING_TYPE) AS MARKETING_TYPE,
    LISTAGG(DISTINCT u.CHANNEL_NAME, ', ') WITHIN GROUP (ORDER BY u.CHANNEL_NAME) AS CHANNEL_NAME,
    DATEDIFF('day', CURRENT_DATE, u.POST_CAMPAIGN_DT) AS days_until_post_end
FROM {{ get_table('measurement_unified_campaign_pollen_daily_etl') }} u
LEFT JOIN {{ get_table('campaign_booking_media_channel') }} b
    ON b.BOOKING_ID = u.JOB_BAG_NUMBER
WHERE u.POST_CAMPAIGN_DT >= CURRENT_DATE
  AND u.POST_CAMPAIGN_DT <= DATEADD('day', {{ params.days_threshold }}, CURRENT_DATE)
  AND u.LOAD_TS::DATE = CURRENT_DATE
  AND EXISTS (
      SELECT 1
      FROM {{ get_table('measurement_metadata') }} m
      WHERE m.BOOKING_ID = u.JOB_BAG_NUMBER
        AND m.EVALUATION_PERIOD = 'during'
  )
GROUP BY u.JOB_BAG_NUMBER, b.BOOKING_NAME, u.POST_CAMPAIGN_DT
ORDER BY u.POST_CAMPAIGN_DT ASC
