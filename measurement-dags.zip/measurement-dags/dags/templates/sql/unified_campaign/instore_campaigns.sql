CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_instore_campaigns') }} COPY GRANTS AS
(

{#
/**************************************************************************************************
1. This cte filters out campaign specific details for instore from base table and channel specific
2. Some of the filters include campaign start year and campaign start month which is taken from dbt_project.yml
3. where it has been configured as per the environment where it is run. To avoid having multiple start and expiry date
4. we are taking the minimum value of it for start date and maximum value for end date so as to have single start and end date to avoid multiples start and end date.
5. Media cost is aggregated at campaign level grouped by campaign id, start date, end date, media no and targeted id
****************************************************************************************************/
#}
with instore_data as (
    select
        master_campaign_id
        , start_date
        , end_date
        , media_no
        , targeted_id
        , sum(media_cost) as media_cost
    from {{ get_table('ie_media') }}
    where
        year(start_date) >= '{{ params.campaign_start_year }}'
        and month(start_date) >= '{{ params.campaign_start_month }}'
        and end_date < '{{ params.run_date }}'
        and (master_campaign_id, media_no)
        in (
            select
                master_campaign_id
                , media_no
            from {{ get_table('ie_location') }}
        )
    group by 1, 2, 3, 4, 5
)

{#
/*********************************************************************************************************************
1. The base_campaign_data CTE extracts and filters campaign data from the BASE_FINANCE_ASSETS_DATA table, focusing on campaigns that
meet specific criteria related to dates, statuses, media host names, and service types. It also enriches the data by deriving additional fields such as targeted_id
2. Some of the filters include campaign start year and campaign start month which is taken from dbt_project.yml
3. where it has been configured as per the environment where it is run. To avoid having multiple start and expiry date
4. This result from this cte will be used in later queries to get relevant campaign data for the In-store channel.
**********************************************************************************************************************/
#}
, base_campaign_data as (
    select
        job_bag_number
        , campaign_title
        , service_type as channel_name
        , asset_name_media_host_prf_name as subchannel_name
        , split_part(asset_unique_id, '-', -1) as targeted_id
    from {{ get_table('base_finance_assets') }} b1
    where
        timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = b1.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
        and
        year(asset_actual_start_date) >= '{{ params.campaign_start_year }}'
        and lower(campaign_status) in ('campaign completed','hfss unknown','campaign underway','current','approved')
        and lower(media_host_name) like 'sainsbur%'
        and lower(service_type) in
        (
            select distinct lower(service_type)
            from {{ get_table('unified_channel_mapping') }}
            where
                channel = 'Instore'
                and status = 'Active'
        )
)

{#
/*********************************************************************************************************************
1. The filtered_ean CTE retrieves the most recent record for each item_nk1 from the EAN_BR table, ensuring that only valid records are included.
2. It filters out records that are marked as deleted or have a validity date of '9999-12-31'.
3. This CTE is used to ensure that the most up-to-date information is used in subsequent joins.
***********************************************************************************************************************/
#}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag <> 'Y'
    group by 1
)

{#
/*********************************************************************************************************************
1. The get_brand_data CTE joins the filtered_ean CTE with the EAN_BR table to retrieve brand-related information for each item_nk1.
2. It filters out records that are marked as deleted or have a validity date of '9999-12-31'.
3. The result includes the item_nk1, brand_name, brand_owner_name, and ean_nk1 for each item.
5. This CTE is used to enrich the campaign data with brand information.
****************************************************************************************************************/
#}
, get_brand_data as (
    select
        fe.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
        , eb.ean_nk1
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag <> 'Y'
)

{#
/***********************************************************
1. The cte get_evaluated_campaigns retrieves campaign data from the base_campaign_data CTE and joins it with the instore_data CTE and the IE_PRODUCT table.
2. It filters the data to include only campaigns that have a product name of 'offer' and are associated with valid brands.
3. The result includes the job_bag_number, campaign_title, channel_name, subchannel_name, media_no, item_nk1, brand_name, and a unique identifier for the brand.
4. The brand_name and brand_owner_name are concatenated to create a unique identifier for the brand.
********************************************************/
#}
, get_evaluated_campaigns as (
    select
        bcd.job_bag_number
        , bcd.campaign_title
        , bcd.channel_name
        , bcd.subchannel_name
        , id.media_no
        , gbd.item_nk1
        , gbd.brand_name
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from base_campaign_data as bcd
    inner join instore_data as id
        on
            bcd.job_bag_number = id.master_campaign_id
            and bcd.targeted_id = id.targeted_id
    inner join {{ get_table('ie_product') }} as iep
        on lower(bcd.job_bag_number) = lower(iep.master_campaign_id)
    inner join get_brand_data as gbd
        on substr(iep.product_key, 2, 13) = gbd.ean_nk1
    where lower(iep.product_name) = 'offer'
)

{#
/*****************************************************
1. The cte get_correct_campaign filters the evaluated campaigns to include only those that have no null brand names.
2. It groups the data by job_bag_number and checks if the sum of null brand names is zero.
3. This ensures that only campaigns with valid brand names are included in the final result.
********************************************************/
#}
, get_correct_campaign as (
    select job_bag_number
    from get_evaluated_campaigns
    group by 1
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{#
/*****************************************
1. The instore_campaigns CTE retrieves campaign data for the In-store channel by joining the get_evaluated_campaigns CTE with the instore_data CTE and the DIM_ITEM table.
2. It filters the data to include only campaigns that are present in the get_correct_campaign CTE.
3. The result includes the job_bag_number, campaign_id, marketing_type, channel_name, campaign_name, campaign_start_dt, subchannel_name, media_spend_amt, campaign_end_dt, item_cd_list, unique_brand_name, super_category_name, and sub_category_name.
4. The item_cd_list, unique_brand_name, super_category_name, and sub_category_name are aggregated using listagg to create comma-separated lists.
5. The data is grouped by job_bag_number, campaign_id, marketing_type, channel_name, campaign_name, campaign_start_dt, subchannel_name, media_spend_amt, and campaign_end_dt.
6. The result is ordered by job_bag_number.
7. This CTE is used to create a final view of the In-store campaigns with all relevant details.
*******************************************/
#}
, instore_campaigns as (
    select
        gec.job_bag_number
        , gec.job_bag_number as campaign_id
        , 'In-store' as marketing_type
        , gec.channel_name
        , gec.campaign_title as campaign_name
        , id.start_date as campaign_start_dt
        , gec.subchannel_name
        , id.media_cost as media_spend_amt
        , id.end_date as campaign_end_dt
        , listagg(distinct di.item_cd, ',') within group (order by di.item_cd) as item_cd_list
        , listagg(distinct gec.unique_brand_name, ',')
        within group (order by gec.unique_brand_name) as unique_brand_name
        , listagg(distinct di.super_cat_name, ',') within group (order by di.super_cat_name) as super_category_name
        , listagg(distinct di.sub_cat_name, ',') within group (order by di.sub_cat_name) as sub_category_name
    from get_evaluated_campaigns as gec
    inner join instore_data as id
        on
            id.master_campaign_id = gec.job_bag_number
            and id.media_no = gec.media_no
    inner join {{ get_table('dim_item') }} as di
        on gec.item_nk1 = di.item_cd
    where gec.job_bag_number in (select distinct job_bag_number from get_correct_campaign)
    group by
        1, 2, 3, 4, 5, 6, 7, 8, 9
    order by 1
)

{# /* Generating the final output which is the consolidated view of the In-store campaigns */ #}
select
    job_bag_number,
    campaign_id,
    marketing_type,
    channel_name,
    campaign_name,
    campaign_start_dt,
    subchannel_name,
    media_spend_amt,
    campaign_end_dt,
    item_cd_list,
    unique_brand_name,
    super_category_name,
    sub_category_name
from instore_campaigns

);
