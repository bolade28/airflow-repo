CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_citrus_campaigns') }} COPY GRANTS AS
(

{#
/**************************************************************************************************
1. The get_base_finance_data CTE retrieves distinct job bag numbers and booking line IDs from the BASE_FINANCE_ASSETS_DATA table.
2. It filters the data based on specific criteria, such as campaign status, media host name, service type, and asset name.
3. The CTE also ensures that the asset actual start date is within a specified range and that the asset actual end date is before the current date.
4. This CTE is used to identify the relevant campaigns for further processing.
*************************************************************************************************/
#}
with get_base_finance_data as (
    select distinct
        bfad.job_bag_number
        , bfad.booking_line_id
        , 'Onsite-GOL' as channel
    from {{ get_table("base_finance_assets") }} as bfad
    where
        timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = bfad.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
        and
        year(bfad.asset_actual_start_date) >= '{{ params.campaign_start_year }}'
        and lower(bfad.campaign_status) in ('campaign completed','hfss unknown','campaign underway','current','approved')
        and lower(bfad.media_host_name) like 'sainsbur%'
        and bfad.service_type = '{{ params.channel_mapping_onsite_citrus_service_type }}'
        and bfad.asset_name_media_host_prf_name in
        (
            select distinct asset_name
            from {{ get_table('unified_channel_mapping') }}
            where
                status = 'Active'
                and channel = '{{ params.channel_mapping_onsite_citrus }}'
                and service_type = '{{ params.channel_mapping_onsite_citrus_service_type }}'
        )
)

{#
/*************************************************************************************
1. The get_max_load_citrus CTE retrieves the maximum load timestamp for each advertising campaign from the ADVERTISING_CAMPAIGN_CITCAM_SAT table.
2. It groups the data by advertising_campaign_nk1 to ensure that only the latest load timestamp is retained for each campaign.
3. This CTE is used to identify the most recent data for each advertising campaign.
************************************************************************************/
#}
, get_max_load_citrus as (
    select
        advertising_campaign_nk1
        , max(load_ts) as load_ts
    from {{ get_table('advertising_campaign_citcam_sat') }}
    group by advertising_campaign_nk1
)

{#
/*************************************************************************************
1. The get_citrus_max CTE retrieves the maximum load timestamp for each advertising campaign from the ADVERTISING_CAMPAIGN_CITCAM_SAT table.
2. It filters the data based on the advertising_campaign_nk1 and load_ts values obtained from the get_max_load_citrus CTE.
3. This CTE is used to identify the most recent data for each advertising campaign.
4. The CTE also selects relevant columns such as campaign start and end timestamps, campaign name, advertising campaign key, placements, spend amount, and product list.
**********************************************************/
#}
, get_citrus_max as (
    select
        campaign_start_ts
        , campaign_end_ts
        , campaign_name
        , advertising_campaign_nk1
        , campaign_placements
        , campaign_total_spend_amt
        , campaign_catalog_product_list
    from {{ get_table('advertising_campaign_citcam_sat') }}
    where
        (advertising_campaign_nk1, load_ts)
        in (
            select distinct
                advertising_campaign_nk1
                , load_ts
            from get_max_load_citrus
        )

)

{#
/*********************************
1. The get_citrus_channel_data CTE retrieves data from the get_citrus_max CTE.
2. It filters the data based on specific criteria, such as campaign placements, campaign start and end dates, and product list length. The campaign_start_date
and campaign_end_date are filtered to ensure they are not null and that the campaign end date is before the current date. Also the campaign_start_date is
filtered to ensure it is greater than or equal to the specified year and month in the dbt_project.yml file.
3. The CTE also aggregates the data by summing the campaign total spend amount and creating a list of distinct product values.
4. It groups the data by advertising campaign key, campaign name, placements, and campaign start and end dates.
5. This CTE is used to prepare the data for further processing and analysis.
**********************************/
#}
, get_citrus_channel_data as (
    select
        gcm.advertising_campaign_nk1
        , gcm.campaign_name as campaign_title
        , date(gcm.campaign_start_ts) as campaign_start_dt
        , date(gcm.campaign_end_ts) as campaign_end_dt
        , trim(substr(gcm.campaign_placements, (position('-', gcm.campaign_placements, 1) + 1))) as subchannel
        , sum(gcm.campaign_total_spend_amt) as media_spend_amt
        , listagg(distinct item.value, ',') within group (order by item.value) as product_list
    from get_citrus_max as gcm
    , lateral flatten(input => gcm.campaign_catalog_product_list::array) as item
    where
        gcm.campaign_placements ilike '%sainsbury%'
        and year(gcm.campaign_start_ts) >= '{{ params.campaign_start_year }}'
        and month(gcm.campaign_start_ts) >= '{{ params.campaign_start_month }}'
        and gcm.campaign_start_ts is not null
        and gcm.campaign_end_ts is not null
        and len(gcm.campaign_catalog_product_list) != 0
    group by
        gcm.advertising_campaign_nk1, gcm.campaign_name, gcm.campaign_placements, date(gcm.campaign_start_ts)
        , date(gcm.campaign_end_ts)
)

{#
/*************************************************************************************
1. The base_citrus_campaigns CTE retrieves distinct job bag numbers, booking line IDs, and other campaign-related information
 from the get_base_finance_data and get_citrus_channel_data CTEs.
2. It joins the two CTEs on the booking line ID and advertising_campaign_nk1 to combine the data.
3. The CTE selects relevant columns such as channel, job bag number, campaign title, product list, campaign start and end dates, media spend amount, and subchannel.
**************************************************************************************/
#}
, base_citrus_campaigns as (
    select distinct
        gbfd.booking_line_id
        , gbfd.channel
        , gbfd.job_bag_number
        , gccd.campaign_title
        , gccd.product_list
        , gccd.campaign_start_dt
        , gccd.campaign_end_dt
        , gccd.media_spend_amt
        , gccd.subchannel
    from get_base_finance_data as gbfd
    inner join get_citrus_channel_data as gccd
        on gbfd.booking_line_id = gccd.advertising_campaign_nk1
)

{#
/**********************************************************************
1. The get_product_data CTE retrieves distinct job bag numbers, booking line IDs, item codes, super category names, and subcategory names from the base_citrus_campaigns CTE.
2. It uses the lateral flatten function to split the product list into individual SKUs and joins with the DIM_ITEM table to get item details.
3. The CTE selects relevant columns such as job bag number, booking line ID, item code, super category name, and subcategory name.
4. This CTE is used to prepare the data for further processing and analysis.
***********************************************************************/
#}
, get_product_data as (
    select distinct
        bcc.job_bag_number
        , bcc.booking_line_id
        , di.item_cd
        , di.super_cat_name
        , di.sub_cat_name
    from base_citrus_campaigns as bcc
    ,
        lateral flatten(
            input => split(bcc.product_list, ','), outer => true
        ) as sku
    inner join {{ get_table('dim_item') }} as di
        on sku.value::number(10, 0) = di.item_cd
)

{#
/********************************************************************
1. The filtered_ean CTE retrieves distinct item numbers and the maximum load timestamp from the EAN_BR table.
2. It filters the data based on specific criteria, such as valid_to_dt and record_deleted_flag. The valid_to_dt is set to '9999-12-31'
which means the data is still valid.
3. The CTE groups the data by item number to ensure that only the latest load timestamp is retained for each item.
******************************************************************/
#}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag <> 'Y'
    group by 1
)

{#
/************************************************************
1. The get_brand_data CTE retrieves brand information from the EAN_BR table.
2. It joins the filtered_ean CTE with the EAN_BR table to get brand name, brand owner name, and ean_nk1.
3. The join condition ensures that only the most recent records are included based on the load_ts column.
4. The CTE filters the data to include only valid records (valid_to_dt = '9999-12-31' and record_deleted_flag <> 'Y').
*************************************************************/
#}
, get_brand_data as (
    select
        fe.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
        , eb.ean_nk1
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag <> 'Y'
)

{#
/********************************************************************
1. Get_product_details CTE retrieves distinct job bag numbers, booking line IDs, item codes, super category names, subcategory names, brand names, and unique brand names.
2. It joins the get_product_data CTE with the get_brand_data CTE to get brand information.
3. The join condition ensures that the item number from the get_brand_data CTE matches the item code from the get_product_data CTE.
4. The CTE concatenates brand name and brand owner name to create a unique brand name.
**************************************************************/
#}
, get_product_details as (
    select distinct
        gpd.job_bag_number
        , gpd.booking_line_id
        , gpd.item_cd
        , gpd.super_cat_name
        , gpd.sub_cat_name
        , gbd.brand_name
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from get_product_data as gpd
    inner join get_brand_data as gbd
        on to_varchar(gbd.item_nk1) = to_varchar(gpd.item_cd)
)

{#
/************************************************
1. The get_correct_campaign CTE retrieves distinct job bag numbers from the get_product_details CTE.
2. It groups the data by job bag number and checks if the sum of null brand names is equal to 0.
3. This ensures that only campaigns with valid brand names are included.
4. The CTE is used to filter out campaigns with null brand names.
*************************************************/
#}
, get_correct_campaign as (
    select job_bag_number
    from get_product_details
    group by job_bag_number
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{#
/******************************************************
1. The citrus_campaigns_pre CTE retrieves campaign-related data from the base_citrus_campaigns CTE.
2. It joins the base_citrus_campaigns CTE with the get_product_details CTE to get product information.
3. The join condition ensures that the job bag number and booking line ID match between the two CTEs.
4. The CTE filters the data based on the job bag number from the get_correct_campaign CTE.
5. It selects relevant columns such as job bag number, campaign ID, marketing type, channel name, campaign name, campaign start and end dates, media spend amount, and product details.
6. The CTE also aggregates product details using listagg to create a comma-separated list of item codes, unique brand names, super category names, and subcategory names.
7. The data is grouped by job bag number, booking line ID, marketing type, channel name, campaign title, campaign start date,
media spend amount, subchannel name, and campaign end date.
8. This CTE is used to prepare the data for further processing and analysis.
*******************************************************/
#}
, citrus_campaigns_pre as (
    select
        bcc.job_bag_number
        , bcc.booking_line_id as campaign_id
        , 'Onsite' as marketing_type
        , bcc.channel as channel_name
        , bcc.campaign_title as campaign_name
        , bcc.campaign_start_dt
        , bcc.subchannel as subchannel_name
        , bcc.media_spend_amt
        , bcc.campaign_end_dt
        , listagg(distinct gpd.item_cd, ',') within group (order by gpd.item_cd) as item_cd_list
        , listagg(distinct gpd.unique_brand_name, ',')
        within group (order by gpd.unique_brand_name) as unique_brand_name
        , listagg(distinct gpd.super_cat_name, ',') within group (order by gpd.super_cat_name) as super_category_name
        , listagg(distinct gpd.sub_cat_name, ',') within group (order by gpd.sub_cat_name) as sub_category_name
    from base_citrus_campaigns as bcc
    inner join get_product_details as gpd
        on
            bcc.job_bag_number = gpd.job_bag_number
            and bcc.booking_line_id = gpd.booking_line_id
    where bcc.job_bag_number in (select distinct job_bag_number from get_correct_campaign)
    group by
        bcc.job_bag_number, bcc.booking_line_id
        , marketing_type, bcc.channel
        , bcc.campaign_title, bcc.campaign_start_dt
        , bcc.media_spend_amt, bcc.subchannel
        , bcc.campaign_end_dt
)

{#
/***********************************************
1. The get_job_bag_groups CTE retrieves distinct job bag numbers and campaign IDs from the citrus_campaigns_pre CTE.
2. It groups the data by campaign ID and aggregates the job bag numbers into a comma-separated list using listagg.
3.This solves the problem where a campaign ID can have multiple job bag numbers associated with it.
*************************************************/
#}
, get_job_bag_groups as (
    select
        campaign_id
        , listagg(distinct job_bag_number, '|') within group (order by job_bag_number) as job_bag_number
    from citrus_campaigns_pre
    group by campaign_id
)

{#
/*******************************************
1. The final select statement retrieves distinct job bag numbers, campaign IDs, marketing type, channel name, campaign name,
campaign start and end dates, subchannel name, media spend amount, item code list, unique brand name, super category name, and subcategory name from the citrus_campaigns_pre CTE.
2. It joins the citrus_campaigns_pre CTE with the get_job_bag_groups CTE on campaign ID to get the job bag numbers associated with each campaign.
3. The final output includes all the relevant campaign details for citrus_campaign view.
4. The data is filtered to include only distinct records to avoid duplicates.
*********************************************/
#}
select distinct
    gjbg.job_bag_number
    , gjbg.campaign_id
    , ccp.marketing_type
    , ccp.channel_name
    , ccp.campaign_name
    , ccp.campaign_start_dt
    , ccp.subchannel_name
    , ccp.media_spend_amt
    , ccp.campaign_end_dt
    , ccp.item_cd_list
    , ccp.unique_brand_name
    , ccp.super_category_name
    , ccp.sub_category_name
from citrus_campaigns_pre as ccp
inner join get_job_bag_groups as gjbg
    on ccp.campaign_id = gjbg.campaign_id

);
