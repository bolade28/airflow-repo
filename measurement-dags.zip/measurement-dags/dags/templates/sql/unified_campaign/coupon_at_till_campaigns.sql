CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_coupon_at_till_campaigns') }} COPY GRANTS AS
(
{#
-- /*********************************************************************************************************************************************
-- * Objective -  The script processes and combines data from multiple sources to create a clean, filtered, and enriched dataset of coupon at till campaigns. The final dataset includes:
-- * campaign details, brand information, and spend data for coupon at till.
-- * The script uses various CTEs to filter, join, and aggregate data from different tables, ensuring that only relevant and valid records are included.
-- * The final output is a comprehensive view of campaign data from both platforms, which can be used as input for UNIFIED_CAMPAIGN
-- * Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/838116003/Unified+Campaign
-- * Upstream: 
-- * Downstream: UNIFIED_CAMPAIGN
-- *
-- * This script will return all the campaigns and related information for coupon at till.
-- /**************************************************************************************************
-- * This cte filters out campaign specific details for coupon at till from base table and channel specific
-- table. Some of the filters include campaign start year and campaign start month which is taken from dbt_project.yml
-- where it has been configured as per the environment where it is run. To avoid having multiple start and expiry date
-- we are taking the minimum value of it for start date and maximum value for end date. 
-- ***************************************************************************************************/
#}
with base_cat_campaigns as (
    select
        bfad.job_bag_number
        , bfad.campaign_title as campaign_name
        , bfad.asset_value_unweighted
        , 'Coupon At Till' as channel
        , bfad.asset_name_media_host_prf_name as subchannel
        , bfad.campaign_title
        , split_part(bfad.asset_unique_id, '-', -1) as campaign_id
        , min(coup.start_date) as campaign_start_date
        , max(coup.expiry_date) as campaign_end_date
    from {{ get_table('base_finance_assets') }} as bfad
    inner join {{ get_table('cell') }} as c on c.campaign_id = split_part(bfad.asset_unique_id, '-', -1)
    inner join {{ get_table('coupon_cell') }} as cc on c.cell_key = cc.cell_key
    inner join {{ get_table('coupon') }} as coup on cc.coupon_key = coup.coupon_key
    where
        timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = bfad.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
        and
        year(bfad.asset_actual_start_date) >= '{{ params.campaign_start_year }}'
        and lower(bfad.media_host_name) like 'sainsbur%'
        and lower(bfad.service_type) in ('coupon at till')
        and coup.expiry_date is not null
        and year(coup.start_date) >= '{{ params.campaign_start_year }}'
        and month(coup.start_date) >= '{{ params.campaign_start_month }}'
        and lower(bfad.campaign_status) in ('campaign completed', 'hfss unknown','campaign underway','current','approved')
    group by 1, 2, 3, 4, 5, 6, 7
)

{# /* Getting the latest record grouped by an item_nk1 to avoid duplicate values and get the most updated information */ #}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag <> 'Y'
    group by 1
)

{# /* 1. Getting brand specific details. We wil use the brand name concatenated with brand owner name as the unique brand name. 
    The filter valid_to_dt = 9999-12-31 represents the sku doesn't have roll out date , so it is a valid item. */ #}
, get_brand_data as (
    select
        fe.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
        , eb.ean_nk1
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag <> 'Y'
)

{# /* Getting all sku specific detals after a join with dim item table. We have also applied the necessary filters
The filters correct_offer and correct_brand fetches valid products */ #}
, sku_data as (
    select distinct
        bcc.job_bag_number
        , bcc.campaign_id
        , di.super_cat_name
        , di.sub_cat_name
        , di.item_cd
        , gbd.brand_name
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from base_cat_campaigns as bcc
    inner join {{ get_table('cell') }} as c on bcc.campaign_id = c.campaign_id
    inner join {{ get_table('coupon_cell') }} as cc on c.cell_key = cc.cell_key
    inner join {{ get_table('coupon_to_product') }} as ctp on cc.coupon_key = ctp.coupon_key
    inner join get_brand_data as gbd
        on substr(ctp.product_key, 2, 13) = to_varchar(gbd.ean_nk1)
    inner join {{ get_table('dim_item') }} as di on to_varchar(gbd.item_nk1) = to_varchar(di.item_cd)
    where
        ctp.correct_offer = 'Y'
        and ctp.correct_brand = 'Y'
)

{# /* If the brand name is not available then we should filter out those campaign as null values in brand name is not permitted. */ #}
, get_correct_campaign as (
    select job_bag_number
    from sku_data
    group by 1
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{# /* getting all campaign related information for coupon at till as fetched from the previous ctes
    Getting only details of those campaign which are valid as selected from last cte */ #}
, coupon_at_till_campaigns as (
    select
        bcc.job_bag_number,
        bcc.campaign_id,
        'Targeted Media' as marketing_type,
        bcc.channel as channel_name,
        bcc.campaign_name,
        bcc.campaign_start_date as campaign_start_dt,
        bcc.subchannel as subchannel_name,
        bcc.asset_value_unweighted as media_spend_amt,
        bcc.campaign_end_date as campaign_end_dt,
        listagg(distinct sd.item_cd, ',') within group (order by sd.item_cd) as item_cd_list,
        listagg(distinct sd.unique_brand_name, ',') within group (order by sd.unique_brand_name) as unique_brand_name,
        listagg(distinct sd.super_cat_name, ',') within group (order by sd.super_cat_name) as super_category_name,
        listagg(distinct sd.sub_cat_name, ',') within group (order by sd.sub_cat_name) as sub_category_name
    from base_cat_campaigns as bcc
    inner join sku_data as sd
        on
            bcc.job_bag_number = sd.job_bag_number
            and bcc.campaign_id = sd.campaign_id
    where bcc.job_bag_number in (select distinct job_bag_number from get_correct_campaign)
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9
)

select 
    job_bag_number, 
    campaign_id, 
    marketing_type,
    channel_name,
    campaign_name,
    campaign_start_dt, 
    subchannel_name, 
    media_spend_amt,
    campaign_end_dt, 
    item_cd_list, 
    unique_brand_name, 
    super_category_name, 
    sub_category_name 
from coupon_at_till_campaigns
);
