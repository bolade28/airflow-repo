COPY INTO {{ get_stage('unified_campaigns_pollen') }}
FROM (
SELECT
    job_bag_number,
    campaign_id,
    media_spend_amt,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    job_bag_number AS booking_id,
    NULL as campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    post_campaign_dt,
    marketing_hierarchy_cd
FROM {{ get_table('measurement_unified_campaign_pollen') }}
WHERE load_ts = (SELECT MAX(load_ts) FROM {{ get_table('measurement_unified_campaign_pollen') }})
)
include_query_id = true
header = true;
