CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_meta_campaigns') }} COPY GRANTS AS
(

{#
/****************************************************************************
1. The query retrieves distinct campaign details, including job bag IDs, campaign channels, start and end dates, and SKU (Stock Keeping Unit) information.
 It also processes a list of SKUs by splitting and flattening it into individual values
2. The query filters the campaigns based on specific criteria, such as job bag ID patterns, campaign start and end dates, and the year and month of the campaign start date.
3. The campaigns are filtered to include only those that have a job bag ID starting with 'nec' and a campaign start date greater than or equal
 to the specified year and month in dbt_project.yml as per the environment where it is running.
*****************************************************************************/
#}
with fb_campaign as (
    select distinct
        dtcds.job_bag_id
        , dtccdl.digital_trading_campaign_channel_nk1
        , date(dtcds.campaign_start_ts) as campaign_start_date
        , date(dtcds.campaign_end_ts) as campaign_end_date
        , substr(dtcds.measurement_sku_list, 2, len(dtcds.measurement_sku_list) - 2) as sku
        , substr(sku_list.value, 2, len(sku_list.value) - 2) as sku_no
    from {{ get_table('digital_trading_campaign_sat') }} as dtcds
    inner join {{ get_table('digital_trading_campaign_link') }} as dtccdl
        on dtcds.digital_trading_campaign_nk1 = dtccdl.digital_trading_campaign_nk1
    , lateral flatten(input => split(sku, ',')) as sku_list
    where
        len(sku_list.value) != 0
        and dtcds.job_bag_id ilike 'nec%'
        and year(dtcds.campaign_start_ts) >= '{{ params.campaign_start_year }}'
        and month(dtcds.campaign_start_ts) >= '{{ params.campaign_start_month }}'
)
{#
/*********************************************************************************************************************
1. The base_meta_campaigns CTE retrieves distinct campaign details from the BASE_FINANCE_ASSETS_DATA table.
2. It filters the data based on specific criteria, such as asset name, time ID, campaign status, and media host name.
3. The CTE selects the job bag number, campaign ID, and campaign name for campaigns that meet the criteria.
4. The campaigns are filtered to include only those with asset names containing 'facebook' and media host names starting with 'sainsbur'.
5. The campaign status is limited to 'campaign completed' or 'hfss unknown'.
6. The time ID is set to the maximum value from the BASE_FINANCE_ASSETS_DATA table.
7. The campaign start date is filtered to be greater than or equal to the specified year in dbt_project.yml as per the environment where it is running.
*********************************************************************************************************/
#}
, base_meta_campaigns as (
    select distinct
        job_bag_number
        , job_bag_number as campaign_id
        , campaign_title as campaign_name
    from
        {{ get_table('base_finance_assets') }} b1
    where
        timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = b1.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
        and
        asset_name_media_host_prf_name ilike '%facebook%'
        and year(asset_actual_start_date) >= '{{ params.campaign_start_year }}'
        and lower(campaign_status) in ('campaign completed','hfss unknown','campaign underway','current','approved')
        and lower(media_host_name) like 'sainsbur%'
)

{#
/*********************************************************************************************************************
1. The filtered_ean CTE retrieves distinct item numbers (item_nk1) and their maximum load timestamps (max_ts) from the EAN_BR table.
2. It filters the data to include only valid records (valid_to_dt = '9999-12-31' and record_deleted_flag != 'Y').
3. The CTE groups the data by item_nk1 to ensure that only the most recent record for each item is included.
********************************************************************************************************************/
#}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag != 'Y'
    group by item_nk1
)

{#
/*********************************************************************************************************************
1. The get_brand_data CTE retrieves brand information from the EAN_BR table.
2. It joins the filtered_ean CTE with the EAN_BR table on item_nk1 and load_ts to get the most recent brand data.
3. The CTE selects the item number (item_nk1), brand name, and brand owner name.
4. The data is filtered to include only valid records (valid_to_dt = '9999-12-31' and record_deleted_flag != 'Y').
5. The brand name and brand owner name are concatenated to create a unique brand name in the later cte
**********************************************************************************************************************/
#}
, get_brand_data as (
    select
        eb.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag != 'Y'
)

{#
/*********************************************************************************************************************
1. The base_exist_campaigns CTE retrieves campaign data from the fb_campaign and base_meta_campaigns CTEs.
2. It joins the fb_campaign CTE with the base_meta_campaigns CTE on job bag ID to get campaign details.
3. The CTE also joins the get_brand_data CTE to get brand information based on the SKU number.
4. The join condition ensures that the SKU number from the fb_campaign CTE matches the item code in the DIM_ITEM table.
5. The CTE selects various columns, including job bag number, campaign ID, campaign name, campaign start and end dates, 
item code, super category name, sub category name, brand name, and a concatenated brand field.
6. The unique brand name is created by concatenating the brand name and brand owner name.
****************************************************************************************/
#}
, base_exist_campaigns as (
    select
        bmc.job_bag_number
        , bmc.campaign_id
        , bmc.campaign_name
        , fc.campaign_start_date
        , fc.campaign_end_date
        , di.item_cd
        , di.super_cat_name
        , di.sub_cat_name
        , gbd.brand_name
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from fb_campaign as fc
    inner join base_meta_campaigns as bmc
        on lower(fc.job_bag_id) = lower(bmc.campaign_id)
    inner join get_brand_data as gbd
        on to_varchar(gbd.item_nk1) = to_varchar(fc.sku_no)
    inner join {{ get_table('dim_item') }} as di
        on to_varchar(fc.sku_no) = to_varchar(di.item_cd)
)

{#
/*********************************************************************************************************************
1. The get_correct_campaign CTE filters the base_exist_campaigns CTE to identify campaigns with valid brand names.
2. It groups the data by job bag number and checks if the sum of null brand names is zero.
3. This ensures that only campaigns with valid brand names are included in the final result.
**************************************************************************************************************/
#}
, get_correct_campaign as (
    select job_bag_number
    from base_exist_campaigns
    group by job_bag_number
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{#
/*********************************************************************************************************************
1. The base_campaigns CTE retrieves distinct campaign IDs and their start and end dates from the base_exist_campaigns CTE.
2. It filters the data to include only valid campaigns that are present in the get_correct_campaign CTE.
***********************************************************************************************************************/
#}
, base_campaigns as (
    select distinct
        campaign_id
        , campaign_start_date
        , campaign_end_date
    from base_exist_campaigns
    where campaign_id in (select distinct job_bag_number from get_correct_campaign)
)

{#
/*********************************************************************************************************************
1. The fb_result CTE retrieves distinct job bag IDs, digital trading campaign channel IDs, and their start and end dates from the fb_campaign CTE.
2. It joins the fb_campaign CTE with the base_campaigns CTE on job bag ID to get campaign details.
3. The CTE selects the job bag ID, digital trading campaign channel ID, and their start and end dates.
4. The data is filtered to include only valid campaigns that are present in the base_campaigns CTE.
5. The join condition ensures that the job bag ID from the fb_campaign CTE matches the campaign ID in the base_campaigns CTE.
6. The CTE selects distinct values to avoid duplicates.
7. The final result includes job bag IDs, digital trading campaign channel IDs, and their start and end dates.
8. The fb_result CTE is used to filter the spend data in the spend_result CTE.
*****************************************************************************************************************/
#}
, fb_result as (
    select distinct
        fbc.job_bag_id
        , fbc.digital_trading_campaign_channel_nk1
        , bc.campaign_start_date
        , bc.campaign_end_date
    from fb_campaign as fbc
    inner join base_campaigns as bc
        on fbc.job_bag_id = bc.campaign_id
)

{#
/*******************************************************
1. The spend_result CTE retrieves media spend data from the DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK table.
2. It joins the fb_result CTE with the DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK table on digital trading campaign channel ID.
3. The CTE selects distinct values for job bag ID, campaign start and end dates, digital trading campaign ID, reporting start and end dates, and media spend.
4. The media spend is extracted from the measures JSON field in the DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK table.
5. The data is filtered to include only valid campaigns that are present in the fb_result CTE.
6. The reporting start date is set to be greater than or equal to the specified year and month in dbt_project.yml as per the environment where it is running.
7. The reporting start date must be equal to the reporting end date, and the campaign start and end dates must encompass the reporting start date.
8. The CTE selects distinct values to avoid duplicates.
9. The final result includes job bag IDs, campaign start and end dates, digital trading campaign IDs, reporting start and end dates, and media spend.
10. The spend_result CTE is used to aggregate the media spend data in the final_spend CTE.
*********************************************************/
#}
, spend_result as (
    select distinct
        fbr.job_bag_id
        , fbr.campaign_start_date
        , fbr.campaign_end_date
        , dtcidl.digital_trading_campaign_nk1
        , dtcidl.reporting_start_dt
        , dtcidl.reporting_end_dt
        , json_extract_path_text(dtcidl.measures, 'internals.media_spend') as media_spend
    from {{ get_table('digital_trading_campaign_insight_link') }} as dtcidl
    inner join fb_result as fbr
        on dtcidl.digital_trading_campaign_nk1 = fbr.digital_trading_campaign_channel_nk1
    where
        year(dtcidl.reporting_start_dt) >= '{{ params.campaign_start_year }}'
        and month(dtcidl.reporting_start_dt) >= '{{ params.campaign_start_month }}'
        and dtcidl.reporting_start_dt = dtcidl.reporting_end_dt
        and fbr.campaign_start_date <= dtcidl.reporting_start_dt
        and fbr.campaign_end_date >= dtcidl.reporting_start_dt
)

{#
/*****************************************
1. The final_spend CTE aggregates media spend data from the spend_result CTE.
2. It groups the data by job bag ID, campaign start and end dates.
3. The CTE calculates the total media spend for each campaign by summing the media spend values.
4. The final result includes job bag IDs, campaign start and end dates, and the total media spend for each campaign.
5. The final_spend CTE is used to join with the base_exist_campaigns CTE to create the meta_campaigns CTE.
6. The final_spend CTE is used to create the meta_campaigns CTE, which includes campaign details, brand information, and spend data.
*********************************************************/
#}
, final_spend as (
    select
        job_bag_id
        , campaign_start_date
        , campaign_end_date
        , sum(media_spend) as media_spend
    from spend_result
    group by job_bag_id, campaign_start_date, campaign_end_date
)

{#
/*********************************************************************************************************************
1. The meta_campaigns CTE aggregates data from the base_exist_campaigns CTE and the final_spend CTE.
2. It groups the data by various campaign-related fields, including job bag number, campaign ID, marketing type, channel name,
campaign name, campaign start and end dates, subchannel name, media spend, and item codes.
3. The CTE uses the listagg function to create comma-separated lists of item codes, brand names, super categories, and subcategories for each campaign.
4. The CTE selects the job bag number, campaign ID, marketing type, channel name, campaign name, campaign start and end dates,
subchannel name, media spend, and aggregated lists of item codes, brand names, super categories, and subcategories.
5. The data is filtered to include only valid campaigns that are present in the final_spend CTE.
6. This cte gives a comprehensive view of campaign data from Meta, including campaign details, brand information, and spend data.
***********************************************************************************************************************/
#}
, meta_campaigns as (
    select
        bec.job_bag_number
        , bec.campaign_id
        , 'Offsite' as marketing_type
        , 'Meta' as channel_name
        , bec.campaign_name
        , bec.campaign_start_date as campaign_start_dt
        , 'NA' as subchannel_name
        , fs.media_spend as media_spend_amt
        , bec.campaign_end_date as campaign_end_dt
        , listagg(distinct bec.item_cd, ',') within group (order by bec.item_cd) as item_cd_list
        , listagg(distinct bec.unique_brand_name, ',')
        within group (order by bec.unique_brand_name) as unique_brand_name
        , listagg(distinct bec.super_cat_name, ',') within group (order by bec.super_cat_name) as super_category_name
        , listagg(distinct bec.sub_cat_name, ',') within group (order by bec.sub_cat_name) as sub_category_name
    from base_exist_campaigns as bec
    inner join final_spend as fs
        on
            bec.campaign_id = fs.job_bag_id
            and bec.campaign_start_date = fs.campaign_start_date
            and bec.campaign_end_date = fs.campaign_end_date
    group by
        bec.job_bag_number, bec.campaign_id, marketing_type, channel_name, bec.campaign_name, bec.campaign_start_date
        , subchannel_name, fs.media_spend, bec.campaign_end_date
)

{#  /*Generating the final output */ #}
select
    job_bag_number,
    campaign_id,
    marketing_type,
    channel_name,
    campaign_name,
    campaign_start_dt,
    subchannel_name,
    media_spend_amt,
    campaign_end_dt,
    item_cd_list,
    unique_brand_name,
    super_category_name,
    sub_category_name
from meta_campaigns
);
