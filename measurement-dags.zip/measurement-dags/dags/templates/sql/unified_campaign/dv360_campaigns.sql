{#
/*********************************************************************************************************************************************
* Objective -  The script processes and combines data from multiple sources to create a clean, filtered, and enriched dataset of YouTube campaigns. The final dataset includes:
* campaign details, brand information, and spend data for both DV360 and YouTube campaigns.
* The script uses various CTEs to filter, join, and aggregate data from different tables, ensuring that only relevant and valid records are included.
* The final output is a comprehensive view of campaign data from both platforms, which can be used as input for UNIFIED_CAMPAIGN
* Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/838116003/Unified+Campaign
* Upstream:
* Downstream: UNIFIED_CAMPAIGN
*
* This script will return all the campaigns and related information for DV360 and YouTube.


*************************************************************************************************************************************************/
#}

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_dv360_campaigns') }} COPY GRANTS AS


{#
/*********************************************
1.The CTE is used to find the latest record_arrival_ts (timestamp) for each unique digital_trading_campaign_nk1.
2. Digital_trading_campaign_nk1: It is a unique identifier for DIGITAL_TRADING_CAMPAIGN_DMDVIO_SAT
3. record_arrival_ts: A timestamp indicating when a record arrived.
4. The CTE groups the data by digital_trading_campaign_nk1 and selects the maximum record_arrival_ts for each group.
5. In the later stage this is used to fetch latest data from the DIGITAL_TRADING_CAMPAIGN_DMDVIO_SAT
******************************************/
#}
with record_ts as (
    select
        digital_trading_campaign_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ get_table('digital_trading_campaign_dmdvio_sat') }}
    group by digital_trading_campaign_nk1
)


{#/*********************************************
1.The filtered_record CTE produces a filtered dataset containing:
a.Campaigns with the latest record_arrival_ts (as determined by record_ts).
b.Campaigns whose names do not include the with names containing "dnu", "donotuse", or "test".
2. Columns Selected:
job_bag_id: Likely an identifier for a job or campaign.
campaign_start_dt: The start date of the campaign.
campaign_end_dt: The end date of the campaign.
campaign_name: The name of the campaign.
measurement_sku_list: A list of measurement SKUs associated with the campaign.
3. This filtered data is used  for further processing or reporting in subsequent queries.
****************************************/
#}
, filtered_record as (
    select
        job_bag_id
        , campaign_start_dt
        , campaign_end_dt
        , campaign_name
        , measurement_sku_list
    from {{ get_table('digital_trading_campaign_dmdvio_sat') }}
    where
        (digital_trading_campaign_nk1, record_arrival_ts) in
        (select distinct
            digital_trading_campaign_nk1
            , record_arrival_ts
        from record_ts)
        and campaign_name not ilike '%dnu%'
        and campaign_name not ilike '%donotuse%'
        and campaign_name not ilike '%test%'
)


{#/*********************************************
1.Each row represents a campaign with its associated SKUs.
2.The SKUs are split into individual rows.
3.Only campaigns meeting the filtering criteria (e.g., containing "nec", starting after a certain date, and already ended) are included.
3. This filtered data is used  for further processing or reporting in subsequent queries.
****************************************/
#}
, dv360_raw_campaigns as (
    select
        fr.job_bag_id,
        fr.campaign_start_dt,
        fr.campaign_end_dt,
        fr.campaign_name,
        substr(fr.measurement_sku_list, 2, len(fr.measurement_sku_list) - 2) as sku,
        substr(sku_list.value, 2, len(sku_list.value) - 2) as skus
    from filtered_record as fr
    , lateral flatten(input => split(sku, ',')) as sku_list
    where
        fr.job_bag_id ilike '%nec%'
        and year(fr.campaign_start_dt) >= '{{ params.campaign_start_year }}'
        and month(fr.campaign_start_dt) >= '{{ params.campaign_start_month }}'
)

{#/*********************************************
1.The dv360_campaigns CTE is designed to:
Remove duplicate rows from the dv360_raw_campaigns CTE.
2.Select only specific columns for further use
****************************************/
#}
, dv360_campaigns as (
    select distinct
        job_bag_id,
        campaign_start_dt,
        campaign_end_dt,
        campaign_name,
        skus as skus
    from dv360_raw_campaigns
)

{#/*********************************************
1.The filtered_ean CTE is designed to:
Identify the latest record (max(load_ts)) for each unique item_nk1.
2.Filter out invalid or deleted records based on specific conditions.
3. Filtering Conditions:
a.valid_to_dt = "9999-12-31":
Ensures only records that are currently valid (not expired) are included.
b.record_deleted_flag != "Y":
Excludes records that are marked as deleted.
****************************************/
#}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag != 'Y'
    group by item_nk1
)


{#/*********************************************
1.The get_brand_data CTE produces a dataset where:
a.Each row represents an item (item_nk1) with its associated brand_name and brand_owner_name.
Only the latest, valid, and non-deleted records are included.
This dataset is likely used in subsequent queries to analyze or report brand-related information for items.
****************************************/
#}
, get_brand_data as (
    select
        eb.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag != 'Y'
)

{#
/*********************************************
1.The dv360_product_results CTE has:
a.Each row represents a unique campaign with its associated SKUs and brand information.
b. The join with the get_brand_data CTE ensures that each campaign is associated with its respective brand and owner.
c. Only the latest, valid, and non-deleted records are included.
*********************************************/
#}
, dv360_product_results as (
    select distinct
        dc.job_bag_id as job_bag_number
        , dc.job_bag_id as campaign_id
        , dc.campaign_start_dt as campaign_start_date
        , dc.campaign_end_dt as campaign_end_date
        , dc.campaign_name
        , 'DV360' as channel_name
        , di.super_cat_name
        , di.sub_cat_name
        , gbd.brand_name
        , dc.skus as sku_no
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from dv360_campaigns as dc
    inner join get_brand_data as gbd
        on to_varchar(gbd.item_nk1) = to_varchar(dc.skus)
    inner join {{ get_table('dim_item') }} as di
        on to_varchar(gbd.item_nk1) = to_varchar(di.item_cd)
)


{#/*********************************************
1.The youtube_campaign CTE is designed to:
2. Extract campaign data from the DIGITAL_TRADING_CAMPAIGN_DMYTIO_SAT table.
3. Each row represents a unique YouTube campaign with its associated SKUs.
4. lateral flatten(input => try_parse_json(json_extract_path_text(dtcds.dtp_input, "measurementSkus"))) as out:
5.Extracts the measurementSkus field from the dtcds.dtp_input JSON.
6. The where clause filters the campaigns based on specific criteria:
a. The job_bag_number must not be null and should contain "nec".
b. The campaign_start_dt must be greater than or equal to the specified year and month.
c. The campaign_start_dt must be before the current date.
d. The campaigns must be related to YouTube.
7. This result is used for further processing to join with base table
*****/#}
, youtube_campaign as (
    select
        'YouTube' as channel
        , dtcds.campaign_start_dt
        , dtcds.campaign_end_dt
        , json_extract_path_text(dtcds.dtp_input, 'integrationDetails.jobBagId') as job_bag_number
        , to_number(out.value) as sku_no
    from {{ get_table('digital_trading_campaign_sat_youtube_table') }} as dtcds
    , lateral flatten(input => try_parse_json(json_extract_path_text(dtcds.dtp_input, 'measurementSkus'))) as out
    where
        json_extract_path_text(dtcds.dtp_input, 'integrationDetails.jobBagId') is not null
        and json_extract_path_text(dtcds.dtp_input, 'integrationDetails.jobBagId') ilike '%nec%'
        and year(dtcds.campaign_start_dt) >= '{{ params.campaign_start_year }}'
        and month(dtcds.campaign_start_dt) >= '{{ params.campaign_start_month }}'
)



{#
/*********************************************
The base_yt_campaigns CTE extracts and processes data to create a dataset of YouTube campaigns by joining multiple tables and applying specific filters.
Here is a detailed explanation:
a. The CTE selects distinct records from the BASE_FINANCE_ASSETS_DATA table, which contains information about various campaigns.
b. It joins the youtube_campaign CTE to filter for YouTube campaigns based on the job_bag_number.
Here are the filters applied:
a. The asset_name_media_host_prf_name must contain "youtube".
b. The timeid must be the maximum value from the BASE_FINANCE_ASSETS_DATA table.
c. The asset_actual_start_date must be greater than or equal to the specified year.
d. The campaign_status must be either "campaign completed" or "hfss unknown".
e. The media_host_name must start with "sainsbur".
2. The CTE selects various fields, including job_bag_number, campaign_start_date, campaign_end_date, campaign_name, channel_name, super_cat_name, sub_cat_name, brand_name, sku_no, and unique_brand_name.
3. The unique_brand_name is created by concatenating the brand_name and brand_owner_name.
4. The CTE also joins the DIM_ITEM table to get the super category and subcategory names for each SKU.
5. The final result is a dataset of YouTube campaigns with relevant details, which can be used for further analysis or reporting.
***********************************************/
#}

, base_yt_campaigns as (
    select distinct
        bfad.job_bag_number
        , bfad.job_bag_number as campaign_id
        , yc.campaign_start_dt as campaign_start_date
        , yc.campaign_end_dt as campaign_end_date
        , bfad.campaign_title as campaign_name
        , yc.channel as channel_name
        , di.super_cat_name
        , di.sub_cat_name
        , gbd.brand_name
        , to_varchar(yc.sku_no) as sku_no
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as unique_brand_name
    from {{ get_table('base_finance_assets') }} as bfad
    inner join youtube_campaign as yc
        on lower(yc.job_bag_number) = lower(bfad.job_bag_number)
    inner join get_brand_data as gbd
        on to_varchar(gbd.item_nk1) = to_varchar(yc.sku_no)
    inner join {{ get_table('dim_item') }} as di on to_varchar(gbd.item_nk1) = to_varchar(di.item_cd)
    where
            timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = bfad.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
        and
        bfad.asset_name_media_host_prf_name ilike any ('%youtube%')
        and year(bfad.asset_actual_start_date) >= '{{ params.campaign_start_year }}'
        and lower(bfad.campaign_status) in ('campaign completed', 'hfss unknown', 'campaign underway','current','approved')
        and lower(bfad.media_host_name) like 'sainsbur%'
)

{#/****************************************
1.The dv_yt_campaigns_raw CTE combines the dv360_product_results and base_yt_campaigns datasets.
2. It uses a UNION operation to merge the two datasets, allowing for the inclusion of all records from both sources.
3. The resulting dataset contains campaign data from both DV360 and YouTube, which can be used for further analysis or reporting.
******************************************/#}
, dv_yt_campaigns_raw as (
    select * from dv360_product_results
    union
    select * from base_yt_campaigns
)

{#/****************************************
1.The get_correct_campaign CTE filters the dv_yt_campaigns_raw dataset to identify campaigns that have valid brand names.
2. It groups the data by job_bag_number and checks if there are any null brand names.
3. The HAVING clause ensures that only campaigns with no null brand names are included.
4. The result is a list of job_bag_numbers that have valid campaigns.
5. This is used to filter the dv_yt_campaigns_raw dataset in the next step.
****************************************/#}
, get_correct_campaign as (
    select job_bag_number
    from dv_yt_campaigns_raw
    group by job_bag_number
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{#/****************************************
1.The dv_yt_campaigns CTE filters the dv_yt_campaigns_raw dataset to include only those campaigns that are present in the get_correct_campaign dataset.
2. It uses a WHERE clause to match the job_bag_number from dv_yt_campaigns_raw with the job_bag_number from get_correct_campaign.
3. The resulting dataset contains only the campaigns that have valid brand names and are associated with the specified job_bag_numbers.
******************************************/#}
, dv_yt_campaigns as (
    select *
    from dv_yt_campaigns_raw
    where job_bag_number in (select distinct job_bag_number from get_correct_campaign)
)

{#/****************************************
1.The final_dv360_youtube_campaigns CTE filters the dv_yt_campaigns dataset to include only distinct campaigns.
2. It selects specific columns such as job_bag_number, campaign_start_date, campaign_end_date, campaign_name, and sku_no.
3. The resulting dataset contains unique campaigns with their associated details.
**************************************/#}
, final_dv360_youtube_campaigns as (
    select distinct
        job_bag_number
        , campaign_start_date
        , campaign_end_date
        , campaign_name
        , sku_no
    from dv_yt_campaigns
)

{#/****************************************
1.The campaign_spend CTE calculates the total revenue generated from campaigns within a specific date range.
2. It joins the MEDIA_REPORT table with the final_dv360_youtube_campaigns dataset based on the job_bag_number.
3. The WHERE clause ensures that the campaign_date falls within the campaign_start_date and campaign_end_date.
4. The resulting dataset contains the revenue generated from each campaign.
5. The final_campaign_spend CTE aggregates the revenue by job_bag_number, campaign_start_date, and campaign_end_date.
*******************************/#}
, campaign_spend as (
    select
        mr.revenue
        , fdyc.job_bag_number
        , fdyc.campaign_start_date
        , fdyc.campaign_end_date
    from {{ get_table('media_report') }} as mr
    inner join final_dv360_youtube_campaigns as fdyc
        on mr.jobbag_id = fdyc.job_bag_number
    where
        mr.campaign_date >= fdyc.campaign_start_date
        and mr.campaign_date <= fdyc.campaign_end_date
)

{#/****************************************
1.The final_campaign_spend CTE aggregates the revenue by job_bag_number, campaign_start_date, and campaign_end_date.
2. It calculates the total spend for each campaign.
3. The resulting dataset contains the total spend for each campaign, which can be used for further analysis or reporting.
4. The final result is a dataset of campaigns with their associated spend amounts.
*******************************************/#}
, final_campaign_spend as (
    select
        job_bag_number
        , campaign_start_date
        , campaign_end_date
        , sum(revenue) as spend
    from campaign_spend
    group by job_bag_number, campaign_start_date, campaign_end_date
)

{#/****************************************
1.The dv360_youtube_campaigns CTE combines the dv360_campaigns and final_campaign_spend datasets.
2. It selects specific columns such as job_bag_number, campaign_id, marketing_type, channel_name, campaign_name, campaign_start_dt, subchannel_name, media_spend_amt, campaign_end_dt, item_cd_list, unique_brand_name, super_category_name, and sub_category_name.
3. The resulting dataset contains campaign data from both DV360 and YouTube, along with their associated spend amounts.
4. The listagg function is used to aggregate the item codes, unique brand names, super category names, and sub category names into comma-separated lists.
5. The final result is a dataset of campaigns with their associated details, which can be used for further analysis or reporting.
6. The dv360_youtube_campaigns CTE is the final output of the script, providing a comprehensive view of campaign data from both DV360 and YouTube.
*****************************************/#}
, dv360_youtube_campaigns as (
    select
        dyc.job_bag_number
        , dyc.campaign_id
        , 'Offsite' as marketing_type
        , dyc.channel_name
        , dyc.campaign_name
        , dyc.campaign_start_date as campaign_start_dt
        , 'NA' as subchannel_name
        , fcs.spend as media_spend_amt
        , dyc.campaign_end_date as campaign_end_dt
        , listagg(distinct dyc.sku_no, ',') within group (order by dyc.sku_no) as item_cd_list
        , listagg(distinct dyc.unique_brand_name, ',')
        within group (order by dyc.unique_brand_name) as unique_brand_name
        , listagg(distinct dyc.super_cat_name, ',')
        within group (order by dyc.super_cat_name) as super_category_name
        , listagg(distinct dyc.sub_cat_name, ',') within group (order by dyc.sub_cat_name) as sub_category_name
    from dv_yt_campaigns as dyc
    inner join final_campaign_spend as fcs
        on
            dyc.campaign_id = fcs.job_bag_number
            and dyc.campaign_start_date = fcs.campaign_start_date
    group by
        dyc.job_bag_number, dyc.campaign_id, marketing_type, dyc.channel_name, dyc.campaign_name
        , dyc.campaign_start_date, subchannel_name, fcs.spend, dyc.campaign_end_date
)

select
    job_bag_number,
    campaign_id,
    marketing_type,
    channel_name,
    campaign_name,
    campaign_start_dt,
    subchannel_name,
    media_spend_amt,
    campaign_end_dt,
    item_cd_list,
    unique_brand_name,
    super_category_name,
    sub_category_name

from dv360_youtube_campaigns
