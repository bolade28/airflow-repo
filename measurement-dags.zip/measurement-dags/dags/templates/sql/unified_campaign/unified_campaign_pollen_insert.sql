INSERT INTO {{ params.table }}
(
    job_bag_number,
    campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    booking_id,
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
)
with campaign_data AS (
    SELECT
        campaign_id,
        booking_media_live_start_dt AS campaign_start_dt,
        booking_media_live_end_dt AS campaign_end_dt,
        case
        when booking_status = 'COMPLETED'
             and cumulative_billable_spend_amt IS NOT NULL
             and cumulative_billable_spend_amt != 0
        then cumulative_billable_spend_amt
        else booking_media_budget_amt
    end AS budget_amt,
    case
        when booking_status = 'COMPLETED'
             and cumulative_billable_spend_amt is not NULL
             and cumulative_billable_spend_amt != 0
        then 'CUMULATIVE_BILLABLE_SPEND_AMT'
        else 'BOOKING_MEDIA_BUDGET_AMT'
    end AS media_spend_source,
        marketing_subchannel AS subchannel_name,
        json_extract_path_text(out.value,'skuId') AS items,
        booking_id,
        channel_type AS marketing_type,
        marketing_channel AS channel_name,
        booking_name AS campaign_name,
        partner_id,
        advertiser_id,
        advertiser_name,
        marketing_hierarchy_cd
    FROM {% if params.emulate_prod_env | default(false) %}
        {{ get_table('campaign_booking_media_channel_prod') }}
    {% else %}
        {{ get_table('campaign_booking_media_channel') }}
    {% endif %} AS aal
    , lateral flatten(input => aal.booking_item_cd_list) AS out
    where
        campaign_id !='-1'
        and booking_status IN ('COMPLETED','ACTIVE')
        and marketing_channel!='-1'
        and marketing_subchannel!='-1'
        and channel_type !='-1'
        and booking_media_live_start_dt is not null
        and booking_media_live_end_dt is not null
        -- Add null checks to filter out invalid skuIds
        and booking_item_cd_list is not null
        and json_extract_path_text(out.value,'skuId') is not null
        and NOT EXISTS (
            SELECT 1
            FROM {{ get_table('bookings_blacklist') }} AS b
            WHERE b.booking_id = aal.booking_id
        )
        and NOT EXISTS (
            SELECT 1
            FROM {{ get_table('campaign_validation_issues') }} c
            WHERE c.booking_id = aal.booking_id
              AND c.load_ts = (
                    SELECT MAX(load_ts)
                    FROM {{ get_table('campaign_validation_issues') }})
        )
)
, brand_data AS (
    with filtered_ean AS (
        SELECT
            item_nk1
            , max(load_ts) AS max_ts
            FROM
        {{ get_table('ean_br') }}
        where
            valid_to_dt = '9999-12-31'
            and record_deleted_flag != 'Y'
        GROUP by item_nk1
    )
    SELECT
        eb.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
    FROM filtered_ean AS fe
    INNER JOIN {{ get_table('ean_br') }} AS eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag != 'Y'
)
-- get the item level details for each sku
, campaign_items AS (
    SELECT
        es.booking_id,
        es.campaign_id,
        es.items,
        es.channel_name,
        es.subchannel_name,
        di.super_cat_name,
        di.sub_cat_name,
        bd.brand_name,
        concat(trim(bd.brand_name), ' | ', trim(bd.brand_owner_name)) AS unique_brand_name,
        es.marketing_hierarchy_cd
    FROM campaign_data AS es
    LEFT JOIN brand_data AS bd
        ON es.items = bd.item_nk1
    LEFT JOIN {{ get_table('dim_item') }} AS di
        ON es.items = di.item_cd
)
, get_correct_campaign AS (
    SELECT campaign_id
    FROM campaign_items
    GROUP by campaign_id
    having sum(case when brand_name is null then 1 else 0 end) = 0
)
, campaign_result AS (
    SELECT
        cd.booking_id,
        cd.campaign_id,
        cd.marketing_type,
        cd.channel_name,
        cd.campaign_name,
        cd.campaign_start_dt,
        cd.subchannel_name,
        cd.budget_amt AS media_spend_amt,
        cd.media_spend_source,
        cd.campaign_end_dt,
        partner_id,
        advertiser_id,
        advertiser_name,
        cd.marketing_hierarchy_cd,
        listagg(DISTINCT ci.items, ',') WITHIN GROUP (ORDER BY ci.items) AS item_cd_list,
        listagg(DISTINCT ci.unique_brand_name, ',') within GROUP (ORDER BY ci.unique_brand_name) AS unique_brand_name,
        listagg(DISTINCT ci.super_cat_name, ',') within GROUP (ORDER BY ci.super_cat_name) AS super_category_name,
        listagg(DISTINCT ci.sub_cat_name, ',') within GROUP (ORDER BY ci.sub_cat_name) AS sub_category_name
    FROM campaign_data cd
    INNER join campaign_items ci
    ON cd.campaign_id = ci.campaign_id AND cd.channel_name = ci.channel_name AND cd.subchannel_name = ci.subchannel_name
    WHERE cd.campaign_id!='~~'
    AND cd.campaign_id IN (SELECT DISTINCT campaign_id FROM campaign_items)
    GROUP BY
        cd.marketing_type,
        cd.channel_name,
        cd.campaign_id,
        cd.campaign_name,
        cd.campaign_start_dt,
        cd.campaign_end_dt,
        cd.subchannel_name,
        cd.budget_amt,
        cd.media_spend_source,
        cd.booking_id,
        partner_id,
        advertiser_id,
        advertiser_name,
        cd.marketing_hierarchy_cd
)
, get_new_records AS (
    SELECT * FROM campaign_result
    WHERE unique_brand_name not ilike '%,%'
)
, get_skus_for_post_campaign AS (
    SELECT
        gnr.campaign_id
        , gnr.item_cd_list
        , gnr.channel_name
        , gnr.subchannel_name
        , sku_list.value::integer AS item
    FROM get_new_records AS gnr
    , lateral flatten(input => split(gnr.item_cd_list, ',')) AS sku_list
)
, get_post_campaign_period AS (
    SELECT
        gns.campaign_id
        , gns.channel_name
        , gns.subchannel_name
        , max(pcp.median_proposed_bucket_wk) AS post_campaign_wk
    FROM get_skus_for_post_campaign AS gns
    INNER JOIN {{ get_table('post_campaign_period') }} AS pcp
        ON gns.item = pcp.item_cd
    WHERE pcp.year_of_transaction = (SELECT year(current_date()) - 1)
    GROUP by 1, 2, 3
)
, combined_unified_campaign AS (
    SELECT
        gnr.campaign_id,
        gnr.media_spend_amt,
        gnr.media_spend_source,
        gnr.campaign_start_dt,
        gnr.campaign_end_dt,
        gnr.item_cd_list,
        gnr.super_category_name,
        gnr.sub_category_name,
        gnr.channel_name,
        gnr.campaign_name,
        gnr.marketing_type,
        gnr.unique_brand_name,
        gnr.booking_id,
        regexp_replace(
            gnr.subchannel_name, '[^a-zA-Z0-9_|, -]', ''
        ) AS subchannel_name,
        case
            when gpcp.post_campaign_wk is null then dateadd('DAY', 42, gnr.campaign_end_dt)
            else dateadd('DAY', gpcp.post_campaign_wk * 7, gnr.campaign_end_dt)
        end AS post_campaign_dt,
        partner_id,
        advertiser_id,
        advertiser_name,
        gnr.marketing_hierarchy_cd
    FROM get_new_records AS gnr
    LEFT JOIN get_post_campaign_period AS gpcp
        on
            gnr.campaign_id = gpcp.campaign_id
            and gnr.channel_name = gpcp.channel_name
            and gnr.subchannel_name = gpcp.subchannel_name
    WHERE 
    {% if not params.emulate_prod_env | default(false) %}
        gnr.campaign_end_dt < current_date()
    {% else %}
        TRUE  -- ignores the filtering as we want to consider incompleted campaigns to get early evaluations.  
    {% endif %}
)
, check_multi_channel AS (
    SELECT
        *,
        count(DISTINCT channel_name) over (partition by booking_id) AS channel_count,
        count(DISTINCT subchannel_name) over (partition by booking_id) AS subchannel_count
    FROM combined_unified_campaign
)
, apply_is_multichannel AS (
    SELECT DISTINCT
        cuc.*
        , case
            when cmc.channel_count > 1 then true
            when cmc.channel_count = 1 and cmc.subchannel_count > 1 then true
            when cmc.channel_count = 1 and cmc.channel_name not in ('Onsite-GOL') then false
            else false
        end AS is_multi_channel
    FROM combined_unified_campaign AS cuc
    INNER JOIN check_multi_channel AS cmc
        on
            cuc.booking_id = cmc.booking_id
            and cuc.campaign_id = cmc.campaign_id
            and cuc.campaign_start_dt = cmc.campaign_start_dt
            and cuc.campaign_end_dt = cmc.campaign_end_dt
)
, unified_campaign_pre_overlap AS (
    SELECT
        'NA'::varchar(1000) AS job_bag_number,
        campaign_id::varchar(1000) AS campaign_id,
        media_spend_amt::float AS media_spend_amt,
        media_spend_source::varchar(1000) AS media_spend_source,
        campaign_start_dt::date AS campaign_start_dt,
        campaign_end_dt::date AS campaign_end_dt,
        subchannel_name::varchar(1000) AS subchannel_name,
        item_cd_list::varchar(16777216) AS item_cd_list,
        super_category_name::varchar(1000) AS super_category_name,
        sub_category_name::varchar(1000) AS sub_category_name,
        channel_name::varchar(1000) AS channel_name,
        campaign_name::varchar(1000) AS campaign_name,
        booking_id::varchar(1000) AS booking_id,
        null::varchar(1000) AS campaign_status,
        is_multi_channel::boolean AS is_multi_channel,
        current_timestamp::timestamp_ntz AS load_ts,
        '{{ params.correlation_id }}'::varchar(36) AS job_run_id,
        marketing_type::varchar(100) AS marketing_type,
        unique_brand_name::varchar(1000) AS unique_brand_name,
        partner_id,
        advertiser_id,
        advertiser_name,
        post_campaign_dt::date AS post_campaign_dt,
        marketing_hierarchy_cd::varchar(100) AS marketing_hierarchy_cd
    FROM apply_is_multichannel
)
, direct_overlaps AS (
    SELECT DISTINCT
        LEAST(a.campaign_id, b.campaign_id) AS source_campaign_id,
        GREATEST(a.campaign_id, b.campaign_id) AS target_campaign_id
    FROM unified_campaign_pre_overlap a
    JOIN unified_campaign_pre_overlap b
        ON (
           a.campaign_start_dt BETWEEN b.campaign_start_dt AND b.campaign_end_dt OR
           b.campaign_start_dt BETWEEN a.campaign_start_dt AND a.campaign_end_dt
       )
       AND ARRAY_SIZE(ARRAY_INTERSECTION(SPLIT(a.item_cd_list, ','), SPLIT(b.item_cd_list, ','))) > 0
       AND a.campaign_id <> b.campaign_id
)
, overlapping_booking_ids AS (
    SELECT  a.target_campaign_id,
         MIN(COALESCE( d.source_campaign_id ,c.source_campaign_id, b.source_campaign_id, a.source_campaign_id)) AS root_campaign_id
    FROM direct_overlaps a
    LEFT JOIN direct_overlaps b ON a.source_campaign_id = b.target_campaign_id
    LEFT JOIN direct_overlaps c ON b.source_campaign_id = c.target_campaign_id
    LEFT JOIN direct_overlaps d ON c.source_campaign_id = d.target_campaign_id
    GROUP BY 1)
, initial_booking_ids AS (
    SELECT  root_campaign_id
        ,   a.target_campaign_id AS Campaign_id
    FROM overlapping_booking_ids a
    UNION ALL
    SELECT
        campaign_id AS root_campaign_id,
        campaign_id
    FROM unified_campaign_pre_overlap
    WHERE campaign_id NOT IN (SELECT target_campaign_id FROM direct_overlaps)
)
, campaign_booking_map AS (
    SELECT
        root_campaign_id,
        LISTAGG(DISTINCT a.campaign_id, ',') WITHIN GROUP (ORDER BY a.campaign_id) AS booking_string,
        SHA2(booking_string, 256) AS campaign_overlap_id
    FROM unified_campaign_pre_overlap a
    LEFT JOIN initial_booking_ids b ON a.campaign_id = b.campaign_id
    GROUP BY root_campaign_id
)
, unified_campaign AS (
SELECT DISTINCT
    booking_id AS job_bag_number, -- Once E2E run is complete, we need to change this back.
    uc.campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    campaign_overlap_id AS booking_id, -- Once E2E run is complete, we need to change this back.
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
FROM unified_campaign_pre_overlap uc
LEFT JOIN initial_booking_ids ibi ON uc.campaign_id = ibi.campaign_id
LEFT JOIN campaign_booking_map cbm ON ibi.root_campaign_id = cbm.root_campaign_id)
SELECT 
    job_bag_number,
    campaign_id,
    media_spend_amt,
    media_spend_source,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    booking_id,
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    partner_id,
    advertiser_id,
    advertiser_name,
    post_campaign_dt,
    marketing_hierarchy_cd
FROM unified_campaign
;