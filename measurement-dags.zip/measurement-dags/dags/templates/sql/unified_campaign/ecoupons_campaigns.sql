{#
/*********************************************************************************************************************************************
* Objective -  The script processes and combines data from multiple sources to create a clean, filtered, and enriched dataset of Ecoupon campaigns. The final dataset includes:
* campaign details, brand information, and spend data for ecoupon.
* The script uses various CTEs to filter, join, and aggregate data from different tables, ensuring that only relevant and valid records are included.
* The final output is a comprehensive view of campaign data from both platforms, which can be used as input for UNIFIED_CAMPAIGN
* Confluence Link : https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/838116003/Unified+Campaign
* Upstream: 
* Downstream: UNIFIED_CAMPAIGN
*
* This script will return all the campaigns and related information for Ecoupon.
********/

/**********************************************************************************************
1. The ecoupon_res CTE extracts and filters e-coupon campaign data from the OC_CAMPAIGN table.
It ensures that only distinct campaigns meeting specific date-related criteria are included in the result.
2. The select distinct ensures that duplicate rows are removed, so only unique combinations of these columns are included.
3. The code snippet year(start_date) >= {{ var('campaign_start_year') }}:
    only campaigns that started in or after the year specified by the campaign_start_year variable.
    month(start_date) >= {{ var('campaign_start_month') }}:
    Includes only campaigns that started in or after the month specified by the campaign_start_month variable.
4. The expiry_date < current_date() condition filters out campaigns that have not yet expired.

************************************************************************************************/
#}

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_ecoupons_campaigns') }} COPY GRANTS AS
(
    with ecoupon_res as (
        select distinct
            campaign_id,
            start_date,
            expiry_date,
            base_asset_id
        from {{get_table('oc_campaign')}}
        where
            year(start_date) >= '{{ params.campaign_start_year }}'
            and month(start_date) >= '{{ params.campaign_start_month }}'
    )

    {#
    /**************************************************************************************************
    1. The filtered_ean CTE filters the EAN_BR table to include only valid records (valid_to_dt = '9999-12-31' and record_deleted_flag <> 'Y').
    2. The filtered_ean CTE groups the data by item_nk1 and selects the maximum load_ts for each item_nk1.
    *************************************************************************************************/
    #}
    , filtered_ean as (
        select
            item_nk1
            , max(load_ts) as max_ts
        from {{ get_table('ean_br') }}
        where
            valid_to_dt = '9999-12-31'
            and record_deleted_flag <> 'Y'
        group by item_nk1
    )

    {#
    /**************************************************************************************************
    1. The get_brand_data CTE joins the filtered_ean CTE with the EAN_BR table to retrieve brand-related information.
    2. It selects the item_nk1, brand_name, brand_owner_name, and ean_nk1 columns.
    3. The join condition ensures that only records with matching item_nk1 and the maximum load_ts are included.
    4. The where clause filters the EAN_BR table to include only valid records (valid_to_dt = '9999-12-31' and record_deleted_flag <> 'Y').
    *************************************************************************************************/
    #}
    , get_brand_data as (
        select
            fe.item_nk1
            , eb.brand_name
            , eb.brand_owner_name
            , eb.ean_nk1::varchar as ean_nk1
        from filtered_ean as fe
        inner join {{ get_table('ean_br') }} as eb
            on
                fe.item_nk1 = eb.item_nk1
                and fe.max_ts = eb.load_ts
        where
            eb.valid_to_dt = '9999-12-31'
            and eb.record_deleted_flag <> 'Y'
    )

    {#
    /***********************************************
    1. The base_campaign_ecoupon_data CTE retrieves campaign data for eCoupons by joining the base_res inner query with the ecoupon_res CTE.
    2. It selects various columns, including job_bag_number, spend, start_date, expiry_date, subchannel, sku_no, super_category, sub_category, channel, campaign_name, campaign_id, brand_name, and brand.
    3. The join condition ensures that only records with matching asset_id, campaign_start_date, and campaign_end_date are included.
    4. The inner join with the OC_PRODUCTS table filters the data to include only products with product_no = 1.
    5. The join with the DIM_ITEM table ensures that the item_cd matches the ean_nk1 from the get_brand_data CTE.
    6. The where clause filters the data to include only campaigns that have been completed or have an unknown HFSS status.
    7. The base_campaign_ecoupon_data CTE also includes a subquery to calculate the spend for each campaign.
    8. The base_res inner query groups the data by job_bag_number, asset_actual_start_date, asset_actual_end_date, campaign_title, and asset_id.
    9. The sum function calculates the total spend for each campaign.
    10. The split_part function extracts the asset_id from the asset_unique_id column.
    11. The base_res inner query filters the data to include only campaigns that started in or after the year specified by the campaign_start_year variable.
    12. The timeid condition ensures that only the most recent data is included.
    13. The lower function is used to perform case-insensitive comparisons for the media_host_name and asset_name_media_host_prf_name columns.
    ************************************************/
    #}
    , base_campaign_ecoupon_data as (
        select
             base_res.job_bag_number,
             base_res.spend,
             er.start_date,
             er.expiry_date,
             'Sampling ecoupon' as subchannel,
             di.item_cd as sku_no,
             di.super_cat_name as super_category,
             di.sub_cat_name as sub_category,
             'eCoupons' as channel,
             base_res.campaign_title as campaign_name,
             er.campaign_id,
             gbd.brand_name,
             concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as brand
        from (
            select
                job_bag_number,
                asset_actual_start_date as campaign_start_date,
                asset_actual_end_date as campaign_end_date,
                campaign_title,
                sum(asset_value_unweighted) as spend,
                split_part(asset_unique_id, '-', -1) as asset_id
            from {{get_table('base_finance_assets')}} b1
            where
                timeid = (
                    SELECT MAX(timeid)
                    FROM {{ get_table('base_finance_assets') }} b2
                    WHERE b2.job_bag_number = b1.job_bag_number
                    and job_bag_number is not null
                    and job_bag_number != ''
                )
                and
                year(asset_actual_start_date) >= '{{params.campaign_start_year}}'
                and lower(media_host_name) like 'sainsbur%'
                and lower(asset_name_media_host_prf_name) in ('online sampling - ecoupon')
                and lower(campaign_status) in ('campaign completed','hfss unknown','campaign underway','current','approved')
            group by job_bag_number, asset_actual_start_date, asset_actual_end_date, campaign_title, asset_id
        )
            as base_res
        inner join ecoupon_res as er
            on
                base_res.asset_id = er.base_asset_id
                and base_res.campaign_start_date = er.start_date
                and base_res.campaign_end_date = er.expiry_date
        inner join {{get_table('oc_products')}} as op
            on er.campaign_id = op.campaign_id
        inner join get_brand_data as gbd
            on substr(op.product_key, 2, 13) = gbd.ean_nk1
        inner join {{ get_table('dim_item') }} as di
            on to_varchar(gbd.item_nk1) = to_varchar(di.item_cd)
        where
            op.product_no = 1

    )

    {#
    /**************************************************************************************************
    1. The get_correct_campaign CTE filters the base_campaign_ecoupon_data CTE to include only campaigns that have no null brand names.
    2. It groups the data by job_bag_number and uses the having clause to ensure that the sum of null brand names is zero.
    3. This ensures that only campaigns with valid brand names are included in the final result.
    *******************************************************************************************/
    #}
    , get_correct_campaign as (
        select job_bag_number
        from base_campaign_ecoupon_data
        group by job_bag_number
        having sum(case when brand_name is null then 1 else 0 end) = 0
    )

    {#
    /**************************************************************************************************
    1. The ecoupons_campaigns CTE retrieves campaign data for eCoupons by joining the base_campaign_ecoupon_data CTE with the get_correct_campaign CTE.
    2. It selects various columns, including job_bag_number, campaign_id, marketing_type, channel_name, campaign_name, campaign_start_dt, subchannel_name, media_spend_amt, campaign_end_dt, item_cd_list, unique_brand_name, super_category_name, and sub_category_name.
    3. The listagg function is used to concatenate distinct values of sku_no, brand, super_category, and sub_category into comma-separated lists.
    4. The group by clause ensures that the data is grouped by job_bag_number, campaign_id, channel_name, campaign_name, campaign_start_dt, spend, subchannel_name, and expiry_date.
    5. We are getting all the consolidated data for all the valid campaigns
    *********************************************************************************************************/
    #}
    , ecoupons_campaigns as (
        select
             bced.job_bag_number,
             bced.campaign_id,
             'Onsite' as marketing_type,
             bced.channel as channel_name,
             bced.campaign_name,
             bced.start_date as campaign_start_dt,
             bced.subchannel as subchannel_name,
             bced.spend as media_spend_amt,
             bced.expiry_date as campaign_end_dt,
             listagg(distinct bced.sku_no, ',') within group (order by bced.sku_no) as item_cd_list,
             listagg(distinct bced.brand, ',') within group (order by bced.brand) as unique_brand_name,
             listagg(distinct bced.super_category, ',') within group (order by bced.super_category) as super_category_name,
             listagg(distinct bced.sub_category, ',') within group (order by bced.sub_category) as sub_category_name,
        from base_campaign_ecoupon_data as bced
        where bced.job_bag_number in (select distinct job_bag_number from get_correct_campaign)
        group by
            bced.job_bag_number,
            bced.campaign_id,
            bced.channel,
            bced.campaign_name,
            bced.start_date,
            bced.spend,
            bced.subchannel,
            bced.expiry_date
    )

    {# /* Getting consolidated data for valid campaigns. */ #}
    select
        job_bag_number,
        campaign_id,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_start_dt,
        subchannel_name,
        media_spend_amt,
        campaign_end_dt,
        item_cd_list,
        unique_brand_name,
        super_category_name,
        sub_category_name
    from ecoupons_campaigns
);
