
INSERT INTO {{ get_table('measurement_unified_campaign') }} (
    job_bag_number,
    campaign_id,
    media_spend_amt,
    campaign_start_dt,
    campaign_end_dt,
    subchannel_name,
    item_cd_list,
    super_category_name,
    sub_category_name,
    channel_name,
    campaign_name,
    booking_id,
    campaign_status,
    is_multi_channel,
    load_ts,
    job_run_id,
    marketing_type,
    unique_brand_name,
    post_campaign_dt
)
SELECT DISTINCT
    uc.job_bag_number,
    uc.campaign_id,
    uc.media_spend_amt,
    uc.campaign_start_dt,
    uc.campaign_end_dt,
    uc.subchannel_name,
    uc.item_cd_list,
    uc.super_category_name,
    uc.sub_category_name,
    uc.channel_name,
    uc.campaign_name,
    uc.booking_id,
    NULL as campaign_status,
    uc.is_multi_channel,
    -- TODO:: this is a workaround and we need to do some changes in future and remove historical unified_campaign(GRID one).
    -- current_timestamp::timestamp_ntz as load_ts,
    (SELECT max(load_ts) FROM {{ get_table('measurement_unified_campaign') }}) as load_ts,
    '{{ params.correlation_id }}'::varchar(36) as job_run_id,
    uc.marketing_type,
    REPLACE(uc.unique_brand_name,'|',' | ') as unique_brand_name,
    uc.post_campaign_dt
FROM {{get_table('unified_campaign_grid')}} uc
LEFT JOIN {{get_table('measurement_unified_campaign')}} AS muc
USING (campaign_id,job_bag_number, campaign_start_dt, campaign_end_dt)
WHERE muc.campaign_id IS NULL 
AND JOB_BAG_NUMBER <> 'NA';