CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_magazine_campaigns') }} COPY GRANTS AS
(

{#
/**************************************************************************************************
* This The ie_media_magazine CTE aggregates media spend data for magazine-related campaigns from the IE_MEDIA table.
It filters the data based on specific criteria, such as campaign ID patterns, date ranges, and non-null date
values, and calculates the total media spend for each campaign.
2. In the ie_media table, the media_no column modulo 100 equals 7 when it is used for magazine-related campaigns.
************************************************************************************************/
#}
with ie_media_magazine as (
    select
        master_campaign_id
        , start_date
        , end_date
        , sum(media_cost) as media_spend
    from {{ get_table('ie_media') }}
    where
        media_no % 100 = 7
        and start_date is not null
        and end_date is not null
        and media_cost is not null
        and master_campaign_id ilike 'nec%'
        and year(start_date) >= '{{ params.campaign_start_year }}'
        and month(start_date) >= '{{ params.campaign_start_month }}'
        and end_date < '{{ params.run_date }}'
    group by 1, 2, 3
)

{#
/*********************************************************************************************************************
1. The filtered_ean CTE retrieves the most recent record for each item_nk1 from the EAN_BR table, ensuring that only valid records are included.
2. It filters out records that are marked as deleted or have a validity date of '9999-12-31'.
3. This CTE is used to ensure that the most up-to-date information is used in subsequent joins.
***********************************************************************************************************************/
#}
, filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ get_table('ean_br') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag <> 'Y'
    group by 1
)

{#
/********************************************************************************
1.This CTE retrieves brand-related data by joining the filtered_ean CTE with the EAN_BR table.
2. It selects the item_nk1, brand_name, brand_owner_name, and ean_nk1 columns.
3. The join condition ensures that only the most recent records are included based on the load_ts column.
4. The CTE selects only those items which are still in circulation.
*************************************************************************/
#}
, get_brand_data as (
    select
        fe.item_nk1
        , eb.brand_name
        , eb.brand_owner_name
        , eb.ean_nk1
    from filtered_ean as fe
    inner join {{ get_table('ean_br') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
    where
        eb.valid_to_dt = '9999-12-31'
        and eb.record_deleted_flag <> 'Y'
)

{#
/**************************************************************************************************
1. The base_magazine_campaigns CTE retrieves campaign data for Sainsbury's Magazine campaigns.
2. It joins the base_res CTE with the ie_media_magazine CTE to get media spend data.
3. The join condition ensures that only campaigns with valid media spend data are included.
4. The CTE selects various columns, including campaign name, marketing type, channel name, subchannel name, super category, sub category, campaign start and end dates, campaign ID, item_cd, media spend, brand name, and a concatenated brand field.
5. The base_res subquery filters the BASE_FINANCE_ASSETS_DATA table to include only completed campaigns with specific media host names and service types.
6. The base_magazine_campaigns CTE produces a dataset where:
Each row represents a magazine-related campaign associated with Sainsbury's.
The dataset includes:
Campaign details (name, type, channel, start/end dates, ID).
Product details (super category, subcategory, item code).
Brand details (name, owner).
Media spend for the campaign.
The data is filtered to include only campaigns that:
Started in or after 2023.
Are completed or have an "hfss unknown" status.
Are associated with Sainsbury's Magazine.
Have valid product and brand data
*********************************************/
#}
, base_magazine_campaigns as (
    select
        base_res.campaign_title as campaign_name
        , 'Magazine' as marketing_type
        , 'Sainburys Magazine' as channel_name
        , 'NA' as subchannel_name
        , di.super_cat_name as super_category
        , di.sub_cat_name as sub_category
        , iem.start_date as campaign_start_date
        , iem.end_date as campaign_end_date
        , base_res.job_bag_number as campaign_id
        , base_res.job_bag_number
        , di.item_cd
        , iem.media_spend
        , gbd.brand_name
        , concat(TRIM(gbd.brand_name), ' | ', TRIM(gbd.brand_owner_name)) as brand
    from (
        select distinct
            job_bag_number
            , campaign_title
        from {{ get_table('base_finance_assets') }} b1
        where
            timeid = (
                SELECT MAX(timeid)
                FROM {{ get_table('base_finance_assets') }} b2
                WHERE b2.job_bag_number = b1.job_bag_number
                and job_bag_number is not null
                and job_bag_number != ''
            )
            and
            -- ToDo This should not be static
            year(asset_actual_start_date) >= 2023
            and lower(campaign_status) in ('campaign completed', 'hfss unknown')
            and lower(media_host_name) like 'sainsbur%'
            and lower(service_type) in ('sainsburys magazine')
    ) as base_res
    inner join ie_media_magazine as iem
        on base_res.job_bag_number = iem.master_campaign_id
    inner join {{ get_table('ie_product') }} as iep
        on iep.master_campaign_id = base_res.job_bag_number
    inner join get_brand_data as gbd
        on substr(iep.product_key, 2, 13) = gbd.ean_nk1
    inner join {{ get_table('dim_item') }} as di
        on gbd.item_nk1 = di.item_cd
    where
        lower(iep.product_name) = 'offer'
)

{#
/**************************************************************************************************
1. The get_correct_campaign CTE filters the base_magazine_campaigns CTE to include only campaigns with valid brand names.
2. It groups the data by job_bag_number and checks if there are any null brand names.
3. The CTE selects only those campaigns where the sum of null brand names is zero, indicating that all campaigns have valid brand names.
4. The get_correct_campaign CTE is used to ensure that only campaigns with valid brand data are included in the final dataset.
**************************************************************************************************/
#}
, get_correct_campaign as (
    select job_bag_number
    from base_magazine_campaigns
    group by 1
    having sum(case when brand_name is null then 1 else 0 end) = 0
)

{#
/*******************************************
1. The magazine_campaigns CTE aggregates data from the base_magazine_campaigns CTE.
2. It groups the data by various campaign-related fields, including job_bag_number, campaign_id,
marketing_type, channel_name, campaign_name, campaign_start_date, subchannel_name, media_spend, and campaign_end_date.
3. The CTE uses the listagg function to create comma-separated lists of item codes, brand names, super categories, and subcategories for each campaign.
**************************************************/
#}
, magazine_campaigns as (
    select
        bmc.job_bag_number
        , bmc.campaign_id
        , bmc.marketing_type
        , bmc.channel_name
        , bmc.campaign_name
        , bmc.campaign_start_date as campaign_start_dt
        , bmc.subchannel_name
        , bmc.media_spend as media_spend_amt
        , bmc.campaign_end_date as campaign_end_dt
        , listagg(distinct bmc.item_cd, ',') within group (order by bmc.item_cd) as item_cd_list
        , listagg(distinct bmc.brand, ',') within group (order by bmc.brand) as unique_brand_name
        , listagg(distinct bmc.super_category, ',') within group (order by bmc.super_category) as super_category_name
        , listagg(distinct bmc.sub_category, ',') within group (order by bmc.sub_category) as sub_category_name
    from base_magazine_campaigns as bmc
    where bmc.job_bag_number in (select distinct job_bag_number from get_correct_campaign)
    group by
        1, 2, 3, 4, 5, 6, 7, 8, 9
)

{# /* Final output of the campaign data for Sainsbury's Magazine */ #}
select
    job_bag_number,
    campaign_id,
    marketing_type,
    channel_name,
    campaign_name,
    campaign_start_dt,
    subchannel_name,
    media_spend_amt,
    campaign_end_dt,
    item_cd_list,
    unique_brand_name,
    super_category_name,
    sub_category_name
from magazine_campaigns

);
