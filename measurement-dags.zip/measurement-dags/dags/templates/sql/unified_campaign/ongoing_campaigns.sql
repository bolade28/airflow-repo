-- Query for campaigns that need evaluation:
SELECT
    u.JOB_BAG_NUMBER AS BOOKING_ID,
    b.BOOKING_NAME,
    u.CAMPAIGN_END_DT,
    LISTAGG(DISTINCT u.MARKETING_TYPE, ', ') WITHIN GROUP (ORDER BY u.MARKETING_TYPE) AS MARKETING_TYPE,
    LISTAGG(DISTINCT u.CHANNEL_NAME, ', ') WITHIN GROUP (ORDER BY u.CHANNEL_NAME) AS CHANNEL_NAME,
    DATEDIFF('day', CURRENT_DATE, u.CAMPAIGN_END_DT) AS days_until_end
FROM {{ get_table('measurement_unified_campaign_pollen_daily_etl') }} u
LEFT JOIN {{ get_table('campaign_booking_media_channel') }} b
    ON b.BOOKING_ID = u.JOB_BAG_NUMBER
WHERE u.LOAD_TS::DATE = CURRENT_DATE
  AND (
      -- Future campaigns: ending in next N days
      (u.CAMPAIGN_END_DT >= CURRENT_DATE 
       AND u.CAMPAIGN_END_DT <= DATEADD('day', {{ params.days_threshold }}, CURRENT_DATE))
      OR
      -- Past campaigns: ended in last N days but NOT evaluated (not in metadata)
      (u.CAMPAIGN_END_DT >= DATEADD('day', -{{ params.days_threshold }}, CURRENT_DATE)
       AND u.CAMPAIGN_END_DT < CURRENT_DATE
       AND NOT EXISTS (
           SELECT 1
           FROM {{ get_table('measurement_metadata') }} m
           WHERE m.BOOKING_ID = u.JOB_BAG_NUMBER
             AND m.EVALUATION_PERIOD = 'during'
       ))
  )
GROUP BY u.JOB_BAG_NUMBER, b.BOOKING_NAME, u.CAMPAIGN_END_DT
ORDER BY u.CAMPAIGN_END_DT ASC
