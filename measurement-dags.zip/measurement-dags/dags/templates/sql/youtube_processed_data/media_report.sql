COPY INTO {{ get_stage('media_report') }}
FROM (
SELECT 
    jobbag_id,
    campaign_date,
    impressions,
    clicks,
    revenue,
    measurable_impressions,
    viewable_impressions
from {{ get_table('media_report') }}
)
include_query_id = true
header = true;
