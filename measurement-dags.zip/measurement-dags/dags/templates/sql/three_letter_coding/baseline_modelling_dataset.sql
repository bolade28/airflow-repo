COPY INTO {{ get_stage('previous_baseline_modelling_dataset') }}
FROM (
    SELECT
    super_category_name,
    unique_brand_name,
    cluster_num,
    marketing_type_name,
    marketing_channel_name,
    marketing_sub_channel_name,
    metric_name,
    metric_value,
    variable_cd,
    job_run_id
    FROM {{ get_table('measurement_baseline_modelling_dataset') }}
)
include_query_id = true
header = true;
