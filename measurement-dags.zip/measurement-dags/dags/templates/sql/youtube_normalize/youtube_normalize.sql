COPY INTO {{ get_stage('youtube_normalize') }}
FROM (
with youtube_normalize as
 (
select DISTINCT
    replace(dtp_input:integrationDetails.jobBagId,'"','') AS jobbagid
    , to_timestamp(REPLACE(dtp_input:startDate,'"','')) AS start_dt
    , to_timestamp(REPLACE(dtp_input:endDate,'"','')) AS end_dt
    , REPLACE(f.value ,'"','') AS item_cd
    , '{{params.channel }}' AS channel
from {{ get_table('digital_trading_campaign_sat_youtube_table') }} as yt_sat_table, lateral flatten(input => yt_sat_table.dtp_input, path => 'measurementSkus') as f
where jobbagid like 'nec%'
 )
select
      start_dt
    , end_dt
    , item_cd
    , jobbagid
    , channel
from youtube_normalize
)
include_query_id = true
header = true;
