COPY INTO {{ get_stage('agg_value_index_dashboard_w') }}
FROM (
select 
   primary_item_cd,
   primary_annual_sales_amt,
   secondary_annual_sales_amt,
   secondary_retailer_cd,
   process_dt
from {{ get_table('agg_value_index_dashboard_w') }}
)
include_query_id = true
header = true;
