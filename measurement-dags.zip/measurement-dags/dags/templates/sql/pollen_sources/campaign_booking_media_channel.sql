COPY INTO {{ get_stage('campaign_booking_media_channel') }}
FROM (
    WITH flattened_booking_skus_check AS (
        SELECT
            booking_id,
            MIN(CASE WHEN json_extract_path_text(f.value, 'skuId') IS NULL THEN 1 ELSE 0 END) as has_null_skuId
        FROM {{ get_table('campaign_booking_media_channel') }}
        , LATERAL FLATTEN(INPUT => booking_item_cd_list) AS f
        WHERE booking_item_cd_list IS NOT NULL
        GROUP BY booking_id
    )
    SELECT
        t.booking_id,
        t.campaign_id,
        t.channel_type,
        t.booking_status,
        CASE
            WHEN t.booking_status = 'COMPLETED'
                 AND t.cumulative_billable_spend_amt IS NOT NULL
                 AND t.cumulative_billable_spend_amt != 0
            THEN t.cumulative_billable_spend_amt
            ELSE t.booking_media_budget_amt
        END AS media_spend_amt,
        t.media_provider,
        t.media_business_group,
        t.booking_media_live_start_dt,
        t.booking_media_live_end_dt,
        t.booking_item_cd_list as item_cd_list,
        t.marketing_hierarchy_cd,
        t.store_cd_list
    FROM {{ get_table('campaign_booking_media_channel') }} t
    INNER JOIN flattened_booking_skus_check fc ON t.booking_id = fc.booking_id
    WHERE t.booking_item_cd_list IS NOT NULL
    AND fc.has_null_skuId = 0
)
include_query_id = true
header = true;