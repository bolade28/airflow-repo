CREATE TABLE IF NOT EXISTS {{ get_table('measurement_baseline_modelling_output') }} (
    week_start_dt DATE NOT NULL,
    super_category_name VARCHAR(900) NOT NULL,
    unique_brand_name VARCHAR(3456) NOT NULL,
    cluster_num VARCHAR(1000) NOT NULL,
    iteration VARCHAR(1000),
    modelling_type VARCHAR(1000),
    cluster_type VARCHAR(1000),
    best_iteration VARCHAR(1000),
    metric_name VARCHAR(1000) NOT NULL,
    metric_value NUMBER(38,10),
    rsq NUMBER(38,10),
    wsmape NUMBER(38,10),
    job_run_id VARCHAR(36) NOT NULL,
    load_ts TIMESTAMP_NTZ NOT NULL,
    baseline_perc NUMBER(38,10)
);
-- This query will fail in development environment as the ownership of this table lies with RL_UP_DEV_ETL 
-- whereas airflow runs with role RL_UP_PROD_ETL. Also it cannot be dropped and recreated due to same issue.