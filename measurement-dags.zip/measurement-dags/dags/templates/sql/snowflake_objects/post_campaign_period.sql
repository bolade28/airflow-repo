CREATE TABLE IF NOT EXISTS {{ get_table('post_campaign_period') }} (
    SUPER_CAT_NAME VARCHAR(100) COMMENT 'Super category name classification for the product',
    ITEM_SHORT_NAME VARCHAR(100) COMMENT 'Short descriptive name of the item/product',
    ITEM_CD NUMBER(38,0) COMMENT 'Unique item code/SKU identifier',
    MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS NUMBER(12,3) COMMENT 'Median number of days between customer transactions for this item',
    TIME_PERIOD_70_PCT_DAYS NUMBER(12,3) COMMENT '70th percentile of time period between transactions in days',
    TIME_PERIOD_80_PCT_DAYS NUMBER(12,3) COMMENT '80th percentile of time period between transactions in days',
    TIME_PERIOD_90_PCT_DAYS NUMBER(12,3) COMMENT '90th percentile of time period between transactions in days',
    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK NUMBER(19,0) COMMENT 'Median time period between transactions expressed in weeks',
    TIME_PERIOD_70_PCT_WK NUMBER(19,0) COMMENT '70th percentile of time period between transactions in weeks',
    TIME_PERIOD_80_PCT_WK NUMBER(19,0) COMMENT '80th percentile of time period between transactions in weeks',
    TIME_PERIOD_90_PCT_WK NUMBER(19,0) COMMENT '90th percentile of time period between transactions in weeks',
    MEDIAN_PROPOSED_BUCKET_WK NUMBER(19,0) COMMENT 'Median proposed time bucket for post-campaign measurement period in weeks',
    JOB_RUN_ID VARCHAR(36) COMMENT 'Job execution identifier for data lineage and processing tracking',
    LOAD_TS TIMESTAMP_NTZ(9) COMMENT 'Timestamp when the record was loaded into the table',
    YEAR_OF_TRANSACTION NUMBER(5,0) COMMENT 'Year when the transactions occurred for the analysis period'
)
COMMENT='Post-campaign period analysis dataset containing transaction timing patterns and percentile distributions used to find optimal measurement windows for campaign effectiveness'
;