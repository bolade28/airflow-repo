-- Add marketing_hierarchy_cd column to multiple tables

-- Baseline attribution integration
ALTER TABLE {{ get_table('baseline_attribution_integration_aws') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(1000) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

-- Measurement campaign execution
ALTER TABLE {{ get_table('measurement_campaign_execution_aws') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(100) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

-- Measurement campaign reporting
ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(100) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

-- Measurement reach engagement
ALTER TABLE {{ get_table('measurement_reach_engagement_aws') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(100) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

-- Measurement unified campaign pollen
ALTER TABLE {{ get_table('measurement_unified_campaign_pollen') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(100) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;

-- Measurement unified campaign pollen prod evaluation
ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }}
ADD COLUMN IF NOT EXISTS
  marketing_hierarchy_cd VARCHAR(100) COMMENT 'Marketing hierarchy code derived from subchannel_name, used for hierarchical campaign reporting and grouping'
;