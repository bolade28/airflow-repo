CREATE TABLE IF NOT EXISTS {{ get_table('campaign_validation_issues') }} (
    correlation_id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(1000) NOT NULL,
    campaign_id VARCHAR(1000) NOT NULL,
    channel_name VARCHAR(1000),
    booking_name VARCHAR(1000),
    booking_status VARCHAR(100),
    campaign_end_date DATE,
    reason_for_blacklisting VARCHAR(500) NOT NULL,
    load_ts TIMESTAMP_NTZ(9) NOT NULL
)
COMMENT='This table contains the list of bookings that are blacklisted for campaign validation due to various reasons such as data quality issues, missing information, etc.';