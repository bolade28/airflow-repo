-- baseline_attribution_integration_aws

ALTER TABLE {{ get_table('baseline_attribution_integration_aws') }}
ADD COLUMN IF NOT EXISTS
-- TODO NOTE: can't have default & add column at the same time because snowflake (would be default null anyway so that's fine)
  run_type TEXT COMMENT 'Run type - either "DTP" or "Pollen"'
;
ALTER TABLE {{ get_table('baseline_attribution_integration_aws') }}
ADD COLUMN IF NOT EXISTS
  dag_run_ts TIMESTAMP_NTZ COMMENT 'Date & time of DAG run'
;

-- measurement_campaign_reporting_aws

ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS
  run_type TEXT COMMENT 'Run type - either "DTP" or "Pollen"'
;
ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS
  dag_run_ts TIMESTAMP_NTZ COMMENT 'Date & time of DAG run'
;

-- measurement_reach_engagement_aws

ALTER TABLE {{ get_table('measurement_reach_engagement_aws') }}
ADD COLUMN IF NOT EXISTS
  run_type TEXT COMMENT 'Run type - either "DTP" or "Pollen"'
;
ALTER TABLE {{ get_table('measurement_reach_engagement_aws') }}
ADD COLUMN IF NOT EXISTS
  dag_run_ts TIMESTAMP_NTZ COMMENT 'Date & time of DAG run'
;

-- unified_products_aws

ALTER TABLE {{ get_table('unified_products_aws') }}
ADD COLUMN IF NOT EXISTS
  run_type TEXT COMMENT 'Run type - either "DTP" or "Pollen"'
;
ALTER TABLE {{ get_table('unified_products_aws') }}
ADD COLUMN IF NOT EXISTS
  dag_run_ts TIMESTAMP_NTZ COMMENT 'Date & time of DAG run'
;
