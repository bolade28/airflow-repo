CREATE TABLE IF NOT EXISTS {{ get_table('measurement_baseline_modelling_dataset') }} (
    WEEK_START_DT DATE NOT NULL COMMENT 'Week start date',
    super_category_name VARCHAR(900) NOT NULL COMMENT 'Super category name',
    unique_brand_name VARCHAR(3456) NOT NULL COMMENT 'Unique brand name',
    cluster_num VARCHAR(1000) NOT NULL COMMENT 'Cluster number',
    marketing_type_name VARCHAR(72) NOT NULL COMMENT 'Marketing type name',
    marketing_channel_name VARCHAR(126) NOT NULL COMMENT 'Marketing channel name',
    marketing_sub_channel_name VARCHAR(1000) NOT NULL COMMENT 'Marketing sub channel name',
    metric_name VARCHAR(1000) NOT NULL COMMENT 'Metric name',
    metric_value NUMBER(38,10) NOT NULL COMMENT 'Metric value',
    variable_cd VARCHAR(1000) NOT NULL COMMENT 'Variable code',
    job_run_id VARCHAR(36) NOT NULL COMMENT 'Job run ID',
    load_ts TIMESTAMP_NTZ NOT NULL COMMENT 'Load timestamp'

)
COMMENT='This table is for baseline modelling dataset';
