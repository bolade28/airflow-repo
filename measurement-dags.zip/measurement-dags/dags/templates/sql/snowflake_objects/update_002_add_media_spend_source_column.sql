-- measurement_unified_campaign_pollen

ALTER TABLE {{ get_table('measurement_unified_campaign_pollen') }}
ADD COLUMN IF NOT EXISTS
  media_spend_source TEXT COMMENT 'Source of media spend data either "CUMULATIVE_BILLABLE_SPEND_AMT" or "BOOKING_MEDIA_BUDGET_AMT"'
;