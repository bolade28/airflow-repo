CREATE TABLE IF NOT EXISTS {{ get_table('planogram_campaigns') }} (
    date_dt DATE,
    week_start_dt DATE,
    store_cd NUMBER(38,0),
    section_id NUMBER(38,0),
    item_cd NUMBER(38,0),
    planogram_id NUMBER(38,0),
    planogram_position_id NUMBER(38,0),
    store_item_position_start_dt DATE,
    store_item_position_end_dt DATE,
    hash_key VARCHAR(32)
);
