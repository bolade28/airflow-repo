CREATE TABLE IF NOT EXISTS {{ get_table('measurement_marketing_channel_hierarchy') }} (
    -- Primary identifiers
    MARKETING_HIERARCHY_CD VARCHAR(100) NOT NULL COMMENT 'Stable primary key from Aspire representing unique marketing hierarchy classification',
    MAPPING_TYPE VARCHAR(100) NOT NULL COMMENT 'Type of hierarchy mapping classification (e.g., channel grouping level)',
    
    -- Campaign and hierarchy details
    MARKETING_CHANNEL VARCHAR(200) COMMENT 'High-level marketing channel classification (e.g., Sponsored Products, Display, Social)',
    MARKETING_SUBCHANNEL VARCHAR(200) COMMENT 'Granular subchannel detail for specific campaign placements (e.g., Argos Or Sainsburys Search, Meta, YouTube)',
    MEDIA_TYPE VARCHAR(100) COMMENT 'Media type classification for the marketing activity',
    CHANNEL_TYPE VARCHAR(100) COMMENT 'Broad marketing activity type: ONSITE / OFFSITE / INSTORE / ATHOME',
    
    -- Measurement controls
    IN_SCOPE_FLAG BOOLEAN NOT NULL COMMENT 'Business decision flag indicating if this channel is approved for measurement reporting (TRUE=reportable, FALSE=excluded)',
    MEASUREMENT_CAMPAIGN_READY BOOLEAN NOT NULL COMMENT 'Technical readiness flag indicating if measurement reporting implementation is complete and active (TRUE=ready, FALSE=in development)',
    
    -- Audit fields
    CORRELATION_ID VARCHAR(36) COMMENT 'Unique identifier for tracking data lineage and pipeline execution runs',
    LOAD_TS TIMESTAMP_NTZ COMMENT 'Timestamp when the record was first created/inserted into the table',
    LAST_MODIFIED_TS TIMESTAMP_NTZ COMMENT 'Timestamp when the record was last updated with data changes'
)
COMMENT='Marketing media hierarchy reference table containing channel classifications, scope definitions, and measurement readiness flags for all campaign types across digital, in-store, and at-home marketing activities';
