CREATE TABLE IF NOT EXISTS {{ get_table('measurement_unified_campaign_regress') }} AS
SELECT * FROM {{ get_table('measurement_unified_campaign') }};

UPDATE {{ get_table('measurement_unified_campaign') }} 
SET UNIQUE_BRAND_NAME = REPLACE(UNIQUE_BRAND_NAME, '|', ' | ')
WHERE UNIQUE_BRAND_NAME NOT LIKE '% | %'; 

UPDATE {{ get_table('unified_products_aws') }}
SET UNIQUE_BRAND_NAME = REPLACE(UNIQUE_BRAND_NAME, '|', ' | ')
WHERE UNIQUE_BRAND_NAME NOT LIKE '% | %';
