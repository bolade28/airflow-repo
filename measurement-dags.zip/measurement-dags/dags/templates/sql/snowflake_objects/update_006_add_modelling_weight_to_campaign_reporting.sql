
-- Measurement campaign reporting
ALTER TABLE {{ get_table('measurement_campaign_reporting_aws') }}
ADD COLUMN IF NOT EXISTS
  modelling_weight FLOAT COMMENT 'Field to check and validate the recalibration factor applied during modelling'
;