CREATE TABLE IF NOT EXISTS {{ get_table('measurement_campaign_execution_aws') }} (
    campaign_id VARCHAR(1000),
    booking_id VARCHAR(1000),
    job_bag_number VARCHAR(1000),
    marketing_type VARCHAR(14),
    channel_name VARCHAR(1000),
    subchannel_name VARCHAR(1000),
    campaign_name VARCHAR(1000),
    campaign_start_dt DATE,
    campaign_end_dt DATE,
    campaign_duration VARCHAR(6),
    job_status VARCHAR(11),
    load_ts TIMESTAMP_NTZ(9),
    job_run_id VARCHAR(1000)
);
