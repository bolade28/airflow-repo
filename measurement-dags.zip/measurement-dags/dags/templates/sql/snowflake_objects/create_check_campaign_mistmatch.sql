CREATE TABLE IF NOT EXISTS {{ get_table('check_campaign_mismatch') }} COPY GRANTS(
    booking_id VARCHAR(1000) NOT NULL COMMENT 'Booking ID from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
    booking_name VARCHAR(1000) NOT NULL COMMENT 'Booking name from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
    campaign_id VARCHAR(1000) NOT NULL COMMENT 'Campaign ID from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
    subchannel_name VARCHAR(1000) COMMENT 'Subchannel name from MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN',
    bdv_count NUMBER(38,10) NOT NULL COMMENT 'Count of distinct marketing_hierarchy_cd for the campaign from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
    unified_count NUMBER(38,10) NOT NULL COMMENT 'Count of distinct marketing_hierarchy_cd for the campaign from MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN',
    campaign_end_dt DATE COMMENT 'Campaign end date from MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN'
)
COMMENT='This table captures the count of distinct marketing_hierarchy_cd for each campaign from CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR to check for mismatches with MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN';
