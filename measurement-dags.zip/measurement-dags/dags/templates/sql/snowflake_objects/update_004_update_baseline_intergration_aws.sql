CREATE TABLE IF NOT EXISTS {{ get_table('baseline_attribution_integration_aws_regress') }} AS
SELECT * FROM {{ get_table('baseline_attribution_integration_aws') }};

UPDATE {{ get_table('baseline_attribution_integration_aws') }} 
SET UNIQUE_BRAND_NAME = REPLACE(UNIQUE_BRAND_NAME, '|', ' | ')
WHERE UNIQUE_BRAND_NAME NOT LIKE '% | %'; 