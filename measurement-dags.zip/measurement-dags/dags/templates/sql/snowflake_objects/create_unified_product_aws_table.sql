CREATE TABLE IF NOT EXISTS {{ get_table('unified_products_aws') }} (
item_cd NUMBER(38,0),
item_name VARCHAR(100),
segment_name VARCHAR(100),
sub_cat_name VARCHAR(100),
cat_name VARCHAR(100),
super_cat_name VARCHAR(300),
item_weight_or_vol_uom_cd VARCHAR(128),
unit_or_item_weight_or_vol_qty NUMBER(18,4),
item_total_weight_or_vol_qty NUMBER(18,4),
base_price_amt NUMBER(18,4),
std_item_wgt_or_vol_qty_uom_cd VARCHAR(128),
std_item_total_wgt_or_vol_qty NUMBER(18,4),
unique_brand_name VARCHAR(300),
raw_unique_brand_name VARCHAR(300),
job_run_id VARCHAR(36),
load_ts TIMESTAMP_NTZ(9)
)
COMMENT='Unified product aws table unload from s3';