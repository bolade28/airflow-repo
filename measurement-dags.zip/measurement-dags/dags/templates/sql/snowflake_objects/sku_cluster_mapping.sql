CREATE TABLE IF NOT EXISTS {{ get_table('measurement_sku_cluster_mapping') }} (
	item_cd VARCHAR(2000) NOT NULL,
	super_category_name VARCHAR(2000),
	unique_brand_name VARCHAR(2000),
	cluster_num VARCHAR(2000),
	modelling_type VARCHAR(2000),
	job_run_id VARCHAR(2000) COMMENT 'Job run ID',
	load_ts TIMESTAMP_NTZ(9)  COMMENT 'Load timestamp'
  )
COMMENT='This table is for Sku Cluster Mapping';
