alter session set statement_timeout_in_seconds = 43200;
CREATE TABLE IF NOT EXISTS {{ get_table('transactions_agg_intermediate') }} cluster by (DATE_)
(
    sku_no NUMBER(38,0),
    date_ DATE,
    total_quantity NUMBER(38,0),
    freq_of_purch NUMBER(18,0),
    distinct_customers NUMBER(18,0),
    avg_purchase_per_customer_cnt NUMBER(24,6),
    online_trans NUMBER(30,4),
    conven_trans NUMBER(30,4),
    super_trans NUMBER(30,4),
    nectar_sales NUMBER(30,4),
    non_nectar_sales NUMBER(30,4)
)
AS
with sales_week AS (
    SELECT
        min(week_start_dt) AS start_date,
        date_trunc('week', to_date(to_varchar(current_date))) AS end_date
    FROM {{ get_table('weekly_start_dates_daily_etl') }}
)

-- Retrieve Unified_Product Model (Creating Dependency)
,  brand_select_table1 AS (
    SELECT *
    FROM {{ get_table('unified_products') }}
),

-- Retrieve Transaction Data FROM FACT_SALE_TRANSACTION_ITEM. Business Context - Tagging Item Sales and Item Returns separately using filters. Also Filtering transactions between SELECT dates 
transactions_sales AS (
    SELECT
        *
        , iff(
            item_type_sale_or_return = 'sale'
            , iff(uom_cd <> 'EA', 1, item_qty)
            , 0
        )::integer AS item_sale_qty
        , iff(
            item_type_sale_or_return = 'return'
            , iff(uom_cd <> 'EA', 1, item_qty)
            , 0
        )::integer AS item_return_qty
    FROM {{ get_table('fact_sale_transaction_item') }}
    WHERE
        transaction_dt >= (SELECT start_date FROM sales_week)
        and transaction_dt <= (SELECT end_date FROM sales_week)
),

-- Retrieve Transaction Data From FACT_SALE_TRANSACTION_BASKET to get additional transaction information. Business Context -  Also Required Transaction codes that are Specific to Sainsburys are filtered
transaction_basket AS (
    SELECT *
    FROM {{ get_table('fact_sale_transaction_basket') }}
    -- Filtering for sainsburys records
    WHERE sales_origination_channel_cd in (
        SELECT upper(value)::string AS codes
        FROM lateral flatten(input => parse_json('{{ params.transaction_codes | tojson }}'))
    )

),

-- Retrieve Additional information about store that the transaction took place in
location_reqd AS (
    SELECT
        location_cd
        , site_type
    FROM {{ get_table('dim_location') }}
),
-- Joining Both Transaction tables, Unified_Product and DIM_LOCATION to collate below required columns FROM respective sources. In Case Pack Size in not available imputing with 1
transactions_data_int AS (   
    SELECT
        ts.transaction_dt,
        ts.item_cd AS sku_no,
        ts.net_retail_sales_amt AS sales_value,
        ts.item_sale_qty AS item_quantity_sold,
        ts.item_return_qty AS item_quantity_returned,
        tb.sales_origination_channel_cd,
        tb.transaction_id,
        -- mst.unique_brand_name AS unique_brand_name,
        -- mst.super_cat_name AS super_category_name,
        -- mst.item_cd AS sku_no,
        -- mst.item_name,
        -- mst.std_item_total_wgt_or_vol_qty AS sku_volume_std,
        -- mst.base_price_amt,
        lr.site_type,
        tb.nectar_card_num_hash AS loyalty_id,
        -- coalesce(mst.unit_or_item_weight_or_vol_qty, 1) AS pack_size,
    FROM transactions_sales AS ts
    JOIN transaction_basket AS tb on ts.transaction_id = tb.transaction_id
    -- JOIN brand_select_table1 AS mst on ts.item_cd = mst.item_cd
    left join location_reqd AS lr on ts.store_cd = lr.location_cd
    ),
     sales_brand_agg_table3 as (
    select
        sku_no
        , date_trunc('week', to_date(to_varchar(transaction_dt))) as date_
        , sum(item_quantity_sold) - sum(item_quantity_returned) as total_quantity
        , count(distinct transaction_id) as freq_of_purch
        , count(distinct loyalty_id) as distinct_customers
        , count(distinct transaction_id) / nullif(count(distinct loyalty_id),0) as avg_purchase_per_customer_cnt
        , sum(
            CASE
                WHEN UPPER(sales_origination_channel_cd) LIKE '%21%' THEN sales_value
            END
        ) as online_trans
        , sum(
            CASE
                WHEN
                    upper(sales_origination_channel_cd) LIKE '%14%'
                    and upper(site_type) LIKE '%CONVENIENCE%' THEN sales_value
            END
        ) as conven_trans
        , sum(
            CASE
                WHEN
                    upper(sales_origination_channel_cd) LIKE '%14%'
                    and upper(site_type) LIKE '%SUPERMARKET%' THEN sales_value
            END
        ) as super_trans
        , sum(
            CASE
                WHEN loyalty_id IS NOT NULL THEN sales_value
            END
        ) as nectar_sales
        , sum(
            CASE
                WHEN loyalty_id IS NULL THEN sales_value
            END
        ) AS non_nectar_sales
    from
        transactions_data_int
    GROUP BY
        date_
        , sku_no
)

SELECT
    sku_no::NUMBER(38,0),
    date_::DATE,
    total_quantity::NUMBER(38,0),
    freq_of_purch::NUMBER(18,0),
    distinct_customers::NUMBER(18,0),
    avg_purchase_per_customer_cnt::NUMBER(24,6),
    online_trans::NUMBER(30,4),
    conven_trans::NUMBER(30,4),
    super_trans::NUMBER(30,4),
    nectar_sales::NUMBER(30,4),
    non_nectar_sales::NUMBER(30,4)  
FROM sales_brand_agg_table3;

