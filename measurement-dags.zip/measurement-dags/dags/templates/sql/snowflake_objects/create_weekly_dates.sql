CREATE TABLE IF NOT EXISTS {{ get_table('weekly_start_dates') }} (
    WEEK_START_DT DATE NOT NULL COMMENT 'Week start date'
)
COMMENT='Weekly start date table for baseline DAG';
