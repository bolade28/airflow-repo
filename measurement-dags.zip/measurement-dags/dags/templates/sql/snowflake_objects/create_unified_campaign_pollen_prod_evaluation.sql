CREATE TABLE IF NOT EXISTS {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }} (
job_bag_number VARCHAR(1000),
campaign_id VARCHAR(1000),
media_spend_amt FLOAT,
media_spend_source VARCHAR(1000),
campaign_start_dt DATE,
campaign_end_dt DATE,
subchannel_name VARCHAR(1000),
item_cd_list VARCHAR(16777216),
super_category_name VARCHAR(1000),
sub_category_name VARCHAR(1000),
channel_name VARCHAR(1000),
campaign_name VARCHAR(1000),
booking_id VARCHAR(1000),
campaign_status VARCHAR(1000),
is_multi_channel BOOLEAN,
load_ts TIMESTAMP_NTZ(9),
job_run_id VARCHAR(36),
marketing_type VARCHAR(100),
unique_brand_name VARCHAR(1000),
post_campaign_dt DATE,
partner_id VARCHAR(128),
advertiser_id VARCHAR(128),
advertiser_name VARCHAR(100)
)
COMMENT='This table is for unified campaign pollen data to emulate prod environment';

ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }}
ADD IF NOT EXISTS partner_id VARCHAR(128);
ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }}
ADD IF NOT EXISTS advertiser_id VARCHAR(128);
ALTER TABLE {{ get_table('measurement_unified_campaign_pollen_prod_evaluation') }}
ADD IF NOT EXISTS advertiser_name VARCHAR(100);