
-- Measurement campaign execution status
ALTER TABLE {{ get_table('measurement_campaign_execution_aws') }}
ADD COLUMN IF NOT EXISTS
  overlapping_campaign_flag BOOLEAN COMMENT 'Indicator of whether the campaign_id is overlapping in the context of pipeline run'
;