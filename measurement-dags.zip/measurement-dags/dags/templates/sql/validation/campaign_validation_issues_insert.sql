MERGE INTO {{ get_table('campaign_validation_issues') }} AS target
USING (
    SELECT DISTINCT
        correlation_id,
        booking_id,
        campaign_id,
        channel_name,
        booking_name,
        booking_status,
        campaign_end_date,
        reason_for_blacklisting,
        load_ts
    FROM {{ get_table('campaign_validation_issues_stage') }}
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY correlation_id, booking_id, campaign_id
        ORDER BY load_ts DESC
    ) = 1
) AS source
    ON target.correlation_id = source.correlation_id
    AND target.booking_id    = source.booking_id
    AND target.campaign_id   = source.campaign_id
WHEN MATCHED THEN UPDATE SET
    target.channel_name            = source.channel_name,
    target.booking_name            = source.booking_name,
    target.booking_status          = source.booking_status,
    target.campaign_end_date       = source.campaign_end_date,
    target.reason_for_blacklisting = source.reason_for_blacklisting,
    target.load_ts                 = source.load_ts
WHEN NOT MATCHED THEN INSERT (
    correlation_id,
    booking_id,
    campaign_id,
    channel_name,
    booking_name,
    booking_status,
    campaign_end_date,
    reason_for_blacklisting,
    load_ts
) VALUES (
    source.correlation_id,
    source.booking_id,
    source.campaign_id,
    source.channel_name,
    source.booking_name,
    source.booking_status,
    source.campaign_end_date,
    source.reason_for_blacklisting,
    source.load_ts
);
