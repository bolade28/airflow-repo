CREATE OR REPLACE TRANSIENT TABLE {{ get_table('campaign_validation_issues_stage') }} COPY GRANTS AS
WITH campaign_base AS (
    SELECT
        cbmc.campaign_id,
        cbmc.booking_id,
        cbmc.booking_status,
        cbmc.booking_name,
        cbmc.marketing_channel AS channel_name,
        cbmc.marketing_channel,
        cbmc.marketing_subchannel,
        cbmc.channel_type,
        cbmc.booking_media_live_start_dt,
        cbmc.booking_media_live_end_dt,
        CAST(cbmc.booking_media_live_end_dt AS DATE) AS campaign_end_date,
        cbmc.booking_item_cd_list,
        cbmc.store_cd_list
    FROM {{ get_table('campaign_booking_media_channel') }} AS cbmc
    WHERE LOWER(cbmc.booking_status) IN ('completed', 'active')
),
campaign_sku_validity AS (
    SELECT
        cb.campaign_id,
        cb.booking_id,
        MAX(
            CASE
                WHEN json_extract_path_text(out.value, 'skuId') IS NOT NULL THEN 1
                ELSE 0
            END
        ) AS has_valid_sku
    FROM campaign_base AS cb
    LEFT JOIN LATERAL FLATTEN(input => cb.booking_item_cd_list) AS out
    GROUP BY
        cb.campaign_id,
        cb.booking_id
),
invalid_campaigns AS (
    SELECT
        cb.campaign_id,
        cb.booking_id,
        cb.channel_name,
        cb.booking_name,
        cb.booking_status,
        cb.campaign_end_date,
        ARRAY_TO_STRING(
            ARRAY_CONSTRUCT_COMPACT(
                IFF(CAST(cb.campaign_id AS VARCHAR) = '-1', '501', NULL),
                IFF(cb.marketing_channel = '-1', '502', NULL),
                IFF(cb.marketing_subchannel = '-1', '503', NULL),
                IFF(cb.channel_type = '-1', '504', NULL),
                IFF(cb.booking_media_live_start_dt IS NULL, '505', NULL),
                IFF(cb.booking_media_live_end_dt IS NULL, '506', NULL),
                IFF(cb.booking_item_cd_list IS NULL, '507', NULL),
                IFF(COALESCE(sv.has_valid_sku, 0) = 0, '508', NULL),
                IFF(
                    LOWER(cb.channel_type) = 'instore'
                    AND LOWER(cb.marketing_subchannel) NOT LIKE '%coupon at till%'
                    AND cb.store_cd_list IS NULL,
                    '509', NULL
                )
            ), ', '
        ) AS reason_for_blacklisting
    FROM campaign_base AS cb
    LEFT JOIN campaign_sku_validity AS sv
        ON cb.campaign_id = sv.campaign_id
        AND cb.booking_id = sv.booking_id
    WHERE (
          CAST(cb.campaign_id AS VARCHAR) = '-1'
          OR cb.marketing_channel = '-1'
          OR cb.marketing_subchannel = '-1'
          OR cb.channel_type = '-1'
          OR cb.booking_media_live_start_dt IS NULL
          OR cb.booking_media_live_end_dt IS NULL
          OR cb.booking_item_cd_list IS NULL
          OR COALESCE(sv.has_valid_sku, 0) = 0
          OR (
              LOWER(cb.channel_type) = 'instore'
              AND LOWER(cb.marketing_subchannel) NOT LIKE '%coupon at till%'
              AND cb.store_cd_list IS NULL
          )
      )
),
invalid_campaigns_dedup AS (
    SELECT
        campaign_id,
        booking_id,
        channel_name,
        booking_name,
        booking_status,
        campaign_end_date,
        reason_for_blacklisting
    FROM invalid_campaigns
    WHERE campaign_id IS NOT NULL
      AND booking_id IS NOT NULL
)
SELECT DISTINCT
    CAST('{{params.correlation_id}}' AS VARCHAR(36)) AS correlation_id,
    CAST(booking_id AS VARCHAR(1000)) AS booking_id,
    CAST(campaign_id AS VARCHAR(1000)) AS campaign_id,
    channel_name,
    booking_name,
    booking_status,
    campaign_end_date,
    reason_for_blacklisting,
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ(9)) AS load_ts
FROM invalid_campaigns_dedup;

SELECT DISTINCT
    booking_id,
    campaign_id,
    channel_name,
    booking_name,
    booking_status,
    reason_for_blacklisting,
    campaign_end_date
FROM {{ get_table('campaign_validation_issues_stage') }}
WHERE campaign_end_date BETWEEN CURRENT_DATE AND DATEADD(day, 30, CURRENT_DATE)
ORDER BY campaign_end_date
LIMIT 10;
