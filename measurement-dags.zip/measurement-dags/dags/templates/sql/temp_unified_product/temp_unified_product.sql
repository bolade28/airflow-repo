COPY INTO {{ get_stage('temp_unified_product') }}
FROM (
    {#/**************************************************************************
    # TODO:: incrementality has been removed from this table, for this logic must be changed with merge query
    # reference: https://docs.snowflake.com/en/sql-reference/sql/merge
    * Objective:
         - This script is used to create "temp_unified_product" table at product key level that contains mapping
          between each item codes of "unified_product" table with their product keys.

    * Business Context:
         - This mapping would be later used in the pipeline to get item codes corresponding to product keys in
          In-Store & Coupon at till time series data processing. Instore and Coupon at Till do not have direct mapping to the
           ITEM_CDs targetted but only have Product Keys targetted. This table helps bridge this gap since we require data at Item_Cd level.

    * Lineage:
        Upstream:
            - Nothing here this would run in parallel with "weekly_dates.sql" & "unified_product.sql" module
        Downstream:
            - sales_data_transformation (sales_data_transformation_output.sql)

    * Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/834535856/Unified+Product

    * Owner : Sai Bollimunta

    ******************************************************************************/#}
    -- Generating a Product Key and Creating an ITEM_CD to Product Key Mapping
    with temp_ean_valid_date as (
    select
    dih.item_cd
    , dth.ean
    , dih.valid_from_dt
    , replace('1' || dth.ean || dih.valid_from_dt, '-', '') as product_key
    from {{ get_table('dim_item_hist') }} AS dih
    inner join {{ get_table('dim_trading_hierarchy') }} AS dth
    on dih.item_cd = dth.item_cd
    )

    -- Filtering for Sainsburys entries
    , temp_ean_valid_date_brand as (
    select
    tevd.item_cd
    , tevd.ean
    , tevd.valid_from_dt
    , tevd.product_key
    , dri.retailer_cd
    , dri.manufacturer_name
    , dri.brand_name
    from temp_ean_valid_date AS tevd
    inner join {{ get_table('dim_retailer_item') }} AS dri
    on cast (tevd.item_cd as varchar) = cast (dri.item_cd as varchar)
    where lower (dri.retailer_cd) like '%sainsbury%'
    )

    -- Filtering required columns and item_cds
    , temp_unified_product as (
    select distinct
    di.item_cd
    , tevdb.product_key
    , '{{params.correlation_id}}' as job_run_id
    from temp_ean_valid_date_brand AS tevdb
    inner join {{ get_table('dim_item') }} AS di
    on tevdb.item_cd = di.item_cd
    )
    -- Creation of temp_unified_product output table containing unified mapping of item codes to generated product keys for further processing and analysis and use in instore and coupon at till tables.
    -- Casting all columns to the datatypes and formats of the already existing table's columns to prevent errors
    select
    CAST (item_cd as number (38,0)) as item_cd
    , CAST (product_key as varchar (1000)) as product_key
    , CAST (job_run_id as varchar (36)) as job_run_id
    , CAST (CURRENT_TIMESTAMP AS TIMESTAMP_NTZ) AS LOAD_TS
    from temp_unified_product
)
include_query_id = true
header = true;

