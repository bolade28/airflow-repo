COPY INTO {{ get_stage('dv360_media_report') }}
FROM (
select 
   jobbag_id,
   campaign_date,
   campaign_id,
   insertion_order_id,
   measurable_impressions,
   viewable_impressions,
   clicks,
   impressions,
   line_item_id,
   total_conversions,
   time_of_day,
   device_type,
   run_at,
   revenue

from {{ get_table('dv360_media_report') }}
)
include_query_id = true
header = true;
