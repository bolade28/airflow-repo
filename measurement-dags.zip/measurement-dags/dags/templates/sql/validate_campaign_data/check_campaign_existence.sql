WITH manual_campaign_list1 AS (
    SELECT trim(table1.value) AS campaign_id
    FROM TABLE(SPLIT_TO_TABLE(
        CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
)

SELECT 
    c.campaign_id,
    CASE 
        WHEN MAX(m.campaign_id) IS NOT NULL OR MAX(m.job_bag_number) IS NOT NULL THEN true
        ELSE false
    END AS exist
FROM manual_campaign_list1 c
LEFT JOIN (
    SELECT DISTINCT campaign_id, job_bag_number, booking_id
    FROM {{ get_table("measurement_campaign_reporting_aws") }}
    WHERE CAMPAIGN_DURATION = 'During'
        {% if params.ci_of_during_run != 'latest' %}
            AND correlation_id = '{{ params.ci_of_during_run }}'
        {% endif %}
) m
ON c.campaign_id = m.campaign_id OR c.campaign_id = m.job_bag_number OR c.campaign_id = m.booking_id
GROUP BY c.campaign_id; 