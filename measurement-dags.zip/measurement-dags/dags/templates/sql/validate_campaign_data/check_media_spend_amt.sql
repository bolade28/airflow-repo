WITH manual_campaign_list1 AS (
 SELECT trim(table1.value) AS campaign_id
        FROM TABLE(SPLIT_TO_TABLE(
            CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
             ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
),
campaign_details AS (
        SELECT job_bag_number 
        FROM {{ get_table('measurement_unified_campaign') }} muc
        WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
        AND (
        (job_bag_number, campaign_end_dt) IN (
                SELECT job_bag_number, 
                        max(campaign_end_dt) AS campaign_end_dt 
                FROM {{ get_table('measurement_unified_campaign') }} muc
                WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
                AND '{{params.during_run_type}}' = '{{params.campaign_duration}}'
                GROUP BY job_bag_number
        )
        OR
        (job_bag_number, post_campaign_dt) IN (
                SELECT job_bag_number, 
                        max(post_campaign_dt) AS campaign_end_dt 
                FROM {{ get_table('measurement_unified_campaign') }} muc
                WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
                AND '{{params.post_run_type}}' = '{{params.campaign_duration}}'
                GROUP BY job_bag_number
        )
        )

        UNION ALL

        SELECT job_bag_number
        FROM {{ get_table('measurement_unified_campaign_pollen') }} muc
        WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
        AND (
                (job_bag_number, campaign_end_dt) IN (
                        SELECT job_bag_number, 
                                max(campaign_end_dt) AS campaign_end_dt 
                        FROM {{ get_table('measurement_unified_campaign_pollen') }} muc
                        WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
                        AND '{{params.during_run_type}}' = '{{params.campaign_duration}}'
                        GROUP BY job_bag_number
                )
                OR
                (job_bag_number, post_campaign_dt) IN (
                        SELECT job_bag_number, 
                                max(post_campaign_dt) AS campaign_end_dt 
                        FROM {{ get_table('measurement_unified_campaign_pollen') }} muc
                        WHERE media_spend_amt IS NOT NULL AND media_spend_amt > 0
                        AND '{{params.post_run_type}}' = '{{params.campaign_duration}}'
                        GROUP BY job_bag_number
                )
        )
)

-- ToDo Add a CTE that defines which campaign are flagged for automated runs
-- If any manual runs are specified, only those campaigns will be validated
-- Likewise if no manual runs are specified, all automated campaigns will be validated

SELECT DISTINCT job_bag_number
FROM campaign_details 
JOIN manual_campaign_list1 mcl
ON campaign_details.job_bag_number = mcl.campaign_id;
