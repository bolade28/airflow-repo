INSERT INTO {{ get_table('check_campaign_mismatch') }} (
    booking_id,
    booking_name,
    campaign_id,
    subchannel_name,
    bdv_count,
    unified_count,
    campaign_end_dt
)
-- Retrieves the list of campaigns to check for mismatches from the bdv and the amount of distinct marketing_hierarchy_cd associated with those campaigns in the booking table
with campaign_bdv as (
    SELECT
        booking_id
        , booking_name
        , campaign_id
        , count(distinct marketing_hierarchy_cd) as bdv_count
    FROM {{ get_table('campaign_booking_media_channel') }}
    WHERE booking_id = '{{params.configured_campaign_id}}'
    GROUP BY booking_id, booking_name, campaign_id
)
-- Retrieves the amount of distinct marketing_hierarchy_cd associated with the campaigns in the unified pollen table, along with subchannel name and campaign end date for additional context in the mismatch table
, unified as (
    SELECT
        job_bag_number as booking_id
        , campaign_id
        , subchannel_name
        , campaign_end_dt
        , count(distinct marketing_hierarchy_cd) as unified_count
    FROM {{ get_table('measurement_unified_campaign_pollen') }}
    WHERE job_bag_number = '{{params.configured_campaign_id}}'
    GROUP BY job_bag_number, campaign_id, subchannel_name, campaign_end_dt
)
-- Final selection: Joins the two cte's and returns the booking_id, campaign_id, subchannel_name, bdv_count, unified_count and campaign_end_dt for the campaigns where bdv_count is greater than unified_count, indicating a mismatch between the two tables. 
-- This will help identify if there are any discrepancies in the count of distinct marketing_hierarchy_cd for the same campaign between the booking table and the unified pollen table. 
-- The additional context of subchannel_name and campaign_end_dt aids further investigation into the mismatches.
SELECT 
    c.booking_id
    , c.booking_name
    , c.campaign_id
    , u.subchannel_name
    , c.bdv_count as bdv_count
    , COALESCE(u.unified_count, 0) as unified_count
    , u.campaign_end_dt
FROM campaign_bdv c
LEFT JOIN unified u
    on c.campaign_id = u.campaign_id
    and c.booking_id = u.booking_id
where c.bdv_count > COALESCE(u.unified_count, 0);

SELECT DISTINCT
    booking_id,
    booking_name,
    campaign_id,
    subchannel_name,
    bdv_count,
    unified_count,
    campaign_end_dt
FROM {{ get_table('check_campaign_mismatch') }}
WHERE booking_id = '{{params.configured_campaign_id}}'
ORDER BY campaign_end_dt
limit 10;

