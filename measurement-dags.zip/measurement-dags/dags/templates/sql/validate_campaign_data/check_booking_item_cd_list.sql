WITH manual_campaign_list AS (
    -- List of campaign IDs to check, from manual or default params
    SELECT trim(table1.value) AS campaign_id
        FROM TABLE(SPLIT_TO_TABLE(
            CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
            ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
    ),
-- Get all the bookings which have null sku's in their booking_item_cd_list
missing_booking_skus_check AS (
    SELECT DISTINCT
        booking_id
    FROM (
        SELECT booking_id
        FROM {{ get_table('campaign_booking_media_channel') }},
        LATERAL FLATTEN(INPUT => booking_item_cd_list) AS s
        WHERE booking_item_cd_list IS NOT NULL
        GROUP BY booking_id
        HAVING COUNT_IF(s.value:skuId::VARCHAR IS NULL) > 0

        UNION ALL

        SELECT booking_id
        FROM {{ get_table('campaign_booking_media_channel') }}
        WHERE booking_item_cd_list IS NULL
    )
),
-- Get all the valid bookings which can be used for validation
valid_bookings AS (
    SELECT DISTINCT
        booking_id
    FROM {{ get_table('campaign_booking_media_channel') }} AS aal
    , lateral flatten(input => aal.booking_item_cd_list) AS out
    WHERE
        campaign_id !='-1'
        AND booking_status IN ('COMPLETED','ACTIVE')
        AND marketing_channel!='-1'
        AND marketing_subchannel!='-1'
        AND channel_type !='-1'
        AND booking_media_live_start_dt IS NOT NULL
        AND booking_media_live_end_dt IS NOT NULL
)
-- ToDo Add a CTE that defines which campaign are flagged for automated runs
-- The job bag ids associated with those campaigns will need to be validated against the booking ids

-- Final selection: For campaigns in manual_campaign_list, return booking_ids that are in missing_booking_skus_check.
-- If booking_id is also in valid_bookings, reason is 'Invalid booking_item_cd_list'.
-- If not in valid_bookings, reason is 'Validation failure due to incomplete or incorrect booking data for measurement'.
-- If this returns no rows, all bookings passed the validation.
-- When it's the DTP branch this should return no rows as the manual campaigns won't match with any BDV values
SELECT DISTINCT
    mbsc.booking_id,
    CASE
        WHEN vb.booking_id IS NOT NULL THEN 'Invalid booking_item_cd_list'
        ELSE 'Validation failure due to incomplete/incorrect booking data in addition to invalid booking_item_cd_list'
    END AS reason
FROM manual_campaign_list mcl
INNER JOIN missing_booking_skus_check mbsc
    ON mcl.campaign_id = mbsc.booking_id
LEFT JOIN valid_bookings vb
    ON mbsc.booking_id = vb.booking_id
