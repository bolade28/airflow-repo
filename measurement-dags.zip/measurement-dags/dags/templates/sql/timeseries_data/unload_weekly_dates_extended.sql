COPY INTO {{ get_stage('weekly_dates_extended') }}
FROM (
    WITH min_date AS (
        SELECT MIN(week_start_dt) AS min_week_start_dt
        FROM {{ get_table('weekly_start_dates') }}
    ),
    original_dates AS (
        SELECT week_start_dt
        FROM {{ get_table('weekly_start_dates') }}
    ),
    extra_weeks AS (
        SELECT DATEADD(week, -seq4() - 1, min_week_start_dt) AS week_start_dt
        FROM min_date
        CROSS JOIN TABLE(GENERATOR(ROWCOUNT => {{ params.additional_weeks }}))
    )
    SELECT week_start_dt
    FROM original_dates

    UNION

    SELECT week_start_dt
    FROM extra_weeks
)
include_query_id = true
header = true;
