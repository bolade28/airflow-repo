COPY INTO {{ get_stage('unified_product') }}
FROM (
    SELECT
        item_cd,
        item_name,
        segment_name,
        sub_cat_name,
        cat_name,
        super_cat_name,
        item_weight_or_vol_uom_cd,
        unit_or_item_weight_or_vol_qty,
        item_total_weight_or_vol_qty,
        std_item_wgt_or_vol_qty_uom_cd,
        std_item_total_wgt_or_vol_qty,
        unique_brand_name,
        base_price_amt,
        raw_unique_brand_name,
        job_run_id,
        load_ts
    FROM {{ get_table('unified_products') }}
)
include_query_id = true
header = true;

