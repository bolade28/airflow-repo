COPY INTO {{ get_stage('measurement_legacy_campaign_performance') }}
FROM (
    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        has_multiple_rows,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('measurement_legacy_campaign_performance') }}
)
include_query_id = true
header = true;
