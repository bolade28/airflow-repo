COPY INTO {{ get_stage('marketing_media_hierarchy_mkthrc_ref') }}
FROM (
    SELECT
        media_placement,
        marketing_channel,
        marketing_subchannel,
        mapping_type,
        channel_type,
        media_provider,
        media_type,
        media_subtype,
        store_type,
        store_location,
        template_type,
        technical_metadata, 
        load_ts
    FROM
        {{ get_table('marketing_media_hierarchy_mkthrc_ref') }}
)
include_query_id = true
header = true;