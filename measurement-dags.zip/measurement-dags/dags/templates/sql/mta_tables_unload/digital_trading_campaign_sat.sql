COPY INTO {{ get_stage('digital_trading_campaign_sat') }}
FROM (
    select
        digital_trading_campaign_nk1,
        digital_trading_campaign_nk3,
        record_arrival_ts,
        campaign_name,
        job_bag_id
    from {{ get_table('digital_trading_campaign_sat') }}
)
include_query_id = true
header = true;
