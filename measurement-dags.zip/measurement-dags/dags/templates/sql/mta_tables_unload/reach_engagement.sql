COPY INTO {{ get_stage('reach_engagement') }}
FROM (
    WITH manual_campaign_list AS (
        SELECT trim(table1.value) AS campaign_id
        FROM TABLE(SPLIT_TO_TABLE(
            CASE WHEN NOT(REPLACE('{{params.campaign_id_manual}}','[]','') = '') THEN '{{params.campaign_id_manual}}'
                 ELSE '{{params.campaign_id_default}}' END ,',')) AS table1
    ),
    unified_campgn AS (
        SELECT DISTINCT uc.campaign_id
        FROM {{ get_table('measurement_unified_campaign') }} AS uc
        INNER JOIN manual_campaign_list AS mc
            ON uc.job_bag_number = mc.campaign_id
            OR uc.campaign_id = mc.campaign_id
    ),
    get_max_load_ts AS (
        SELECT 
            MAX(mre.load_ts)::TIMESTAMP_NTZ AS max_load_ts
        FROM {{ get_table('measurement_reach_engagement_aws') }} AS mre
        LEFT JOIN manual_campaign_list AS mc
            ON mre.campaign_id = mc.campaign_id
            OR mre.booking_id = mc.campaign_id
        LEFT JOIN unified_campgn AS uc
            ON mre.campaign_id = uc.campaign_id
        WHERE mc.campaign_id IS NOT NULL
        OR uc.campaign_id IS NOT NULL
    )
    SELECT DISTINCT
        mre.campaign_id,
        mre.booking_id,
        mre.marketing_type,
        mre.channel_name,
        mre.subchannel_name,
        mre.reach_count AS reach_cnt,
        mre.impressions_count AS impressions_cnt,
        mre.clicks_count AS clicks_cnt,
        mre.sales_amount AS sales_amt,
        mre.conversions_count AS conversions_cnt,
        mre.media_spend_amount AS media_spend_amt,
        mre.engagement_click_through_rate_percent AS engagement_ctr_pct,
        mre.correlation_id AS job_run_id,
        mre.load_ts::TIMESTAMP_NTZ AS load_ts,
        mre.marketing_hierarchy_cd
    FROM {{ get_table('measurement_reach_engagement_aws') }} AS mre
    JOIN get_max_load_ts mts
        ON mre.load_ts = mts.max_load_ts
    LEFT JOIN manual_campaign_list AS mc
        ON mre.campaign_id = mc.campaign_id
        OR mre.booking_id = mc.campaign_id
    LEFT JOIN unified_campgn AS uc
        ON mre.campaign_id = uc.campaign_id
    WHERE mc.campaign_id IS NOT NULL
    OR uc.campaign_id IS NOT NULL
)
include_query_id = true
header = true;
