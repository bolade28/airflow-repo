COPY INTO {{ get_stage('measurement_campaign_execution') }}
FROM (
    SELECT
        campaign_id,
        booking_id,
        job_bag_number,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt,
        campaign_end_dt,
        campaign_duration,
        job_status,
        load_ts,
        job_run_id,
        overlapping_campaign_flag,
        marketing_hierarchy_cd
    FROM
        {{ get_table('measurement_campaign_execution_status') }}
    WHERE campaign_duration = '{{ params.campaign_duration }}'
)
include_query_id = true
header = true;
