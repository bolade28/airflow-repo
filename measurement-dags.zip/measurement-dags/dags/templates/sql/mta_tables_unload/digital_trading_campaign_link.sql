COPY INTO {{ get_stage('digital_trading_campaign_link') }}
FROM (
    -- Retrieve Transaction Data From FACT_SALE_TRANSACTION_BASKET to get additional transaction information. Business Context -  Also Required Transaction codes that are Specific to Sainsburys are filtered
    select
        digital_trading_campaign_nk1,
        digital_trading_campaign_nk3,
        digital_trading_campaign_channel_nk1,
        digital_trading_campaign_channel_nk3,
        digital_trading_advertiser_nk1,
        digital_trading_advertiser_nk3,
        digital_trading_brand_nk1,
        digital_trading_brand_nk3,
        record_arrival_ts
    from {{ get_table('digital_trading_campaign_link') }}
)
include_query_id = true
header = true;
