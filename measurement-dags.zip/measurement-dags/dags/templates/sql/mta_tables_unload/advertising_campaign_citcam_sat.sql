COPY INTO {{ get_stage('advertising_campaign_citcam_sat') }}
FROM (
    select
        advertising_campaign_nk1,
        advertising_campaign_nk3,
        campaign_name,
        campaign_type,
        campaign_subtype,
        campaign_valid_state,
        campaign_placements
    from {{ get_table('advertising_campaign_citcam_sat') }}
)
include_query_id = true
header = true;
