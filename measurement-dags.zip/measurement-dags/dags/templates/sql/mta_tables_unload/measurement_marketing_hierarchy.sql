COPY INTO {{ get_stage('measurement_marketing_channel_hierarchy') }}
FROM (
    SELECT
        marketing_hierarchy_cd,
        mapping_type,
        marketing_channel,
        marketing_subchannel,
        media_type,
        channel_type,
        in_scope_flag,
        measurement_campaign_ready,
    FROM
        {{ get_table('measurement_marketing_channel_hierarchy') }}
    WHERE
        in_scope_flag = true
        AND measurement_campaign_ready = true
)
include_query_id = true
header = true;