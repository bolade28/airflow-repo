
COPY INTO {{ get_stage('digital_trading_campaign_insight_link') }}
FROM (
    select
        digital_trading_campaign_nk1,
        digital_trading_campaign_nk3,
        digital_trading_brand_nk1,
        digital_trading_brand_nk3,
        digital_trading_insight_id,
        record_arrival_ts,
        reporting_start_dt,
        reporting_end_dt,
        measures
    from {{ get_table('digital_trading_campaign_insight_link') }}
)
include_query_id = true
header = true;
