COPY INTO {{ get_stage('unique_reach_lineitem_report') }}
FROM (
    select
        run_at,
        date_from,
        date_until,
        line_item_id,
        total_reach,
        country
    from {{ get_table('unique_reach_lineitem_report') }}
)
include_query_id = true
header = true;
