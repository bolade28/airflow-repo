COPY INTO {{ get_stage('floodlight_report') }}
FROM (
    select
        run_at,
        campaign_date,
        floodlight_id,
        insertion_order_id,
        insertion_order_name,
        line_item_id,
        total_conversions,
        spend
    from {{ get_table('floodlight_report') }}
)
include_query_id = true
header = true;
