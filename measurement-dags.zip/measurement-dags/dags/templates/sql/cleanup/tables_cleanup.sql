DROP TABLE IF EXISTS {{ get_table('measurement_campaign_execution_status') }};

DROP TABLE IF EXISTS {{ get_table('campaign_product_type_aws') }};

DROP TABLE IF EXISTS {{ get_table('weekly_start_dates') }};
