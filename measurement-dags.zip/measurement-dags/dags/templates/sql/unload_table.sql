COPY INTO {{ params.output }}
FROM (
    SELECT *
    FROM {{ params.table }}
)
include_query_id = true
header = true;
