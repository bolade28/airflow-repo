COPY INTO {{ get_stage('ie_campaign_filt') }}
FROM
(
    select
        master_campaign_id,
        start_date,
        end_date,
        media_cost,
        npd
    from {{ get_table('ie_campaign_filt') }}
    WHERE
        campaign_type in ('In-store', 'Integrated', 'Sampling')
        -- Filtering for nectar campaigns
        and master_campaign_id like 'nec%a'
        -- Filtering for processing period
)
include_query_id = true
header = true;
