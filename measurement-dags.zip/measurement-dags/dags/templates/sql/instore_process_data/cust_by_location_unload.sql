COPY INTO {{ get_stage('cust_by_location') }}
FROM
(
select
    store_cd,
    date_,
    distinct_customers
from {{ get_table('customer_by_location') }}
)
include_query_id = true
header = true;
