COPY INTO {{ get_stage('ie_location') }}
FROM
(
    select distinct
        location_key
        , master_campaign_id
        , media_no
    from {{ get_table('ie_location') }}
)
include_query_id = true
header = true;
