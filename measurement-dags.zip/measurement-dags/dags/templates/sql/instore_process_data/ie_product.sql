COPY INTO {{ get_stage('ie_product') }}
FROM
(
    select distinct
        product_key
        , product_name
        , master_campaign_id
    from {{ get_table('ie_product') }}
    WHERE product_name = 'Offer'
)
include_query_id = true
header = true;
