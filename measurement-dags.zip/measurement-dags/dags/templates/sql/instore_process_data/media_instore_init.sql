COPY INTO {{ get_stage('media_instore_init') }}
FROM
(
    select distinct
        master_campaign_id
        , targeted_id
        , media_no
    from {{ get_table('media_instore_init') }}
)
include_query_id = true
header = true;
