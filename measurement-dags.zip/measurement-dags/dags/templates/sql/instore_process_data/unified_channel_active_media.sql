COPY INTO {{ get_stage('unified_channel_active_media') }}
FROM
(
    select
        DISTINCT media_number AS media_no
    FROM {{ get_table('unified_channel_mapping') }}
    WHERE
        UPPER(status) = 'ACTIVE'
        and UPPER(channel) = 'INSTORE'
)
include_query_id = true
header = true;
