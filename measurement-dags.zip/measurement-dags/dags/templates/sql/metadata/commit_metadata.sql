MERGE INTO {{ get_table('measurement_metadata') }} AS target
USING (
    SELECT
        '{{ params.correlation_id }}' AS correlation_id,
        '{{ params.run_date }}' AS run_date,
        '{{ params.run_by }}' AS run_by,
        '{{ params.dags_base_commit }}' AS dags_base_commit,
        '{{ params.pipelines_base_commit }}' AS pipelines_base_commit,
        PARSE_JSON('{{ params.pipelines_git_commits }}') AS pipelines_git_hashes,
        PARSE_JSON('{{ params.dags_git_commits }}') AS dags_git_hashes,
        '{{ params.start_time }}' AS start_time,
        {% if params.end_time %}
            '{{ params.end_time }}'
        {% else %}
            NULL
        {% endif %} AS end_time,
        '{{ params.pipeline_status }}' AS pipeline_status,
        '{{ params.deployment_status }}' AS deployment_status,
        '{{ params.run_type }}' AS run_type,
        '{{ params.booking_id }}' AS booking_id,
        PARSE_JSON('{{ params.validated_booking_ids }}') AS validated_booking_id,
        PARSE_JSON('{{ params.paths }}') AS paths,
        PARSE_JSON('{{ params.campaign_date }}') AS campaign_date,
        '{{ params.evaluation_period }}' AS evaluation_period,
        '{{ params.during_cid }}' AS during_correlation_id,
        '{{ params.configured_end_date }}' AS campaign_end_date,
        '{{ params.airflow_platform }}' AS airflow_platform,
        {% if params.additional_info %}
            PARSE_JSON('{{ params.additional_info }}')
        {% else %}
            NULL
        {% endif %} AS additional_metadata
) AS source
ON target.correlation_id = source.correlation_id
WHEN MATCHED THEN
    UPDATE SET
        run_date = source.run_date,
        run_by = source.run_by,
        dags_base_commit = source.dags_base_commit,
        pipelines_base_commit = source.pipelines_base_commit,
        pipelines_git_hashes = source.pipelines_git_hashes,
        dags_git_hashes = source.dags_git_hashes,
        start_time = COALESCE(target.start_time, source.start_time),  -- Keep original start time
        end_time = source.end_time,
        pipeline_status = source.pipeline_status,
        deployment_status = source.deployment_status,
        run_type = source.run_type,
        booking_id = source.booking_id,
        validated_booking_id = source.validated_booking_id,
        paths = source.paths,
        campaign_date = source.campaign_date,
        evaluation_period = source.evaluation_period,
        during_correlation_id = source.during_correlation_id,
        campaign_end_date = source.campaign_end_date,
        airflow_platform = source.airflow_platform,
        additional_metadata = source.additional_metadata,
        load_ts = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        correlation_id,
        run_date,
        run_by,
        dags_base_commit,
        pipelines_base_commit,
        pipelines_git_hashes,
        dags_git_hashes,
        start_time,
        end_time,
        pipeline_status,
        deployment_status,
        run_type,
        booking_id,
        validated_booking_id,
        paths,
        campaign_date,
        evaluation_period,
        during_correlation_id,
        campaign_end_date,
        airflow_platform,
        additional_metadata,
        load_ts
    )
    VALUES (
        source.correlation_id,
        source.run_date,
        source.run_by,
        source.dags_base_commit,
        source.pipelines_base_commit,
        source.pipelines_git_hashes,
        source.dags_git_hashes,
        source.start_time,
        source.end_time,
        source.pipeline_status,
        source.deployment_status,
        source.run_type,
        source.booking_id,
        source.validated_booking_id,
        source.paths,
        source.campaign_date,
        source.evaluation_period,
        source.during_correlation_id,
        source.campaign_end_date,
        source.airflow_platform,
        source.additional_metadata,
        CURRENT_TIMESTAMP()
    );
