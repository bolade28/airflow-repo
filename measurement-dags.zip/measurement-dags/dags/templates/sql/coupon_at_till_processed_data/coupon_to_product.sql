COPY INTO {{ get_stage('coupon_to_product') }}
FROM (
    SELECT 
        coupon_key,
        product_key,
        correct_brand,
        correct_offer
    FROM 
        {{ get_table('coupon_to_product') }}
)
include_query_id = true
header = true;