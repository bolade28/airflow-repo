COPY INTO {{ get_stage('cell') }}
FROM (
    SELECT 
        campaign_id,
        cell_key
    FROM 
        {{ get_table('cell') }}
)
include_query_id = true
header = true;
