COPY INTO {{ get_stage('campaign') }}
FROM (
    SELECT  
        campaign_id,
        pre_period,
        post_period
    FROM 
        {{ get_table('campaign') }}
)
include_query_id = true
header = true;
