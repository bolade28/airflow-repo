COPY INTO {{ get_stage('base_finance_assets') }}
FROM (
    SELECT 
        job_bag_number
        , asset_actual_start_date
        , asset_actual_end_date 
        , asset_value_unweighted 
        , asset_unique_id
        , service_type
        , media_host_name
        , campaign_status
        , timeid
    FROM 
        {{ get_table('base_finance_assets') }} b1
    where
        timeid = (
            SELECT MAX(timeid)
            FROM {{ get_table('base_finance_assets') }} b2
            WHERE b2.job_bag_number = b1.job_bag_number
            and job_bag_number is not null
            and job_bag_number != ''
        )
)
include_query_id = true
header = true;
