COPY INTO {{ get_stage('coupon_cell') }}
FROM (
    SELECT 
        coupon_key,
        cell_key
    FROM 
        {{ get_table('coupon_cell') }}
)
include_query_id = true
header = true;
