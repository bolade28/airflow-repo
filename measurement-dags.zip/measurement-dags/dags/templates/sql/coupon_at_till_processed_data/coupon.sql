COPY INTO {{ get_stage('coupon') }}
FROM (
    SELECT 
        coupon_key,
        start_date,
        expiry_date,
        coupon_value
    FROM 
        {{ get_table('coupon') }}
)
include_query_id = true
header = true;
