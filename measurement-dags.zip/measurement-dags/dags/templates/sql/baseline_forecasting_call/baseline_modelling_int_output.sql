COPY INTO {{ get_stage('baseline_modelling_int_output') }}
FROM (
    SELECT 
        unique_brand_name
        ,super_category_name
        ,cluster_num
        ,load_ts
        ,best_iteration
        ,marketing_type_name
        ,variable_cd
    FROM 
        {{ get_table('baseline_modelling_int_output') }}
)
include_query_id = true
header = true;
