COPY INTO {{ get_stage('baseline_modelling_output') }}
FROM (
    SELECT 
        unique_brand_name
        ,super_category_name
        ,cluster_num
        ,load_ts
        ,best_iteration
        ,modelling_type
        ,week_start_dt
        ,metric_name
        ,metric_value
    FROM 
        {{ get_table('baseline_modelling_output') }}
)
include_query_id = true
header = true;
