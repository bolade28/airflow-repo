COPY INTO {{ get_stage('oc_campaign') }}
FROM (
    SELECT  
        campaign_id,
        base_asset_id,
        start_date,
        expiry_date
    FROM 
        {{ get_table('oc_campaign') }}
)
include_query_id = true
header = true;
