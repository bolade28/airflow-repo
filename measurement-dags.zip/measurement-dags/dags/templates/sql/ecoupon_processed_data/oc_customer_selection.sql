COPY INTO {{ get_stage('oc_customer_selection') }}
FROM (
    SELECT  
        campaign_id,
        base_asset_id,
        status,
        coupon_id
    FROM 
        {{ get_table('oc_customer_selection') }}
)
include_query_id = true
header = true;
