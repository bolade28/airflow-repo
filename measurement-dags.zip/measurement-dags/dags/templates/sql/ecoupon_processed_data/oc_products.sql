COPY INTO {{ get_stage('oc_products') }}
FROM (
    SELECT  
        product_key,
        base_asset_id
    FROM 
        {{ get_table('oc_products') }}
)
include_query_id = true
header = true;
