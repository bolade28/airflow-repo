COPY INTO {{ get_stage('external_processed_data_output') }}
FROM(
    {#/*********************************************************************************************************************

    * Objective:
        - This script is used to generate time series data for external factors and create feature metrics like -
          gdp_index, unemployment_index, cpi_index, cci_index, petrol price variable, holiday_flags, festival_flags,
          sport_event_flags, weather variables like temperature, precipitation etc..

    * Business Context:
        - Sales could be affected by external factors such as major holidays, festivals, macroeconomics factors, weather etc.
        - Although these factors don’t drive incremental, they help the model in estimating baseline sales.
          We are passing a wide variety of external factors to be tested.
        - These variables have been aligned with analytics team as they are more likely to affect sales at Sainsburys.

    * Lineage:
        Upstream:
            - 01_date_skeleton(weekly_dates.sql)
        Downstream:
            - 08_ads_creation(channel_processed_data.sql)
            - 14_stored_procedure_call(baseline_forecasting_call.sql)

    * Confluence:
        https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/657162421/External+Variables

    * Owner : Sai Bollimunta

    *************************************************************************************************************************/#}
    -- Retrieve weekly date skeleton between start and end dates
    with temp_date_dataset as (
        select week_start_dt as week_start_date
        from {{ get_table('weekly_start_dates') }}
    )

    , constants AS (
        select
        'TOTAL' AS keyword_total,
        'EXTERNAL' AS keyword_external,
        'HOLIDAYS' AS keyword_holidays
    )
    -- Retrieve unemployment raw data
    ,  unemployment_raw as (
        select
            *,
            last_day(date) as month_end
        from {{ get_table('unemployment_data') }}
    )

    -- Merging with date skeleton and Imputing values not present using previous 52 weeks rolling average
    ,  unemployment_processed as (
        select
            tdd.week_start_date,
            'UNEMPLOYEMENT' as marketing_channel,
            'UNEMPLOYEMENT INDEX' as metric,
            coalesce(ur.unemployment_index, avg(ur.unemployment_index) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as value_
        from temp_date_dataset AS tdd
        left join unemployment_raw AS ur
            on tdd.week_start_date between ur.date and ur.month_end
    )

    -- Retrieve BCI raw data
    ,  bci_raw as (
        select
            *,
            last_day(date) as month_end
        from {{ get_table('bci_data') }}
    )

    -- Merging with date skeleton
    ,  bci_processed as (
        select
            tdd.week_start_date,
            'BCI' as marketing_channel,
            'BCI_INDEX' as metric,
            br.bci_m as value_
        from temp_date_dataset AS tdd
        left join bci_raw AS br
            on tdd.week_start_date between br.date and br.month_end
    )

    -- Imputing missing values with previous 52 weeks rolling average. If still missing then imputing with 0 as a safety net
    ,  bci_imputation as (
        select
            *,
            coalesce(value_, avg_last_3,0) as imputed_value
        from (
            select
                week_start_date,
                value_,
                avg(nullif(value_, 0))
                    over (
                        order by week_start_date rows
                        between 52 preceding and current row
                    ) as avg_last_3
            from bci_processed
        )
    )

    -- Merging imputed dataset with original dataset
    ,  bci_processed_imputed as (
        select
            bp.week_start_date,
            bp.marketing_channel,
            bp.metric,
            bi.imputed_value as value_
        from bci_processed AS bp
        left join bci_imputation AS bi
            on bp.week_start_date = bi.week_start_date
    )

    -- Retrieve CCI raw data
    ,  cci_raw as (
        select
            *,
            last_day(date) as month_end
        from {{ get_table('cci_data') }}
    )

    -- Merging with date skeleton
    ,  cci_processed as (
        select
            tdd.week_start_date,
            'CCI' as marketing_channel,
            'CCI_INDEX' as metric,
            cr.cci_m as value_
        from temp_date_dataset AS tdd
        left join cci_raw AS cr
            on tdd.week_start_date between cr.date and cr.month_end
    )

    -- Imputing missing values with last 52 weeks average value. If still missing then imputing with 0 as a safety net
    ,  cci_imputation as (
        select
            *,
             coalesce(value_, avg_last_3,0) as imputed_value
        from (
            select
                week_start_date,
                value_,
                avg(nullif(value_, 0))
                    over (
                        order by week_start_date rows
                        between 52 preceding and current row
                    ) as avg_last_3
            from cci_processed
        )
    )

    -- Merging imputed dataset with original dataset
    ,  cci_processed_imputed as (
        select
            cp.week_start_date,
            cp.marketing_channel,
            cp.metric,
            ci.imputed_value as value_
        from cci_processed AS cp
        left join cci_imputation AS ci
            on cp.week_start_date = ci.week_start_date
    )

    -- Retrieve GDP raw data
    ,  gdp_raw as (
        select
            *,
            last_day(date) as month_end
        from {{ get_table('gdp_data') }}
    )

    -- Merging with date skeleton and Imputing values not present using previous 52 weeks rolling average. If still missing imputing with 0 as a safety net
    ,  gdp_processed as (
        select
            tdd.week_start_date,
            'GDP' as marketing_channel,
            'GDP' as metric,
            coalesce(gr.gdp, avg(gr.gdp) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as value_
        from temp_date_dataset AS tdd
        left join gdp_raw AS gr
            on tdd.week_start_date between gr.date and gr.month_end
    )

    -- Retrieve CPI raw data
    ,  cpi_raw as (
        select
            *,
            last_day(date) as month_end
        from {{ get_table('cpi_data') }}

    )

    -- Merging with date skeleton and Imputing values not present using previous 52 weeks rolling average
    ,  cpi_processed_pre as (
        select
            tdd.week_start_date,
            'CPI' as marketing_channel,
            coalesce(cr.cpi_index,avg(cr.cpi_index) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as cpi_index,
            coalesce(cr.cpih_index,avg(cr.cpih_index) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as cpih_index
        from temp_date_dataset AS tdd
        left join cpi_raw AS cr
            on tdd.week_start_date between cr.date and cr.month_end
    )

    -- Melting dataset to bring in all metrics
    ,  cpi_processed as (
        select
            week_start_date,
            marketing_channel,
            metric,
            value_
        from (
            select
                week_start_date,
                marketing_channel,
                cpih_index,
                cpi_index
            from cpi_processed_pre
        ) unpivot (
            value_ for metric in (
                cpih_index, cpi_index
            )
        )
    )

    -- Retrieve Fuel prices raw data
    ,  fuel_prices_raw as (
        select
            ulsp_pence_per_litre,
            ulsd_pence_per_litre,
            ulsp_vat,
            ulsd_vat,
            ulsd_duty,
            date_trunc('week', date) as week_start_date
        from {{ get_table('fuel_prices') }}
    )

    -- Merging with date skeleton and Imputing values not present using previous 52 weeks rolling average. If still missing imputing with 0 as a safety net
    ,  fuel_processed_pre as (
        select
            tdd.week_start_date,
            'FUEL PRICES' as marketing_channel,
            coalesce(fpr.ulsp_pence_per_litre, avg(fpr.ulsp_pence_per_litre) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as ulsp_pence_per_litre,
            coalesce(fpr.ulsd_pence_per_litre,  avg(fpr.ulsd_pence_per_litre) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as ulsd_pence_per_litre,
            coalesce(fpr.ulsp_vat, avg(fpr.ulsp_vat) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as ulsp_vat,
            coalesce(fpr.ulsd_vat, avg(fpr.ulsd_vat) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as ulsd_vat,
            coalesce(fpr.ulsd_duty, avg(fpr.ulsd_duty) over (order by tdd.week_start_date rows between 52 preceding and current row),0) as ulsd_duty
        from temp_date_dataset AS tdd
        left join fuel_prices_raw AS fpr
            on tdd.week_start_date = fpr.week_start_date
    )

    -- Melting dataset to bring in all metrics
    ,  fuel_processed as (
        select
            week_start_date,
            marketing_channel,
            metric,
            to_number(value_) as value_
        from (
            select
                week_start_date,
                marketing_channel,
                to_number(ulsp_pence_per_litre) as ulsp_pence_per_litre,
                to_number(ulsd_pence_per_litre) as ulsd_pence_per_litre,
                to_number(ulsp_vat) as ulsp_vat,
                to_number(ulsd_vat) as ulsd_vat,
                to_number(ulsd_duty) as ulsd_duty
            from fuel_processed_pre
        ) unpivot (
            value_ for metric in (
                ulsp_pence_per_litre, ulsd_pence_per_litre, ulsp_vat, ulsd_vat, ulsd_duty
            )
        )
    )

    -- Retrieve School Holiday raw data
    ,  school_holiday_raw as (
        select
            date_trunc('week', date) as week_start_date,
            max(is_school_holiday) as school_holiday_flag
        from {{ get_table('school_holiday_data') }}
        group by week_start_date
    )

    -- Merging with date skeleton and Imputing values not present with 0
    ,  school_holiday_processed as (
        select
            tdd.week_start_date,
            'school holiday' as marketing_channel,
            'school_holiday_flag' as metric,
            coalesce(shr.school_holiday_flag, 0) as value_
        from temp_date_dataset AS tdd
        left join school_holiday_raw AS shr
            on tdd.week_start_date = shr.week_start_date
    )

    -- Retrieve Sports Events Data raw data. Parsing the Names of weeks and Concatenting Competition and Sport values to make event column more descriptive. Filtering for required time period.
    ,  historic_sports_temp as (
        select distinct
            date_trunc('WEEK', date_) as week_start_date,
            upper(trim(replace(replace(replace(replace(name_, '(', ''), ')', ''), '/', '_'), '''', ''))) as event
        from (
            select
                date_,
                concat(competition, '_', sport) as name_
            from (
                select distinct
                    sport,
                    competition,
                    date(datefrom) as date_
                from {{ get_table('sports_data') }}
            )
        )
        where
            week_start_date between cast('{{params.start_date}}' as date) and cast('{{params.end_date}}' as date)
    )

    -- Selecting distinct sports events
    ,  distinct_sports_events as (
        select distinct event
        from historic_sports_temp
    )

    -- Merging distinct sports events with Date Skeleton
    ,  sport_event_skele as (
        select
            tdd.*,
            dse.*
        from temp_date_dataset AS tdd
        cross join distinct_sports_events AS dse
    )

    -- Imputing all weeks without events with 0. Weeks where the event is active tagged as 1
    ,  sport_event_processed as (
        select
            ses.week_start_date,
            c.keyword_total as super_category_name,
            c.keyword_total as unique_brand_name,
            c.keyword_external  as marketing_type,
            'SPORTS EVENTS' as marketing_channel,
            c.keyword_total as cluster_no,
            'EVENT_FLAG' as metric,
            replace(upper(ses.event), ' ', '_') as marketing_sub_channel,
            case when hst.event is null then 0 else 1 end as value_
        from sport_event_skele AS ses
        left join historic_sports_temp AS hst
            on
                ses.week_start_date = hst.week_start_date
                and ses.event = hst.event
        CROSS JOIN constants c
        order by marketing_channel, ses.week_start_date
    )

    -- Taking a union of all previous datasets
    ,  external_processed as (
        select * from unemployment_processed AS up
        union all
        select * from bci_processed_imputed AS bpi
        union all
        select * from cci_processed_imputed AS cpi
        union all
        select * from gdp_processed AS gp
        union all
        select * from school_holiday_processed AS shp
        union all
        select * from fuel_processed AS fp
        union all
        select * from cpi_processed AS cp
    )

    -- Retrieve holiday raw data and filter for required types
    ,  calendar_holiday_raw as (
        select distinct
            date_trunc('week', clndr_dt) as week_start_date,
            case
                when holiday_type in (
                (
                    select value::string as codes
                from lateral flatten(input => parse_json('{{ params.ext_holiday_name_list | tojson }}'))
                )
                ) then holiday_name
                else holiday_type
            end as holiday_flag
        from {{ get_table('dim_calendar_events') }}
        where holiday_type in (
                (
                select value::string as codes
                from lateral flatten(input => parse_json('{{ params.ext_holiday_type_filter | tojson }}'))
                )
        )
    )
    -- Adding Black Friday and Cyber Events which are not present in input data.
    -- TODO:: dates need to be updated
    , calendar_holiday_extended AS (
        -- Use the existing calendar_holiday_raw data first
        SELECT *
        FROM calendar_holiday_raw AS hr

        UNION ALL

        SELECT
            date_trunc('week', TO_DATE(holiday_date)) AS week_start_date,
            holiday_name AS holiday_flag
        FROM (
            SELECT DATE '2022-11-25' AS holiday_date, 'Black Friday' AS holiday_name
            UNION ALL
            SELECT DATE '2023-11-24', 'Black Friday'
            UNION ALL
            SELECT DATE '2024-11-29', 'Black Friday'
            UNION ALL
            SELECT DATE '2025-11-28', 'Black Friday'
            UNION ALL
            SELECT DATE '2026-11-27', 'Black Friday'
            UNION ALL
            SELECT DATE '2022-11-28', 'Cyber Monday'
            UNION ALL
            SELECT DATE '2023-11-27', 'Cyber Monday'
            UNION ALL
            SELECT DATE '2024-12-02', 'Cyber Monday'
            UNION ALL
            SELECT DATE '2025-12-01', 'Cyber Monday'
            UNION ALL
            SELECT DATE '2026-11-30', 'Cyber Monday'
        ) AS holidays
    )



    -- Creating Prechristmas start date for each year .Pre Christmas is considered from 15th Nov to week before Christmas
    , pre_christmas_base_dates AS (
        SELECT DISTINCT DATE_FROM_PARTS(YEAR(week_start_date), 11, 15) AS start_date
        FROM calendar_holiday_extended
    )

    -- Creating Prechristmas weekly dates for each year which is from 15th Nov to week before Christmas. In this step the values are equal to 1 for all weeks till end of year
    , pre_christmas_all_dates AS (
        SELECT DATE_TRUNC('WEEK', start_date) AS monday_date, start_date
        FROM pre_christmas_base_dates
        UNION ALL
        SELECT DATEADD('WEEK', 1, monday_date), start_date
        FROM pre_christmas_all_dates
        WHERE DATEADD('WEEK', 1, monday_date) <= DATE_FROM_PARTS(YEAR(start_date), 12, 25)
    )

    -- Gathering start dates for Christmas
    , christmas_start_dates AS (
        SELECT
            EXTRACT(YEAR, DATE_TRUNC('WEEK', week_start_date)) AS year_mon_csd,
            MIN(DATEADD(WEEK, -2,DATE_TRUNC('WEEK', week_start_date))) AS week_start_date_csd
        FROM
            calendar_holiday_extended
        WHERE
            holiday_flag in (
                select value::string as codes
                from lateral flatten(input => parse_json('{{ params.ext_christmas_list | tojson }}'))
            )
        GROUP BY
        EXTRACT(YEAR, DATE_TRUNC('WEEK', week_start_date))
    )

    -- Selecting Year and week_start_date of prechristmas
    , pre_christmas_filter AS (
        select YEAR(monday_date) as year_mon,monday_date  as week_start_date
        from pre_christmas_all_dates
    )

    -- Joining tables to Filter out the Christmas period so that Prechristmas weekly dates is from 15th Nov to week before Christmas. Joining dates to filter in next step.
    , pre_christmas_filter_1 AS (
        select pre_christmas_filter.year_mon as year_mon,
        pre_christmas_filter.week_start_date as week_start_date,
        christmas_start_dates.week_start_date_csd as week_start_date_csd,
        christmas_start_dates.year_mon_csd as year_mon_csd
        from pre_christmas_filter
        left join christmas_start_dates
        on pre_christmas_filter.year_mon = christmas_start_dates.year_mon_csd
    )

    -- Filtering out the Christmas period so that Prechristmas weekly dates is from 15th Nov to week before Christmas
    , pre_christmas_filtered as (
        select distinct week_start_date as monday_date, year_mon from pre_christmas_filter_1
        where year_mon = year_mon_csd
        and week_start_date < week_start_date_csd
    )

    -- Appending Pre Christmas to Existing holidays list
    , calendar_holiday_union AS (
        select * from calendar_holiday_extended as hr
        union all
        select monday_date as week_start_date, 'Pre Christmas' as holiday_flag
        from pre_christmas_filtered
    )
    , key_value_pairs AS (
         SELECT '2ND JANUARY (SUBSTITUTE DAY)' AS key, 'NEW YEARS DAY OBSERVED' AS value
         UNION ALL
         SELECT 'SUBSTITUTE BANK HOLIDAY FOR CHRISTMAS DAY', 'CHRISTMAS DAY'
         UNION ALL
         SELECT 'CHRISTMAS EVE', 'CHRISTMAS DAY'
         UNION ALL
         SELECT 'BATTLE OF THE BOYNE OBSERVED', 'BATTLE OF THE BOYNE'
         UNION ALL
         SELECT 'DAY OFF FOR ST PATRICKS DAY', 'ST PATRICKS DAY'
         UNION ALL
         SELECT 'EARLY MAY BANK HOLIDAY / VE DAY', 'EARLY MAY BANK HOLIDAY'
         UNION ALL
         SELECT 'NEW YEARS DAY HOLIDAY', 'NEW YEARS DAY OBSERVED'
         UNION ALL
         SELECT 'NEW YEARS DAY', 'NEW YEARS DAY HOLIDAY'
         UNION ALL
         SELECT 'ST ANDREWS DAY OBSERVED', 'ST ANDREWS DAY'
         UNION ALL
         SELECT 'SUBSTITUTE BANK HOLIDAY FOR BOXING DAY', 'BOXING DAY'
         UNION ALL
         SELECT 'EASTER SUNDAY', 'EASTER'
         UNION ALL
         SELECT 'EASTER MONDAY', 'EASTER'
         UNION ALL
         SELECT 'GOOD FRIDAY', 'EASTER'
         UNION ALL
         SELECT 'NEW YEARS EVE', 'NEW YEARS DAY OBSERVED'
    )

    -- Transformation of Holiday Names based on input dictionary in config. Business Context - Some holidays are similar in name (or expected impact on sales) but seperate in input data. We club these into same variable.
    ,  calendar_holiday_cleaned as (
        select
            hr.week_start_date,
            hr.holiday_flag as old_holiday,
            case when
                kvp.value is not null
                then kvp.value
            else
                hr.holiday_flag
            end as holiday_flag
        from calendar_holiday_union AS hr
        left join key_value_pairs AS kvp
        on upper(replace(hr.holiday_flag,'''', '')) = upper(replace(kvp.key,'''', ''))
    )

    -- Removing special characters from holiday Names
    ,   calendar_holiday_weekly as (
        select
            week_start_date,
            holiday_flag
        from (
            select
                week_start_date,
                upper(
                    trim(replace(replace(replace(replace(holiday_flag, '(', ''), ')', ''), '/', '_'), '''', ''))
                ) as holiday_flag
            from calendar_holiday_cleaned
        )
    )

    -- Merging holiday data with date skeleton
    ,  holiday_skele as (
        select
            tdd.*,
            hw.holiday_flag as metric_name
        from temp_date_dataset AS tdd
        cross join calendar_holiday_weekly AS hw
    )

    -- Selecting required columns and tagging certain holidays under Festival bucket
    ,  holiday_processed_brand_final as (
        select distinct
            hs.week_start_date,
            c.keyword_total as super_category_name,
            c.keyword_total as unique_brand_name,
            c.keyword_external as marketing_type,
            c.keyword_total as cluster_no,
            case
                when hs.metric_name in ('HINDUISM', 'MUSLIM', 'CHRISTIAN') then 'FESTIVALS'
                else c.keyword_holidays
            end as marketing_channel,
            replace(upper(hs.metric_name), ' ', '_') as marketing_sub_channel,
            case
                when hs.metric_name in ('HINDUISM', 'MUSLIM', 'CHRISTIAN') then 'FESTIVAL_FLAG'
                else 'HOLIDAY_FLAG'
            end as metric,
            case when hw.holiday_flag is not null then 1 else 0 end as value_
        from holiday_skele as hs
        left join calendar_holiday_weekly as hw
            on
                hs.week_start_date = hw.week_start_date
                and hs.metric_name = hw.holiday_flag
        CROSS JOIN constants c
    )

    -- Selecting required columns
    ,   holiday_processed_brand_final_dec as (
        select
            week_start_date,
            value_,
            metric,
            super_category_name,
            unique_brand_name as brand,
            marketing_type,
            marketing_channel,
            marketing_sub_channel
        from holiday_processed_brand_final as hpbf
    )

    -- Selecting list of holidays to extend its duration to 2 weeks prior. Business Context - Analytics team mentioned this list of Holidays that could have an impact sales 2 weeks prior to the actual holiday date.
    -- So we extend the flag to 2 weeks prior to capture this impact
    ,   holiday_active_dates as (
        select
        week_start_date,
        super_category_name,
        brand,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        value_ as value_active
        from holiday_processed_brand_final_dec as hpbfd
        CROSS JOIN constants c
        where value_>0
        and marketing_channel in (c.keyword_holidays)
        and marketing_sub_channel in (
            (
            select upper(value)::string as codes
            from lateral flatten(input => parse_json('{{ params.ext_marketing_sub_channel_extend | tojson }}'))
            )
        )
    )

    -- Intermediate step to backshift holidays by 1 week
    ,   holidays_backshifted_1 as (
        select
        dateadd(week, -1, week_start_date) as week_start_date,
        super_category_name,
        brand,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        value_active
        from holiday_active_dates as had
    )

    -- Intermediate step to backshift holidays by 2 week
    ,   holidays_backshifted_2 as (
        select
        dateadd(week, -2, week_start_date) as week_start_date,
        super_category_name,
        brand,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        value_active
        from holiday_active_dates as had
    )

    -- Union of Holidays along with 2 weeks backshift
    ,   holiday_active_dates_updated as (
        select * from holiday_active_dates as had
        union
        select * from holidays_backshifted_1 as hb1
        union
        select * from holidays_backshifted_2 as hb2
    )

    -- Joining Backshifted holiday dataset and original holiday dataset
    ,   holiday_processed_brand_final_updated as (
        select
        hpbfd.week_start_date,
        hpbfd.super_category_name,
        hpbfd.brand,
        hpbfd.marketing_type,
        hpbfd.marketing_channel,
        hpbfd.marketing_sub_channel,
        hpbfd.metric,
        hpbfd.value_,
        hadu.value_active
        from holiday_processed_brand_final_dec as hpbfd
        left join holiday_active_dates_updated as hadu
        on
        hpbfd.week_start_date = hadu.week_start_date
        and hpbfd.super_category_name = hadu.super_category_name
        and hpbfd.brand = hadu.brand
        and hpbfd.marketing_type = hadu.marketing_type
        and hpbfd.marketing_channel = hadu.marketing_channel
        and hpbfd.marketing_sub_channel = hadu.marketing_sub_channel
        and hpbfd.metric = hadu.metric
    )

    -- Combining backshifted variables into their respective holiday flags
    ,   holiday_processed_brand_final_combined as (
        select
        week_start_date,
        super_category_name,
        brand,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        case
        when value_ = 1 or value_active = 1 then 1
        else 0
        end as final_value_
        from holiday_processed_brand_final_updated as hpbfu
    )

    -- Filtering required columns in required format
    ,   holiday_processed_brand_final_filtered as (
        select
        week_start_date,
        super_category_name,
        brand as unique_brand_name,
        lower(c.keyword_total) as cluster_no,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        final_value_ as value_
        from holiday_processed_brand_final_combined as hpbfu1
        CROSS JOIN constants c

    )

    -- Selecting dates from Pre Christmas Period
    , holiday_processed_brand_final_christmas as (
        select distinct week_start_date from holiday_processed_brand_final_filtered
        where marketing_sub_channel = 'PRE_CHRISTMAS'
        and value_ = 1
    )

    -- Extending Christmas Day to include Pre Christmas Period. Now Pre Christmas and Christmas are combined. Business Context - Analytics team mentioned Christmas is expected to have an impact from Mid November on sales.
    -- We extend the Christmas Variable from raw data to capture this impact
    , holiday_processed_brand_final_extended as (
        select
        week_start_date,
        super_category_name,
        unique_brand_name,
        cluster_no,
        marketing_type,
        marketing_channel,
        marketing_sub_channel,
        metric,
        case when marketing_sub_channel = 'CHRISTMAS_DAY' and
        week_start_date in (select week_start_date from holiday_processed_brand_final_christmas) then 1
        else value_
        end as value_
        from holiday_processed_brand_final_filtered
    )

    -- Retrieving Weather Raw Data and aggregate weather metrics at week_start_date level. Filtering for Great Britain
    ,  weather_weekly as (
        select
            date_trunc('WEEK', date_calendar) as week_start_date,
            avg(temperature_avg) as average_temperature,
            avg(temperature_max) as maximum_temperature,
            avg(temperature_min) as minimum_temperature,
            avg(precipitation_lwe_total) as average_precipitation_mm,
            avg(minutes_of_precipitation_total) as average_precipitation_minutes,
            avg(snow_total) as average_snowfall
        from {{ get_table('vw_sainsbury_daily_metric_v1_0') }}
        where country_code = 'GB'
        group by week_start_date
    )

    -- Filter required columns and format as per requirement
    ,  weather_weekly_hier as (
        select
            week_start_date,
            c.keyword_total as super_category_name,
            c.keyword_total as unique_brand_name,
            c.keyword_external as marketing_type,
            'WEATHER' as marketing_channel,
            c.keyword_total as marketing_sub_channel,
            c.keyword_total as cluster_no,
            average_temperature,
            maximum_temperature,
            minimum_temperature,
            average_precipitation_minutes,
            average_precipitation_mm,
            average_snowfall
        from weather_weekly
        CROSS JOIN constants c
        where week_start_date between cast('{{params.start_date}}' as date) and cast('{{params.end_date}}' as date)
        order by week_start_date
    )

    -- Melt columns to include all metrics. Impute missing values with 0.
    ,  weather_unpivot as (
        select
            week_start_date,
            super_category_name,
            unique_brand_name,
            marketing_type,
            marketing_channel,
            marketing_sub_channel,
            cluster_no,
            metric,
            coalesce(to_number(value_), 0) as value_
        from (
            select
                week_start_date,
                super_category_name,
                unique_brand_name,
                marketing_type,
                marketing_channel,
                marketing_sub_channel,
                cluster_no,
                to_number(average_temperature) as average_temperature,
                to_number(maximum_temperature) as maximum_temperature,
                to_number(minimum_temperature) as minimum_temperature,
                to_number(average_precipitation_minutes) as average_precipitation_minutes,
                to_number(average_precipitation_mm) as average_precipitation_mm,
                to_number(average_snowfall) as average_snowfall
            from weather_weekly_hier
        ) unpivot (
            value_ for metric in (
                average_temperature,
                maximum_temperature,
                minimum_temperature,
                average_precipitation_minutes,
                average_precipitation_mm,
                average_snowfall
            )
        )
    )

    -- Create Skeleton for weather variable
    ,  unique_skele_weather as (
        select distinct
            super_category_name,
            unique_brand_name,
            marketing_type,
            marketing_channel,
            marketing_sub_channel,
            cluster_no,
            metric
        from weather_unpivot
    )

    -- Merge with Date Skeleton
    ,  skele_weather_final as (
        select
            tdd.*,
            usw.*
        from temp_date_dataset AS tdd
        cross join unique_skele_weather AS usw
    )

    -- Join with Skeleton and impute missing values
    ,  weather_processed_brand_final as (
        select
            swf.*,
            coalesce(wu.value_, 0) as value_
        from skele_weather_final AS swf
        left join weather_unpivot AS wu
            on
                swf.week_start_date = wu.week_start_date
                and swf.super_category_name = wu.super_category_name
                and swf.unique_brand_name = wu.unique_brand_name
                and swf.marketing_type = wu.marketing_type
                and swf.marketing_channel = wu.marketing_channel
                and swf.marketing_sub_channel = wu.marketing_sub_channel
                and swf.cluster_no = wu.cluster_no
                and swf.metric = wu.metric
    )

    -- Collate all the external variables
    ,  external_processed_brand_processed as (
        select
            week_start_date,
            value_,
            replace(upper(metric), ' ', '_') as metric,
            lower(c.keyword_total) as super_category_name,
            lower(c.keyword_total) as unique_brand_name,
            lower(c.keyword_external) as marketing_type,
            marketing_channel,
            lower(c.keyword_total) as marketing_sub_channel,
            lower(c.keyword_total) as cluster_no
        from external_processed AS ep
        CROSS JOIN constants c
        union all
        (
            select
                week_start_date,
                value_,
                metric,
                super_category_name,
                unique_brand_name,
                marketing_type,
                marketing_channel,
                marketing_sub_channel,
                cluster_no
            from holiday_processed_brand_final_extended AS hpbfe
        )
        union all
        (
            select
                week_start_date,
                value_,
                metric,
                super_category_name,
                unique_brand_name,
                marketing_type,
                marketing_channel,
                marketing_sub_channel,
                cluster_no
            from weather_processed_brand_final AS wpmf
        )
        union all
        (
            select
                week_start_date,
                value_,
                metric,
                super_category_name,
                unique_brand_name,
                marketing_type,
                marketing_channel,
                marketing_sub_channel,
                cluster_no
            from sport_event_processed AS sep
        )
    )

    ,  external_processed_data as (
        select distinct
            week_start_date,
            super_category_name,
            unique_brand_name,
            marketing_type,
            marketing_channel,
            marketing_sub_channel,
            cluster_no,
            metric,
            value_
        from external_processed_brand_processed AS epmp
    )

    /*Creation of external_processed_data output table containing  entire external variables in a processed format. It is used not only in creating the ADS for Baseline Modelling,
    but is used in Forecasting as well where it is used to Forecast Baseline Sales.*/

    -- Casting all columns to the datatypes and formats of the already existing table's columns to prevent errors
    select
        cast(week_start_date as date) as week_start_dt,
        cast(value_ as number(38,8)) as metric_value,
        cast(upper(super_category_name) as varchar(15)) as super_category_name,
        cast(upper(unique_brand_name) as varchar(15)) as unique_brand_name,
        cast(upper(cluster_no) as varchar(15)) as cluster_num,
        cast(upper(marketing_type) as varchar(24)) as marketing_type_name,
        cast(upper(marketing_channel) as varchar(42)) as marketing_channel_name,
        cast(upper(marketing_sub_channel) as  varchar(1000)) as marketing_sub_channel_name,
        cast(upper(metric) as  varchar(1000)) as metric_name,
        cast('{{params.correlation_id}}' as varchar(36)) as job_run_id,
        cast(current_timestamp as timestamp_ntz) as load_ts
    from external_processed_data

    )
include_query_id = true
header = true;