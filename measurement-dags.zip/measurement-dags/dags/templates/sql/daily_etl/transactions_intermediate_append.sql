MERGE INTO {{ get_table('transactions_agg_intermediate') }} AS target
USING (
WITH sales_week AS (
    SELECT
        max(date_) AS start_date,
        CAST('{{ params.modelling_end_date }}' AS DATE) AS end_date
    FROM {{ get_table('transactions_agg_intermediate') }}
),

-- Retrieve Transaction Data FROM FACT_SALE_TRANSACTION_ITEM. Business Context - Tagging Item Sales and Item Returns separately using filters. Also Filtering transactions between SELECT dates 
transactions_sales AS (
    SELECT
        *,
        iff(
            item_type_sale_or_return = 'sale',
            iff(uom_cd <> 'EA', 1, item_qty),
            0
        )::integer AS item_sale_qty,
        iff(
            item_type_sale_or_return = 'return',
            iff(uom_cd <> 'EA', 1, item_qty),
            0
        )::integer AS item_return_qty
    FROM {{ get_table('fact_sale_transaction_item') }}
    JOIN (SELECT  date_trunc('week', min(transaction_dt)) AS start_dt from {{ get_table('fact_sale_transaction_item') }} 
    WHERE cast(aspire_arrival_Ts as date) >= (SELECT start_date FROM sales_week) and cast(aspire_arrival_Ts as date) <= (SELECT end_date FROM sales_week)) t
        ON transaction_dt >= t.start_dt 
        AND transaction_dt <= (SELECT end_date FROM sales_week)
),

-- Retrieve Transaction Data From FACT_SALE_TRANSACTION_BASKET to get additional transaction information. Business Context -  Also Required Transaction codes that are Specific to Sainsburys are filtered
transaction_basket AS (
    SELECT *
    FROM {{ get_table('fact_sale_transaction_basket') }}
    -- Filtering for sainsburys records
    WHERE sales_origination_channel_cd in (
        SELECT upper(value)::string AS codes
        FROM lateral flatten(input => parse_json('{{ params.transaction_codes | tojson }}'))
    )
),

-- Retrieve Additional information about store that the transaction took place in
location_reqd AS (
    SELECT
        location_cd,
        site_type
    FROM {{ get_table('dim_location') }}
),
-- Joining Both Transaction tables, Unified_Product and DIM_LOCATION to collate below required columns FROM respective sources. In Case Pack Size in not available imputing with 1
transactions_data_int AS (   
    SELECT
        ts.transaction_dt,
        ts.item_cd AS sku_no,
        ts.net_retail_sales_amt AS sales_value,
        ts.item_sale_qty AS item_quantity_sold,
        ts.item_return_qty AS item_quantity_returned,
        item_sequence_num AS item_sequence_num,
        tb.sales_origination_channel_cd,
        tb.transaction_id,
        lr.site_type,
        tb.nectar_card_num_hash AS loyalty_id
    FROM transactions_sales AS ts
    JOIN transaction_basket AS tb on ts.transaction_id = tb.transaction_id
    left join location_reqd AS lr on ts.store_cd = lr.location_cd
    ),
     sales_brand_agg_table3 as (
    select
        sku_no,
        date_trunc('week', to_date(to_varchar(transaction_dt))) as date_,
        sum(item_quantity_sold) - sum(item_quantity_returned) as total_quantity,
        count(distinct transaction_id) as freq_of_purch,
        count(distinct loyalty_id) as distinct_customers,
        count(distinct transaction_id) / nullif(count(distinct loyalty_id),0) as avg_purchase_per_customer_cnt,
        sum(
            CASE
                WHEN UPPER(sales_origination_channel_cd) LIKE '%21%' THEN sales_value
            END
        ) as online_trans,
        sum(
            CASE
                WHEN
                    upper(sales_origination_channel_cd) LIKE '%14%'
                    and upper(site_type) LIKE '%CONVENIENCE%' THEN sales_value
            END
        ) as conven_trans,
        sum(
            CASE
                WHEN
                    upper(sales_origination_channel_cd) LIKE '%14%'
                    and upper(site_type) LIKE '%SUPERMARKET%' THEN sales_value
            END
        ) as super_trans,
        sum(
            CASE
                WHEN loyalty_id IS NOT NULL THEN sales_value
            END
        ) as nectar_sales,
        sum(
            CASE
                WHEN loyalty_id IS NULL THEN sales_value
            END
        ) AS non_nectar_sales,
    from
        transactions_data_int
    GROUP BY
        date_,
        sku_no
)

SELECT
    sku_no,
    date_,
    total_quantity,
    freq_of_purch,
    distinct_customers,
    avg_purchase_per_customer_cnt,
    online_trans,
    conven_trans,
    super_trans,
    nectar_sales,
    non_nectar_sales  
FROM sales_brand_agg_table3
) AS source
ON target.sku_no = source.sku_no
AND target.date_ = source.date_
WHEN MATCHED THEN
    UPDATE SET
        target.total_quantity = source.total_quantity,
        target.freq_of_purch = source.freq_of_purch,
        target.distinct_customers = source.distinct_customers,
        target.avg_purchase_per_customer_cnt = source.avg_purchase_per_customer_cnt,
        target.online_trans = source.online_trans,
        target.conven_trans = source.conven_trans,
        target.super_trans = source.super_trans,
        target.nectar_sales = source.nectar_sales,
        target.non_nectar_sales = source.non_nectar_sales
WHEN NOT MATCHED THEN
    INSERT (
        sku_no,
        date_,
        total_quantity,
        freq_of_purch,
        distinct_customers,
        avg_purchase_per_customer_cnt,
        online_trans,
        conven_trans,
        super_trans,
        nectar_sales,
        non_nectar_sales
    )
    VALUES (
        source.sku_no,
        source.date_,
        source.total_quantity,
        source.freq_of_purch,
        source.distinct_customers,
        source.avg_purchase_per_customer_cnt,
        source.online_trans,
        source.conven_trans,
        source.super_trans,
        source.nectar_sales,
        source.non_nectar_sales
    );