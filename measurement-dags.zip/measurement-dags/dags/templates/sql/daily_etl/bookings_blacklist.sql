-- List of booking ids that needs to be excluded from unified_campaigns
-- TODO:: !important  - once booking linking is functional, we should look into removing this

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('bookings_blacklist') }} AS
SELECT
    column1 AS correlation_id,
    column2 AS booking_id,
    column3 AS reason_for_exclusion,
    column4 AS load_ts
FROM (VALUES
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '69304b8fbc8295fbebf8c317',
           'we have to exclude this booking id as it''s been merged into 697cb5625dc3bb4b7469a763 . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9)),
          (CAST('{{params.correlation_id}}' AS VARCHAR(36)), '6960cfcd86951c1f0b2be885',
           'we have to exclude this booking id as it''s been merged into 697cb5625dc3bb4b7469a763 . this needs to be done due to manual booking linking issue in Pollen platform.',
           current_timestamp::timestamp_ntz(9))
);

