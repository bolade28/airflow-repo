{#/*******************************************************************************************************************
TODO: work out logic to get start and end date for downstream once from weekly_dates.
* Objective:
    - This script is used to create time series date skeleton at weekly level between start and end date
    - Start Date would be the date, 3 years ago from today (lower bound set at 1st Jan 2022)
    - End Date would be the today's date
    - Both start and end dates would be shifted to previous monday (i.e., start of the respective week)

* Lineage:
    Upstream:
        - Nothing here as this is the first module of the baseline pipeline
    Downstream:
        - sales_data_transformation (sales_data_transformation_output.sql, campaign_selection_python.py)
        - 04_external_data (external_processed_data_output.sql
**********************************************************************************************************************/#}

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('weekly_start_dates_daily_etl') }}  COPY GRANTS AS
(
with date_range as (
    select
        date_trunc('week', cast('{{ params.start_date }}' as date)) as start_date
        , date_trunc('week', cast('{{ params.end_date }}' as date)) as end_date
)

-- Setting start date to a Monday, if it's not a Monday, move it to the next nearest Monday
, first_monday as (
    select
        case
            when dayofweek(start_date) = 2 then start_date
            else dateadd(day, (8 - dayofweek(start_date)) % 7, start_date)
        end as week_start_date
    from
        date_range
)

-- Listing numbers to add consecutive weeks
, week_numbers as (
    select row_number() over (order by NULL) - 1 as week_number
    from
        table(generator(rowcount => (1000)))
)

-- Creating consecutive weeks and filtering for required start and end date
, weekly_dates as (
    select dateadd(week, week_number, (select week_start_date from first_monday)) as week_start_dt
    from
        week_numbers
    where
        week_start_dt >= cast('{{ params.start_date }}' as date) and
        week_start_dt <= cast('{{ params.end_date }}' as date)
    order by week_start_dt desc limit {{ params.number_of_weeks }}
)
select * from weekly_dates order by week_start_dt
);