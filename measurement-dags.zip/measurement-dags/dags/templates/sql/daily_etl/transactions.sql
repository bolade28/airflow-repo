{#/******************************************************************************************************************

* Objective:
    - This script is used to create time series data of sales along with other features listed below at Item code level
      AND create feature metrics - total_sales_amt, avg_purchase_per_customer_cnt, online, super market,
      convenience sales percentage, pack size, price per point etc...

* Business Context:
    - Sales forms the main depENDent variable in our process to estimate baseline sales. However raw transaction data
      is too granular AND unprocessed for us to use directly
    - This script not only provides the sales in a processed manner, but also calculates other variablesFROM the
      transacation table which form features for the clustering model.
    - The output of this script basically forms a starting point for all the other scripts since our entire process
      is depENDent on sales.

* Lineage:
    Upstream:
        - 02_unified_product (unified_product.sql)
    Downstream:
        - sales_data_transformation (campaign_SELECTion_python.py)

* Confluence:
    https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/834210620/Sales+Data+Transformation


*******************************************************************************************************************/#}


-- Retrieve Date WHERE Sales Data Begins (FROM Sales_Data_Transformation_Output) AS Start Date, AND END date is today
alter session set statement_timeout_in_seconds = 43200;
CREATE OR REPLACE TRANSIENT TABLE {{ get_table('transactions') }} COPY GRANTS AS
WITH brand_SELECT_table1 AS (
    SELECT 
        item_cd,
        item_name,
        segment_name,
        sub_cat_name,
        cat_name,
        super_cat_name,
        item_weight_or_vol_uom_cd,
        unit_or_item_weight_or_vol_qty,
        item_total_weight_or_vol_qty,
        base_price_amt,
        std_item_wgt_or_vol_qty_uom_cd,
        std_item_total_wgt_or_vol_qty,
        unique_brand_name,
        raw_unique_brand_name,
        job_run_id,
        load_ts
    FROM {{ get_table('unified_products') }}
),

-- Aggregating Transaction Data AND calculating required output variables at Week, Super Category Brand, SKU level. Filtering Transaction data after aggregation to required period for safety.
-- Business Context - Applying CASE WHEN filters (using sales_origination_channel_cd) to identify Super Market/Convenience AND Online Sales (more info available on Alation pages - https://sainsburys.eu.alationcloud.com/app/table/136633/OVERview)
-- Code 21 refers to website, code 14 refers to store WHERE we filter for  Super Market/Convenience

-- Retrieve all the required week start dates till today to form Date Skeleton (To ensure same number of time series data points exist for each item_cd for modelling)
temp_date_dataset AS (
   SELECT week_start_dt AS week_start_date
   FROM {{ get_table('weekly_start_dates_daily_etl') }}
),

-- Skeleton to have all skus in historic AS well AS current data(to ensure that even if an item_cd does not have a transaction in current modelling period, 
-- it has an entry in the current period)

sales_brand_agg_table3 AS (
    SELECT DISTINCT
        ta.sku_no,
        ta.date_,
        ta.total_quantity,
        ta.freq_of_purch,
        ta.distinct_customers,
        ta.avg_purchase_per_customer_cnt,
        ta.online_trans,
        ta.conven_trans,
        ta.super_trans,
        ta.nectar_sales,
        ta.non_nectar_sales,
        mst.unique_brand_name AS unique_brand_name,
        mst.super_cat_name AS super_category_name,
        mst.item_name,
        mst.std_item_total_wgt_or_vol_qty AS sku_volume_std,
        mst.base_price_amt,
        coalesce(mst.unit_or_item_weight_or_vol_qty, 1) AS pack_size
   FROM {{ get_table('transactions_agg_intermediate') }} ta
    JOIN brand_select_table1 mst
    ON sku_no = item_cd
),
sales_brand_agg_table3_req AS (
    SELECT DISTINCT
            mst.unique_brand_name AS unique_brand_name,
            mst.super_cat_name AS super_category_name,
            ta.sku_no
    FROM {{ get_table('transactions_agg_intermediate') }} ta
    JOIN brand_select_table1 mst
    ON
    ta.sku_no = mst.item_cd
),

-- Cross Join with a Skeleton dataframe to create a dataset with equal number of time series data points for each item_cd. Impute the missing values appropriately. 
sales_weekly_brand_table3_agg AS (
    SELECT
        smatr.super_category_name,
        smatr.unique_brand_name,
        smatr.sku_no,
        tdd.week_start_date,
        coalesce(avg(smat.sku_volume_std), null) AS sku_volume_std,
        coalesce(avg(smat.pack_size), null) AS pack_size,
        coalesce(avg(smat.base_price_amt), null) AS base_price_amt,
        coalesce(sum(smat.avg_purchase_per_customer_cnt),0) AS avg_purchase_per_customer_cnt,
        coalesce(sum(smat.total_quantity), 0) AS total_item_qty,
        coalesce(sum(smat.freq_of_purch), 0) AS freq_of_purch,
        coalesce(sum(smat.distinct_customers), 0) AS distinct_customers,
        coalesce(sum(smat.online_trans), 0) AS online_trans,
        coalesce(sum(smat.conven_trans), 0) AS conven_trans,
        coalesce(sum(smat.super_trans), 0) AS super_trans,
        coalesce(sum(smat.nectar_sales),0) AS nectar_sales,
        coalesce(sum(smat.non_nectar_sales),0) AS non_nectar_sales
   FROM sales_brand_agg_table3_req AS smatr
    CROSS JOIN temp_date_dataset AS tdd
    LEFT JOIN sales_brand_agg_table3 AS smat
        on
            -- smatr.super_category_name = smat.super_category_name
            -- AND smatr.unique_brand_name = smat.unique_brand_name
            smatr.sku_no = smat.sku_no
            AND tdd.week_start_date <= smat.date_
            AND smat.date_ < dateadd(week, 1, tdd.week_start_date)
    GROUP BY
        tdd.week_start_date
        , smatr.super_category_name
        , smatr.unique_brand_name
        , smatr.sku_no
),

-- Imputation of missing values with the oldest then newest present value passed onto the missing datapoints
sales_weekly_brand_table4 AS (
    SELECT
        week_start_date,
        super_category_name,
        unique_brand_name,
        sku_no,
        nectar_sales,
        non_nectar_sales,
        total_item_qty,
        freq_of_purch,
        avg_purchase_per_customer_cnt,
        distinct_customers,
        online_trans,
        conven_trans,
        super_trans,
        coalesce(
            sku_volume_std, first_value(sku_volume_std ignore nulls)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date rows between current row AND unbounded following
                )
            , last_value(sku_volume_std ignore nulls)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date rows between unbounded preceding AND current row
                )
        ) AS sku_volume_std,
        coalesce(
            pack_size, FIRST_VALUE(pack_size IGNORE NULLS)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                )
            , last_value(pack_size ignore nulls)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                )
        ) AS pack_size,
        coalesce(
            base_price_amt, first_value(base_price_amt IGNORE NULLS)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
                )
            , last_value(base_price_amt IGNORE NULLS)
                OVER
                (
                    PARTITION BY super_category_name, unique_brand_name, sku_no
                    ORDER BY week_start_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                )
        ) AS base_price_amt,
    FROM 
        sales_weekly_brand_table3_agg
),

-- Imputing any negative values to 0 in CASE such values exist
sales_negatives_adjusted_table5 AS (
    SELECT
        week_start_date,
        super_category_name,
        unique_brand_name,
        sku_no,
        nectar_sales,
        non_nectar_sales,
        total_item_qty,
        freq_of_purch,
        avg_purchase_per_customer_cnt,
        distinct_customers,
        online_trans,
        conven_trans,
        super_trans,
        sku_volume_std,
        pack_size,
        base_price_amt,
        CASE
            WHEN nectar_sales < 0 THEN 0
            ELSE nectar_sales
        END AS nectar_sales_value,
        CASE
            WHEN non_nectar_sales < 0 THEN 0
            ELSE non_nectar_sales
        END AS non_nectar_sales_value,
        (nectar_sales_value + non_nectar_sales_value) AS sales_value,
        CASE
            WHEN total_item_qty < 0 THEN 0
            ELSE total_item_qty
        END AS item_qty,
        CASE
            WHEN online_trans < 0 then 0
            ELSE online_trans
        END AS online_sales,
        CASE
            WHEN super_trans < 0 then 0
            ELSE super_trans
        END AS super_sales,
        CASE
            WHEN conven_trans < 0 then 0
            ELSE conven_trans
        END AS conven_sales
    FROM 
        sales_weekly_brand_table4
),

-- Calculating Percentage of Online, Convenience AND Super Market Sales AND imputing extreme values to 0
sales_format_table6 AS (
    SELECT
        week_start_date,
        super_category_name,
        unique_brand_name,
        sku_no,
        nectar_sales,
        non_nectar_sales,
        total_item_qty,
        freq_of_purch,
        avg_purchase_per_customer_cnt,
        distinct_customers,
        online_trans,
        conven_trans,
        super_trans,
        sku_volume_std,
        pack_size,
        base_price_amt,
        nectar_sales_value,
        non_nectar_sales_value,
        sales_value,
        item_qty,
        online_sales,
        super_sales,
        conven_sales,
        total_sales_volume,
        perc_onl,
        perc_super,
        perc_conv,
        coalesce(sales_value / nullif(total_sales_volume, 0), 0) AS vpv
   FROM (
        SELECT
            week_start_date,
            super_category_name,
            unique_brand_name,
            sku_no,
            nectar_sales,
            non_nectar_sales,
            total_item_qty,
            freq_of_purch,
            avg_purchase_per_customer_cnt,
            distinct_customers,
            online_trans,
            conven_trans,
            super_trans,
            sku_volume_std,
            pack_size,
            base_price_amt,
            nectar_sales_value,
            non_nectar_sales_value,
            sales_value,
            item_qty,
            online_sales,
            super_sales,
            conven_sales,
            item_qty * sku_volume_std AS total_sales_volume,
            coalesce(online_sales / nullif(sales_value, 0), 0)
                AS perc_onl,  --percentage of online transactions out of total transactions
            coalesce(super_sales / nullif(sales_value, 0), 0)
                AS perc_super, --percentage of super market transactions out of total transactions
            coalesce(conven_sales / nullif(sales_value, 0), 0)
                AS perc_conv --percentage of convenience transactions out of total transactions
       FROM sales_negatives_adjusted_table5
    )
),


-- Selecting required columns for final output AND imputing WHEREver required
sales_data_transformation_output_pre AS (
    SELECT
        week_start_date AS week_start_dt,
        super_category_name,
        unique_brand_name AS unique_brand_name,
        sku_no AS item_cd,
        sales_value AS total_sales_amt,
        nectar_sales_value AS nectar_sales_amt,
        non_nectar_sales_value AS non_nectar_sales_amt,
        freq_of_purch AS frequency_of_purchase,
        distinct_customers AS distinct_customer_cnt,
        avg_purchase_per_customer_cnt,
        perc_onl AS online_sales_pct,
        perc_super AS supermarket_sales_pct,
        perc_conv AS convenience_sales_pct,
        coalesce(pack_size, 0) AS pack_size,
        coalesce(base_price_amt / pack_size, 0) AS price_per_point,
        coalesce(base_price_amt, 0) AS base_price_amt
   FROM sales_format_table6
),

-- merging sales for current week with unified product to get latest brand for skus with 0 sales in current week
sales_data_transformation_output AS (
    SELECT
        a.week_start_dt,
        a.item_cd,
        a.total_sales_amt,
        a.nectar_sales_amt,
        a.non_nectar_sales_amt,
        a.frequency_of_purchase,
        a.distinct_customer_cnt,
        a.avg_purchase_per_customer_cnt,
        a.online_sales_pct,
        a.supermarket_sales_pct,
        a.convenience_sales_pct,
        a.pack_size,
        a.price_per_point,
        a.base_price_amt,
        b.super_category_name,
        b.unique_brand_name
       FROM sales_data_transformation_output_pre AS a
        left join (
            SELECT DISTINCT
                item_cd,
                super_cat_name AS super_category_name,
                unique_brand_name AS unique_brand_name
           FROM brand_SELECT_table1
        ) AS b
        ON a.item_cd = b.item_cd
),

-- If its not incremental we don't update anything

data_to_appEND AS (
    SELECT DISTINCT *
   FROM sales_data_transformation_output
)
-- Creation of sales_data_transformation_output output table containing aggregated weekly sales data metrics. This data highlights key sales metrics, including online, convenience, AND supermarket sales percentages, average purchase per consumer, purchase frequency, etc.

-- Casting all columns to the datatypes AND formats of the already existing table's columns to prevent errors
SELECT DISTINCT
    CAST(WEEK_START_DT AS DATE) AS WEEK_START_DT,
    CAST(COALESCE(SUPER_CATEGORY_NAME,'') AS VARCHAR(300)) AS SUPER_CATEGORY_NAME,
    CAST(COALESCE(UNIQUE_BRAND_NAME, '') AS VARCHAR(384)) AS UNIQUE_BRAND_NAME,
    CAST(ITEM_CD AS NUMBER(38, 0)) AS ITEM_CD,
    CAST(TOTAL_SALES_AMT AS NUMBER(38, 4)) AS TOTAL_SALES_AMT,
    CAST(NECTAR_SALES_AMT AS NUMBER(38, 4)) AS NECTAR_SALES_AMT,
    CAST(NON_NECTAR_SALES_AMT AS NUMBER(38, 4)) AS NON_NECTAR_SALES_AMT,
    CAST(FREQUENCY_OF_PURCHASE AS NUMBER(30, 0)) AS FREQUENCY_OF_PURCHASE,
    CAST(DISTINCT_CUSTOMER_CNT AS NUMBER(30, 0)) AS DISTINCT_CUSTOMER_CNT,
    CAST(AVG_PURCHASE_PER_CUSTOMER_CNT AS NUMBER(36, 6)) AS AVG_PURCHASE_PER_CUSTOMER_CNT,
    CAST(ONLINE_SALES_PCT AS NUMBER(38, 10)) AS ONLINE_SALES_PCT,
    CAST(SUPERMARKET_SALES_PCT AS NUMBER(38, 10)) AS SUPERMARKET_SALES_PCT,
    CAST(CONVENIENCE_SALES_PCT AS NUMBER(38, 10)) AS CONVENIENCE_SALES_PCT,
    CAST(PACK_SIZE AS NUMBER(38, 12)) AS PACK_SIZE,
    CAST(PRICE_PER_POINT AS NUMBER(38, 12)) AS PRICE_PER_POINT,
    CAST(BASE_PRICE_AMT AS NUMBER(38, 12)) AS BASE_PRICE_AMT,

FROM data_to_append
