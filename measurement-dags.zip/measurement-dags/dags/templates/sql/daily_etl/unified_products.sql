
CREATE OR REPLACE TRANSIENT TABLE {{ get_table('unified_products') }} COPY GRANTS AS
(
    -- Reading DIM_RETAILER_ITEM and filtering for SAINSBURYS
    with filtered_dim_retailer_item as (
        select * from {{ get_table('dim_retailer_item') }}
        where retailer_cd = 'SAINSBURYS'
    )

    -- Reading DIM_ITEM and applying required filters for sainsburys records
    , dim_item_filtered as (
        select *
        from {{ get_table('dim_item') }} AS di
        where
            -- Filtering to get DIM_ITEM info for Sainsburys
            operating_company_cd = 1
            and op_co_item_cd <> -2
    )


    -- Retrieving Brand from EAN_BR. In case of multiple entries, we sort by below columns and choose the first one
    , ean_br_data as (
        select distinct
            item_nk1
            , brand_name
            , brand_owner_name
        from (
            select
                item_nk1,
                brand_name,
                brand_owner_name,
                row_number() over (partition by item_nk1 order by load_ts desc,valid_to_dt desc, record_deleted_flag, primary_ean_flag desc) as rn
            from {{ get_table('ean_br') }} where brand_name is not null
        )
        where rn = 1
    )

    --Filtering required columns
    ,  unified_product_raw_pre_ean as (
        select
            dif.item_cd
            , dif.item_name
            , dif.segment_name
            , dif.sub_cat_name
            , dif.cat_name
            , dif.item_weight_or_vol_uom_cd
            , dif.unit_or_item_weight_or_vol_qty
            , dif.item_total_weight_or_vol_qty
            , fdri.base_price_amt
            , dif.std_item_wgt_or_vol_qty_uom_cd
            , dif.std_item_total_wgt_or_vol_qty
            , upper(trim(dif.super_cat_name)) as super_cat_name
        from dim_item_filtered as dif
        left join filtered_dim_retailer_item AS fdri
            on dif.item_cd = fdri.item_cd

    )

    -- Creating Unique Brand Name with Pipe operator as a separator
    ,  unified_product_raw as (
        select
            a.*
            ,upper(concat(TRIM(b.brand_name), ' | ', TRIM(b.brand_owner_name))) as unique_brand_name
        from unified_product_raw_pre_ean as a
        left join ean_br_data as b
            on a.item_cd = b.item_nk1
    )

    -- Imputing values which are not present. Imputation by 1 since quantity of 0 leads to divide by zero error.
    , unified_product_wo_base_price as (
        select
            item_cd
            , item_name
            , segment_name
            , sub_cat_name
            , cat_name
            , super_cat_name
            , item_weight_or_vol_uom_cd
            , coalesce(unit_or_item_weight_or_vol_qty,1) as unit_or_item_weight_or_vol_qty
            , coalesce(item_total_weight_or_vol_qty,1) as item_total_weight_or_vol_qty
            , std_item_wgt_or_vol_qty_uom_cd
            , coalesce(std_item_total_wgt_or_vol_qty,1) as std_item_total_wgt_or_vol_qty
            , unique_brand_name
        from unified_product_raw

    )

    -- Retrieving Price from Supermarket. Business Context - Aligned with Analytics team to use Super Market price for Modelling
    ,  super_market_price as (
        select *
        from (
            select distinct
                item_cd,
                store_cd,
                base_unit_price_amt
            from {{ get_table('fact_sale_transaction_item') }}
        ) as a
        inner join
        (
            select * from {{ get_table('dim_store_org_hierarchy') }}
        ) as b
        on a.store_cd = b.store_cd
        where upper(b.store_type) = 'SUPERMARKET'
    )

    -- In case of multiple values max price is chosen
    , max_price_item_cd as (
        select
            item_cd ,
            max(base_unit_price_amt) as base_price_amt
        from super_market_price
        group by item_cd
    )

    -- In case of missing values impute price with 0
    , unified_product_raw as (
        select
            upwbp.*,
            coalesce(mpic.base_price_amt,0) as base_price_amt
        from unified_product_wo_base_price as upwbp
        left join max_price_item_cd as mpic
        on upwbp.item_cd = mpic.item_cd
    )

    -- Filter for required columns. In case Unique Brand Name has any special characters we remove them from our process
    , unified_product as (
    select distinct
        ITEM_CD
        , ITEM_NAME
        , SEGMENT_NAME
        , SUB_CAT_NAME
        , CAT_NAME
        , SUPER_CAT_NAME
        , ITEM_WEIGHT_OR_VOL_UOM_CD
        , UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY
        , ITEM_TOTAL_WEIGHT_OR_VOL_QTY
        , BASE_PRICE_AMT
        , STD_ITEM_WGT_OR_VOL_QTY_UOM_CD
        , STD_ITEM_TOTAL_WGT_OR_VOL_QTY
        , UNIQUE_BRAND_NAME as RAW_UNIQUE_BRAND_NAME
        , REGEXP_REPLACE(UNIQUE_BRAND_NAME, '[^\x00-\x7F]', '') as UNIQUE_BRAND_NAME
    from unified_product_raw
    )

    -- Creation of unified_product output table containing unified view of product data, including item details, brand & super category information, pack size and price to act as source for further processing scripts.
    -- Casting all columns to the datatypes and formats of the already existing table's columns to prevent errors
    select
        CAST(ITEM_CD AS NUMBER(38,0)) AS ITEM_CD
        , CAST(ITEM_NAME AS VARCHAR(100)) AS ITEM_NAME
        , CAST(SEGMENT_NAME AS VARCHAR(100)) AS SEGMENT_NAME
        , CAST(SUB_CAT_NAME AS VARCHAR(100)) AS SUB_CAT_NAME
        , CAST(CAT_NAME AS VARCHAR(100)) AS CAT_NAME
        , CAST(SUPER_CAT_NAME AS VARCHAR(300)) AS SUPER_CAT_NAME
        , CAST(ITEM_WEIGHT_OR_VOL_UOM_CD AS VARCHAR(128)) AS ITEM_WEIGHT_OR_VOL_UOM_CD
        , CAST(UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY AS NUMBER(18,4)) AS UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY
        , CAST(ITEM_TOTAL_WEIGHT_OR_VOL_QTY AS NUMBER(18,4)) AS ITEM_TOTAL_WEIGHT_OR_VOL_QTY
        , CAST(BASE_PRICE_AMT AS NUMBER(18,4)) AS BASE_PRICE_AMT
        , CAST(STD_ITEM_WGT_OR_VOL_QTY_UOM_CD AS VARCHAR(128)) AS STD_ITEM_WGT_OR_VOL_QTY_UOM_CD
        , CAST(STD_ITEM_TOTAL_WGT_OR_VOL_QTY AS NUMBER(18,4)) AS STD_ITEM_TOTAL_WGT_OR_VOL_QTY
        , COALESCE(CAST(UNIQUE_BRAND_NAME AS VARCHAR(300)),'') AS UNIQUE_BRAND_NAME
        , COALESCE(CAST(RAW_UNIQUE_BRAND_NAME AS VARCHAR(300)),'') AS RAW_UNIQUE_BRAND_NAME
        , CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS JOB_RUN_ID
        , CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ) AS LOAD_TS
    from unified_product
);
