MERGE INTO {{ get_table('customer_by_location') }} AS target
USING
(
    SELECT 
        store_cd,
        date_,
        distinct_customers
    FROM 
    {{ get_table('customer_by_location_int') }}
) AS source
ON target.store_cd = source.store_cd
AND target.date_ = source.date_
WHEN MATCHED THEN
    UPDATE SET
        target.distinct_customers = source.distinct_customers
WHEN NOT MATCHED THEN
    INSERT (store_cd, date_, distinct_customers)
    VALUES (source.store_cd, source.date_, source.distinct_customers);