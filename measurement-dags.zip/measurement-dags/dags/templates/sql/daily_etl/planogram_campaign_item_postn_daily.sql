MERGE INTO {{ get_table('planogram_campaigns') }} AS target
USING {{ get_table('planogram_campaigns_int') }} AS source
ON target.hash_key = source.hash_key
WHEN MATCHED THEN
    UPDATE SET
        target.date_dt = source.date_dt,
        target.week_start_dt = source.week_start_dt,
        target.store_cd = source.store_cd,
        target.section_id = source.section_id,
        target.item_cd = source.item_cd,
        target.planogram_id = source.planogram_id,
        target.planogram_position_id = source.planogram_position_id,
        target.store_item_position_start_dt = source.store_item_position_start_dt,
        target.store_item_position_end_dt = source.store_item_position_end_dt
WHEN NOT MATCHED THEN
    INSERT (
        date_dt,
        week_start_dt,
        store_cd,
        section_id,
        item_cd,
        planogram_id,
        planogram_position_id,
        store_item_position_start_dt,
        store_item_position_end_dt,
        hash_key
    )
    VALUES (
        source.date_dt,
        source.week_start_dt,
        source.store_cd,
        source.section_id,
        source.item_cd,
        source.planogram_id,
        source.planogram_position_id,
        source.store_item_position_start_dt,
        source.store_item_position_end_dt,
        source.hash_key
    );