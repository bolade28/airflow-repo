CREATE OR REPLACE TRANSIENT TABLE {{ get_table('planogram_campaigns_int') }}
(
    date_dt,
    week_start_dt,
    store_cd,
    section_id,
    item_cd,
    planogram_id,
    planogram_position_id,
    store_item_position_start_dt,
    store_item_position_end_dt,
    hash_key
)   AS 
(
with date_ref AS (
    SELECT
        date_dt
        , date_trunc('week', date_dt) AS week_start_dt
    FROM {{ get_table('date_dimension')}}
    where
        date_dt <= current_date()
        and date_dt >= dateadd(day, -7, (SELECT COALESCE(MAX(date_dt), '2019-01-08') FROM {{ get_table('planogram_campaigns') }}))
)
, campaign_sku_items AS (
    SELECT distinct booking_item_cd_list
    FROM {{ get_table('campaign_booking_media_channel') }}
)
, flattened_items AS (
    SELECT f.value:skuId::VARCHAR AS item_cd
    FROM campaign_sku_items AS c
    cross join lateral flatten(input => c.booking_item_cd_list) AS f
    where c.booking_item_cd_list is not null
    and json_extract_path_text(f.value,'skuId') is not null
)
, candidate_items AS (
    SELECT TRIM(item_cd) AS item_cd
    FROM flattened_items
    where item_cd is not null
)
, valid_items AS (
    SELECT c.item_cd
    FROM candidate_items AS c
    inner join {{ get_table('dim_item') }} AS i
        on c.item_cd::VARCHAR(50) = i.item_cd::VARCHAR(50)
    qualify row_number() over (partition by i.item_cd order by i.item_cd asc) = 1
)
, item_union AS (
    SELECT
        item_cd::VARCHAR(50) AS item_cd,
        'NEW_CAMPAIGN' AS source,
        1 AS source_flag
    FROM valid_items
    union all
    SELECT
        item_cd::VARCHAR(50) AS item_cd,
        source,
        source_flag
    FROM {{ get_table('historic_campaign_sku_scope') }} 
)
, sku_scope AS (
    SELECT
        item_cd
        , source
    FROM item_union
    qualify row_number() over (partition by item_cd order by source_flag asc) = 1
)
, planogram_data AS (
    SELECT
        store_cd,
        planogram_id,
        section_id,
        item_cd::VARCHAR(50) AS item_cd,
        planogram_position_id,
        store_item_position_start_dt,
        store_item_position_end_dt
    FROM {{ get_table('flf_str_plngrm_item_postn') }} 
    where
        store_item_position_start_dt <= current_date()
        AND (
            store_item_position_end_dt IS NULL 
            OR store_item_position_end_dt >= dateadd(day, -7, (SELECT COALESCE(MAX(date_dt), '2019-01-08') FROM {{ get_table('planogram_campaigns') }}))
    )
)

SELECT
    date_ref.date_dt,
    date_ref.week_start_dt,
    plngrm.store_cd,
    plngrm.section_id,
    plngrm.item_cd,
    plngrm.planogram_id,
    plngrm.planogram_position_id,
    plngrm.store_item_position_start_dt,
    plngrm.store_item_position_end_dt,
    MD5 (date_ref.date_dt || '-' || plngrm.store_cd || '-' || plngrm.section_id || '-' ||plngrm.planogram_id ||'-' ||plngrm.planogram_position_id || '-' || plngrm.item_cd) AS hash_key
FROM planogram_data AS plngrm
inner join date_ref
    on
        (
            date_ref.date_dt between plngrm.store_item_position_start_dt and COALESCE(
                plngrm.store_item_position_end_dt, current_date()
            )
        )
inner join sku_scope
    on plngrm.item_cd = sku_scope.item_cd
    );