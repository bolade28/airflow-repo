CREATE OR REPLACE TRANSIENT TABLE {{ get_table('customer_by_location_int') }} COPY GRANTS AS
(
WITH
transaction_basket AS
    (
    select
        sales_origination_channel_cd,
        transaction_id,
        transaction_dt,
        nectar_card_num_hash
    from {{ get_table('fact_sale_transaction_basket') }}
    JOIN (
        SELECT MIN(transaction_dt) AS min_transaction_dt
        from (
                SELECT 
                    COALESCE(MAX(DATE_),cast('{{params.start_date}}' as date)) AS max_date 
                FROM {{ get_table('customer_by_location') }}
            ) mcbl 
    JOIN {{ get_table('fact_sale_transaction_basket') }} FSTB
    ON to_date(ASPIRE_ARRIVAL_ts) between mcbl.max_date and cast('{{params.end_date}}' as date)
    ) INCR
    ON transaction_dt between min_transaction_dt and cast('{{params.end_date}}' as date)
    and sales_origination_channel_cd IN (
        select upper(value)::string as codes
        from lateral flatten(input => parse_json('{{ params.transaction_codes | tojson }}'))
    )
),
transaction_item AS
(
    select
        transaction_id,
        transaction_dt,
        net_retail_sales_amt,
        pre_promotional_sale_amt,
        item_cd,
        store_cd,
        uom_cd,
        item_qty,
        item_type_sale_or_return,
        base_unit_price_amt
    from {{ get_table('fact_sale_transaction_item') }}
    join (
        SELECT MIN(transaction_dt) AS MIN_TRANSACTION_DT
        from (
                SELECT 
                    COALESCE(MAX(DATE_),cast('{{params.start_date}}' as date)) AS max_date 
                FROM {{ get_table('customer_by_location') }}
            ) mcbl 
        JOIN {{ get_table('fact_sale_transaction_item') }} FSTI
        ON to_date(ASPIRE_ARRIVAL_ts) between mcbl.max_date and cast('{{params.end_date}}' as date)
    ) INCR
    ON transaction_dt between min_transaction_dt and cast('{{params.end_date}}' as date)
)
select
    fsti.store_cd,
    date_trunc('WEEK', fsti.transaction_dt) as date_,
    count(distinct tb.nectar_card_num_hash) as distinct_customers
from transaction_item AS fsti
inner join transaction_basket AS tb
on fsti.transaction_id = tb.transaction_id
group by fsti.store_cd, date_
);