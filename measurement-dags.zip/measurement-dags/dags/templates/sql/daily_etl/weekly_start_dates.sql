{#/*******************************************************************************************************************
TODO: work out logic to get start and end date for downstream once from weekly_dates.
* Objective:
    - This script is used to create time series date skeleton at weekly level between start and end date
    - Start Date would be the date, 3 years ago from today (lower bound set at 1st Jan 2022)
    - End Date would be the today's date
    - Both start and end dates would be shifted to previous monday (i.e., start of the respective week)

* Lineage:
    Upstream:
        - Nothing here as this is the first module of the baseline pipeline
    Downstream:
        - sales_data_transformation (sales_data_transformation_output.sql, campaign_selection_python.py)
        - 04_external_data (external_processed_data_output.sql
**********************************************************************************************************************/#}

CREATE OR REPLACE TRANSIENT TABLE {{ get_table('weekly_start_dates') }} COPY GRANTS AS
(
    -- Calculating start and end date for processing period, to generate weekly_dates view
    -- Retrieve and set Start Date that is 2 Years Ago from Today and end date would be today's date but shifted to previous monday

    -- End Date would be today's date but shifted to previous monday (i.e., start of the respective week)
    WITH
    date_anchors AS (
        SELECT date_trunc('week', cast('{{ params.run_date }}' as date)) AS current_week_monday
    ),
    generator_nums AS (
        SELECT seq1() AS num
          FROM TABLE(GENERATOR(ROWCOUNT => {{ params.number_of_weeks }}))
    ),
    -- Create a series of dates starting from the current week's monday and going back 104 weeks aiming to cover all previous mondays
    -- Example:  The campaigns that start on a Wednesday will be considered to have started on the Monday of the same week.
    monday_series AS (
        SELECT DATEADD(week, -gen.num, (SELECT current_week_monday FROM date_anchors)) AS monday_date
          FROM generator_nums AS gen
         -- ensure campaign start dates are never too far in the past
         WHERE monday_date >= to_date('2022-01-03')
    )

  SELECT monday_date AS WEEK_START_DT FROM monday_series
  ORDER BY monday_date

);
