/*
Builds the legacy campaign performance dataset populated in the daily ETL DAG.

This template:
- Aggregates campaign performance metrics for instore, coupon-at-till, ecoupon, and DTP (META) campaigns.
- Maps campaign SKUs to unified product hierarchy attributes for reporting.
- Adds campaign dates, media cost, and duplicate-row flags for safe downstream aggregation.
- Unions all campaign sources into measurement_legacy_campaign_performance with metadata.

Note:
- This data is calculated for the During period (timeperiod = 2)
- This data is calculated on the Brand level (product = 'brand') to align with the UCM methodology

Output table:
- {{ get_table('measurement_legacy_campaign_performance') }}
*/

CREATE OR REPLACE TEMP TABLE {{ get_table('instore_performance_temp') }} AS
WITH
    -- Aggregate Instore performance data from media level to campaign level.
    instore_performance_data_campaign_level AS (
        SELECT
            master_campaign_id AS campaign_id,
            SUM(uplift) AS uplift,
            SUM(test) AS test,
            SUM(control) AS control
        FROM {{ get_table('instore_dashboard') }}
        WHERE
            LOWER(product) = '{{ params.product_type }}'
            AND timeperiod = '{{ params.time_period }}' -- filter for the during period
            AND LOWER(media_type) = 'total'
            AND LOWER(metric) = 'spend'
            AND uplift IS NOT NULL
        GROUP BY master_campaign_id
    ),
    -- Retrieve distinct SKUs linked to each instore campaign.
    campaign_skus AS (
        SELECT DISTINCT
            inpdcl.campaign_id,
            pdl.sku_no
        FROM instore_performance_data_campaign_level AS inpdcl
        INNER JOIN {{ get_table('ie_product') }} AS iep
            ON inpdcl.campaign_id = iep.master_campaign_id
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON iep.product_key = pdl.product_key
        WHERE LOWER(iep.product_name) = '{{ params.product_type }}'
    ),
    -- Map campaign SKUs to unified product attributes used for reporting,
    -- ensuring we can match the data to the UCM
    all_brands AS (
        SELECT DISTINCT
            cs.campaign_id,
            up.super_cat_name,
            up.unique_brand_name,
            up.sub_cat_name
        FROM campaign_skus AS cs
        INNER JOIN {{ get_table('unified_products') }} AS up
            ON cs.sku_no = up.item_cd
        WHERE up.unique_brand_name != ''
    ),
    -- Get list of sub_categories and unique_brands per super_category
    campaign_brand_names AS (
        SELECT
            campaign_id,
            super_cat_name AS super_category_name,
            COUNT(DISTINCT sub_cat_name) AS num_unique_subcats,
            COUNT(DISTINCT unique_brand_name) AS num_unique_brands,
            LISTAGG(DISTINCT sub_cat_name, ', ') WITHIN GROUP (ORDER BY sub_cat_name) AS sub_category_name_list,
            LISTAGG(DISTINCT unique_brand_name, ', ') WITHIN GROUP (ORDER BY unique_brand_name) AS unique_brand_name_list
        FROM all_brands AS ab
        GROUP BY
            campaign_id,
            super_cat_name
    )
-- Combine campaign metrics, product hierarchy and campaign dates.
SELECT
    ipdcl.campaign_id,
    iec.start_date AS campaign_start_date,
    iec.end_date AS campaign_end_date,
    cbn.super_category_name,
    cbn.sub_category_name_list,
    cbn.unique_brand_name_list,
    cbn.num_unique_subcats,
    cbn.num_unique_brands,
    NULL AS exposed, -- exposed metric not currently available for instore finding a new source in progress :D
    ipdcl.uplift,
    ipdcl.test,
    ipdcl.control,
    iec.media_cost,
    'instore' AS campaign_source
FROM instore_performance_data_campaign_level AS ipdcl
INNER JOIN campaign_brand_names AS cbn
    ON ipdcl.campaign_id = cbn.campaign_id
INNER JOIN {{ get_table('ie_campaign_filt') }} AS iec
    ON iec.master_campaign_id = ipdcl.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('cat_performance_temp') }} AS
WITH

    -- Coupon at till campaign media data.
    -- The data is should already be aggregated at the campaign level but just in case we have multiple rows per campaign, we take the max value of total cost to avoid double counting.
    cat_media_cost AS (
        SELECT
            campaign_id,
            MAX(total_cost) AS media_cost
        FROM {{ get_table('cat_media_costs') }}
        WHERE analysis_level = 2 -- This is a filter for the aggregated values at the campaign level, as opposed to the coupon level which is analysis_level 1
        GROUP BY campaign_id
    ),
    -- Aggregate CAT dashboard data from coupon level to campaign level.
    -- The data is currently partitioned per coupon per cycle
    cat_performance_data_campaign_level AS (
        SELECT
            cd.campaign_id,
            SUM(cd.exposed) AS exposed,
            COALESCE(
                NULLIF(MAX(cmc.media_cost), 0), -- if the value is 0 use the fallback
                SUM(total_cost)
            ) AS media_cost,
            SUM(cd.uplift) AS uplift,
            SUM(cd.test) AS test,
            SUM(cd.control) AS control
        FROM {{ get_table('cat_dashboard') }} cd
        LEFT JOIN cat_media_cost AS cmc
            ON cd.campaign_id = cmc.campaign_id
        WHERE
            cd.uplift IS NOT NULL
            AND cd.brand_name IS NOT NULL
            AND LOWER(cd.brand_name) != 'unknown'
        GROUP BY cd.campaign_id
    ),
    -- Retrieve distinct SKUs linked to each coupon-at-till campaign.
    -- We persist coupon key as well to get the campaign dates later
    campaign_skus AS (
        SELECT DISTINCT
            pd.campaign_id,
            ctp.coupon_key,
            pdl.sku_no
        FROM cat_performance_data_campaign_level AS pd
        INNER JOIN {{ get_table('cell') }} AS c
            ON pd.campaign_id = c.campaign_id
        INNER JOIN {{ get_table('coupon_cell') }} AS cc
            ON c.cell_key = cc.cell_key
        INNER JOIN {{ get_table('coupon_to_product') }} AS ctp
            ON cc.coupon_key = ctp.coupon_key
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON ctp.product_key = pdl.product_key
        WHERE ctp.correct_offer = 'Y'
          AND ctp.correct_brand = 'Y'
    ),
    -- Map campaign SKUs to unified product attributes used for reporting,
    -- ensuring we can match the data to the UCM
    all_brands AS (
        SELECT DISTINCT
            cs.campaign_id,
            up.super_cat_name,
            up.unique_brand_name,
            up.sub_cat_name
        FROM campaign_skus AS cs
        INNER JOIN {{ get_table('unified_products') }} AS up
            ON cs.sku_no = up.item_cd
        WHERE up.unique_brand_name != ''
    ),
    -- Get list of sub_categories and unique_brands per super_category
    campaign_brand_names AS (
        SELECT
            campaign_id,
            super_cat_name AS super_category_name,
            COUNT(DISTINCT sub_cat_name) AS num_unique_subcats,
            COUNT(DISTINCT unique_brand_name) AS num_unique_brands,
            LISTAGG(DISTINCT sub_cat_name, ', ') WITHIN GROUP (ORDER BY sub_cat_name) AS sub_category_name_list,
            LISTAGG(DISTINCT unique_brand_name, ', ') WITHIN GROUP (ORDER BY unique_brand_name) AS unique_brand_name_list
        FROM all_brands AS ab
        GROUP BY
            campaign_id,
            super_cat_name
    ),
    -- Get campaign start and end dates for coupon-at-till campaigns.
    cat_campaign_dates AS (
        SELECT
            coupon_key,
            MIN(start_date) AS campaign_start_date,
            MAX(expiry_date) AS campaign_end_date
        FROM {{ get_table('coupon') }}
        WHERE expiry_date IS NOT NULL
        GROUP BY coupon_key
    ),
    cat_campaign_dates_filtered AS (
        SELECT DISTINCT
            ck.campaign_id,
            MIN(cat_dates.campaign_start_date) AS campaign_start_date,
            MAX(cat_dates.campaign_end_date) AS campaign_end_date
        FROM cat_campaign_dates AS cat_dates
        INNER JOIN campaign_skus AS ck
            ON cat_dates.coupon_key = ck.coupon_key
       GROUP BY ck.campaign_id
    )
-- Combine campaign metrics, product hierarchy and campaign dates.
SELECT
    cpd.campaign_id,
    cpdtf.campaign_start_date,
    cpdtf.campaign_end_date,
    cbn.super_category_name,
    cbn.sub_category_name_list,
    cbn.unique_brand_name_list,
    cbn.num_unique_subcats,
    cbn.num_unique_brands,
    cpd.exposed,
    cpd.uplift,
    cpd.test,
    cpd.control,
    cpd.media_cost,
    'coupon-at-till' AS campaign_source
FROM cat_performance_data_campaign_level AS cpd
INNER JOIN campaign_brand_names AS cbn
    ON cpd.campaign_id = cbn.campaign_id
INNER JOIN cat_campaign_dates_filtered AS cpdtf
    ON cpd.campaign_id = cpdtf.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('ecoupon_performance_temp') }} AS
WITH
    -- Get the total cost which is exposed_cost + redemption_cost this is an estimate so it's not reliable,
    -- it's only used to backfill any missing values that aren't present in ec_dash_metrics_3
    ecoupon_exposed_redemptions AS (
        SELECT
            campaign_id,
            sum(case when metric = 'EXPOSED' then test else 0 end) as exposed,
            sum(case when metric = 'EXPOSED' then test else 0 end) * '{{ params.exposed_cost_estimate }}' as exposed_cost,
            sum(case when metric = 'REDEMPTIONS' then test else 0 end) as redemptions,
            sum(case when metric = 'REDEMPTION COST' then test else 0 end) as redemptions_cost
        from {{ get_table('ecoupon_results_table') }}
            where timeperiod = '{{ params.time_period }}' -- during period
            AND product_no = 1 -- the costs are created on the offer level as that's what the campaign is targeting so we need to filter on product_no 1
        group by 1
    ),
    -- Aggregate ecoupon dashboard data from coupon level to campaign level and join with cost data
    -- The data is currently partitioned per coupon per cycle per offer, brand, aisle
    ecoupon_performance_data_campaign_level AS (
        SELECT
            ee.campaign_id,
            SUM(emc.tot_exposed) AS exposed,
            COALESCE(
                SUM(emc.total_cost),
                SUM(eer.exposed_cost) + SUM(eer.redemptions_cost)
            ) AS media_cost,
            SUM(ee.uplift) AS uplift,
            SUM(ee.test) AS test,
            SUM(ee.control) AS control
        FROM {{ get_table('ecoupon_results_table') }} AS ee
        INNER JOIN {{ get_table('ecoupon_media_costs') }} AS emc
            ON ee.campaign_id = emc.campaign_id
        LEFT JOIN ecoupon_exposed_redemptions AS eer
            ON ee.campaign_id = eer.campaign_id
        WHERE ee.timeperiod = '{{ params.time_period }}' -- filter for the during period
            AND ee.product_no = '{{ params.product_type_no }}' -- filter for brand skus
            AND LOWER(ee.metric) = 'spend' -- get the spend of the campaigns
            AND ee.uplift IS NOT NULL
        GROUP BY ee.campaign_id
    ),

    -- Retrieve distinct SKUs linked to each ecoupon campaign.
    campaign_skus AS (
        SELECT DISTINCT
            epd.campaign_id,
            pdl.sku_no
        FROM ecoupon_performance_data_campaign_level AS epd
        INNER JOIN {{ get_table('oc_products') }} AS ocp
            ON epd.campaign_id = ocp.campaign_id
        INNER JOIN {{ get_table('product_dim_latest') }} AS pdl
            ON ocp.product_key = pdl.product_key
        WHERE ocp.product_no = '{{ params.product_type_no }}' -- filter for brand skus
    ),
    -- Map campaign SKUs to unified product attributes used for reporting,
    -- ensuring we can match the data to the UCM
    all_brands AS (
        SELECT DISTINCT
            cs.campaign_id,
            up.super_cat_name,
            up.unique_brand_name,
            up.sub_cat_name
        FROM campaign_skus AS cs
        INNER JOIN {{ get_table('unified_products') }} AS up
            ON cs.sku_no = up.item_cd
        WHERE up.unique_brand_name != ''
    ),
    -- Get list of sub_categories and unique_brands per super_category
    campaign_brand_names AS (
        SELECT
            campaign_id,
            super_cat_name AS super_category_name,
            COUNT(DISTINCT sub_cat_name) AS num_unique_subcats,
            COUNT(DISTINCT unique_brand_name) AS num_unique_brands,
            LISTAGG(DISTINCT sub_cat_name, ', ') WITHIN GROUP (ORDER BY sub_cat_name) AS sub_category_name_list,
            LISTAGG(DISTINCT unique_brand_name, ', ') WITHIN GROUP (ORDER BY unique_brand_name) AS unique_brand_name_list
        FROM all_brands AS ab
        GROUP BY
            campaign_id,
            super_cat_name
    ),
    campaign_dates AS (
        SELECT
            campaign_id,
            MIN(start_date) AS campaign_start_date,
            MAX(expiry_date) AS campaign_end_date
        FROM {{ get_table('oc_campaign') }}
        WHERE start_date IS NOT NULL
            AND expiry_date IS NOT NULL
        GROUP BY campaign_id
    )
-- Combine campaign metrics, product hierarchy and campaign dates.
SELECT
    epdcl.campaign_id,
    cd.campaign_start_date,
    cd.campaign_end_date,
    cbn.super_category_name,
    cbn.sub_category_name_list,
    cbn.unique_brand_name_list,
    cbn.num_unique_subcats,
    cbn.num_unique_brands,
    epdcl.exposed,
    epdcl.uplift,
    epdcl.test,
    epdcl.control,
    epdcl.media_cost,
    'ecoupon' AS campaign_source
FROM ecoupon_performance_data_campaign_level AS epdcl
INNER JOIN campaign_brand_names AS cbn
    ON epdcl.campaign_id = cbn.campaign_id
INNER JOIN campaign_dates AS cd
    ON cd.campaign_id = epdcl.campaign_id;


CREATE OR REPLACE TEMP TABLE {{ get_table('dtp_performance_temp') }} AS
WITH
    -- Aggregate DTP data from weekly level to campaign level.
    dtp_performance_data_campaign_level AS (
        SELECT
            campaign_id,
            SUM(uplift) AS uplift,
            SUM(total_exposed_spend) AS test,
            SUM(total_control_spend) AS control
        FROM {{ get_table('dtp_dashboard') }}
        WHERE
            timeperiod = '{{ params.time_period }}' -- filter for the during period
            AND LOWER(product) = '{{ params.product_type }}'
            AND uplift IS NOT NULL
        GROUP BY campaign_id
    ),
    -- Retrieve distinct SKUs linked to each DTP campaign.
    campaign_skus AS (
        SELECT DISTINCT
            dpdcl.campaign_id,
            pd.sku_no
        FROM dtp_performance_data_campaign_level AS dpdcl
        INNER JOIN {{ get_table('de_product') }} AS dp
            ON dpdcl.campaign_id = dp.master_campaign_id
       -- product_dim is a tactical source so this may need to be replaced in the future, as of now I'm using to map product keys to skus for the DTP (Meta) campaigns,
       -- This source is also being used for the Analytics team
        INNER JOIN {{ get_table('product_dim') }} AS pd
            ON dp.product_key = pd.product_key
        WHERE LOWER(dp.product_name) = '{{ params.product_type }}'
    ),
    -- Map campaign SKUs to unified product attributes used for reporting,
    -- ensuring we can match the data to the UCM
    all_brands AS (
        SELECT DISTINCT
            cs.campaign_id,
            up.super_cat_name,
            up.unique_brand_name,
            up.sub_cat_name
        FROM campaign_skus AS cs
        INNER JOIN {{ get_table('unified_products') }} AS up
            ON cs.sku_no = up.item_cd
        WHERE up.unique_brand_name != ''
    ),
    -- Get list of sub_categories and unique_brands per super_category
    campaign_brand_names AS (
        SELECT
            campaign_id,
            super_cat_name AS super_category_name,
            COUNT(DISTINCT sub_cat_name) AS num_unique_subcats,
            COUNT(DISTINCT unique_brand_name) AS num_unique_brands,
            LISTAGG(DISTINCT sub_cat_name, ', ') WITHIN GROUP (ORDER BY sub_cat_name) AS sub_category_name_list,
            LISTAGG(DISTINCT unique_brand_name, ', ') WITHIN GROUP (ORDER BY unique_brand_name) AS unique_brand_name_list
        FROM all_brands AS ab
        GROUP BY
            campaign_id,
            super_cat_name
    ),
    campaign_dates AS (
        SELECT
            master_campaign_id AS campaign_id,
            MIN(start_date) AS campaign_start_date,
            MAX(end_date) AS campaign_end_date,
            MAX(media_cost) AS media_cost
        FROM {{ get_table('de_campaign') }}
        WHERE start_date IS NOT NULL
            AND end_date IS NOT NULL
        GROUP BY master_campaign_id
    )
-- Combine campaign metrics, product hierarchy and campaign dates.
SELECT
    dpdcl.campaign_id,
    cd.campaign_start_date,
    cd.campaign_end_date,
    cbn.super_category_name,
    cbn.sub_category_name_list,
    cbn.unique_brand_name_list,
    cbn.num_unique_subcats,
    cbn.num_unique_brands,
    NULL AS exposed, -- exposed metric not currently available for DTP, finding some in progress
    dpdcl.uplift,
    dpdcl.test,
    dpdcl.control,
    cd.media_cost,
    'meta' AS campaign_source
FROM dtp_performance_data_campaign_level AS dpdcl
INNER JOIN campaign_brand_names AS cbn
    ON dpdcl.campaign_id = cbn.campaign_id
INNER JOIN campaign_dates AS cd
    ON cd.campaign_id = dpdcl.campaign_id;


CREATE OR REPLACE TRANSIENT TABLE {{ get_table('measurement_legacy_campaign_performance') }} COPY GRANTS AS
WITH unioned_campaign_performance AS (
    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('instore_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('cat_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('ecoupon_performance_temp') }}

    UNION ALL

    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM {{ get_table('dtp_performance_temp') }}
),
final_campaign_performance AS (
    SELECT
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        super_category_name,
        sub_category_name_list,
        unique_brand_name_list,
        num_unique_subcats,
        num_unique_brands,
        CASE
            WHEN COUNT(*) OVER (PARTITION BY campaign_id) > 1 THEN 'Y'
            ELSE 'N'
        END AS has_multiple_rows,
        exposed,
        uplift,
        test,
        control,
        media_cost,
        campaign_source
    FROM unioned_campaign_performance
)
SELECT
    CAST(UPPER(campaign_id) AS VARCHAR(50)) AS campaign_id,
    CAST(campaign_start_date AS DATE) AS campaign_start_date,
    CAST(campaign_end_date AS DATE) AS campaign_end_date,
    CAST(UPPER(super_category_name) AS VARCHAR(3000)) AS super_category_name,
    CAST(UPPER(sub_category_name_list) AS VARCHAR(3000)) AS sub_category_name_list,
    CAST(UPPER(unique_brand_name_list) AS VARCHAR(3000)) AS unique_brand_name_list,
    CAST(num_unique_subcats AS NUMBER(38,0)) AS num_unique_subcats,
    CAST(num_unique_brands AS NUMBER(38,0)) AS num_unique_brands,
    CAST(has_multiple_rows AS VARCHAR(1)) AS has_multiple_rows,
    CAST(exposed AS NUMBER(38,0)) AS exposed,
    CAST(uplift AS NUMBER(18,6)) AS uplift,
    CAST(test AS NUMBER(18,6)) AS test,
    CAST(control AS NUMBER(18,6)) AS control,
    CAST(media_cost AS NUMBER(18,6)) AS media_cost,
    CAST(UPPER(campaign_source) AS VARCHAR(300)) AS campaign_source,
    CAST('{{ params.correlation_id }}' AS VARCHAR(36)) AS correlation_id,
    CAST(CURRENT_TIMESTAMP AS TIMESTAMP_NTZ) AS load_ts
FROM final_campaign_performance;
