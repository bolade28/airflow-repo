COPY INTO {{ get_stage('plngrm_campaign_item_postn_daily') }}
FROM (
    SELECT
        date_dt,
        week_start_dt,
        store_cd,
        section_id,
        item_cd
    FROM
        {{ get_table('plngrm_campaign_item_postn_daily') }}
        JOIN (SELECT MIN(week_start_dt) AS min_week_start_dt , MAX(week_start_dt) AS max_week_start_dt FROM {{ get_table('weekly_dates')}}
        WHERE week_start_dt between cast('{{params.start_date}}' as date) and cast('{{params.end_date}}' as date)) wkly_dates
        ON week_start_dt BETWEEN wkly_dates.min_week_start_dt AND wkly_dates.max_week_start_dt
)
include_query_id = true
header = true;