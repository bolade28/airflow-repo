COPY INTO {{ get_stage('dim_section') }}
FROM (
    SELECT
        section_id,
        section_name,
        section_type_desc,
        section_created_ts,
        section_expired_ts,
    FROM
        {{ get_table('dim_section') }}
)
include_query_id = true
header = true;