COPY INTO {{ get_stage('planogram_campaigns') }}
FROM (
    SELECT
        date_dt,
        week_start_dt,
        store_cd,
        section_id,
        item_cd
    FROM
        {{ get_table('planogram_campaigns') }}
        JOIN (
            -- Extend the lower week boundary by 2 weeks so planogram data includes the additional pre-period needed for downstream processing
            SELECT
                DATEADD(week, -2, MIN(week_start_dt)) AS min_week_start_dt,
                MAX(week_start_dt) AS max_week_start_dt
            FROM {{ get_table('weekly_start_dates')}}
            WHERE week_start_dt BETWEEN CAST('{{params.start_date}}' AS DATE)
                AND CAST('{{params.end_date}}' AS DATE)
    ) wkly_dates
        ON week_start_dt BETWEEN wkly_dates.min_week_start_dt
            AND wkly_dates.max_week_start_dt
)
include_query_id = true
header = true;