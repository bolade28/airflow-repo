from typing import Dict, List, Optional, Tuple


def step_config(
    environment: str,
    glue_warehouse: str,
    num_executors: int,
    pipelines_commit_hash: str,
    step_args: List[Tuple],
    step_name: str,
    step_script: str,
    use_iceberg: bool,
    cpus_per_task: int = 1,
    default_parallelism: int = 500,
    executor_cores: int = 5,
    executor_memory: str = "30g",
    packages: Optional[List[str]] = None,
) -> Dict:
    """Return the configuration for an EMR step.


    :param environment: The environment in which to execute the step.
    :param glue_warehouse: The S3 path where Spark will write output files for this step.
    :param num_executors: The number of Spark executors to use to run the step.
    :param pipelines_commit_hash: The measurement pipelines commit hash to use for the step.
    :param step_args: The CLI args for the PySpark script.
    :param step_name: The name of the EMR step.
    :param step_script: The name of the PySpark script to execute.
    :param use_iceberg: Whether to use Iceberg for the step.
    :param cpus_per_task: The number of CPUs to use for each task.
    :param default_parallelism: The default number of partitions in RDDs
        returned by transformations like join, reduceByKey, and parallelize
    :param executor_cores: The number of cores to use on each executor.
        when not set by user.
    :param executor_memory: The amount of memory to use per executor process.
    :param packages: A list of Maven coordinates required to run the step.
        all partitions for each Spark action (e.g. collect) in bytes.
    """

    package_args = ["--packages", ",".join(packages)] if packages else []
    return {
        "Name": step_name,
        "ActionOnFailure": "CONTINUE",
        "HadoopJarStep": {
            "Jar": "command-runner.jar",
            "Args": [
                "spark-submit",
                "--deploy-mode", "client",
                "--num-executors", f'\'{num_executors}\'',
                "--executor-memory", str(executor_memory),
                "--executor-cores", f'\'{executor_cores}\'',
                "--driver-memory", str(executor_memory),
                "--conf", f"spark.task.cpus={cpus_per_task}",
                "--conf", "spark.driver.extraJavaOptions -Dfs.s3.canned.acl=BucketOwnerFullControl",
                "--conf", "spark.driver.defaultJavaOptions=-XX:+UseG1GC",
                "--conf", "spark.executor.defaultJavaOptions=-XX:+UseG1GC",
                "--conf", "spark.driver.maxResultSize=29g",
                "--conf", f"spark.default.parallelism={default_parallelism}",
                "--conf", "spark.sql.windowExec.buffer.spill.threshold=2097152",
                "--conf", "spark.executorEnv.PYTHONHASHSEED=0",
                "--conf", "spark.dynamicAllocation.enabled=false",
                "--conf", "spark.pyspark.python=/usr/bin/python3.11",
                "--conf", "spark.rpc.message.maxSize=1024",
            ] + (
                [
                    "--conf", "spark.sql.catalog=my_catalog",
                    "--conf", "spark.sql.defaultCatalog=my_catalog",
                    "--conf", "spark.sql.catalog.my_catalog.type=glue",
                    "--conf", "spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
                    "--conf", "spark.sql.catalog.my_catalog=org.apache.iceberg.spark.SparkCatalog",
                    "--conf", f"spark.sql.catalog.my_catalog.warehouse={glue_warehouse}",
                    "--conf", "spark.sql.sources.v2.bucketing.enabled=true",
                    "--conf", "spark.sql.sources.v2.bucketing.pushPartValues.enabled=true",
                    "--conf", "spark.sql.sources.v2.bucketing.partiallyClusteredDistribution.enabled=true",
                    "--conf", "spark.sql.sources.v2.bucketing.allowJoinKeysSubsetOfPartitionKeys.enabled=true",
                    "--conf", "spark.sql.sources.v2.bucketing.allowCompatibleTransforms.enabled=true",
                    "--conf", "spark.sql.sources.v2.bucketing.shuffle.enabled=true",
                    "--conf", "spark.sql.catalog.my_catalog.http-client.apache.max-connections=3000",
                ] if use_iceberg else []
            ) + [
                "--name", step_name,
                *package_args,
                "--py-files",
                f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/measurement_pipelines-1.0-py3-none-any.whl",
                f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/{step_script}",

            ] + [val for arg in step_args for val in arg]
        }
    }
