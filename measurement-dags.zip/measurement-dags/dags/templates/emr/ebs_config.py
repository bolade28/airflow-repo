from typing import Dict


def ebs_config(size_in_gb: int = 128, volumes_per_instance: int = 1) -> Dict:
    return {
        "EbsBlockDeviceConfigs": [
            {
                "VolumeSpecification": {
                    "VolumeType": "gp2",
                    "SizeInGB": size_in_gb
                },
                "VolumesPerInstance": volumes_per_instance
            }
        ],
        "EbsOptimized": True
    }
