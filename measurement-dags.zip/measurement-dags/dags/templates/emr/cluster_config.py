from typing import Dict, List, Union

from airflow.sdk import Variable

from helpers.constants import (
    DEV_ACCOUNT_NUMBER,
    DEV_KEY,
    DEV_SUBNETS,
    EMR_RELEASE,
    PROD,
    PROD_ACCOUNT_NUMBER,
    PROD_KEY,
    PROD_SUBNETS,
    MAX_RUNTIME_HOURS,
)
from templates.emr.ebs_config import ebs_config
from helpers.xcom import (
    get_compute_units,
    get_configured_campaign,
    pipeline_run_type_name,
    get_current_aws_user,
)
from helpers.utils import get_cluster_termination_cron


def default_emr_tags(env: str) -> dict:
    return {
        "for-use-with-amazon-emr-managed-policies": "true",
        "owner": "Measurement",
        "email": "measurement@sainsburys.co.uk",
        "costcentre": "PD8634",
        "project": "Measurement - UP",
        "dataClassification": "highlySensitive",
        "environment": env,
        "live": "yes" if env == PROD else "no",
        "dataRetention": "1-month",
        "servicename": "Nectar 360 Measurement",
        "servicecatalogueID": "001071675",
        "runBy": get_current_aws_user(),
        "pipelineRunType": pipeline_run_type_name(),
        "campaign": get_configured_campaign(is_tag=True),
    }


def job_flow(
    name: str,
    master_ebs_config: dict,
    master_instance_type: str,
    core_instance_types: List[Dict[str, Union[str, int]]],
    tags: Dict[str, str]
) -> Dict:
    """
     See https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/emr/client/run_job_flow.html
     for details of the config.

    Args:
        name: Name of the job_blow
        master_ebs_config:  additional settings
        master_instance_type: specify the master instance type
        core_instance_types: list of instance type that the custer try to use, capped at 30
        tags: tags for the cluster

    Returns:
        dict with job flow config
    """
    environment = Variable.get("MEASUREMENT_ENVIRONMENT")
    subnet_ids = PROD_SUBNETS if environment == PROD else DEV_SUBNETS
    ec2_key_name = PROD_KEY if environment == PROD else DEV_KEY
    account_number = PROD_ACCOUNT_NUMBER if environment == PROD else DEV_ACCOUNT_NUMBER
    standard_tags = default_emr_tags(environment)
    standard_tags.update(tags)

    return {
        "Name": f"{name}",
        "ReleaseLabel": EMR_RELEASE,
        "LogUri": f"s3://aws-logs-{account_number}-eu-west-1/",
        "Applications": [{"Name": "Spark"}],
        "BootstrapActions": [
            {
                "Name": "Install Requirements",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/emr_bootstrap.sh",
                    "Args": [
                        f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/requirements.txt",
                    ]
                }
            },
            {
                "Name": "Install SSM",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/emr_bootstrap_ssm.sh",
                }
            },
            {
                "Name": "Setup cronjob to fail-safe terminate cluster in 6 hours",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/emr_cronjob_terminatecluster.sh",
                    "Args": [
                        get_cluster_termination_cron(hours=MAX_RUNTIME_HOURS)
                    ]
                }
            }
        ],
        "Instances": {
            "InstanceFleets": [
                {
                    "Name": "Master",
                    "InstanceFleetType": "MASTER",
                    "InstanceTypeConfigs": [
                        {
                            "InstanceType": master_instance_type,
                            "EbsConfiguration": master_ebs_config,
                        },
                    ],
                    "TargetOnDemandCapacity": 1,
                },
                {
                    "Name": "Core",
                    "InstanceFleetType": "CORE",
                    "InstanceTypeConfigs": [
                        {
                            "InstanceType": master_instance_type,
                            "EbsConfiguration": master_ebs_config,
                        },
                    ],
                    "TargetOnDemandCapacity": 4,
                },
                {
                    "Name": "Task",
                    "InstanceFleetType": "TASK",
                    "TargetOnDemandCapacity": 0,
                    "TargetSpotCapacity": get_compute_units(),
                    "InstanceTypeConfigs": [
                        {
                            "InstanceType": instance["type"],
                            "BidPriceAsPercentageOfOnDemandPrice": 100.0,
                            "WeightedCapacity": instance["weight"],
                            "EbsConfiguration": ebs_config(instance["ebs_vol_size"], instance["ebs_volumes"])
                        } for instance in core_instance_types
                    ],
                    "LaunchSpecifications": {
                        "SpotSpecification": {
                            "TimeoutDurationMinutes": 10,
                            "TimeoutAction": "SWITCH_TO_ON_DEMAND",
                            "AllocationStrategy": "price-capacity-optimized",
                        },
                    }
                }
            ],
            "Ec2KeyName": ec2_key_name,
            "Ec2SubnetIds": subnet_ids,
            "KeepJobFlowAliveWhenNoSteps": True,
            "TerminationProtected": False,
            "UnhealthyNodeReplacement": True,
        },
        "EbsRootVolumeSize": 64,
        "VisibleToAllUsers": True,
        "JobFlowRole": "EMR_EC2_DefaultRole",
        "SecurityConfiguration": f"measurement-{environment}-IMDSv2",
        "ServiceRole": "EMR_DefaultRole",
        "StepConcurrencyLevel": 4,
        "AutoTerminationPolicy": {
            "IdleTimeout": 3600  # 1 hour
        },
        'Configurations': [
            {
                'Classification': 'spark',
                'Properties': {
                    'maximizeResourceAllocation': 'false'
                }
            },
            {
                "Classification": "spark-defaults",
                "Properties": {
                    "spark.jars.packages": "net.snowflake:snowflake-jdbc:3.24.2,net.snowflake:spark-snowflake_2.12:3.1.3"
                }
            },
            {
                "Classification": "iceberg-defaults",
                "Properties": {
                    "iceberg.enabled": "true"
                }
            },
            {
                "Classification": "yarn-env",
                "Configurations": [
                    {
                        "Classification": "export",
                        "Properties": {
                            "PYSPARK_PYTHON": "/usr/bin/python3.11"
                        }
                    }
                ]
            }
        ],
        "Tags": [
            {"Key": k, "Value": v} for k, v in standard_tags.items()
        ]
    }
