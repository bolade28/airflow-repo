from datetime import datetime

from airflow.sdk import dag

from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, resolve_pipelines_version
from task_groups import snowflake_objects_update, snowflake_objects_setup


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    }
)
def snowflake_objects_update_dag():
    """
    Snowflake Objects UPDATE DAG
    This DAG is responsible for non-destructively updating/altering self-managed Snowflake objects.
    """

    setup = snowflake_objects_setup.task_group()

    update_snowflake_objects = snowflake_objects_update.task_group()
    update_snowflake_objects.set_upstream(setup)


snowflake_objects_update_dag()
