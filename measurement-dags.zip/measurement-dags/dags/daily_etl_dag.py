from datetime import datetime
from airflow.sdk import dag
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table
from task_groups import daily_etl_operations, daily_etl_setup


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule="00 6 * * *",
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    tags=['daily_etl'],
    catchup=False,
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    }
)
def daily_etl_dag():

    """
    Measurement Daily ETL DAG
    This DAG is responsible for running daily ETL processes.
    """
    setup = daily_etl_setup.task_group()

    run_daily_etl = daily_etl_operations.task_group()
    setup >> run_daily_etl


daily_etl_dag()
