import os
from typing import Optional

from airflow.sdk import Variable


class Paths:
    def __init__(
        self,
        correlation_id: str,
        dt: Optional[str] = None,
    ):
        self.correlation_id = correlation_id
        self.env = Variable.get('MEASUREMENT_ENVIRONMENT')
        self.dt = dt

        #
        #  ---- Set paths ----
        #
        self.paths = {
            "attribution_model_result_aisle":
                self.etl_output_bucket("attribution_model_result_aisle"),
            "attribution_model_result_brand":
                self.etl_output_bucket("attribution_model_result_brand"),
            "attribution_model_result_offer":
                self.etl_output_bucket("attribution_model_result_offer"),
            "attribution_synergy_results":
                self.etl_output_bucket("attribution_synergy_results"),
            'attribution_pre_requisite_aisle':
                self.etl_output_bucket('attribution_pre_requisite_aisle'),
            'attribution_pre_requisite_brand':
                self.etl_output_bucket('attribution_pre_requisite_brand'),
            'attribution_pre_requisite_offer':
                self.etl_output_bucket('attribution_pre_requisite_offer'),
            'baseline_mta_integration':
                self.etl_output_bucket('baseline_mta_integration'),
            'campaign_booking_media_channel':
                self.snowflake_unload_bucket('campaign_booking_media_channel'),
            'campaign_product_type_dim_item':
                self.snowflake_unload_bucket('campaign_product_type_dim_item'),
            'campaign_product_type_ean_br':
                self.snowflake_unload_bucket('campaign_product_type_ean_br'),
            'campaign_product_type':
                self.snowflake_unload_bucket('campaign_product_type'),
            'campaign_selection':
                self.etl_output_bucket('campaign_selection'),
            'cs_proxy_mappings':
                self.etl_output_bucket('cs_proxy_mappings'),
            'coupon_at_till_campaigns':
                self.snowflake_unload_bucket('coupon_at_till_campaigns'),
            'coupon_at_till_processed_data':
                self.etl_output_bucket('coupon_at_till_processed_data'),
            'coupon_at_till_processed_data_pollen':
                self.etl_output_bucket('coupon_at_till_processed_data_pollen'),
            'baseline_modelling_dataset_output':
                self.snowflake_unload_bucket('baseline_modelling_dataset'),
            'baseline_forecasting_call_output':
                self.snowflake_unload_bucket('baseline_forecasting_call_output'),
            'baseline_primary_metric':
                self.snowflake_unload_bucket('baseline_primary_metric'),
            'base_finance_assets':
                self.snowflake_unload_bucket('base_finance_assets'),
            'base_price_data':
                self.etl_output_bucket('base_price_data'),
            'campaign':
                self.snowflake_unload_bucket('campaign'),
            'cell':
                self.snowflake_unload_bucket('cell'),
            'secondary_space_processed_data':
                self.etl_output_bucket('secondary_space_processed_data'),
            'coupon':
                self.snowflake_unload_bucket('coupon'),
            'coupon_cell':
                self.snowflake_unload_bucket('coupon_cell'),
            'coupon_to_product':
                self.snowflake_unload_bucket('coupon_to_product'),
            'citrus_campaigns':
                self.snowflake_unload_bucket('citrus_campaigns'),
            'cs_baseline_modelling_output':
                self.snowflake_unload_bucket('cs_baseline_modelling_output'),
            'cs_sales_data':
                self.snowflake_unload_bucket('cs_sales_output'),
            'dim_item_hist':
                self.snowflake_unload_bucket('dim_item_hist'),
            'dim_section':
                self.snowflake_unload_bucket('dim_section'),
            'dim_store_org_hierarchy':
                self.snowflake_unload_bucket('dim_store_org_hierarchy'),
            'dv360_campaign':
                self.snowflake_unload_bucket('dv360_campaign'),
            'dv360_normalised':
                self.etl_output_bucket('dv360_normalised'),
            'dv360_normalised_pollen':
                self.etl_output_bucket('dv360_normalised_pollen'),
            'external_processed_data_output':
                self.snowflake_unload_bucket('external_processed_data_output'),
            'fb_insight_normalize':
                self.snowflake_unload_bucket('fb_insight_normalize'),
            'feature_prioritisation':
                self.etl_output_bucket('feature_prioritisation'),
            'measurement_legacy_campaign_performance':
                self.snowflake_unload_bucket('measurement_legacy_campaign_performance'),
            'planogram_campaigns':
                self.snowflake_unload_bucket('planogram_campaigns'),
            'processed_dim_locations':
                self.snowflake_unload_bucket('processed_dim_locations'),
            'processed_fact_sales_transaction_item':
                self.snowflake_unload_bucket('processed_fact_sales_transaction_item'),
            'processed_fact_sales_transaction_item_agg':
                self.snowflake_unload_bucket('processed_fact_sales_transaction_item_agg'),
            'processed_fact_sales_transaction_basket':
                self.snowflake_unload_bucket('processed_fact_sales_transaction_basket'),
            'promotional_discount_processed_data':
                self.etl_output_bucket('promotional_discount_processed_data'),
            'refactoring':
                self.snowflake_unload_bucket('refactoring'),
            'sales_data_transaction':
                self.snowflake_unload_bucket('sales_data_transaction'),
            'sales_processed_data':
                self.etl_output_bucket('sales_processed_data'),
            "sales_data_sku_clustering":
                self.snowflake_unload_bucket("sales_data_sku_clustering"),
            "sku_cluster_mapping_features_output":
                self.snowflake_unload_bucket("sku_cluster_mapping_features_output"),
            "sku_cluster_mapping_final_output":
                self.snowflake_unload_bucket("sku_cluster_mapping_final_output"),
            "sku_cluster_mapping_kmeans_raw_output":
                self.etl_output_bucket("sku_cluster_mapping_kmeans_raw_output"),
            "sku_cluster_mapping_kmeans_full_output":
                self.etl_output_bucket("sku_cluster_mapping_kmeans_full_output"),
            "sku_cluster_mapping_short_data_bad_output":
                self.etl_output_bucket("sku_cluster_mapping_short_data_output"),
            "sku_cluster_mapping_time_series_output":
                self.etl_output_bucket("sku_cluster_mapping_time_series_output"),
            # NOTE: this is the one calculated within this dag
            "sku_cluster_mapping":
                self.snowflake_unload_bucket("sku_cluster_mapping_final_output"),
            'three_letter_coding':
                self.etl_output_bucket('three_letter_coding'),
            'sku_level_attributed_sales_and_units_offer':
                self.etl_output_bucket('sku_level_attributed_sales_and_units_offer'),
            'sku_level_attributed_sales_and_units_brand':
                self.etl_output_bucket('sku_level_attributed_sales_and_units_brand'),
            'sku_level_attributed_sales_and_units_aisle':
                self.etl_output_bucket('sku_level_attributed_sales_and_units_aisle'),
            # # TODO:: confirm this would be changed to the original sources in future
            # 'cluster_features':
            #     self.snowflake_unload_bucket('cluster_features'),
            # # Cluster Mapping will be changed when SKU cluster mapping is done
            'instore_campaigns':
                self.snowflake_unload_bucket('instore_campaigns'),
            'magazine_campaigns':
                self.snowflake_unload_bucket('magazine_campaigns'),
            'media_report':
                self.snowflake_unload_bucket('media_report'),
            # TODO: see dags/steps/campaign_etl/unified_campaigns.py - what's this then. used?
            'meta_campaigns':
                self.snowflake_unload_bucket('meta_campaigns'),
            'processed_dim_location':
                self.snowflake_unload_bucket('processed_dim_location'),
            'meta_processed_data':
                self.etl_output_bucket('meta_processed_data'),
            'meta_processed_data_pollen':
                self.etl_output_bucket('meta_processed_data_pollen'),
            'temp_unified_product':
                self.snowflake_unload_bucket('temp_unified_product'),
            'fb_campaign':
                self.snowflake_unload_bucket('fb_campaign'),
            'fb_campaign_normalized':
                self.etl_output_bucket('fb_campaign_normalized'),
            'fb_campaign_normalized_pollen':
                self.etl_output_bucket('fb_campaign_normalized_pollen'),
            'unified_product':
                self.snowflake_unload_bucket('unified_product'),
            'up_campaign_data':
                self.snowflake_unload_bucket('up_campaign_data_path'),
            'weekly_dates':
                self.snowflake_unload_bucket('weekly_dates'),
            # This is same as weekly_dates but with an extended date range, so we can use it in the timeseries data so we can truncate the final week of data for cleaner features
            'weekly_dates_extended':
                self.snowflake_unload_bucket('weekly_dates_extended'),
            'youtube_normalize':
                self.snowflake_unload_bucket('youtube_normalize'),
            'youtube_normalize_pollen':
                self.snowflake_unload_bucket('youtube_normalize_pollen'),
            'unified_campaigns':
                self.snowflake_unload_bucket('unified_campaigns'),
            'unified_campaigns_pollen':
                self.snowflake_unload_bucket('unified_campaigns_pollen'),
            'agg_value_index_dashboard_w':
                self.snowflake_unload_bucket('agg_value_index_dashboard_w'),
            'value_index_processed_data':
                self.etl_output_bucket('value_index_processed_data'),
            'advertise_request_realised':
                self.snowflake_unload_bucket('advertise_request_realised'),
            'citrus_processed_data':
                self.etl_output_bucket('citrus_processed_data'),
            'dv360_media_report':
                self.snowflake_unload_bucket('dv360_media_report'),
            'dv360_processed_data':
                self.etl_output_bucket('dv360_processed_data'),
            'dv360_processed_data_pollen':
                self.etl_output_bucket('dv360_processed_data_pollen'),
            'youtube_processed_data':
                self.etl_output_bucket('youtube_processed_data'),
            'youtube_processed_data_pollen':
                self.etl_output_bucket('youtube_processed_data_pollen'),
            'channel_processed_data':
                self.etl_output_bucket('channel_processed_data'),
            'previous_baseline_modelling_dataset':
                self.snowflake_unload_bucket('previous_baseline_modelling_dataset'),
            'ie_campaign_filt':
                self.snowflake_unload_bucket('ie_campaign_filt'),
            'cust_by_location':
                self.snowflake_unload_bucket('cust_by_location'),
            'ie_product':
                self.snowflake_unload_bucket('ie_product'),
            'ie_location':
                self.snowflake_unload_bucket('ie_location'),
            'media_instore_init':
                self.snowflake_unload_bucket('media_instore_init'),
            'unified_channel_active_media':
                self.snowflake_unload_bucket('unified_channel_active_media'),
            'instore_processed_data':
                self.etl_output_bucket('instore_processed_data'),
            'instore_processed_data_pollen':
                self.etl_output_bucket('instore_processed_data_pollen'),
            'incremental_shrinkage':
                self.etl_output_bucket('incremental_shrinkage'),
            'new_launch_estimation':
                self.snowflake_unload_bucket('new_launch_estimation'),
            'sku_cluster_mapping_new_launch':
                self.snowflake_unload_bucket('sku_cluster_mapping_new_launch'),
            'previous_sku_cluster_mapping':
                self.snowflake_unload_bucket('previous_sku_cluster_mapping'),
            'campaign_decay_rate':
                self.snowflake_unload_bucket('campaign_decay_rate'),
            'customer_data_collection':
                self.snowflake_unload_bucket('customer_data_collection'),
            "measurement_campaign_execution":
                self.snowflake_unload_bucket("measurement_campaign_execution"),
            "measurement_marketing_channel_hierarchy":
                self.snowflake_unload_bucket("measurement_marketing_channel_hierarchy"),
            "advertising_campaign_citcam_sat":
                self.snowflake_unload_bucket("advertising_campaign_citcam_sat"),
            "digital_trading_campaign_link":
                self.snowflake_unload_bucket("digital_trading_campaign_link"),
            "digital_trading_campaign_insight_link":
                self.snowflake_unload_bucket("digital_trading_campaign_insight_link"),
            "digital_trading_campaign_sat":
                self.snowflake_unload_bucket("digital_trading_campaign_sat"),
            "digital_trading_lineitem_facebook_insight":
                self.snowflake_unload_bucket("digital_trading_lineitem_facebook_insight"),
            "floodlight_report":
                self.snowflake_unload_bucket("floodlight_report"),
            "unique_reach_lineitem_report":
                self.snowflake_unload_bucket("unique_reach_lineitem_report"),
            "reach_engagement":
                self.snowflake_unload_bucket("reach_engagement"),
            "reach_engagement_reporting":
                self.snowflake_unload_bucket("reach_engagement_reporting"),
            'user_journey_offer':
                self.etl_output_bucket('user_journey_offer'),
            'user_journey_brand':
                self.etl_output_bucket('user_journey_brand'),
            'user_journey_aisle':
                self.etl_output_bucket('user_journey_aisle'),
            'baseline_attribution_integration_sku_level_aisle':
                self.etl_output_bucket('baseline_attribution_integration_sku_level_aisle'),
            'baseline_attribution_integration_sku_level_brand':
                self.etl_output_bucket('baseline_attribution_integration_sku_level_brand'),
            'baseline_attribution_integration_sku_level_offer':
                self.etl_output_bucket('baseline_attribution_integration_sku_level_offer'),
            'measurement_campaign_reporting':
                self.snowflake_unload_bucket('measurement_campaign_reporting'),
            'ucm_base_data':
                self.etl_output_bucket('ucm_base_data'),
            'ucm_summary_data':
                self.etl_output_bucket('ucm_summary_data'),
            'ucm_input_data':
                self.etl_output_bucket('ucm_input_data'),
            'ucm_intermediate_data':
                self.etl_output_bucket('ucm_intermediate_data'),
            # UCM outputs results saved in parquet format
            'ucm_output_data':
                self.snowflake_unload_bucket('ucm_output_data'),
            'unified_baseline_attribution_integration':
                self.snowflake_unload_bucket('unified_baseline_attribution_integration'),
            # Customer data collection
            'youtube_data':
                self.snowflake_unload_bucket('youtube_data'),
            'dv360_data':
                self.snowflake_unload_bucket('dv360_data'),
            'citrus_data':
                self.snowflake_unload_bucket('citrus_data'),
            'instore_data':
                self.snowflake_unload_bucket('instore_data'),
            'meta_data':
                self.snowflake_unload_bucket('meta_data'),
            'magazine_data':
                self.snowflake_unload_bucket('magazine_data'),
            'ecoupon_data':
                self.snowflake_unload_bucket('ecoupon_data'),
            'coupon_at_till_data':
                self.snowflake_unload_bucket('coupon_at_till_data'),
            'mta_baseline_integration_missing_data_offer':
                self.etl_output_bucket('mta_baseline_integration_missing_data_offer'),
            'mta_baseline_integration_zero_or_incrementality_offer':
                self.etl_output_bucket('mta_baseline_integration_zero_or_incrementality_offer'),
            'mta_baseline_integration_missing_data_brand':
                self.etl_output_bucket('mta_baseline_integration_missing_data_brand'),
            'mta_baseline_integration_zero_or_incrementality_brand':
                self.etl_output_bucket('mta_baseline_integration_zero_or_incrementality_brand'),
            'mta_baseline_integration_missing_data_aisle':
                self.etl_output_bucket('mta_baseline_integration_missing_data_aisle'),
            'mta_baseline_integration_zero_or_incrementality_aisle':
                self.etl_output_bucket('mta_baseline_integration_zero_or_incrementality_aisle'),
            'marketing_media_hierarchy_mkthrc_ref':
                self.snowflake_unload_bucket('marketing_media_hierarchy_mkthrc_ref'),
            'previous_measurement_campaign_reporting':
                self.snowflake_unload_bucket('previous_measurement_campaign_reporting'),
            # ecoupon processed data
            'oc_customer_selection':
                self.snowflake_unload_bucket('oc_customer_selection'),
            'oc_campaign':
                self.snowflake_unload_bucket('oc_campaign'),
            'oc_products':
                self.snowflake_unload_bucket('oc_products'),
            'ecoupon_processed_data':
                self.etl_output_bucket('ecoupon_processed_data'),
            'ecoupon_processed_data_pollen':
                self.etl_output_bucket('ecoupon_processed_data_pollen'),
            'dv360_pollen_campaign':
                self.snowflake_unload_bucket('dv360_campaign_booking_media_channel'),
            # ToDo: Remove all checkpoint references once UCM is stable (in optimisation phase)
            'ucm_checkpoint_data':
                self.measurement_ucm_checkpoint_dir()

        }

    # only for snowflake stage
    def snowflake_unload_bucket(self, directory: str) -> str:
        return os.path.join(f's3://measurement-{self.env}-snowflake-unload', self.correlation_id, directory)

    #
    # ----    Buckets    ----
    #
    def measurement_dev_temp_bucket(self, directory) -> str:
        return os.path.join(f's3://measurement-{self.env}-temp', directory)

    def etl_output_bucket(self, directory: str) -> str:
        return os.path.join(f's3://measurement-{self.env}-etl-output', self.correlation_id, directory)

    def measurement_baseline_temp_sources(self, temp_source: str) -> str:
        return os.path.join(f's3://measurement-{self.env}-temp/baseline_temp_sources', temp_source)

    def measurement_ucm_checkpoint_dir(self) -> str:
        return f's3://measurement-{self.env}-temp/ucm_checkpoint_dir/'
