from airflow.sdk import Variable
from helpers.constants import (
    DEV_ACCOUNT_NUMBER,
    PROD,
    PROD_ACCOUNT_NUMBER,
)


class SNS:
    def __init__(self):
        self.env = Variable.get("MEASUREMENT_ENVIRONMENT")
        self.account_number = PROD_ACCOUNT_NUMBER if self.env == PROD else DEV_ACCOUNT_NUMBER

    def metrics_topic_arn(self):
        return f"arn:aws:sns:eu-west-1:{self.account_number}:measurement-{self.env}-metrics-topic"

    def slack_topic_arn(self):
        return f"arn:aws:sns:eu-west-1:{self.account_number}:measurement-{self.env}-slack-messenger-topic"

    def all(self):
        return {
            'metrics_topic_arn': self.metrics_topic_arn(),
            'slack_topic_arn': self.slack_topic_arn(),
        }
