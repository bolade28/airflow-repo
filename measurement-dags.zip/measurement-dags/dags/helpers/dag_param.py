from airflow.sdk import Param
from helpers.constants import DEFAULT_RUN_TYPE
import pendulum


# dag run configuration parameters
def compute_units_param(cores: int = 16) -> Param:

    return Param(
        default=cores,
        description="The number of cores to use for EMR cluster (in multiples of 8)",
        type="integer",
        title="EMR Compute Units",
        description_md=f"""
        The number of cores to use for the EMR cluster. Since the smallest instance size we use has 8 cores,
        the number of cores requested should be a multiple of 8.

        If not specified it will default to **{cores}** cores.
        """
    )


class DagParams:
    pipelines_hash_param = Param(
        default="latest",
        description="Github commit hash for measurement-pipelines version",
        type="string",
        title="Pipelines commit hash",
        description_md="""
        Use `latest` to run pipelines from the `main` branch of the `measurement-pipelines` repository.
        To run a specific version, provide any git commit hash from that repository or create your
        own custom hash value using dev_deploy.sh in pipelines repo.
        """
    )

    source_bucket_key = Param(
        default="/folder_1/",
        description="source location from the file to be copied",
        type="string",
        title="measurement pipelines test source location",
        description_md="""
        Source location to copy the file from
        """
    )

    destination_bucket_key = Param(
        default="s3://measurement-dev-temp/folder_2/some_temp_file.csv",
        description="source location from the file to be copied",
        type="string",
        title="measurement pipelines test destination location",
        description_md="""
        Source location to copy the file from
        """
    )

    pipelines_manual_campaign_list = Param(
        default="nec24110054a, nec2305511a, nec2301099a, nec24120039a",
        type="string",
        title="Job bag number or Booking ID",
        description="List of job bag numbers or booking IDs to run manually. Job bag numbers are needed for DTP based campaigns and Booking IDs for Pollen based campaigns.",
        description_md="""
                A list of job bag numbers or booking IDs to run measurement manually.
                Job bag numbers are needed for DTP based campaigns and Booking IDs for Pollen based campaigns.
                This parameter is only considered if the pipelines_manual_run flag (another DAG param) is set to True/Yes.
                Use this to override standard pipeline campaign selection logic and run a specific set of campaigns.
                Default values: nec24110054a is Meta, nec2305511a is Citrus, nec2301099a is DV360, nec24120039a in In-store
                Example DTP input: job_bag_number1, job_bag_number2, job_bag_number3
                Example Pollen input: booking_id1, booking_id2, booking_id3
            """
    )
    pipeline_run_type = Param(
        default=DEFAULT_RUN_TYPE,
        type="string",
        title="Pipeline run type",
        description="This parameter is used to decide if we are running pipelines using Pollen based campaigns or DTP",
        description_md="""
                Provide only Pollen or DTP as input.
            """
    )

    campaign_end_date = Param(
        default=f"{pendulum.now().to_date_string()}",  # DAG run date",
        type="string",
        title="Campaign end date",
        description="This parameter is used to specify the end date for the campaign.",
        description_md="""
                Provide a valid campaign end date as input. Valid format: YYYY-MM-DD. Example - 2025-07-02
                If no end date is provided, the DAG run date will be used.
            """
    )

    post_period_end_date = Param(
        default=f"{pendulum.now().to_date_string()}",  # DAG run date",
        type="string",
        title="Post period end date",
        description="This parameter is used to specify the end date for the post period evaluation.",
        description_md="""
                Provide a valid post period end date as input. Valid format: YYYY-MM-DD. Example - 2025-07-02
                If no end date is provided, the DAG run date will be used.
            """
    )

    ci_of_during_run = Param(
        default="latest",
        type="string",
        title="Correlation ID of During Run",
        description="This parameter is used to decide if we are pulling results of a specific correlation id or the latest timestamp for specific campaigns.",
        description_md="""
                    Provide a correlation id of a During run to use results of that run in the Post run.
                    Otherwise the latest load_ts will be used for campaign list.
            """
    )
