from airflow.sdk import Variable
from airflow.sdk import task
from airflow.providers.standard.operators.python import get_current_context
from helpers.constants import (
    PROD,
    PROD_SNOWFLAKE_UNLOAD_PATH,
    DEV_SNOWFLAKE_UNLOAD_PATH,
    PROD_SNOWFLAKE_EXTERNAL_STAGE,
    DEV_SNOWFLAKE_EXTERNAL_STAGE,
    XComKeys
)
from helpers.setup import (
    configure_aws_user,
    configure_campaign_end_date,
    configure_ci_of_during_run,
    configure_compute_units,
    configure_correlation_id,
    configure_campaigns,
    configure_pipelines_version,
    configure_paths,
    configure_post_period_end_date,
    configure_snowflake_tables,
    configure_sns,
    configure_campaign_start_date,
    configure_model_start_end_dates,
    configure_mlflow,
    configure_run_type,
    get_airflow_platform,
    configure_master_instance_type,
)
from helpers.utils import get_pipelines_commit_hash, get_dag_commit_hash

#
# ---- Utility functions
#
#


def get_snowflake_unload_stage_name() -> str:
    return PROD_SNOWFLAKE_EXTERNAL_STAGE if Variable.get('MEASUREMENT_ENVIRONMENT') == PROD else DEV_SNOWFLAKE_EXTERNAL_STAGE


def get_snowflake_unload_s3_path() -> str:
    return PROD_SNOWFLAKE_UNLOAD_PATH if Variable.get('MEASUREMENT_ENVIRONMENT') == PROD else DEV_SNOWFLAKE_UNLOAD_PATH


"""
The get_...() functions all return the correct template to use when pulling an xcom variable.
A variable gets substituted in at run-time during Jinja templating, so you may specify them
in the templated fields of any operator, e.g. consider:

    PythonOperator(task_id='some_task', python_callable=print, op_kwargs={"x": get_compute_units()})

get_compute_units() returns the string:

    f'{{task_instance.xcom_pull(task_ids="{compute_units.__wrapped__.__name__}", key="return_value")}}'

When the Python Operator is launched, the op_kwargs() is templated, so Jinja will render
everything inside the {{ }}, in this case it pulls and returns the appropriate value from
the xcom table. The function that is run by the operator is then equivalent to:

    print(3456)

In order to pull the xcom, the pulling task must have the correct task_id. In an @task decorated
function, this is the name of the decorated function, which is why we use the convention

    some_function.__wrapped__.__name__

When referring to a task id - if someone changes the name of the decorated function, this should
break the import in this file, rather than silently returning None during Jinja templating when that
task cannot be found in the xcom table for the current dag run.
"""


def get_all_paths_for_meta_data():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="return_value") | replace("\\\'", "\\\"")}}}}'


def get_ci():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_correlation_id.__wrapped__.__name__}", key="return_value")}}}}'


def get_cluster_id():
    return '{{ task_instance.xcom_pull(task_ids="create_emr_cluster", key="return_value") }}'


def get_compute_units():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_compute_units.__wrapped__.__name__}", key="return_value")}}}}'


def get_pipelines_version():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_pipelines_version.__wrapped__.__name__}", key="return_value")}}}}'


def get_path(path: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="{path}")}}}}'


def get_sns(topic: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_sns.__wrapped__.__name__}", key="{topic}")}}}}'


def get_stage(path: str):
    bucket = get_snowflake_unload_s3_path()
    stage = get_snowflake_unload_stage_name()
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_paths.__wrapped__.__name__}", key="{path}") | replace("{bucket}", "{stage}")}}}}'


def get_table(table: str):
    """
    :param table: The name of the table you wish to template. See helpers.utils.tables for the full list of options
    :return str: The templated table name
    """
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_snowflake_tables.__wrapped__.__name__}", key="{table}")}}}}'


def get_job_flow_start_time():
    return '{{task_instance.xcom_pull(task_ids="job_flow_start_time", key="return_value")}}'


def get_campaign_start_date(period: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaign_start_date.__wrapped__.__name__}", key="{period}")}}}}'


def get_model_start_end_dates(period: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_model_start_end_dates.__wrapped__.__name__}", key="{period}")}}}}'


def get_configured_campaign(is_tag: bool = False):
    if is_tag:
        return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaigns.__wrapped__.__name__}", key="return_value") | replace("|", "-") | lower}}}}'
    else:
        return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaigns.__wrapped__.__name__}", key="return_value")}}}}'


# TODO: why do we need strip() here? can this be removed?
def get_manual_campaigns_list(type: str = None):
    """
    Dynamically pull qualified campaigns list from the correct validation group.
    Checks both 'campaign_validations' (during) and 'campaign_validations_post' (post-period).
    Returns the first non-null result.
    """
    if type == "meta_data":
        return """
    {%- set during = task_instance.xcom_pull(task_ids="campaign_validations.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
    {%- set post = task_instance.xcom_pull(task_ids="campaign_validations_post.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
    {%- set selected = during if during else post -%}
    {{ (selected.split(',') if selected else []) | tojson }}
    """.strip()
    else:
        return """
        {%- set during = task_instance.xcom_pull(task_ids="campaign_validations.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
        {%- set post = task_instance.xcom_pull(task_ids="campaign_validations_post.qualified_campaigns.qualified_campaigns_list", key="return_value") -%}
        {{ during if during else post }}
        """.strip()


# TODO: we need to update this function to grab all campaign start and end dates and return as json
def get_campaign_dates():
    """Return campaign dates as JSON object"""
    return """
    {%- set start_date = task_instance.xcom_pull(task_ids="setup_tasks.configure_model_start_end_dates", key="start_date") -%}
    {%- set end_date = task_instance.xcom_pull(task_ids="setup_tasks.configure_model_start_end_dates", key="end_date") -%}
    {{ {"start_date": start_date, "end_date": end_date} | tojson }}
    """.strip()


# ToDo: We might want to make this function dynamic even though it is only used in post-period currently
def get_manual_campaigns_list_filtered(post_camp_list="campaign_validations_post.campaign_validation.filter_manual_campaigns"):
    """
    Returns the filtered manual campaigns list that only includes campaigns that exist in the validation.
    This pulls from the campaign_validation.filter_manual_campaigns task result.
    """
    return f'{{{{task_instance.xcom_pull(task_ids="{post_camp_list}", key="return_value")}}}}'


def get_mlflow(topic: str):
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_mlflow.__wrapped__.__name__}", key="{topic}")}}}}'


def pipeline_run_type():
    # TODO: if configure_run_type() returns dict like {"run_type": <actual value>} then use key="run_type" here
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_run_type.__wrapped__.__name__}", key="return_value")}}}}'


def pipeline_run_type_name():
    """Get just the run type name in lowercase (e.g., 'pollen', 'dtp')."""
    # TODO: if configure_run_type() returns dict like {"run_type": <actual value>} then use key="run_type" here
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_run_type.__wrapped__.__name__}", key="return_value") | lower}}}}'


def get_campaign_end_date():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_campaign_end_date.__wrapped__.__name__}", key="return_value")}}}}'


def get_post_period_end_date():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_post_period_end_date.__wrapped__.__name__}", key="return_value")}}}}'


def get_git_hash(pipeline_stage: str, type: str = 'dags'):
    if type in ["dags_base", "pipelines_base"]:
        return f'{{{{ task_instance.xcom_pull(task_ids="commit_metadata_{pipeline_stage}.get_git_commits", key="{type}")}}}}'
    else:
        return f'{{{{ task_instance.xcom_pull(task_ids="commit_metadata_{pipeline_stage}.get_git_commits", key="{type}") | tojson}}}}'


def resolve_pipelines_version(environment: str) -> str:
    """
    Macro to resolve pipelines git commit hash value - fetches from SSM if value is 'latest',
    otherwise returns the provided value.

    Note: This function intentionally does NOT cache SSM values to ensure
    each EMR step uses the most current pipelines commit hash value. SSM parameter
    containing pieplines commit hash can be updated during pipeline run (e.g., for hotfixes),
    and we prioritise freshness over caching. AWS SSM Standard Parameters have
    unlimited free API calls with no charges, so there's no cost concern.

    This is designed to be called from Jinja templates where the actual value
    is available (not just the template string).

    Args:
        environment: The environment ('dev' or 'prod') to fetch the parameter for

    Returns:
        Either the SSM parameter value (if 'latest') or the configured custom pipelines
        hash value

    """

    # Get the actual value from XCom
    context = get_current_context()
    ti = context.get('ti')

    if ti is None:
        raise ValueError("Task instance not available in context")
    pipelines_hash_value = ti.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    if pipelines_hash_value == "latest":
        return get_pipelines_commit_hash(environment, context)

    return pipelines_hash_value


@task()
def get_git_commits(environment: str) -> dict:

    context = get_current_context()
    git_commits = {}
    ti = context.get('ti')

    if ti is None:
        raise ValueError("Task instance not available in context")

    # Refresh dags commits by calling configure_dag_version logic
    platform = get_airflow_platform()
    # get fresh dags commit hash values
    _ = get_dag_commit_hash(platform, context)

    dags_commits = ti.xcom_pull(
        key=XComKeys.DAGS_COMMIT_LIST
    )

    git_commits['dags'] = dags_commits or []

    git_commits['dags_base'] = dags_commits[0][:7] if dags_commits else None

    configured_pipelines_hash_value = ti.xcom_pull(
        task_ids='setup_tasks.configure_pipelines_version',
        key='return_value'
    )

    if configured_pipelines_hash_value == "latest":
        # get fresh pipelines commit hash value
        _ = get_pipelines_commit_hash(environment=environment, context=context)
        fresh_pipelines_hash_values = ti.xcom_pull(
            key=XComKeys.PIPELINES_COMMIT_LIST
        )
        git_commits['pipelines'] = fresh_pipelines_hash_values or []
        git_commits['pipelines_base'] = fresh_pipelines_hash_values[0][:7] if fresh_pipelines_hash_values else None
    else:
        git_commits['pipelines'] = [configured_pipelines_hash_value]
        git_commits['pipelines_base'] = configured_pipelines_hash_value

    return git_commits


def get_during_correlation_id():
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_ci_of_during_run.__wrapped__.__name__}", key="return_value")}}}}'


def get_resolved_during_correlation_id():
    return '{{task_instance.xcom_pull(task_ids="during_lookup.during_correlation_id", key="return_value")}}'


def get_current_aws_user():
    """Get the current AWS user's name for cluster naming and pipeline metadata."""
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_aws_user.__wrapped__.__name__}", key="return_value")}}}}'


def get_random_master_instance_type():
    """Get a random master instance type based on weights.
    This is to support multiple DAG runs in dev environment where we can hit capacity issues.
    Once we fix parallelisation issues linked to campaign/job bag number, we can remove this and just use a single instance type.
    """
    return f'{{{{task_instance.xcom_pull(task_ids="setup_tasks.{configure_master_instance_type.__wrapped__.__name__}", key="return_value")}}}}'


def get_validation_check_details(task_id: str):
    return f'{{{{task_instance.xcom_pull(task_ids="{task_id}", key="return_value")}}}}'
