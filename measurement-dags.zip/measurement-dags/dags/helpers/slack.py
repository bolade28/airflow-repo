from airflow.providers.slack.operators.slack import SlackAPIPostOperator
from airflow.sdk import Variable
from helpers.constants import DEV, PROD
from helpers.setup import get_environment


def is_this_prod():
    """This  method checks the environment if the env is Dev, then
     it will return False which will skip the task to send alerts in dev env
    Returns:
        Bool: True or False
    """
    return True if get_environment() == PROD else False


def task_fail_slack_alert(context):
    """
    Sends message to a slack channel.
    If you want to send it to a "user" -> use "@user",
        if "public channel" -> use "#channel",
        if "private channel" -> use "channel"
    """

    env = Variable.get('MEASUREMENT_ENVIRONMENT')
    slack_channel = f'#measurement-{env}-alerts'
    failed_alert = SlackAPIPostOperator(
        task_id='slack_failed',
        channel=slack_channel,
        text="""
            :red_circle: Task Failed.
            *Task*: {task}
            *Dag*: {dag}
            *Execution Time*: {exec_date}
            *Log Url*: {log_url}
            """.format(
            task=context.get('task_instance').task_id,
            dag=context.get('task_instance').dag_id,
            exec_date=context.get('execution_date'),
            log_url=context.get('task_instance').log_url,
        )
    )
    return failed_alert.execute(context=context)


def task_succeed_slack_alert(context):
    """
    Sends message to a slack channel.
    If you want to send it to a "user" -> use "@user",
        if "public channel" -> use "#channel",
        if "private channel" -> use "channel"
    """
    if Variable.get('MEASUREMENT_ENVIRONMENT') == DEV:

        env = Variable.get('MEASUREMENT_ENVIRONMENT')
        if env == PROD:
            slack_channel = f'#measurement-{env}-alerts'

        success_alert = SlackAPIPostOperator(
            task_id='slack_success',
            channel=slack_channel,
            text="""
                :large_green_circle: Task Succeeded at: {exec_date}
                *Dag*: {dag}
                *Task*: {task}
                """.format(
                task=context.get('task_instance').task_id,
                dag=context.get('task_instance').dag_id,
                exec_date=context.get('execution_date')
            )
        )
    return success_alert.execute(context=context)
