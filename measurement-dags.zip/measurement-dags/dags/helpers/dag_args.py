from datetime import timedelta
from helpers.slack import task_fail_slack_alert

DEFAULT_DAG_ARGS = {
    'owner': 'MEASUREMENT',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 4,
    'retry_delay': timedelta(minutes=5),
    'catchup': False,
    'snowflake_conn_id': 'snowflake_conn_private_key',
    'aws_conn_id': 'aws_default',
    'on_failure_callback': task_fail_slack_alert,
}
