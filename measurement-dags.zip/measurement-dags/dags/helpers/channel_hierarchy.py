# Marketing hierarchy codes that are in scope for measurement reporting
# Source: ADW_RDV.MARKETING_MEDIA_HIERARCHY_MKTHRC_REF
INSCOPE_HIERARCHY_CODE = [
    4028,  # Sponsored Products - Sainsburys Search App
    4027,  # Sponsored Products - Sainsburys Pdp Similar Items
    4026,  # Sponsored Products - Sainsburys Offers
    4025,  # Sponsored Products - Sainsburys Cross Sell
    4022,  # Sponsored Products - Sainsburys Checkout Before You Go
    4018,  # Sponsored Products - Argos Or Sainsburys Search
    4017,  # Sponsored Products - Argos Or Sainsburys Homepage
    4016,  # Sponsored Products - Argos Or Sainsburys Browse
    4013,  # eCoupons
    3014,  # Video - Youtube
    3009,  # Social - Meta
    3001,  # Display - DV360
    2193,  # Trolley - Main Estate
    2189,  # Till Dividers - Main Estate
    2188,  # Till Dividers - Convenience
    2183,  # Sugar Showcase - Main Estate
    2181,  # Slim Plinth 4 - Main Estate
    2180,  # Slim Plinth 3 - Main Estate
    2179,  # Slim Plinth 2 - Main Estate
    2178,  # Slim Plinth 1 - Main Estate
    2159,  # Sampling - Main Estate - Power Aisle - Standard
    2157,  # Sampling - Main Estate - In Aisle - Standard
    2156,  # Sampling - Main Estate - In Aisle - Active Sell
    2135,  # Pos Box - Main Estate
    2078,  # Freezer Fins - Convenience - JS Templated
    2074,  # Floor Stickers - Main Estate
    2068,  # Fins - Main Estate - JS Templated
    2067,  # Fins - Main Estate - Fully Branded
    2059,  # Entrance Gates - Main Estate - Fully Branded
    2055,  # Digital Screens - In Store
    2198,  # Digital Screens - Main Estate
    2051,  # Coupon At Till - Main Estate - Smart Counts
    2050,  # Coupon At Till - Main Estate - Bespoke
    2028,  # Blank Ends - Main Estate
    2012,  # Barkers - Main Estate - JS Templated
    1012,  # Print Magazine - Coupon
    1011,  # Print Magazine - Advertorial Page
]

# Codes NOT ready for measurement
NOT_READY_CODE = {1012, 1011}

# Derive measurement ready list
MEASUREMENT_READY_CODE = [code for code in INSCOPE_HIERARCHY_CODE if code not in NOT_READY_CODE]

# Subchannel hierarchy mapping for customer engagement
# The Code is a permanent business identifier that will not change
# We will be adding more subchannels as business requirements evolve
SUBCHANNELS_CODE = {
    "ecoupons": [4013],
    "dv360": [3001],
    "meta": [3009],
    "youtube": [3014],
    "coupon_at_till": [2050, 2051],
    "instore": [
        2028, 2074, 2068, 2067, 2059, 2055, 2050,
        2051, 2078, 2135, 2156, 2157, 2159, 2178,
        2179, 2180, 2181, 2183, 2188, 2189, 2193,
        2012, 2198, 2199, 2200, 2201, 2202, 2203,
        2204, 2205, 2206, 2207, 2208, 2209
    ],
}

MARKETING_TYPE = {"offsite": "offsite", "onsite": "onsite", "instore": "instore"}
