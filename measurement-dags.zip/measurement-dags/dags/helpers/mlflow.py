
from airflow.sdk import Variable


class MLFLOW:
    """Class to manage MLflow configurations based on the environment.
    dev: s3://measurement-dev-mlflow/artifacts/
    prod: s3://measurement-prod-mlflow/artifacts/
    Artifacts are stored in S3, and the MLflow tracking server is hosted internally.
    """
    def __init__(self):
        self.env = Variable.get("MEASUREMENT_ENVIRONMENT")

    def tracker_uri(self):
        return f"http://mlflow.{self.env}.measurement.internal:5000"

    def all(self):
        return {
            'tracker_uri': self.tracker_uri()
        }
