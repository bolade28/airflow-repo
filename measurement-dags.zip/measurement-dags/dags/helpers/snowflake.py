from typing import List, Tuple

import pendulum
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from js_snowflake.hooks.snowflake import SnowflakeKeyArnHook as SnowflakeHook

from helpers.constants import (
    SNOWFLAKE_CONN_ID,
    POLLEN_RUN_TYPE,
    EvaluationPhase,
)


class MeasurementSnowflakeOperator(SQLExecuteQueryOperator):
    """
    This operator just adds an extra round of Jinja templating to the standard SnowflakeOperator which
    allows us to handle a special case.
    We have two set up steps at the beginning which serve to push ASPIRE table names and the various s3
    paths we require into the XCOM table for the dag run.

    This means the paths for that dag run would not be changed if the underlying code is updated, UNLESS
    someone re-runs the setup tasks that push the table names and paths into the XCOM table. This helps us
    maintain idempotency, but in order to render table names in SQL we need two rounds of Jinja templating.
    e.g. consider this line at the top of the l2_transactions.sql:
    COPY INTO {{ get_path('l2_transactions_query', s3=False) }}

    The get_path() macro is a convenience function which returns a string of the xcom to pull, in this example:
    '@measurement_[dev|prod]stage/{{task_instance.xcom_pull(task_ids="configure_paths", key="l2_transactions_query")}}'
    where [dev|prod] depends on which environment the DAG is running.
    This requires templating a second time to replace the returned {{ }} string, which the becomes:
    '@measurement_[dev|prod]_stage/some_correlation_id/l2_transactions_query'

    So assuming we were running in dev, with the correlation_id 12345-abcde the templating would go like this:
    START:  COPY INTO {{ get_path('l2_transactions_query', s3=False) }}
    FIRST:  COPY INTO @measurement_dev_stage/{{task_instance.xcom_pull(task_ids="configure_paths", key="l2_transactions_query")}}
    SECOND: COPY INTO @measurement_dev_stage/12345-abcde/l2_transactions_query
    """
    ui_color = "#fdb462"  # Sainsbury's orange!

    def __init__(self, *, conn_id: str = SNOWFLAKE_CONN_ID, **kwargs) -> None:
        super().__init__(conn_id=conn_id, **kwargs)

    def pre_execute(self, context):
        self.log.info('Rendering templates')
        context['ti'].render_templates()


def check_if_we_should_run_post_campaign_period(run_date: str, table_name: str) -> bool:
    """
    If given run_date is in month 1 (January), AND if table_name does not yet have data for previous year, return True;
    else return False
    """
    date_ob = pendulum.from_format(run_date, 'YYYY-MM-DD')
    current_month = date_ob.month
    previous_year = date_ob.subtract(years=1).year

    if current_month != 1:
        print("It is not January. Skipping post_campaign_period SQL execution.")
        return False

    hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
    result: List[Tuple[int]] = hook.get_records(
        f"""
        SELECT 1
        FROM {table_name}
        WHERE YEAR_OF_TRANSACTION = {previous_year} LIMIT 1
        """
    )

    print(f"RESULT BTW: {result}")

    if any(result):
        print("Previous year's data already exists. Skipping post_campaign_period SQL execution.")
        return False

    print(f"No data found for year {previous_year} in post_campaign_period table {table_name}, and current month is {current_month} - will run SQL to create it...")
    return True


def resolve_during_correlation_id(
        configured_during_cid: str,
        configured_campaign_id: str,
        table: str,
        run_type: str,
) -> str:
    """
    Resolve the "during" correlation ID for a given campaign.

    This function returns the latest correlation ID associated with the provided
    campaign ID by querying the measurement campaign execution table in Snowflake.
    If a specific correlation ID is already configured (i.e., not set to `"latest"`),
    the function returns it directly and logs that it was used.

    When `"latest"` is specified, the function looks up the most recent record
    (based on `load_ts`) where:
        • the campaign identifier matches (`booking_id` for POLLEN runs, otherwise
          `job_bag_number`)
        • the campaign duration equals `"during"`

    If no corresponding record is found, a `ValueError` is raised.

    Parameters
    ----------
    configured_during_cid : str
        The "during" correlation ID specified in configuration.
        If equal to `"latest"`, the function will attempt to fetch the newest
        correlation ID from Snowflake. Otherwise, the provided value is returned
        without querying Snowflake.

    configured_campaign_id : str
         This is the booking_id/job bag number provided as part of DAG parameter
         when kicking off the pipeline.

    table : str
        Name of the Snowflake table containing campaign execution data.

    run_type : str
        The type of run being executed. Determines which column is used as the
        campaign identifier. When equal to `POLLEN_RUN_TYPE`, `booking_id` is used;
        otherwise `job_bag_number`.

    Returns
    -------
    str
        The resolved correlation ID—either the configured value or the latest value
        retrieved from Snowflake.
    """

    if configured_during_cid != 'latest':
        print(f"Using configured correlation id for this post run: {configured_during_cid}")
        return configured_during_cid
    else:
        hook = SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)
        col_name = "booking_id" if run_type == POLLEN_RUN_TYPE else "job_bag_number"
        result: List[Tuple[int]] = hook.get_records(
            f"""
            select correlation_id
            from {table}
            where {col_name} = '{configured_campaign_id}'
            and lower(campaign_duration) = lower('{EvaluationPhase.DURING.value}')
            order by load_ts desc
            limit 1
            """
        )
        if not result or result[0][0] is None:
            raise ValueError(
                f"unable to fetch correlation id for campaign "
                f"{configured_campaign_id} in table {table}. "
                f"Please check that the campaign id is correct and that "
                f"there is data in the table for that campaign id."
            )

        return result[0][0]
