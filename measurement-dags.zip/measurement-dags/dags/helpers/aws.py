from io import BytesIO
import json
from datetime import datetime
import os
from pprint import pprint
from typing import Dict, List, Optional, Tuple

import boto3
from airflow.sdk import task
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.amazon.aws.hooks.ssm import SsmHook
from airflow.providers.amazon.aws.operators.s3 import S3ListOperator
from airflow.utils.context import Context

from helpers.constants import FileExists


def convert_rundate(run_date: str) -> str:
    dt = datetime.fromisoformat(run_date)
    yyyy, mm, dd = format(dt.year, '02d'), format(dt.month, '02d'), format(dt.day, '02d')
    return yyyy, mm, dd


def split_s3_path(s3_path: str, filename: Optional[str] = None) -> Tuple[str, str]:
    path = s3_path if filename is None else os.path.join(s3_path, filename)
    path_parts = path.replace("s3://", "").split("/")
    bucket = path_parts[0]
    key = "/".join(path_parts[1:])
    return bucket, key


@task
def split_s3_path_task(s3_path: str, filename: Optional[str] = None) -> Dict[str, str]:
    bucket, key = split_s3_path(s3_path, filename)
    return {
        "bucket": bucket,
        "key": key,
    }


def get_secret(secret_name: str) -> Dict:
    """
    Fetches secrets from AWS Secrets Manager
    :param str secret_name: The name of the secret to be fetched
    :return: Dict containing key-value pairs of names to secret values
    """
    region_name = "eu-west-1"
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    return json.loads(get_secret_value_response['SecretString'])


def write_json_to_s3(json_data: dict, s3_path: str) -> None:
    buffer = BytesIO()
    buffer.write(json.dumps(json_data).encode())
    buffer.seek(0)
    bucket, path = split_s3_path(s3_path)
    s3 = boto3.client('s3')
    s3.put_object(Body=buffer, Bucket=bucket, Key=path)


def assume_role(role_arn: str, correlation_id: str, session_name: str) -> dict:
    sts_client = boto3.client('sts')
    assumed_role_object = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=f'{session_name}_{correlation_id}'[:64]
    )
    pprint(assumed_role_object['AssumedRoleUser'])
    return assumed_role_object['Credentials']


def copy_files(
    source_file_names: List[str],
    source_prefix: str,
    source_bucket_name: str,
    target_prefix: str,
    target_bucket_name: str,
    s3_client
) -> None:
    for key in source_file_names:
        s3_client.copy_object(
            ACL='bucket-owner-full-control',
            Bucket=target_bucket_name,
            Key=f'{target_prefix}/{key}',
            CopySource={
                'Bucket': source_bucket_name,
                'Key': f'{source_prefix}/{key}'
            }
        )


def get_s3_iterator(s3_client, source_bucket_name: str, source_prefix: str):
    paginator = s3_client.get_paginator('list_objects_v2')
    return paginator.paginate(
        Bucket=source_bucket_name,
        Prefix=source_prefix
    )


def list_source_files(
    s3_client: str,
    source_bucket_name: str,
    source_prefix: str,
    source_type: str
) -> List[str]:
    offers_files = []
    """
    List source files based on the input source type
    -------------
    Return for Csv,  Parquet
    -------------

    List[str]
    """

    if source_type not in ["csv", "parquet", "json"]:
        raise ValueError("The source type is not supported")

    pages = get_s3_iterator(s3_client, source_bucket_name, source_prefix)

    offers_files = [file['Key'].split("/")[-1] for page in pages for file in page['Contents'] if f'.{source_type}' in file['Key']]

    return offers_files


class FileExistsOperator(S3ListOperator):
    """
    Given an S3 bucket and prefix, do any files exist there?
    Returns "YES" if at least one files exists and "NO" otherwise.

    Use of YES/NO avoids truthy/falsy values which are rendered into Python True / False
    objects when used in Jinja templating.
    """
    def execute(self, context: Context):
        hook = S3Hook(aws_conn_id=self.aws_conn_id, verify=self.verify)

        self.log.info(
            "Getting the list of files from bucket: %s in prefix: %s (Delimiter %s)",
            self.bucket,
            self.prefix,
            self.delimiter,
        )

        ll = hook.list_keys(bucket_name=self.bucket, prefix=self.prefix, delimiter=self.delimiter)

        if len(ll) > 0:
            return FileExists.YES.value
        else:
            return FileExists.NO.value


def get_ssm_parameter(param_name: str) -> str:
    """
    Read SSM parameter value from AWS Parameter Store.

    Args:
        parameter_name: The parameter name (e.g., '/measurement/dev/pipelines/commit-hash')
        region: AWS region (default: 'eu-west-1')

    Returns:
        The parameter value as a string
    """
    ssm = SsmHook()

    try:
        ssm_param = ssm.get_parameter_value(param_name)
        return ssm_param
    except Exception as e:
        if 'ParameterNotFound' in str(e):
            raise ValueError(f"Parameter '{param_name}' not found")
        raise Exception(f"Error retrieving parameter: {e}")
