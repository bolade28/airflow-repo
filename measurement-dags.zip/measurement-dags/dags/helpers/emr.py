from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

from airflow.sdk import Variable
from airflow.task.trigger_rule import TriggerRule
from airflow.providers.amazon.aws.operators.emr import (
    EmrAddStepsOperator,
    EmrCreateJobFlowOperator,
    EmrTerminateJobFlowOperator,
)
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor
from templates.emr.cluster_config import job_flow
from templates.emr.ebs_config import ebs_config
from templates.emr.step_config import step_config
from helpers.constants import REGION_NAME, INSTANCE_TYPES, DEV
from helpers.setup import get_environment
from helpers.xcom import (
    get_ci,
    get_pipelines_version,
    get_cluster_id,
    pipeline_run_type_name,
    get_current_aws_user,
    get_random_master_instance_type,
)

master_node_ebs = ebs_config(512, 8)


@dataclass
class Step:
    step_name: str
    step_script: str
    step_args: List[Tuple[str, str]]


class EmrLinkedSensor(EmrStepSensor):
    """
    This class just inherits the EmrStepSensor class, except it takes the kwarg job_flow_id2
    when it is instantiated which is used to set the attribute job_flow_id.
    On its own this would be totally pointless, but it is necessary to create a single operator
    from the add_step and step_sensor operators via multiple inheritance because both of these
    operators require the job_flow_id kwarg causing a name clash.
    """

    def __init__(self, **kwargs):
        kwargs['job_flow_id'] = kwargs['job_flow_id2']
        kwargs.pop('job_flow_id2')
        super().__init__(**kwargs)


class EmrAddAndWatchStep(EmrAddStepsOperator, EmrLinkedSensor):
    """
    Create a single operator which adds and then watches an EMR step.
    Uses multiple inheritance
    """

    ui_color = "#bc80bd"  # Nectar purple!

    def __init__(self, **kwargs):
        kwargs['step_id'] = None
        kwargs['job_flow_id2'] = kwargs['job_flow_id']  # prevent name clash between EmrAddStepsOperator & EmrStepSensor
        #  kwarg['job_flow_id'] used by EmrAddStepsOperator
        #  kwarg['job_flow_id2'] used by EmrLinkedSensor which just uses this kwarg to set the job_flow_id attribute
        super(EmrAddAndWatchStep, self).__init__(**kwargs)

    def execute(self, context):
        self.step_id = super(EmrAddAndWatchStep, self).execute(context)[0]
        super(EmrLinkedSensor, self).execute(context)
        return self.step_id


def launch_cluster(
    name: str,
    master_instance_type: str = "r6in.8xlarge",
    core_instance_types: List[Dict[str, Union[str, int]]] = INSTANCE_TYPES
) -> EmrCreateJobFlowOperator:
    ci = get_ci()
    env = get_environment()

    if env == DEV:
        cluster_name = f'{name}-{Variable.get("MEASUREMENT_ENVIRONMENT")}-{ci}-{pipeline_run_type_name()}-{get_current_aws_user()}'
        master_instance_type = get_random_master_instance_type()
    else:
        cluster_name = f'{name}-{Variable.get("MEASUREMENT_ENVIRONMENT")}-{ci}-{pipeline_run_type_name()}'

    config = job_flow(
        name=cluster_name,
        master_ebs_config=master_node_ebs,
        master_instance_type=master_instance_type,
        core_instance_types=core_instance_types,
        tags={
            "Name": f"{name}-{Variable.get('MEASUREMENT_ENVIRONMENT')}"
        }
    )

    cluster = EmrCreateJobFlowOperator(
        task_id='create_emr_cluster',
        job_flow_overrides=config,
        region_name=REGION_NAME,
        wait_for_completion=True,
        waiter_delay=10,
        waiter_max_attempts=90  # gives max 15 mins to spin up before failing the task
    )

    return cluster


def terminate_cluster(
    job_flow_id: str,
    trigger_rule: TriggerRule = TriggerRule.ALL_DONE
) -> EmrTerminateJobFlowOperator:

    return EmrTerminateJobFlowOperator(
        task_id="terminate_emr_cluster",
        job_flow_id=job_flow_id,
        trigger_rule=trigger_rule
    )


def add_and_watch_step(
    step_args: List[Tuple[str, str]],
    step_name: str,
    step_script: str,
    cpus_per_task: int = 1,
    executor_cores: int = 5,
    executor_memory: str = "30g",
    use_iceberg: bool = False,
    num_executors: int = 10,
    packages: Optional[List[str]] = None,
    default_parallelism: Optional[int] = None,
    trigger_rule: TriggerRule = TriggerRule.ALL_SUCCESS,
) -> EmrAddAndWatchStep:

    if default_parallelism is None:
        default_parallelism = num_executors * 3 * 3
    """
    Create an EMR step and watch it until it completes.

    :param step_args:           The CLI args for the PySpark script.
    :param step_name:           The name of the EMR step.
    :param step_script:         The name of the PySpark script to execute.
    :param cpus_per_task:       The number of CPUs to use for each task.
    :param executor_cores:      The number of cores to use on each executor.
    :param executor_memory:     The amount of memory to use per executor process.
    :param use_iceberg:         Whether to use Iceberg for the step.
    :param num_executors:       The number of Spark executors to use to run the step.
    :param packages:            A list of Maven coordinates required to run the step.
    :param default_parallelism: The default number of partitions in RDDs
    :param trigger_rule:        The Airflow rule by which the task should trigger (
                                default: all upstream dependencies succeeded).

    :return:                    An EmrAddAndWatchStep operator.
    """

    env = get_environment()
    glue_warehouse = f"s3://measurement-{env}-etl-output"

    config = step_config(
        step_args=step_args,
        step_name=step_name,
        step_script=step_script,
        cpus_per_task=cpus_per_task,
        default_parallelism=default_parallelism,
        environment=env,
        executor_cores=executor_cores,
        use_iceberg=use_iceberg,
        glue_warehouse=glue_warehouse,
        executor_memory=executor_memory,
        num_executors=num_executors,
        pipelines_commit_hash=get_pipelines_version(),
        packages=packages,
    )

    step = EmrAddAndWatchStep(
        trigger_rule=trigger_rule,
        task_id=step_name,
        steps=[config],
        job_flow_id=get_cluster_id(),
        poke_interval=15
    )

    return step
