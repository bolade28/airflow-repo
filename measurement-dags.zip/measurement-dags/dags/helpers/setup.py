import os
import uuid
import random
from datetime import datetime
import boto3
import pendulum
from typing import Optional, Dict

from airflow.sdk import task
from airflow.sdk import Variable
from airflow.providers.standard.operators.python import get_current_context

from helpers.constants import (
    CLUSTER_DEFAULT_COMPUTE_UNITS,
    MASTER_INSTANCE_TYPES,
    PROD_ACCOUNT_NUMBER,
    DEV_ACCOUNT_NUMBER,
    PROD,
    DEFAULT_RUN_TYPE,
)
from helpers.tables import Snowflake
from helpers.paths import Paths
from helpers.sns import SNS
from helpers.mlflow import MLFLOW
from helpers.utils import get_dag_commit_hash


def get_environment() -> str:
    return Variable.get("MEASUREMENT_ENVIRONMENT")


def get_airflow_platform() -> str:
    return Variable.get("AIRFLOW_PLATFORM")


def get_build_hash() -> str:
    return Variable.get("BUILD_HASH")


@task
def get_config() -> Dict[str, str]:
    return {
        "environment": get_environment()
    }


def get_value_from_context(context, default, dag_conf_key):
    if context['dag_run'].conf:
        return context['dag_run'].conf.get(dag_conf_key, default)
    else:
        return default


#
#  ---- Setup tasks that push to XCOM
#
"""
The @task decorated functions all push their return value to a xcom entry for that task.
That value can then be used in other tasks by pulling the appropriate xcom entry.
"""


@task
def configure_compute_units(default: int = CLUSTER_DEFAULT_COMPUTE_UNITS) -> int:
    """
    If you call this function as part of your DAG setup you can ensure a sensible default
    size for your DAGs EMR cluster, e.g. configure_compute_units(16).
    """
    context = get_current_context()
    return int(get_value_from_context(context=context, default=default, dag_conf_key='compute_units'))


@task
def configure_correlation_id(date_based: bool = False) -> str:
    """
    Pass in the data_based bool value as True to get the correlation ID in format `yyyy-dd-mm/<8_random_letters>`.
    Otherwise, the correlation ID will be random.
    """
    if date_based:
        return os.path.join(datetime.now().strftime("%Y-%m-%d"), str(uuid.uuid4()).split('-')[0])
    else:
        return str(uuid.uuid4())


@task
def configure_pipelines_version() -> str:
    """
    Used to point spark to a path on the artefacts bucket to a particular version of a script,
    e.g. s3://measurement-dev-artefacts/{pipelines_version}/some_script.py
    The default value of oa_version is 'latest'
    :return:
    """
    context = get_current_context()
    return get_value_from_context(context=context, default='latest', dag_conf_key='pipelines_hash')


@task
def configure_campaign_end_date() -> str:
    """
    Returns the end date for the pipeline run.
    If not specified in the DAG config, it defaults to today's date in 'YYYY-MM-DD' format.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default=pendulum.now().to_date_string(),
        dag_conf_key='campaign_end_date'
    )


@task
def configure_post_period_end_date() -> str:
    """
    Returns the post period end date for the pipeline run.
    If not specified in the DAG config, it defaults to today's date in 'YYYY-MM-DD' format.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default=pendulum.now().to_date_string(),
        dag_conf_key='post_period_end_date'
    )


@task(multiple_outputs=True)
def configure_paths(correlation_id: str, dt: Optional[str] = None):
    return Paths(correlation_id, dt).paths


@task
def configure_seed() -> int:
    return random.randint(0, 1_000_000)


@task(multiple_outputs=True)
def configure_snowflake_tables(ci: str = None) -> Dict[str, str]:
    return Snowflake(correlation_id=ci).tables


@task(multiple_outputs=True)
def configure_sns() -> Dict[str, str]:
    return SNS().all()


@task
def job_flow_start_time():
    return datetime.now(tz=None).replace(microsecond=0).isoformat()


def get_account_number() -> str:
    return PROD_ACCOUNT_NUMBER if get_environment() == PROD else DEV_ACCOUNT_NUMBER


@task
def parse_dag_config() -> Dict[str, str]:
    config = get_current_context()["dag_run"].conf
    return {
        "source_bucket_key": config["source_bucket_key"],
        "destination_bucket_key": config["destination_bucket_key"]
    }


@task(multiple_outputs=True)
def configure_campaign_start_date():
    """
    Campaign start year = 2025 if environment = prod otherwise 2023
    Campaign start month = 02 if environment = prod otherwise 01
    """

    return {
        'year': '2025' if get_environment() == PROD else '2023',
        'month': '02' if get_environment() == PROD else '01'
    }


@task
def configure_campaigns():
    """
    Returns a list of manually specified campaigns to run.
    If no manual campaigns are specified, it returns an empty list.
    """
    context = get_current_context()
    return str(get_value_from_context(
        context=context,
        default=[],
        dag_conf_key='manual_run_campaign_list'
    ))


@task
def configure_mlflow() -> Dict[str, str]:
    """
    Configures MLflow tracking URI based on the environment.
    Returns a dictionary with the MLflow tracker URI.
    """
    mlflow = MLFLOW()
    return mlflow.all()


# TODO:: This function will be updated to retrieve dates from weekly_dates table for consistency
@task(multiple_outputs=True)
def configure_model_start_end_dates(
    run_date: str,
    default_model_start_date: str,
    daily_etl_flag: bool = False
) -> Dict[str, str]:
    """
    Calculate start and end dates based on input parameters.

    Args:
        run_date (str): End of the data interval of the pipeline in 'YYYY-MM-DD' format.
        default_model_start_date (str): The minimum allowed start date in 'YYYY-MM-DD' format.
        daily_etl_flag (bool): Flag indicating whether the pipeline is a daily ETL. If True, start date is set to default_model_start_date.

    Returns:
        dict: A dictionary with 'start_date' and 'end_date' as datetime.date objects.
    Raises:
        ValueError: If `campaign_end_date` is provided in the DAG config but is not a valid date string in 'YYYY-MM-DD' format.

    Notes:
        Please note this function used to normalise the end date to a Monday, however, this means we miss campaigns that end mid-week.
        Since this is passed in as a input into the feature processed scripts we want to allow for end dates that are mid-week so that we can capture all relevant campaigns.

        The weekly dates script already normalises the week start date to a Monday, so this is in the correct format and it is not necessary to also normalise the end date to a Monday here.
    """

    min_start_date = pendulum.parse(default_model_start_date).date()
    context = get_current_context()
    dag_param_model_end_date = get_value_from_context(
        context=context,
        default=pendulum.now().to_date_string(),
        dag_conf_key='campaign_end_date'
    )

    if dag_param_model_end_date:
        try:
            if dag_param_model_end_date:
                end_date = pendulum.parse(dag_param_model_end_date).date()
        except Exception as e:
            raise ValueError(f"Invalid model_end_date provided: {e}")
    else:
        end_date = pendulum.parse(run_date).date()

    # Setting model start date to three years ago from today
    if daily_etl_flag:
        start_date = pendulum.parse(default_model_start_date).date()
    else:
        three_years_ago = end_date.subtract(years=3)
        start_date = three_years_ago.subtract(days=three_years_ago.day_of_week)

    if start_date < min_start_date:
        start_date = min_start_date

    return {'start_date': start_date.strftime('%Y-%m-%d'), 'end_date': end_date.strftime('%Y-%m-%d')}


@task
def configure_run_type() -> str:
    """
    Returns:
        run_type (str): The run type for the pipeline (e.g., "Pollen" or "DTP"), as set with the DAG config parameter.
    """
    context = get_current_context()
    run_type = get_value_from_context(
        context=context,
        default=DEFAULT_RUN_TYPE,
        dag_conf_key='pipeline_run_type'
    )

    if not run_type:
        raise ValueError("run_type must be provided in DAG config. Acceptable values are 'Pollen' or 'DTP'.")
    if run_type not in ['Pollen', 'DTP']:
        raise ValueError("Invalid run_type. Acceptable values are 'Pollen' or 'DTP'.")

    return run_type


@task(multiple_outputs=True)
def configure_dag_version() -> str:
    """
    Returns:
        dag_version (str): The version of the DAG, as set with the DAG config parameter.
        The version of DAG in docker will the the last  commit hash when merged to main branch.
        The version of DAG in EC2 will the the main branch commit hash when deployed to EC2.

    """

    platform = get_airflow_platform()
    context = get_current_context()
    commits = get_dag_commit_hash(platform, context)

    return {'git_commit': commits}


@task
def configure_ci_of_during_run() -> str:
    """
    Returns:
        ci_of_during_run (str): The correlation ID of the 'During' run, as set with the DAG config parameter.
    """
    context = get_current_context()
    return get_value_from_context(
        context=context,
        default='latest',
        dag_conf_key='ci_of_during_run'
    )


@task
def configure_aws_user():
    """Get the current AWS user's name for cluster naming."""
    try:
        # Get current user identity
        sts = boto3.client('sts')
        identity = sts.get_caller_identity()

        # Extract username from ARN
        arn = identity.get('Arn', '')

        if "instance-role" in arn:
            return "airflow-aws"

        user_name = arn.split('/')[-1].lower().split('@')[0]
        return user_name.replace(".", "-")

    except Exception as e:
        raise RuntimeError(f"Not logged in to AWS or credentials expired: {e}") from e


@task
def configure_master_instance_type() -> str:
    """Get a random master instance type based on weights.
    This is to suport multiple DAG runs in dev environment where we can hit capacity issues
    Once we fix parallisation issues linked to campaign/job bag number issue, we can remove this and just use a single instance type
    """
    instances = list(MASTER_INSTANCE_TYPES.keys())
    weights = list(MASTER_INSTANCE_TYPES.values())
    return random.choices(instances, weights=weights)[0]
