import logging
import os
import subprocess
from typing import Any, Dict, Optional
import boto3
import json
from datetime import datetime, timezone

from helpers.constants import (
    DTP_RUN_TYPE,
    POLLEN_RUN_TYPE,
    AIRFLOW_PLATFORM_DOCKER,
    AIRFLOW_PLATFORM_EC2,
    XComKeys
)
from helpers.dags_version import DAGS_COMMIT_HASH
from helpers.aws import get_ssm_parameter


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def is_dtp(run_type: str) -> bool:
    """Return True if the run type is DTP, False otherwise."""
    logger.info(f"Pipeline run type from XCom: {run_type}")
    if run_type == DTP_RUN_TYPE:
        return True
    else:
        return False


def is_pollen(run_type: str) -> bool:
    """Return True if the run type is POLLEN, False otherwise."""
    logger.info(f"Pipeline run type from XCom: {run_type}")
    if run_type == POLLEN_RUN_TYPE:
        return True
    else:
        return False


def decide_pollen_dtp(
        run_type: str,
        dtp_task_name: str,
        pollen_task_name: str,
        task_group_name: str
) -> str:
    if run_type == DTP_RUN_TYPE:
        return f"{task_group_name}.{dtp_task_name}"
    elif run_type == POLLEN_RUN_TYPE:
        return f"{task_group_name}.{pollen_task_name}"


def get_dag_commit_hash(platform: str, context) -> Dict[str, Any]:

    """
    Get the current DAG commit hash(es) based on the Airflow platform.

    Returns:
        Dict containing:
        - 'git_latest_commit': The primary commit hash to use
        - 'all_commits': List of all relevant commit hashes (for docker: [main_hash, latest_hash])
    """

    result = {
        'all_commits': []
    }

    if platform == AIRFLOW_PLATFORM_DOCKER:
        logging.info(f"AIRFLOW platform is: {platform}")
        git_latest_hash = get_docker_git_commits(ref_type='latest')
        git_main_hash = get_docker_git_commits(ref_type='main')

        logging.info(f"git latest commit hash is: {git_latest_hash}")
        logging.info(f"git main hash is: {git_main_hash}")

        result['git_latest_commit'] = git_latest_hash
        result['all_commits'] = [git_main_hash, git_latest_hash]

    elif platform == AIRFLOW_PLATFORM_EC2:
        logging.info(f"AIRFLOW platform is: {platform}")
        logging.info(f"DAG version from dags_version.py is: {DAGS_COMMIT_HASH}")

        result['git_latest_commit'] = DAGS_COMMIT_HASH
        result['all_commits'] = [DAGS_COMMIT_HASH]

    else:
        logging.warning("Unable to ascertain AIRFLOW platform. To get the git commit info, we need to get the airflow platform.")

    # Handle XCom push/pull for dags_commit_hash_list
    if context and 'ti' in context:
        ti = context['ti']

        # Get existing list or create new one
        git_commit_list = ti.xcom_pull(key=XComKeys.DAGS_COMMIT_LIST) or []

        # Add new commits if they're not already in the list
        for commit in result['all_commits']:
            if commit and commit not in git_commit_list:
                git_commit_list.append(commit)

        # Store the updated list back to XCom
        ti.xcom_push(key=XComKeys.DAGS_COMMIT_LIST, value=git_commit_list)

        logging.info(f"Updated dags_commit_hash_list in XCom: {git_commit_list}")

    return result


def get_docker_git_commits(ref_type: str) -> Optional[str]:
    # Returns full git commit hash
    # git root
    repo_root = os.getcwd()
    git_hash = None
    try:
        if ref_type == 'latest':
            git_hash = subprocess.check_output(
                ['git', 'rev-parse', 'HEAD'],
                cwd=repo_root,
                timeout=10,
                text=True,
                stderr=subprocess.STDOUT
            ).strip()
        elif ref_type == 'main':
            git_hash = subprocess.check_output(
                ['git', 'merge-base', 'HEAD', 'main'],
                cwd=repo_root,
                timeout=10,
                text=True,
                stderr=subprocess.STDOUT
            ).strip()
    except subprocess.CalledProcessError as e:
        logging.error(f"Error getting git hash: {e}")
    except FileNotFoundError:
        logging.warning("Git is not installed in this environment. Please update your local branch with main and rebuild your Docker image to track git commit hashes.")

    return git_hash


def get_pipelines_commit_hash(environment, context) -> str:
    """
    Get the current Pipelines commit hash from XCom.

    Returns:
        pipelines_commit_hash (str): The commit hash for Pipelines.
    """
    ti = context.get('ti')

    if ti is None:
        raise ValueError("Task instance not available in context")

    param_name = f'/measurement/{environment}/pipelines/commit-hash'
    resolved_value = get_ssm_parameter(param_name)

    # Get existing list or create new one
    existing_commits = ti.xcom_pull(
        key=XComKeys.PIPELINES_COMMIT_LIST
    ) or []

    # Append new value if not already in list
    if resolved_value not in existing_commits:
        existing_commits.append(resolved_value)

    ti.xcom_push(
        key=XComKeys.PIPELINES_COMMIT_LIST,
        value=existing_commits
    )

    return resolved_value


class MetricsPublisher(object):

    def __init__(self, topic_arn: str):
        self.sns = boto3.client("sns", region_name='eu-west-1')
        self.topic_arn = topic_arn

    def publish_event(self, message_subject: str, event):
        event_fields_dict = vars(event)
        self.publish_to_sns(event_fields_dict, message_subject)

    def publish_to_sns(self, event_fields_dict: Dict, message_subject: str):
        self.sns.publish(
            TopicArn=self.topic_arn,
            Subject=message_subject,
            MessageStructure="json",
            Message=json.dumps({
                'default': json.dumps(event_fields_dict)
            })
        )


class PostgreSQLColumn:
    def __init__(self, name: str, type: str, nullable: bool = True):
        self.name = name
        self.type = type
        self.nullable = nullable


def get_schema(columns):
    schema = {}

    for column in columns:
        if column.nullable:
            schema[column.name] = column.type
        else:
            schema[column.name] = f'{column.type} NOT NULL'
    return schema


class PGDataType:
    text = "text"
    boolean = "boolean"
    decimal = "decimal"
    bigint = "bigint"
    timestamp = "timestamp"
    jsonb = "jsonb"


def current_timestamp() -> str:
    """
    Returns current timestamp in UTC format
    """
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'


def get_current_timestamp():
    """Returns Jinja template for current time as HH:MM:SS."""
    return "{{ macros.datetime.now().strftime('%H:%M:%S') }}"


def get_current_iso_timestamp():
    """Returns Jinja template for current datetime as ISO string."""
    return "{{ macros.datetime.now().isoformat() }}"


def get_cluster_termination_cron(hours: int = 6) -> str:
    """Returns a Jinja cron expression to terminate the EMR cluster N hours from now."""
    return "{{{{ '0 ' + (macros.datetime.now() + macros.timedelta(hours={hours})).strftime('%H') + ' * * *' }}}}".format(hours=hours)
