from typing import Optional

from airflow.sdk import Variable

from helpers.constants import PROD, EMULATE_PROD_CAMPAIGN_IN_DEV


class Snowflake:

    def __init__(
        self,
        correlation_id: str = None,
        env: Optional[str] = None,

    ):
        self.correlation_id = correlation_id
        self.env = env if env is not None else Variable.get('MEASUREMENT_ENVIRONMENT')
        self.schema = 'PRODUCTION' if self.env == PROD else 'DEVELOPMENT'
        self.db = 'UNIFIED_PLATFORM_PROD' if self.env == PROD else 'UNIFIED_PLATFORM_DEV'
        self.adw_db = 'ADW_PROD' if self.env == PROD or EMULATE_PROD_CAMPAIGN_IN_DEV else 'ADW_DEV'
        self.prod_evaluation_table = 'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN_PROD_EVALUATION'

        self.tables = {
            'campaign':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.CAMPAIGN',
            'baseline_modelling_output':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_MODELLING_OUTPUT',
            'baseline_modelling_int_output':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_MODELLING_INTERMEDIATE_OUTPUT',
            # 'cluster_features':
            #     'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.CLUSTER_FEATURES',
            'baseline_primary_metric':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_PRIMARY_METRIC',
            # TODO:This table needs to be replaced with strategic sources
            'advertise_request_realised':
                'ADW_PROD.ADW_RDV.ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK',
            'digital_trading_campaign_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT',
            'digital_trading_campaign_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK',
            'digital_trading_campaign_dmdvio_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_DMDVIO_SAT',
            'digital_trading_campaign_insight_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK',
            'dim_store_org_hierarchy':
                'ADW_PROD.ADW_PROPERTY_PL.DIM_STORE_ORG_HIERARCHY',
            # TODO: This table needs to be replaced with strategic sources, also will add a env variable to switch
            'advertising_campaign_citcam_sat':
                'ADW_PROD.ADW_RDV.ADVERTISING_CAMPAIGN_CITCAM_SAT',
            'base_finance_assets':
                'ADW_PROD.I2C_PL.BASE_FINANCE_ASSETS_DATA',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'bci_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.BCI_DATA',
            'campaign_decay_rate_table':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CAMPAIGN_DECAY_RATE_AWS',
            'campaign_validation_issues':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CAMPAIGN_VALIDATION_ISSUES',
            'campaign_validation_issues_stage':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CAMPAIGN_VALIDATION_ISSUES_STAGE',
            'cell':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.CELL',
            'check_campaign_mismatch':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CHECK_CAMPAIGN_MISMATCH',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'cci_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.CCI_DATA',
            'coupon':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.COUPON',
            'coupon_cell':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.COUPON_CELL',
            'coupon_to_product':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.COUPON_TO_PRODUCT',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'cpi_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.CPI_DATA',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'dim_calendar_events':
                'ADW_PROD.ADW_REFERENCE_PL.DIM_CALENDAR_EVENTS',
            'dim_item':
                'ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM',
            'dim_item_hist':
                'ADW_PROD.ADW_PRODUCT_PL.DIM_ITEM_HIST',
            'dim_retailer_item':
                'ADW_PROD.ADW_PRODUCT_PL.DIM_RETAILER_ITEM',
            'dim_section':
                'ADW_PROD.ADW_RANGE_SPACE_PL.DIM_SECTION',
            'dim_trading_hierarchy':
                'ADW_PROD.ADW_PRODUCT_PL.DIM_TRADING_HIERARCHY',
            'digital_trading_campaign_sat_youtube_table':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_DMYTIO_SAT',
            'digital_trading_lineitem_facebook_insight':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_INSIGHT_DMFBIN_LINK',
            'dim_location':
                'ADW_PROD.ADW_PROPERTY_PL.DIM_LOCATION',
            'ean_br':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.EAN_BR',
            'fact_sale_transaction_basket':
                'ADW_PROD.ADW_SALES_PL.FACT_SALE_TRANSACTION_BASKET',
            'fact_sale_transaction_item':
                'ADW_PROD.ADW_SALES_PL.FACT_SALE_TRANSACTION_ITEM',
            'planogram_campaigns':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.PLANOGRAM_CAMPAIGNS_AWS',
            'planogram_campaigns_int':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.PLANOGRAM_CAMPAIGNS_INT',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'fuel_prices':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.FUEL_PRICES',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'gdp_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.GDP_DATA',
            'ie_location':
                'I2C_WORKSPACE.I2CEVALS.IE_LOCATION',
            'ie_media':
                'I2C_WORKSPACE.I2CEVALS.IE_MEDIA',
            'ie_product':
                'I2C_WORKSPACE.I2CEVALS.IE_PRODUCT',
            'ie_campaign_filt':
                'I2C_WORKSPACE.I2CEVALS.IE_CAMPAIGN',
            'de_campaign':
                'I2C_WORKSPACE.I2CEVALS.DE_CAMPAIGN',
            'de_product':
                'I2C_WORKSPACE.I2CEVALS.DE_PRODUCT',
            "loyalty_segments":
                "adw_prod.adw_pl.loyalty_segments",
            "measurement_citrus_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CITRUS_CAMPAIGNS",
            "measurement_coupon_at_till_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_COUPON_AT_TILL_CAMPAIGNS",
            "measurement_dv360_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_DV360_CAMPAIGNS",
            "measurement_ecoupons_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_ECOUPONS_CAMPAIGNS",
            "measurement_instore_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_INSTORE_CAMPAIGNS",
            "measurement_magazine_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_MAGAZINE_CAMPAIGNS",
            "measurement_meta_campaigns":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_META_CAMPAIGNS",
            # TODO: we could use this GRID generated table for missing campaign such as nec2403007a until we fix measurement_unified_campaign
            "measurement_unified_campaign_temp":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED",
            "measurement_unified_campaign":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED_CAMPAIGN",
            "measurement_unified_campaign_regress":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED_CAMPAIGN_REGRESS",
            "media_report":
                'RTD_PROD.DV360.MEDIA_REPORT',
            "oc_campaign":
                "I2C_WORKSPACE.I2CEVALS.OC_CAMPAIGN",
            "oc_products":
                "I2C_WORKSPACE.I2CEVALS.OC_PRODUCTS",
            'product_dim_latest':
                'I2C_WORKSPACE.I2CUSER.PRODUCT_DIM_LATEST',
            'product_dim':
                'ADW_PROD.INC_PL.PRODUCT_DIM',
            "post_campaign_period":
                f"{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_POST_CAMPAIGN_PERIOD",
            "sales_data":
                # TODO: dev/prod for this table? why dev only?
                "UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SALES_DATA_TRANSFORMATION_OUTPUT",
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'school_holiday_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SCHOOL_HOLIDAY_DATA',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'sports_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SPORTS_DATA',
            'transactions':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.TRANSACTIONS_DATA',
            # TODO:This table needs to be replaced with strategic sources - we should not be consuming
            'unemployment_data':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.UNEMPLOYMENT_DATA',
            # ToDo This table needs to be replaced with strategic sources, also will add a env variable to switch
            'unified_channel_mapping':
                'UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_CHANNEL_MAPPING',
            'unified_products':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_PRODUCTS',
            # DataSources for fb_campaign_normalized table
            'digital_trading_campaign_dmfbca_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT',
            'digital_trading_campaign_channel_dmfbca_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK',
            # TODO: This table needs to be replaced with strategic sources - we should not be consuming
            'vw_sainsbury_daily_metric_v1_0':
                'ACCUWEATHER.PUBLIC.VW_SAINSBURY_DAILY_METRIC_V1_0',
            # TODO: This table needs to be replaced with a new database - we can call it MEASUREMENT_ANALYTICS (without dev/prod)
            # we can use schema to define the environment instead - makes it easier to switch between dev and prod
            # # TODO: Needs to be replaced once all the relevant PR has been approved.
            # 'sku_cluster_mapping':
            #     'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.SKU_CLUSTER_MAPPING',
            'campaign_selection_python':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.CAMPAIGN_SELECTION_PYTHON',
            'agg_value_index_dashboard_w':
                'ADW_PROD.ADW_PRODUCT_PL.AGG_VALUE_INDEX_DASHBOARD_W',
            'weekly_dates':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.WEEKLY_DATES',
            'dv360_media_report':
                'RTD_PROD.DV360.MEDIA_REPORT',
            'unified_products_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_PRODUCTS_AWS',

            # Temporary processed data for checking current performance.
            'instore_processed_data':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.INSTORE_PROCESSED_DATA',
            'baseline_modelling_dataset':
                'UNIFIED_PLATFORM_PROD.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_MODELLING_DATASET',
            'measurement_baseline_modelling_dataset':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_BASELINE_MODELLING_DATASET',
            'measurement_baseline_modelling_output':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_BASELINE_MODELLING_OUTPUT',
            'customer_by_location':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CUSTOMER_BY_LOCATION',
            'customer_by_location_int':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CUSTOMER_BY_LOCATION_INTERMEDIATE',
            'media_instore_init':
                'I2C_WORKSPACE.I2CEVALS.IE_MEDIA',
            'measurement_campaign_execution':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_EXECUTION',
            'measurement_campaign_execution_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_EXECUTION_AWS',
            'measurement_sku_cluster_mapping':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_SKU_CLUSTER_MAPPING',
            'audience_snapshot_deduped':
                'RTD_PROD.AB.AUDIENCE_SNAPSHOT_DEDUPED',
            'digital_trading_audience_group_dmabag_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT',
            'digital_trading_audience_channel_dmdvau_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_AUDIENCE_CHANNEL_DMDVAU_LINK',
            'digital_trading_lineitem_channel_dmfbas_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_CHANNEL_DMFBAS_LINK',
            'digital_trading_lineitem_channel_dmdvli_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_CHANNEL_DMDVLI_LINK',
            'digital_trading_lineitem_dmfbas_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_DMFBAS_SAT',
            'digital_trading_audience_channel_dmfbau_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK',
            'customer_data_collection':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CUSTOMER_DATA_COLLECTION',
            'flf_golweb_online_event_item':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_GOLWEB_ONLINE_EVENT_ITEM',
            'flf_golweb_online_event':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_GOLWEB_ONLINE_EVENT',
            'flf_golweb_online_event_item_initial':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_GOLWEB_ONLINE_EVENT_ITEM_INITIAL',
            'flf_online_event_gol_app':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_ONLINE_EVENT_GOL_APP',
            'flf_online_event_item_gol_app':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_ONLINE_EVENT_ITEM_GOL_APP',
            'flf_online_event_gol_app_initial':
                'ADW_PROD.ADW_DIGITAL_INTERACTIONS_PL.FLF_ONLINE_EVENT_GOL_APP_INITIAL',
            'dim_customer_loyalty':
                'ADW_PROD.ADW_PL.DIM_CUSTOMER_LOYALTY',
            'advertising_campaign_citcam_sat':
                'ADW_PROD.ADW_RDV.ADVERTISING_CAMPAIGN_CITCAM_SAT',
            'oc_customer_selection':
                'I2C_WORKSPACE.I2CEVALS.OC_CUSTOMER_SELECTION',
            'dim_campaign':
                'ADW_PROD.ADW_CUSTOMER_INTERACTIONS_PL.DIM_CAMPAIGN',
            'flf_campaign_event':
                'ADW_PROD.ADW_CUSTOMER_INTERACTIONS_PL.FLF_CAMPAIGN_EVENT',
            # TODO: Needs to be determined in the pipeline where these tables should be created.
            'magazine_date_lookup':
                'I2C_WORKSPACE.I2CUSER.MAGAZINE_DATE_LOOKUP',
            'fact_coupon_at_till':
                'ADW_PROD.ADW_CUSTOMER_INTERACTIONS_PL.FACT_COUPON_AT_TILL',
            'points_coupon_redemption':
                'ADW_PROD.INC_PL.POINTS_COUPON_REDEMPTION',
            'cat_plan_data':
                'I2C_CMPGN_PROD.I2C_CMPGN_PL.CAT_PLAN_DATA',
            'customer_data_collection_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.CUSTOMER_DATA_COLLECTION_AWS',
            'floodlight_report':
                'RTD_PROD.DV360.FLOODLIGHT_REPORT',
            'unique_reach_lineitem_report':
                'RTD_PROD.DV360.UNIQUE_REACH_LINEITEM_REPORT',
            'measurement_unified_campaign_pollen_prod_evaluation':
                self.prod_evaluation_table,
            'measurement_unified_campaign_pollen':
                self.prod_evaluation_table if EMULATE_PROD_CAMPAIGN_IN_DEV else
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN',
            # TODO: need to remove this duplicated entry - added to ensure that we are able to insert to MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN even when prod  evaluation flag is set to true
            'measurement_unified_campaign_pollen_daily_etl':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN',
            'campaign_booking_media_channel':
                f'{self.adw_db}.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
                # This is a temp solution used in MEASUREMENT_UNIFIED_CAMPAIGN_POLLEN_PROD_EVALUATION
            'campaign_booking_media_channel_prod':
                'ADW_PROD.ADW_BDV.CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR',
            'measurement_campaign_reporting_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_REPORTING_AWS',
            'measurement_metadata':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_METADATA',
            'weekly_start_dates_daily_etl':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.WEEKLY_START_DATES_DAILY_ETL',
            'unified_campaign_grid':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_CAMPAIGN',
            'digital_trading_campaign_channel_dmdvio':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMDVIO_LINK',
            'digital_trading_campaign_channel_dmytio_link':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMYTIO_LINK',
            'digital_trading_lineitem_targeting_dmdvta_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_TARGETING_DMDVTA_SAT',
            'measurement_reach_engagement_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_REACH_ENGAGEMENT_AWS',
            'measurement_booking_reach_engagement_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_BOOKING_REACH_ENGAGEMENT_AWS',
            'measurement_booking_reach_engagement_detail_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_BOOKING_REACH_ENGAGEMENT_DETAIL_AWS',
            'baseline_attribution_integration_aws':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_ATTRIBUTION_INTEGRATION_AWS',
            'baseline_attribution_integration_aws_regress':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_ATTRIBUTION_INTEGRATION_AWS_REGRESS',
            'historic_campaign_sku_scope':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.HISTORIC_CAMPAIGN_SKU_SCOPE_AWS',
            'bookings_blacklist':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.POLLEN_BOOKINGS_BLACKLIST_AWS',
            'digital_trading_campaign_channel_dmdvio':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMDVIO_LINK',
            'digital_trading_lineitem_targeting_dmdvta_sat':
                'ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_TARGETING_DMDVTA_SAT',
            'date_dimension':
                'ADW_PROD.ADW_REFERENCE_PL.DIM_DATE',
            'flf_str_plngrm_item_postn':
                'ADW_PROD.ADW_RANGE_SPACE_PL.FLF_STR_PLNGRM_ITEM_POSTN',
            'marketing_media_hierarchy_mkthrc_ref':
                f'{self.adw_db}.ADW_RDV.MARKETING_MEDIA_HIERARCHY_MKTHRC_REF',
            'measurement_marketing_channel_hierarchy':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_MARKETING_CHANNEL_HIERARCHY',
            'measurement_legacy_campaign_performance':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_LEGACY_CAMPAIGN_PERFORMANCE',
            'transactions_agg_intermediate':
                f'{self.db}.ADW_UNIFIED_PLATFORM_TACTICAL.transactions_agg_intermediate',
            # Legacy campaign performance tables
            'cat_dashboard':
                'I2C_WORKSPACE.I2CUSER.CAT_DASHBOARD',
            'cat_media_costs':
                'I2C_WORKSPACE.I2CUSER.PCR_GEN_RESULTS',
            'ecoupon_dashboard':
                'I2C_WORKSPACE.I2CUSER.ECOUPON_DASHBOARD',
            'ecoupon_media_costs':
                'I2C_WORKSPACE.I2CUSER.EC_DASH_METRICS_3',
            'ecoupon_results_table':
                'I2C_WORKSPACE.I2CEVALS.OC_RESULTS_CELL',
            'instore_dashboard':
                'I2C_WORKSPACE.I2CEVALS.IE_RESULTS',
            'dtp_dashboard':
                'I2C_WORKSPACE.I2CUSER.DTP_WEEKLY_UPLIFTS_SNAPSHOT',
            # Temp tables: - no need to delete
            'manual_campaign_list':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='MANUAL_CAMPAIGN_LIST'),
            'fact_coupon_at_till_performant':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='FACT_COUPON_AT_TILL_PERFORMANT'),
            'coupon_at_till_campaign_date_range_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='COUPON_AT_TILL_CAMPAIGN_DATE_RANGE_TEMP'),
            'cat_fact_sale_transaction_basket_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='CAT_FACT_SALE_TRANSACTION_BASKET_PERFORMANT_TEMP'),
            'cat_fact_sale_transaction_item_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='CAT_FACT_SALE_TRANSACTION_ITEM_PERFORMANT_TEMP'),
            'magazine_campaign_date_range_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='MAGAZINE_CAMPAIGN_DATE_RANGE_TEMP'),
            'mag_fact_sale_transaction_basket_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='MAG_FACT_SALE_TRANSACTION_BASKET_PERFORMANT_TEMP'),
            'mag_fact_sale_transaction_item_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='MAG_FACT_SALE_TRANSACTION_ITEM_PERFORMANT_TEMP'),
            'instore_campaign_date_range_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='INSTORE_CAMPAIGN_DATE_RANGE_TEMP'),
            'fact_sale_transaction_basket_instore_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='FACT_SALE_TRANSACTION_BASKET_INSTORE_PERFORMANT_TEMP'),
            'fact_sale_transaction_item_instore_performant_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='FACT_SALE_TRANSACTION_ITEM_INSTORE_PERFORMANT_TEMP'),

            # Temp tables created for legacy campaign performance data
            'instore_performance_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='INSTORE_PERFORMANCE_TEMP'),
            'cat_performance_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='CAT_PERFORMANCE_TEMP'),
            'ecoupon_performance_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='ECOUPON_PERFORMANCE_TEMP'),
            'dtp_performance_temp':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='DTP_PERFORMANCE_TEMP'),
            # Transient tables to be deleted - in cleanup task.
            'measurement_campaign_execution_status':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='MEASUREMENT_CAMPAIGN_EXECUTION_STATUS'),
            'campaign_product_type_aws':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='CAMPAIGN_PRODUCT_TYPE_AWS'),
            'weekly_start_dates':
                self.temp_table(db=self.db, schema='ADW_UNIFIED_PLATFORM_TACTICAL', table_name='WEEKLY_START_DATES'),

        }

    # Temp tables - to be cleaned up after run.
    def temp_table(self, db: str, schema: str, table_name: str) -> str:
        return f'{db}.{schema}.{table_name}_{self.correlation_id[-8:]}'
