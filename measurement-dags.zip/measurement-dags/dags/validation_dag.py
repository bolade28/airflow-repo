from datetime import datetime
from airflow.sdk import dag
from airflow.sdk import TaskGroup
from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, resolve_pipelines_version, get_ci
from task_groups import baseline_setup, validation_slack_alerts
from helpers.snowflake import MeasurementSnowflakeOperator
from helpers.constants import SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule="00 5 * * *",
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    }
)
def validation_dag():
    """
    Validation DAG
    """

    setup = baseline_setup.task_group()

    blacklist_table_alerts = validation_slack_alerts.validation_blacklist_report_alerts(
        group_id="validation_blacklist_report",
        source_task_id="validation_check.check_mandatory_campaign_details",
    )

    with TaskGroup(group_id="validation_check", ui_color="#ff7f00") as validation_check:
        check_mandatory_campaign_details = MeasurementSnowflakeOperator(
            task_id="check_mandatory_campaign_details",
            sql="validation/check_mandatory_campaign_details.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": get_ci(),
            },
            doc_md="""
                This task validates that provided booking IDs do not map to campaign_id = '-1'
                in CAMPAIGN_BOOKING_MEDIA_CHANNEL_BR.
                """,
        )

        campaign_validation_issues_insert = MeasurementSnowflakeOperator(
            task_id="campaign_validation_issues_insert",
            sql="validation/campaign_validation_issues_insert.sql",
            hook_params={"warehouse": SNOWFLAKE_MEASUREMENT_WAREHOUSE_X2LARGE},
            params={
                "correlation_id": get_ci(),
            },
        )

        check_mandatory_campaign_details >> campaign_validation_issues_insert

    setup >> validation_check >> blacklist_table_alerts


validation_dag()
