from datetime import datetime

from airflow.sdk import dag

from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table, get_cluster_id, resolve_pipelines_version
from task_groups import baseline_setup
from steps.experimentation import campaign_efficiency
from helpers.emr import launch_cluster, terminate_cluster


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
        "resolve_pipelines_version": resolve_pipelines_version,
    }
)
def ad_hoc_dag():
    """
    Measurement ad-hoc DAG
    This is an ad-hoc DAG for running one-off tasks.
    """

    start_cluster = launch_cluster('ad-hoc-cluster')

    stop_cluster = terminate_cluster(get_cluster_id())

    setup = baseline_setup.task_group()

    run_ad_hoc_stuff = campaign_efficiency.tasks()
    setup >> start_cluster >> run_ad_hoc_stuff >> stop_cluster


ad_hoc_dag()
