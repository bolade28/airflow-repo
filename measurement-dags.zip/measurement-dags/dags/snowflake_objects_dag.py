from datetime import datetime

from airflow.sdk import dag

from helpers.dag_args import DEFAULT_DAG_ARGS
from helpers.xcom import get_stage, get_table
from task_groups import snowflake_objects, snowflake_objects_setup


@dag(
    default_args=DEFAULT_DAG_ARGS,
    render_template_as_native_obj=True,
    schedule=None,
    start_date=datetime(2022, 1, 1),
    template_searchpath=["/home/airflow/airflow/dags/templates/sql"],
    user_defined_macros={
        "get_stage": get_stage,
        "get_table": get_table,
    }
)
def snowflake_objects_dag():
    """
    Snowflake Objects DAG
    This DAG is responsible for creating self-managed Snowflake objects needed for the
    core DAGs to run without issues.
    """

    setup = snowflake_objects_setup.task_group()

    create_snowflake_objects = snowflake_objects.task_group()
    setup >> create_snowflake_objects


snowflake_objects_dag()
