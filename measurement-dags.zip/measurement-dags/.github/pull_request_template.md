## Description:

*Include a summary of the change and which issue is fixed, and include relevant motivation
and context, and links to design documentation.*

## JIRA Ticket Number:

[NUP-XXXX](https://sainsburys-tech.atlassian.net/browse/NUP-XXXX)

## Type of Change:

*Delete types that don't apply.*

- Bug fix (non-breaking change which fixes an issue)
- New/Updates/Removes feature (non-breaking change which adds/updates/removes functionality)
- Documentation

## Urgent: 

**⚠️ Delete this section if this is NOT an urgent/hotfix PR**

**Reason for urgency:**
*Briefly explain why this PR is urgent (e.g., P1 issue, critical bug, security vulnerability)*

**Risk assessment:**
*Describe what could go wrong and mitigation steps taken*

**Expedited review checklist:**
- [ ] Critical functionality has been tested in a production-like environment. Correlation ID: 
- [ ] Stakeholders/on-call team have been notified
- [ ] Change has been approved by [Tech Lead/Senior Engineer name]
- [ ] Added the 'urgent' label to this PR 

**Post-deployment actions:**
- [ ] Create follow-up ticket for any technical debt introduced
- [ ] Schedule post-incident review if applicable
- [ ] Update runbooks/documentation

**For Reviewers** 

Focus on production safety over style/nitpicks

The below sections are not neccessary for urgent PRs. 


## Checklist:

- [ ] The PR title and commit starts with the JIRA number (e.g. 'NUP-XXXX - Add a new feature'), if applicable.
- [ ] It follows the engineering standards and style guidelines of this project.
- [ ] I have commented my code, particularly in hard-to-understand areas.
- [ ] I have made corresponding changes to the documentation (GitHub or Confluence), where applicable.
- [ ] I have performed a self-review of my own code before requesting a review from others.
- [ ] I have completed the testing section below with documented End to End runs and associated correlation IDs. 
- [ ] UAT has been completed by an engineer, if applicable.


## Testing:

- [ ] I have followed the [E2E testing guidelines](https://sainsburys-tech.atlassian.net/wiki/spaces/NUP/pages/1171881998/Pre-PR+Merge+E2E+Testing+guidelines) for both 'during' and 'post' DAGs. For more info, see [this](https://sainsburys-tech.atlassian.net/wiki/spaces/Measurement/pages/1126337925/Runbook+How+to+run+our+pipeline) documentation. 
- [ ] The associated correlation IDs are:
    * DTP: 
    * Pollen:
- [ ] I have created Jira tickets for any issues or feedback requiring follow-up.


## UAT:

*Describe the tests and UAT that you carried out to verify your changes and list any
relevant details for your test configuration
