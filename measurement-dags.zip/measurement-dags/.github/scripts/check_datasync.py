import argparse
import logging
import sys
import time

import boto3

logging.basicConfig()
logger = logging.getLogger("CheckDataSync")
logger.setLevel(logging.INFO)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="CheckDataSync")
    parser.add_argument("task_execution_arn")

    args = parser.parse_args()
    task_execution_arn = args.task_execution_arn

    client = boto3.client("datasync")

    response = client.describe_task_execution(TaskExecutionArn=task_execution_arn)
    while response["Status"] not in ("SUCCESS", "ERROR"):
        response = client.describe_task_execution(TaskExecutionArn=task_execution_arn)
        logger.info(f"DataSync task status: {response['Status']}")
        time.sleep(10)

    if response["Status"] == "ERROR":
        logger.error(f"DataSync task failed with error code '{response['Result']['ErrorCode']}'. {response['Result']['ErrorDetail']}.")
        sys.exit(1)
