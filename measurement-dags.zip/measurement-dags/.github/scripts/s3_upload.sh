#!/usr/bin/env bash

# This script uploads the dags and requirements.txt to S3..
aws s3 sync $WORKSPACE/dags/ s3://measurement-$ENV-dags/$REVISION --exclude "*__pycache__*" --delete --include "*.py"
aws s3 cp $WORKSPACE/requirements.txt s3://measurement-$ENV-airflow-artefacts/requirements/$REVISION/requirements.txt
