#!/bin/bash
set -e

API_KEY=$(aws secretsmanager get-secret-value --secret-id $SERVICE_NOW_API_KEY_ARN | jq -r '.SecretString')

# All commit messages will be visible in Service Now change notification for merge commits (unless squashed)
COMMIT_MESSAGES="$(git log HEAD...deployment --pretty=format:'%h - %s (%an)' | awk 1 ORS='\\n' | sed -e 's@"@\\"@g')"

mkdir service_now_change_dir

function generate_json_body {
  cat <<EOF
        {
          "deploymentItem": "Pollen Measurement",
          "assignmentGroup": "DTP - Digital Trading Platform",
          "description": "Merging commits from $BRANCH\n\nGit commits since last successful deployment:\n\n$COMMIT_MESSAGES\nGithub Actions Workflow = $GITHUB_WORKFLOW_LINK"
        }
EOF
}

curl \
--header "Content-Type: application/json" \
--header "X-API-KEY: $API_KEY"            \
--request POST                            \
--show-error                              \
--fail                                    \
--data "$(generate_json_body)"            \
https://$SERVICE_NOW_BASE_URL/sops/change > service_now_change_dir/response.json
echo
echo
cat service_now_change_dir/response.json
change_id=$(jq -r .id service_now_change_dir/response.json)
echo $change_id > service_now_change_dir/change_id.txt
