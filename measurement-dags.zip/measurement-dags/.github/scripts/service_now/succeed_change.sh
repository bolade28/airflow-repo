#!/bin/bash
set -e

if [ -f ./service_now_change_dir/change_id.txt ]; then
  echo -n "Change ID: " | cat - ./service_now_change_dir/change_id.txt
else
  echo "Unable to restore cached change id file"
  exit 1
fi

API_KEY=$(aws secretsmanager get-secret-value --secret-id $SERVICE_NOW_API_KEY_ARN | jq -r '.SecretString')
change_id=$(cat service_now_change_dir/change_id.txt)

curl --include \
    --header "Content-Type: application/json" \
    --header "X-API-KEY: $API_KEY" \
    --request POST \
    --fail \
    --data '{}' \
    https://$SERVICE_NOW_BASE_URL/sops/change/${change_id}/succeed
