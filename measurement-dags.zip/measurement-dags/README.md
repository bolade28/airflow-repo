# measurement-dags

Houses Airflow DAGs for measurement pipelines.
All of the code for the individual steps is found in the [Measurement Pipelines repo](https://github.com/sainsburys-tech/measurement-pipelines)

## Setting up a local Python environment

The required Python version for this repository is `3.12`, as specified in the `.env` file.

To setup local Python environment, use [krang-python-env](https://github.com/JSainsburyPLC/krang-python-env)

**To install production and development dependencies, run**:

    make install

## Airflow and Python versions

We maintain a `.env` file in the root of the repo which specifies the python
and airflow versions we are using. These are used in the docker-compose as well
as the makefile command to update dependencies (see below).

## Updating Dependencies

We use [pip-tools](https://github.com/jazzband/pip-tools) to manage our
Python dependencies. To add a new Python dependency, add the package to
requirements.in or dev-requirements.in, then run:
```shell
    make update-deps
```

This will generate a new requirements.txt and dev-requirements.txt file
with pinned library versions. If you run pip-compile seperately, you will
need the environment variables defined in the `.env` file to be available in your
shell. To do this you can run:
```shell
set -o allexport
source .env
set +o allexport
```

## Linting

We use a flake8 linter to keep our code formatted consistently. The
configuration for the linter can be found in `.flake8`. To run the
linter, first install the dev dependencies, activate the measurement-dags
environment, then run:

    make lint

The linter runs in the CI, so ideally you should run this command
before pushing code, your IDE should also be able to give you
warnings. Alternatively, you can use a pre-commit hook, this has
been configured in `.pre-commit-config.yaml`. To install the hook, run:

    pre-commit install

More info on pre-commit hooks here: https://pre-commit.com/

## Running tests locally

    PYTHONPATH=$(pwd)/dags pytest -s tests

### Running tests locally in PyCharm
Edit the run configuration for the tests and set
* Working directory: `/<repo_path>/measurement-dags`
* Environment variable: `PYTHONPATH=/<repo_path>/measurement-dags/dags`
* Additional Argument: `--capture=no` (optional if you wish to see the print statements)

## Airflow operations and troubleshooting

See also [measurement-terraform README](https://github.com/sainsburys-tech/measurement-terraform)

When things go wrong with a DAG running in Airflow, there are alerts in Slack.
To figure out what's happening, you can look at the EMR section of the AWS console, and
also in Airflow GUI.

## MLFlow tracker

MLFlow tracker available via these URIs. These URIs are not exposed externally so can only be used within AWS platform.
dev: http://mlflow.dev.measurement.internal:5000
prod: http://mlflow.prod.measurement.internal:5000

ML artefacts will be stored at these locations:
dev: s3://measurement-dev-mlflow/artefacts/
prod: s3://measurement-prod-mlflow/artefacts/

To access MLFlow interface locally, follow instructions below.

## Running Airflow Docker - Mac

### Prerequisites
- Docker Desktop installed
- GitHub SSH key configured
- Not connected to VPN (for building)

### Build the Docker Image

Ensure you have internet access and run:

```shell
make build-airflow
```

### Run Airflow
1. Connect to VPN
2. Authenticate with AWS:

`aws-azure-login login --profile measurement-dev --mode=gui`

3. Start Airflow

```shell
make airflow
```

Access airflow at: http://localhost:8080

Docker Airflow build hash: `a9d15ffd`

## Running Airflow Docker - AWS Workspace/VDI

There are separate make commands to help you build and run the Airflow containers when working in the AWS Workspaces

### Prerequisites: Configure SSH Agent

Before building the Docker images, you need to configure SSH authentication for GitHub access. The Docker build process requires SSH to clone private repositories during the build.

**Start the SSH agent and add your GitHub key:**

```shell
# Start the SSH agent
eval "$(ssh-agent -s)"

# Add your GitHub SSH key to the agent
# Note: Replace id_ed25519 with your actual SSH key filename if different (e.g., id_rsa)
ssh-add ~/.ssh/id_ed25519
```

Run the following so you have AWS cli and essential build ready

```shell
sudo apt update

sudo apt install build-essential unzip -y
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws awscliv2.zip

```
verify aws cli is installed

```shell
aws --version
```

To build the image, initially (this only needs to be done once or when there are changes to the files within vdi folder):

```shell
make build-airflow-linux
```

To start up the containers and run the airflow instance:

```shell
make airflow-linux
```

Access airflow at: http://localhost:8080

To shutdown the containers, please first stop any DAG runs and then in the terminal session simply press `ctrl + c` to shutdown the containers gracefully.


## Accessing AWS Airflow (Dev/Prod)

Install session manager plugin (if not already installed):
```shell
brew install --cask session-manager-plugin
```

For Dev:
Set your AWS profile:
```shell
export AWS_PROFILE=measurement-dev
```

Then log in using:
```shell
aws-azure-login
```

Start Airflow:

```shell
make airflow-aws
```
Access at: http://localhost:8081

Start MLflow:
```shell
make mlflow
```

Access at: http://localhost:8082

# How to Deploy to Dev and Prod


## Deployment Process

1. **Create a Pull Request (PR)** and push your changes to one of the following repositories:
    - measurement-dags: https://github.com/sainsburys-tech/measurement-dags
    - measurement-pipelines: https://github.com/sainsburys-tech/measurement-pipelines

2. **Ensure your PR meets the following criteria**:
   - Passes CI/CD checks
   - Has no conflicts or unresolved comments
   - All relevant tests (e.g., unit tests) are completed

3. **Request deployment to dev**:
   - Once CI/CD passes, request deployment to dev
   - Requires approval from another engineer

4. **Deployment to prod**:
   - After merging your code to the `main` branch, deployment to prod happens automatically

---

## Deployment Options

You can deploy using either of the following methods:

- **Directly from the PR**:
  - Click on "github-ci / dev / Deploy to Airflow (push)"
  - Click “Review pending deployments”
  - Then click “Approve and deploy”
  - If it’s your PR, another engineer must approve it

- **Using the Actions tab in Github UI**:
  - Select deployment for your branch

---

## Notes

- The deployment process is similar for both the `dags` and `pipelines` repositories.
- For questions, reach out to the page author.

DAG versioning:
Avoid calling pendulum.now() (or any time/random function) at module level in DAG files. Airflow 3.x re-parses DAG files periodically, any non-deterministic value evaluated at parse time produces a different serialised DAG on each parse, as a result a new DAG version is created. Use Jinja macros functions `get_current_iso_timestamp` and `get_current_timestamp`, that uses macro and stored as static strings and are only evaluated at task runtime.

Why this matters?
Each new DAG version triggers re-serialisation and DB writes on every parse cycle (~every 30s). With multiple DAGs doing this simultaneously, the scheduler becomes overwhelmed with constant write load rather than processing tasks.

---
## Full Instructions
1. https://sainsburys-tech.atlassian.net/wiki/spaces/Measurement/pages/1140852196/How+to+deploy+to+dev+and+prod