#!/usr/bin/env bash

export AIRFLOW__CORE__FERNET_KEY=$(aws --region eu-west-1 --profile measurement-dev secretsmanager get-secret-value --secret-id airflow/fernet-key --query 'SecretString' | jq -r '. | fromjson."fernet-key"')

case "$1" in
  api-server)

    airflow db migrate

    airflow variables set MEASUREMENT_ENVIRONMENT dev

    airflow users create \
      --role Admin \
      --username measurement \
      --password measurement \
      --email measurement \
      --firstname measurement \
      --lastname measurement

    airflow connections add \
      --conn-type aws \
      --conn-description "AWS Connection without the VPN" \
      --conn-extra "{\"config_kwargs\": {\"proxies\": {}}}" \
      aws_default

    airflow connections add \
      --conn-type emr \
      --conn-description "EMR Connection" \
      emr_default

airflow connections add 'snowflake_conn' \
  --conn-json "$(cat <<EOF
{
  "conn_type": "snowflake_key_arn",
  "login": "SU_NONPROD_ETL_MEASUREMENT",
  "host": "${SNOWFLAKE_HOST}",
  "schema": "ADW_UNIFIED_PLATFORM_TACTICAL",
  "extra": {
      "private_key_arn": "arn:aws:secretsmanager:eu-west-1:383109991409:secret:snowflake/prod/SU_NONPROD_ETL_MEASUREMENT-AwWiEs",
      "private_key_role": "arn:aws:iam::277707132387:role/measurement-rhubarb-secret-access-role-dev",
      "account": "${SNOWFLAKE_HOST}",
      "warehouse": "WHS_PROD_UP_CUSTOMER_SNOWPARK",
      "database": "UNIFIED_PLATFORM_PROD",
      "role": "RL_PROD_UP_ETL",
      "insecure_mode": false
  }
}
EOF
)"

    airflow connections add \
      --conn-description "Connection to send alerts to slack" \
      --conn-password $(aws --region eu-west-1 --profile measurement-dev secretsmanager get-secret-value --secret-id slack/measurement-courier-auth-token --query 'SecretString' | jq -r '. | fromjson."botAuthTokenValue"') \
      --conn-type "slack" \
      slack_api_default

    airflow api-server
    ;;
  scheduler)
    airflow scheduler
    ;;
  dag-processor)
    airflow dag-processor
    ;;
  *)
    # The command is something like bash, not an airflow subcommand. Just run it in the right environment.
    exec "$@"
    ;;
esac
