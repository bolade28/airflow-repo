-- This script is to serve as unit test for testing magazine customer data.
-- Test directly in Snowflake or you can also use jupyter notebook. As a 
-- matter of fact it will almost work on system that supports SQL Engine.
with magazine_campaign_list as (
    -- Data for the `magazine_campaign_list` CTE
    select
        'Sainburys Magazine 2025 Summer' as campaign_name,
        'Sainburys Magazine' as channel_name,
        '2025-07-01'::date as start_date,
        '2025-07-31'::date as end_date,
        'MAG001' as campaign_id,
        'Printed' as subchannel_name,
        'BOOK001' as booking_id,
        'During' as campaign_duration,
        'JOBBAG001' as job_bag_id,
        'Promotional' as marketing_type
    union all
    select
        'Sainburys Magazine 2024 Autumn' as campaign_name,
        'Sainburys Magazine' as channel_name,
        '2024-09-01'::date as start_date,
        '2024-10-31'::date as end_date,
        'MAG002' as campaign_id,
        'Printed' as subchannel_name,
        'BOOK002' as booking_id,
        'Post' as campaign_duration,
        'JOBBAG002' as job_bag_id,
        'Promotional' as marketing_type
),

magazine_date_lookup as (
    -- Data for the `I2CUSER.MAGAZINE_DATE_LOOKUP` table
    select
        '2025-07-01'::date as start_date,
        '2025-07-31'::date as end_date,
        1001 as sku_no
),

fact_sale_transaction_basket as (
    -- Data for the `ADW_SALES_PL.FACT_SALE_TRANSACTION_BASKET` table
    select
        '2025-07-05 10:00:00.000'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST123' as nectar_card_num_hash,
        'TXN_001' as transaction_id,
        '2025-07-05'::date as transaction_dt,
        '14' as sales_origination_channel_cd
    union all
    select
        '2025-07-10 12:30:00.000'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST123' as nectar_card_num_hash,
        'TXN_002' as transaction_id,
        '2025-07-10'::date as transaction_dt,
        '16' as sales_origination_channel_cd
    union all
    select
        '2024-09-15 11:00:00.000'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST789' as nectar_card_num_hash,
        'TXN_003' as transaction_id,
        '2024-09-15'::date as transaction_dt,
        '14' as sales_origination_channel_cd
    union all
    select
        '2024-09-20 15:00:00.000'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST999' as nectar_card_num_hash,
        'TXN_004' as transaction_id,
        '2024-09-20'::date as transaction_dt,
        '16' as sales_origination_channel_cd
),

fact_sale_transaction_item as (
    -- Data for the `ADW_SALES_PL.FACT_SALE_TRANSACTION_ITEM` table
    select
        'TXN_001' as transaction_id,
        '2025-07-05'::date as transaction_dt,
        1001 as item_cd,
        2.50 as net_retail_sales_amt,
        1 as item_qty,
        1 as item_sequence_num,
        'STORE01' as store_cd
    union all
    select
        'TXN_002' as transaction_id,
        '2025-07-10'::date as transaction_dt,
        456 as item_cd,
        25.50 as net_retail_sales_amt,
        1 as item_qty,
        1 as item_sequence_num,
        'STORE01' as store_cd
    union all
    select
        'TXN_003' as transaction_id,
        '2024-09-15'::date as transaction_dt,
        789 as item_cd,
        10.20 as net_retail_sales_amt,
        2 as item_qty,
        1 as item_sequence_num,
        'STORE02' as store_cd
    union all
    select
        'TXN_004' as transaction_id,
        '2024-09-20'::date as transaction_dt,
        901 as item_cd,
        5.00 as net_retail_sales_amt,
        1 as item_qty,
        1 as item_sequence_num,
        'STORE02' as store_cd
),

dim_customer_loyalty as (
    -- Data for the `ADW_PL.DIM_CUSTOMER_LOYALTY` table
    select
        'CUST123' as nectar_collector_card_num,
        'HASH_CUST123' as customer_loyalty_cd
    union all
    select
        'CUST789' as nectar_collector_card_num,
        'HASH_CUST789' as customer_loyalty_cd
    union all
    select
        'CUST999' as nectar_collector_card_num,
        'HASH_CUST999' as customer_loyalty_cd
),

campaign_product_type as (
    -- Data for the `ADW_UNIFIED_PLATFORM_TACTICAL.CAMPAIGN_PRODUCT_TYPE` table
    select
        'MAG001' as campaign_id,
        'Sainburys Magazine' as channel_name,
        'Printed' as subchannel_name,
        'Electronics' as product_type,
        'Acme' as unique_brand_name,
        456 as item_cd,
        '2025-07-31 14:59:42.000000000'::timestamp_ntz as load_ts
    union all
    select
        'MAG002' as campaign_id,
        'Sainburys Magazine' as channel_name,
        'Printed' as subchannel_name,
        'Groceries' as product_type,
        'FreshFarm' as unique_brand_name,
        789 as item_cd,
        '2024-10-31 14:59:42.000000000'::timestamp_ntz as load_ts
),

unified_campaign as (
    -- Data for the `ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_CAMPAIGN` table
    select
        'MAG002' as campaign_id,
        'Sainburys Magazine' as channel_name,
        'Printed' as subchannel_name,
        'Promotional' as marketing_type,
        '2024-08-01'::date as campaign_start_dt,
        '2024-08-31'::date as campaign_end_dt,
        '2024-10-31'::date as post_campaign_dt,
        'BOOK002' as booking_id,
        '2024-10-31 14:59:42.000000000'::timestamp_ntz as load_ts
),

customer_data_collection as (
    -- Data for the `ADW_UNIFIED_PLATFORM_TACTICAL.CUSTOMER_DATA_COLLECTION` table
    select
        'CUST789' as loyalty_id,
        'MAG002' as campaign_id,
        'Sainburys Magazine' as channel_name,
        'Printed' as subchannel_name,
        'Promotional' as marketing_type,
        '2024-08-05 09:00:00.000'::timestamp_ntz as event_ts,
        '2024-08-05'::date as event_dt
    union all
    select
        'CUST999' as loyalty_id,
        'MAG002' as campaign_id,
        'Sainburys Magazine' as channel_name,
        'Printed' as subchannel_name,
        'Promotional' as marketing_type,
        '2024-08-10 14:00:00.000'::timestamp_ntz as event_ts,
        '2024-08-10'::date as event_dt
),

campaign_details_flattened as (
    select
        campaign_name,
        channel_name,
        start_date,
        end_date,
        campaign_id,
        subchannel_name,
        booking_id,
        campaign_duration,
        job_bag_id,
        marketing_type
    from magazine_campaign_list
),

max_load_ts as (
    select
        ccd.campaign_id,
        ccd.channel_name,
        ccd.subchannel_name,
        max(cpt.load_ts) as load_ts
    from campaign_product_type as cpt
    inner join campaign_details_flattened as ccd
        on cpt.campaign_id = ccd.campaign_id
        and cpt.channel_name = ccd.channel_name
        and cpt.subchannel_name = ccd.subchannel_name
    group by 1, 2, 3
),

get_targeted_skus as (
    select distinct
        cpt.product_type,
        cpt.unique_brand_name,
        cpt.item_cd,
        ccd.campaign_id,
        ccd.channel_name,
        ccd.subchannel_name
    from campaign_product_type as cpt
    inner join magazine_campaign_list as ccd
        on cpt.campaign_id = ccd.campaign_id
        and cpt.channel_name = ccd.channel_name
        and cpt.subchannel_name = ccd.subchannel_name
    inner join max_load_ts as mlt
        on cpt.campaign_id = mlt.campaign_id
        and cpt.channel_name = mlt.channel_name
        and cpt.subchannel_name = mlt.subchannel_name
        and cpt.load_ts = mlt.load_ts
),

get_fact_sale_transaction_basket as (
    select
        transaction_end_ts,
        nectar_card_num_hash,
        transaction_id,
        transaction_dt,
        sales_origination_channel_cd
    from fact_sale_transaction_basket
    where
        nectar_card_num_hash is not null
        and transaction_dt between (select min(start_date) from campaign_details_flattened) and (select max(end_date) from campaign_details_flattened)
        and sales_origination_channel_cd in ('14', '16')
),

get_fact_sale_transaction_item as (
    select
        transaction_id,
        transaction_dt,
        item_cd,
        net_retail_sales_amt,
        item_qty,
        item_sequence_num,
        store_cd
    from fact_sale_transaction_item
    where
        transaction_dt between (select min(start_date) from campaign_details_flattened) and (select max(end_date) from campaign_details_flattened)
        and net_retail_sales_amt > 0
),

dim_customer_loyalty as (
    select
        nectar_collector_card_num,
        customer_loyalty_cd
    from dim_customer_loyalty
    where nectar_collector_card_num != '~~'
),

magazine_date_lookup_during as (
    select distinct
        start_date,
        end_date,
        sku_no
    from magazine_date_lookup
),

magazine_transaction_data_during as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfstb.transaction_end_ts as event_time,
        date(gfstb.transaction_end_ts) as event_date,
        ccd.campaign_id
    from get_fact_sale_transaction_item as gfsti
    inner join get_fact_sale_transaction_basket as gfstb
        on gfsti.transaction_id = gfstb.transaction_id
    inner join dim_customer_loyalty as dcl
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join magazine_date_lookup_during as mdl
        on gfsti.item_cd = mdl.sku_no
    inner join campaign_details_flattened as ccd
        on mdl.start_date = ccd.start_date
        and mdl.end_date = ccd.end_date
        and ccd.campaign_duration = 'During'
    where
        gfstb.transaction_end_ts >= mdl.start_date
        and gfstb.transaction_end_ts <= mdl.end_date
        and gfstb.sales_origination_channel_cd in ('14')
),

magazine_loyalty_data_during as (
    select
        loyalty_id,
        min(event_time) as event_time,
        min(event_date) as event_date,
        campaign_id
    from magazine_transaction_data_during
    group by loyalty_id, campaign_id
),

unified_campaign_post as (
    select
        campaign_id,
        booking_id,
        channel_name,
        subchannel_name,
        marketing_type,
        campaign_start_dt,
        campaign_end_dt,
        post_campaign_dt,
        load_ts
    from unified_campaign
    where load_ts = (select max(load_ts) from unified_campaign)
),

magazine_loyalty_data_post as (
    select
        cdc.loyalty_id,
        min(cdc.event_ts) as event_time,
        min(cdc.event_dt) as event_date,
        ccd.campaign_id
    from customer_data_collection as cdc
    inner join unified_campaign_post as ucp
        on cdc.campaign_id = ucp.campaign_id
        and cdc.channel_name = ucp.channel_name
        and cdc.subchannel_name = ucp.subchannel_name
        and cdc.marketing_type = ucp.marketing_type
    inner join campaign_details_flattened as ccd
        on cdc.campaign_id = ccd.campaign_id
        and ccd.campaign_duration = 'Post'
        and ccd.booking_id = ucp.booking_id
    where
        cdc.event_dt between ucp.campaign_start_dt and ucp.campaign_end_dt
    group by cdc.loyalty_id, ccd.campaign_id
),

magazine_loyalty_data_all as (
    select loyalty_id, event_time, event_date, campaign_id from magazine_loyalty_data_during
    union all
    select loyalty_id, event_time, event_date, campaign_id from magazine_loyalty_data_post
),

get_magazine_sku_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfsti.transaction_id as transaction_key,
        gfsti.transaction_dt as event_date,
        gfsti.item_cd,
        gfstb.transaction_end_ts as event_time,
        ccd.marketing_type,
        case when gfstb.sales_origination_channel_cd in ('14') then 'In-store' else 'Online' end as channel_name,
        ccd.campaign_name,
        ccd.campaign_id,
        'Purchase Transaction' as event_name,
        ccd.booking_id,
        gts.product_type,
        gts.unique_brand_name,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num,
        ccd.subchannel_name
    from get_fact_sale_transaction_item as gfsti
    inner join get_fact_sale_transaction_basket as gfstb
        on gfsti.transaction_id = gfstb.transaction_id
    inner join magazine_loyalty_data_all as mld
        -- on gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
        on gfstb.transaction_end_ts >= mld.event_time
    inner join dim_customer_loyalty as dcl
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
        and gts.campaign_id = mld.campaign_id
    inner join campaign_details_flattened as ccd
        on mld.campaign_id = ccd.campaign_id
    where
        gfstb.sales_origination_channel_cd in ('14', '16')
),

magazine_sku_transaction_data as (
    select
        loyalty_id,
        event_date,
        event_time,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_targetted_sales,
        sum(item_qty) as units
    from get_magazine_sku_transaction_data_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
),

magazine_targetted_sku_touchpoint_data as (
    select distinct
        mst.loyalty_id,
        mst.unique_brand_name,
        mst.marketing_type,
        mst.channel_name,
        ccd.subchannel_name,
        mst.campaign_name,
        mst.campaign_id,
        mld.event_date,
        mld.event_time,
        mst.transaction_key,
        'Touchpoint' as event_name,
        mst.booking_id
    from magazine_sku_transaction_data as mst
    inner join magazine_loyalty_data_all as mld
        on mst.loyalty_id = mld.loyalty_id
        and mst.campaign_id = mld.campaign_id
    inner join campaign_details_flattened as ccd
        on mst.campaign_id = ccd.campaign_id
),

magazine_non_targetted_sku_touchpoint_data as (
    select distinct
        mld.loyalty_id,
        ccd.marketing_type,
        ccd.channel_name,
        ccd.subchannel_name,
        ccd.campaign_name,
        ccd.campaign_id,
        mld.event_date,
        mld.event_time,
        null as transaction_key,
        'Touchpoint' as event_name,
        ccd.booking_id
    from magazine_loyalty_data_all as mld
    inner join campaign_details_flattened as ccd
        on mld.campaign_id = ccd.campaign_id
    where
        mld.loyalty_id not in (
            select distinct loyalty_id
            from magazine_sku_transaction_data
            where campaign_id = mld.campaign_id
        )
),

magazine_data_collection as (
    select distinct
        loyalty_id,
        transaction_key,
        event_date as event_dt,
        event_time as event_ts,
        marketing_type,
        channel_name,
        'TXN' as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_targetted_sales as net_sales_amt,
        units as units_qty
    from magazine_sku_transaction_data
    union all
    select distinct
        loyalty_id,
        transaction_key,
        event_date as event_dt,
        event_time as event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null as item_cd,
        null as product_type,
        null as unique_brand_name,
        null as net_sales_amt,
        null as units_qty
    from magazine_targetted_sku_touchpoint_data
    union all
    select distinct
        loyalty_id,
        null as transaction_key,
        event_date as event_dt,
        event_time as event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null as item_cd,
        null as product_type,
        null as unique_brand_name,
        null as net_sales_amt,
        null as units_qty
    from magazine_non_targetted_sku_touchpoint_data
)

select
    loyalty_id::varchar(1000) as loyalty_id,
    coalesce(transaction_key::varchar(1000), 'NA') as transaction_key,
    event_dt::date as event_dt,
    event_ts::timestamp_ntz(9) as event_ts,
    marketing_type::varchar(1000) as marketing_type,
    channel_name::varchar(1000) as channel_name,
    subchannel_name::varchar(1000) as subchannel_name,
    campaign_name::varchar(1000) as campaign_name,
    campaign_id::varchar(1000) as campaign_id,
    event_name::varchar(1000) as event_name,
    booking_id::varchar(1000) as booking_id,
    current_timestamp::timestamp_ntz(9) as load_ts,
    coalesce(item_cd::number(18, 0), 0) as item_cd,
    coalesce(product_type::varchar(1000), 'NA') as product_type,
    coalesce(unique_brand_name::varchar(1000), 'NA') as unique_brand_name,
    coalesce(net_sales_amt::number(30, 4), 0) as net_sales_amt,
    coalesce(units_qty::number(30, 4), 0) as units_qty,
    '{{ invocation_id }}'::varchar(36) as job_run_id
from magazine_data_collection;