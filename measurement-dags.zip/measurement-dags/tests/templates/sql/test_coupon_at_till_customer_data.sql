-- This unit test script can be executed in almost any database the supports SQL Engine.
-- However, you advised to execute it in Snowflake.
with measurement_campaign_execution as (
    -- Mock data for measurement_campaign_execution table
    select
        'CAMP001' as campaign_id,
        'BOOK001' as booking_id,
        'Promotional' as marketing_type,
        'Digital' as channel_name,
        'Email' as subchannel_name,
        'Summer Coupon Campaign' as campaign_name,
        '2025-07-01'::date as campaign_start_dt,
        '2025-07-31'::date as campaign_end_dt,
        'COMPLETED' as job_status
),

cell as (
    -- Mock data for cell table
    select 101 as cell_key, 'CAMP001' as campaign_id
),

coupon_cell as (
    -- Mock data for coupon_cell table
    select 101 as cell_key, 201 as coupon_key
),

coupon as (
    -- Mock data for coupon table
    select 201 as coupon_key, 'COUPON_1234567' as coupon_id
),

cat_plan_data as (
    -- Mock data for cat_plan_data table
    select
        'CAMP001' as campaigncode,
        'OFFER_12345678' as offerbarcode
),

fact_coupon_at_till_performant as (
    -- Mock data for fact_coupon_at_till_performant table
    select
        'HASH_CUST123' as hash_loyalty_id,
        'COUPON_1234567' as barcode,
        '2025-07-05'::date as coupon_print_dt,
        '10:00:00'::time as coupon_print_tm
),

fact_sale_transaction_basket_performant as (
    -- Mock data for fact_sale_transaction_basket_performant table
    select
        '2025-07-08 11:30:00'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST123' as nectar_card_num_hash,
        'TXN_001' as transaction_id,
        '2025-07-08'::date as transaction_dt,
        '14' as sales_origination_channel_cd,
        'TXN_KEY_001' as transaction_key
    union all
    select
        '2025-07-15 14:00:00'::timestamp_ntz as transaction_end_ts,
        'HASH_CUST456' as nectar_card_num_hash,
        'TXN_002' as transaction_id,
        '2025-07-15'::date as transaction_dt,
        '16' as sales_origination_channel_cd,
        'TXN_KEY_002' as transaction_key
),

fact_sale_transaction_item_performant as (
    -- Mock data for fact_sale_transaction_item_performant table
    select
        'TXN_001' as transaction_id,
        '2025-07-08'::date as transaction_dt,
        5001 as item_cd,
        15.50 as net_retail_sales_amt,
        1 as item_qty,
        1 as item_sequence_num,
        'STORE01' as store_cd
    union all
    select
        'TXN_002' as transaction_id,
        '2025-07-15'::date as transaction_dt,
        6002 as item_cd,
        20.00 as net_retail_sales_amt,
        2 as item_qty,
        1 as item_sequence_num,
        'STORE02' as store_cd
),

campaign_product_type_aws as (
    -- Mock data for campaign_product_type_aws table
    select
        'CAMP001' as campaign_id,
        'Digital' as channel_name,
        'Email' as subchannel_name,
        'Groceries' as product_type,
        'Fresh Farm' as unique_brand_name,
        5001 as item_cd,
        '2025-07-01 08:00:00.000'::timestamp_ntz as load_ts
    union all
    select
        'CAMP001' as campaign_id,
        'Digital' as channel_name,
        'Email' as subchannel_name,
        'Snacks' as product_type,
        'Crispy Crunch' as unique_brand_name,
        5002 as item_cd,
        '2025-07-01 08:00:00.000'::timestamp_ntz as load_ts
),

dim_customer_loyalty as (
    -- Mock data for dim_customer_loyalty table
    select
        'CUST123' as nectar_collector_card_num,
        'HASH_CUST123' as customer_loyalty_cd
    union all
    select
        'CUST456' as nectar_collector_card_num,
        'HASH_CUST456' as customer_loyalty_cd
    where nectar_collector_card_num != '~~'
),

points_coupon_redemption as (
    -- Mock data for points_coupon_redemption table
    select
        'TXN_KEY_001' as transaction_key,
        'COUPON_1234567' as coupon_id,
        '2025-07-08'::date as date_key
),

sales_origination_all_codes as (
    -- Mock data for the sales_origination_all_codes parameter
    select '14' as value
    union all
    select '16' as value
),

sales_origination_instore_codes as (
    -- Mock data for the sales_origination_instore_codes parameter
    select '14' as value
),

get_measure_campgn_exec as (
    select
        campaign_id,
        booking_id,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt,
        campaign_end_dt,
        job_status
    from measurement_campaign_execution as mce
    where mce.job_status = 'COMPLETED'
),
current_campaign_details as (
    select
        campaign_id,
        booking_id,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_start_dt as start_date,
        campaign_end_dt as end_date
    from get_measure_campgn_exec
),
get_coupon_details as (
    select
        substr(trim(cp.coupon_id), 1, 14) as coupon_id,
        substr(cp.coupon_id, 1, 14) as coupon_id_2
    from cell as c
    inner join coupon_cell as cc on c.cell_key = cc.cell_key
    inner join coupon as cp on cc.coupon_key = cp.coupon_key
    inner join current_campaign_details as ccd on c.campaign_id = ccd.campaign_id
    where
        c.campaign_id = ccd.campaign_id
    union
    select
        offerbarcode,
        substr(offerbarcode, 1, 14) as offerbarcode_2
    from cat_plan_data
    inner join current_campaign_details as ccd on cat_plan_data.campaigncode = ccd.campaign_id
    where campaigncode = ccd.campaign_id
),
get_targetted_customers_raw as (
    select distinct
        fcat.hash_loyalty_id as customer_key,
        timestamp_from_parts(fcat.coupon_print_dt, fcat.coupon_print_tm) as event_ts
    from fact_coupon_at_till_performant as fcat
    cross join current_campaign_details as ccd
    where
        fcat.barcode in (select distinct coupon_id_2 from get_coupon_details)
        and fcat.coupon_print_dt between ccd.start_date and ccd.end_date
),
get_targetted_customers as (
    select customer_key,
        min(event_ts) as event_ts
    from get_targetted_customers_raw
    group by 1
),
get_fact_sale_transaction_basket as (
    select
        transaction_end_ts,
        nectar_card_num_hash,
        transaction_id,
        transaction_dt,
        sales_origination_channel_cd,
        transaction_key
    from fact_sale_transaction_basket_performant
    cross join current_campaign_details as ccd
    where
        nectar_card_num_hash is not null
        and transaction_dt between ccd.start_date and ccd.end_date
        and sales_origination_channel_cd in (
            select all_codes.value
            from sales_origination_all_codes as all_codes
        )
),
get_fact_sale_transaction_item as (
    select
        transaction_id,
        transaction_dt,
        item_cd,
        net_retail_sales_amt,
        item_qty,
        item_sequence_num,
        store_cd
    from fact_sale_transaction_item_performant
    cross join current_campaign_details as ccd
    where
        transaction_dt between ccd.start_date and ccd.end_date
),
max_load_ts as (
    select
        max(load_ts) as load_ts
    from campaign_product_type_aws as cpt
    inner join current_campaign_details as ccd on cpt.campaign_id = ccd.campaign_id
    where
        cpt.campaign_id = ccd.campaign_id
        and cpt.channel_name = ccd.channel_name
        and cpt.subchannel_name = ccd.subchannel_name
),
get_targeted_skus as (
    select distinct
        product_type,
        unique_brand_name,
        item_cd
    from campaign_product_type_aws as cpta
    inner join current_campaign_details as ccd on cpta.campaign_id = ccd.campaign_id
    where
        cpta.campaign_id = ccd.campaign_id
        and cpta.channel_name = ccd.channel_name
        and cpta.subchannel_name = ccd.subchannel_name
        and load_ts = (select load_ts from max_load_ts)
),
get_redeem_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfstb.transaction_dt as event_dt,
        gfstb.transaction_end_ts as event_ts,
        gfstb.transaction_id as transaction_key,
        gfsti.item_cd,
        gts.unique_brand_name,
        'NA' as marketing_type,
        'In-store' as channel_name,
        ccd.campaign_name as campaign_name ,
        ccd.campaign_id as campaign_id,
        'Purchase Transaction' as event_name,
        ccd.booking_id as booking_id ,
        gts.product_type,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    from dim_customer_loyalty as dcl
    inner join get_fact_sale_transaction_basket as gfstb
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    inner join points_coupon_redemption as pcr
        on gfstb.transaction_key = pcr.transaction_key
    inner join get_targetted_customers as gtc
        on dcl.nectar_collector_card_num = gtc.customer_key
    cross join current_campaign_details as ccd
    where
        pcr.coupon_id in (select distinct coupon_id from get_coupon_details)
        and dcl.nectar_collector_card_num != '~~'
        and gfsti.net_retail_sales_amt > 0
        and pcr.date_key between ccd.start_date and ccd.end_date
        and gfstb.transaction_dt between ccd.start_date and ccd.end_date
        and gfsti.transaction_dt between ccd.start_date and ccd.end_date
),
get_redeem_transaction_data as (
    select
        loyalty_id,
        event_dt,
        event_ts,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_sales_amt,
        sum(item_qty) as units_qty
    from get_redeem_transaction_data_distinct
    group by 1,2,3,4,5,6,7,8,9,10,11,12,13
),
get_all_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id,
        gfstb.transaction_dt as event_dt,
        gfstb.transaction_end_ts as event_ts,
        gfstb.transaction_id as transaction_key,
        gfsti.item_cd,
        gts.unique_brand_name,
        ccd.marketing_type as marketing_type,
        case when
                gfstb.sales_origination_channel_cd in (
                    select instore_codes.value
                    from sales_origination_instore_codes as instore_codes
                )
            then 'In-store'
        else 'Online' end as channel_name,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        'Purchase Transaction' as event_name,
        ccd.booking_id as booking_id,
        gts.product_type,
        gfsti.net_retail_sales_amt,
        gfsti.item_qty,
        gfsti.item_sequence_num
    from  dim_customer_loyalty as dcl
    inner join get_targetted_customers as gtc
        on dcl.customer_loyalty_cd = gtc.customer_key
    inner join get_fact_sale_transaction_basket as gfstb
        on
            dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
            and gtc.event_ts <= gfstb.transaction_end_ts
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    cross join current_campaign_details as ccd
    where
        gfstb.transaction_dt between ccd.start_date and ccd.end_date
        and gfsti.net_retail_sales_amt > 0
        and gfsti.transaction_dt between ccd.start_date and ccd.end_date
        and dcl.nectar_collector_card_num != '~~'
        and gfstb.transaction_id not in (select distinct transaction_key from get_redeem_transaction_data)
        and gfstb.sales_origination_channel_cd in (
            select all_codes.value
            from sales_origination_all_codes as all_codes
        )
),
get_all_transaction_data as (
    select
        loyalty_id,
        event_dt,
        event_ts,
        transaction_key,
        item_cd,
        unique_brand_name,
        marketing_type,
        channel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        product_type,
        sum(net_retail_sales_amt) as net_sales_amt,
        sum(item_qty) as units_qty
    from get_all_transaction_data_distinct
    group by 1,2,3,4,5,6,7,8,9,10,11,12,13
),
create_get_coupon_touchpoint_data as (
    select distinct
        all_txn.loyalty_id,
        ccd.marketing_type as marketing_type,
        ccd.channel_name as channel_name,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        ccd.subchannel_name as subchannel_name,
        all_txn.transaction_key,
        'Touchpoint' as event_name,
        all_txn.booking_id,
        case when gtc.event_ts > all_txn.event_ts then timeadd(millisecond, -100, all_txn.event_ts) else gtc.event_ts end as event_ts,
        case when date(gtc.event_ts) < date(all_txn.event_ts) then date(gtc.event_ts) else date(all_txn.event_ts) end as event_dt
    from (
            select 
                loyalty_id,
                event_dt,
                event_ts,
                transaction_key,
                item_cd,
                unique_brand_name,
                marketing_type,
                channel_name,
                campaign_name,
                campaign_id,
                event_name,
                booking_id,
                product_type,
                net_sales_amt,
                units_qty
            from get_all_transaction_data
            union
            select 
                loyalty_id,
                event_dt,
                event_ts,
                transaction_key,
                item_cd,
                unique_brand_name,
                marketing_type,
                channel_name,
                campaign_name,
                campaign_id,
                event_name,
                booking_id,
                product_type,
                net_sales_amt,
                units_qty           
            from get_redeem_transaction_data
        ) as all_txn
    inner join get_targetted_customers as gtc on all_txn.loyalty_id = gtc.customer_key
    inner join current_campaign_details as ccd on all_txn.campaign_id = ccd.campaign_id
),
get_non_converted_touchpoint_data as (
    select
        gtc.customer_key as loyalty_id,
        ccd.marketing_type as marketing_type,
        ccd.channel_name as channel_name,
        ccd.campaign_name as campaign_name,
        ccd.campaign_id as campaign_id,
        ccd.subchannel_name as subchannel_name,
        null as transaction_key,
        'Touchpoint' as event_name,
        ccd.booking_id as booking_id,
        min(date(gtc.event_ts)) as event_dt,
        min(gtc.event_ts) as event_ts
    from get_targetted_customers as gtc
    cross join current_campaign_details as ccd
    where
        gtc.customer_key not in (select distinct loyalty_id from create_get_coupon_touchpoint_data)
    group by 1,2,3,4,5,6,7,8,9
),
coupon_at_till_collection as (
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        'TXN' as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_sales_amt,
        units_qty
    from get_redeem_transaction_data
    union all
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        'TXN' as subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        item_cd,
        product_type,
        unique_brand_name,
        net_sales_amt,
        units_qty
    from get_all_transaction_data
    union all
    select
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null,
        null,
        null,
        null,
        null
    from create_get_coupon_touchpoint_data
    union all
    select
        loyalty_id,
        null,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        null,
        null,
        null,
        null,
        null
    from get_non_converted_touchpoint_data
)
    select
        loyalty_id,
        coalesce(transaction_key, 'NA') as transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        campaign_name,
        campaign_id,
        event_name,
        booking_id,
        current_timestamp::timestamp_ntz as load_ts,
        coalesce(item_cd, 0) as item_cd,
        coalesce(product_type, 'NA') as product_type,
        coalesce(unique_brand_name, 'NA') as unique_brand_name,
        coalesce(net_sales_amt, 0) as net_sales_amt,
        coalesce(units_qty, 0) as units_qty,
        'some_job_run_id' as job_run_id
    from coupon_at_till_collection;
