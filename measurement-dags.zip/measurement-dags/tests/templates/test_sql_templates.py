import os
import pathlib

from jinja2 import Environment


def test_sql_templates_are_valid():
    """Check that the sql templates are all valid jinja2 templates."""
    root_dir = pathlib.Path(__file__).parent.parent.parent.absolute()
    templates_dir = os.path.join(root_dir, "dags/templates/sql")

    assert os.path.exists(templates_dir)  # in case they move

    template_paths = (
        os.path.join(dirname, filename)
        for dirname, _, filenames in os.walk(templates_dir)
        for filename in filenames
        if filename.endswith(".sql")  # Only check .sql files

    )

    env = Environment()
    for template_path in template_paths:
        with open(template_path, "r") as template:
            env.parse(template.read())
