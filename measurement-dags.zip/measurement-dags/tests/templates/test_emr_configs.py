from unittest import mock

import pytest

from helpers.constants import (
    DEV_ACCOUNT_NUMBER,
    DEV_KEY,
    DEV_SUBNETS,
    INSTANCE_TYPES,
    PROD_ACCOUNT_NUMBER,
    PROD_KEY,
    PROD_SUBNETS,
)
from templates.emr.ebs_config import ebs_config
from templates.emr.cluster_config import job_flow
from templates.emr.step_config import step_config


def test_ebs_config():
    some_size_in_gb = 0
    some_volumes_per_instance: int = 100

    assert ebs_config(size_in_gb=some_size_in_gb, volumes_per_instance=some_volumes_per_instance) == {
        'EbsBlockDeviceConfigs': [
            {
                'VolumeSpecification': {
                    'VolumeType': 'gp2',
                    'SizeInGB': some_size_in_gb},
                'VolumesPerInstance': some_volumes_per_instance}, ],
        'EbsOptimized': True
    }


@pytest.mark.parametrize(
    ("env", "account_number", "ec2_key_name", "ec2_subnet_ids"),
    [("dev", DEV_ACCOUNT_NUMBER, DEV_KEY, DEV_SUBNETS),
     ("prod", PROD_ACCOUNT_NUMBER, PROD_KEY, PROD_SUBNETS)
     ]
)
@mock.patch("templates.emr.cluster_config.Variable.get")
@mock.patch("templates.emr.cluster_config.get_compute_units")
@mock.patch("templates.emr.cluster_config.get_current_aws_user")
@mock.patch("templates.emr.cluster_config.pipeline_run_type_name")
@mock.patch("templates.emr.cluster_config.get_configured_campaign")
def test_job_flow(
    mock_get_configured_campaign,
    mock_pipeline_run_type_name,
    mock_get_current_aws_user,
    mock_get_compute_units,
    mock_get_environment,
    env,
    account_number,
    ec2_key_name,
    ec2_subnet_ids
):
    name = 'some-cluster'
    some_ebs_config = {'ebs': 'config'}
    some_compute_units = '1'
    run_by = "some-user"
    pipeline_run_type = "some-run-type"
    campaign = "some-campaign"

    mock_get_environment.return_value = env
    mock_get_compute_units.return_value = some_compute_units
    mock_get_current_aws_user.return_value = run_by
    mock_pipeline_run_type_name.return_value = pipeline_run_type
    mock_get_configured_campaign.return_value = campaign

    actual_overrides = job_flow(
        name=name,
        master_ebs_config=some_ebs_config,
        master_instance_type="r5.4xlarge",
        core_instance_types=INSTANCE_TYPES,
        tags={"Name": name}
    )

    assert actual_overrides["Name"] == name
    assert actual_overrides["LogUri"] == f's3://aws-logs-{account_number}-eu-west-1/'
    assert actual_overrides["Instances"]["Ec2KeyName"] == ec2_key_name
    assert actual_overrides["Instances"]["Ec2SubnetIds"] == ec2_subnet_ids
    assert actual_overrides["Instances"]["InstanceFleets"][0]["Name"] == "Master"
    assert actual_overrides["Instances"]["InstanceFleets"][1]["Name"] == "Core"
    assert actual_overrides["BootstrapActions"][0]["ScriptBootstrapAction"]["Path"] == f's3://measurement-{env}-artefacts/pipelines/{{{{ resolve_pipelines_version(\'{env}\') }}}}/emr_bootstrap.sh'
    assert actual_overrides["Tags"] == [
        {'Key': 'for-use-with-amazon-emr-managed-policies', 'Value': 'true'},
        {'Key': 'owner', 'Value': 'Measurement'},
        {'Key': 'email', 'Value': 'measurement@sainsburys.co.uk'},
        {'Key': 'costcentre', 'Value': 'PD8634'},
        {'Key': 'project', 'Value': 'Measurement - UP'},
        {'Key': 'dataClassification', 'Value': 'highlySensitive'},
        {'Key': 'environment', 'Value': env},
        {'Key': 'live', 'Value': 'yes' if env == "prod" else 'no'},
        {'Key': 'dataRetention', 'Value': '1-month'},
        {'Key': 'servicename', 'Value': 'Nectar 360 Measurement'},
        {'Key': 'servicecatalogueID', 'Value': '001071675'},
        {"Key": "runBy", "Value": run_by},
        {"Key": "pipelineRunType", "Value": pipeline_run_type},
        {"Key": "campaign", "Value": campaign},
        {"Key": "Name", "Value": name},
    ]


@pytest.mark.parametrize("use_iceberg", [True, False])
def test_step_config(use_iceberg):
    step_name = "test_step"
    step_script_name = "test_script_name.py"
    step_params = [("--arg1", "value1"), ("--arg2", "value2")]
    environment = "dev"
    pipelines_commit_hash = "abcd1234"
    num_executors = 100
    executor_memory = "40g"
    executor_cores = 8
    glue_warehouse = "s3://some-glue-warehouse"

    actual_step = step_config(
        step_name=step_name,
        step_script=step_script_name,
        step_args=step_params,
        environment=environment,
        pipelines_commit_hash=pipelines_commit_hash,
        num_executors=num_executors,
        executor_cores=executor_cores,
        executor_memory=executor_memory,
        glue_warehouse=glue_warehouse,
        use_iceberg=use_iceberg
    )

    expected_args = [
        "spark-submit",
        "--deploy-mode", "client",
        "--num-executors", f'\'{num_executors}\'',
        "--executor-memory", str(executor_memory),
        "--executor-cores", f'\'{executor_cores}\'',
        "--driver-memory", str(executor_memory),
        "--conf", "spark.task.cpus=1",
        "--conf", "spark.driver.extraJavaOptions -Dfs.s3.canned.acl=BucketOwnerFullControl",
        "--conf", "spark.driver.defaultJavaOptions=-XX:+UseG1GC",
        "--conf", "spark.executor.defaultJavaOptions=-XX:+UseG1GC",
        "--conf", "spark.driver.maxResultSize=29g",
        "--conf", "spark.default.parallelism=500",
        "--conf", "spark.sql.windowExec.buffer.spill.threshold=2097152",
        "--conf", "spark.executorEnv.PYTHONHASHSEED=0",
        "--conf", "spark.dynamicAllocation.enabled=false",
        "--conf", "spark.pyspark.python=/usr/bin/python3.11",
        "--conf", "spark.rpc.message.maxSize=1024",
    ]

    if use_iceberg:
        expected_args += [
            "--conf", "spark.sql.catalog=my_catalog",
            "--conf", "spark.sql.defaultCatalog=my_catalog",
            "--conf", "spark.sql.catalog.my_catalog.type=glue",
            "--conf", "spark.sql.extensions=org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
            "--conf", "spark.sql.catalog.my_catalog=org.apache.iceberg.spark.SparkCatalog",
            "--conf", f"spark.sql.catalog.my_catalog.warehouse={glue_warehouse}",
            "--conf", "spark.sql.sources.v2.bucketing.enabled=true",
            "--conf", "spark.sql.sources.v2.bucketing.pushPartValues.enabled=true",
            "--conf", "spark.sql.sources.v2.bucketing.partiallyClusteredDistribution.enabled=true",
            "--conf", "spark.sql.sources.v2.bucketing.allowJoinKeysSubsetOfPartitionKeys.enabled=true",
            "--conf", "spark.sql.sources.v2.bucketing.allowCompatibleTransforms.enabled=true",
            "--conf", "spark.sql.sources.v2.bucketing.shuffle.enabled=true",
            "--conf", "spark.sql.catalog.my_catalog.http-client.apache.max-connections=3000",
        ]

    expected_args += [
        "--name", step_name,
        "--py-files",
        f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/measurement_pipelines-1.0-py3-none-any.whl",
        f"s3://measurement-{environment}-artefacts/pipelines/{{{{ resolve_pipelines_version('{environment}') }}}}/{step_script_name}",
        "--arg1", "value1",
        "--arg2", "value2"
    ]

    expected_step = {
        "Name": step_name,
        "ActionOnFailure": "CONTINUE",
        "HadoopJarStep": {
            "Jar": "command-runner.jar",
            "Args": expected_args
        }
    }

    assert actual_step == expected_step
