import pytest
from unittest.mock import MagicMock, patch
from steps.attribution_model_results import attribution_model_results


@pytest.fixture
def mock_helpers():
    """Mock the helper functions used in attribution_model_results."""
    with patch('steps.attribution_model_results.attribution_model_results.get_path') as mock_get_path, \
         patch('steps.attribution_model_results.attribution_model_results.get_ci') as mock_get_ci, \
         patch('steps.attribution_model_results.attribution_model_results.add_and_watch_step') as mock_add_step:

        # Configure mock return values
        mock_get_path.side_effect = lambda x: f"path_for_{x}"
        mock_get_ci.return_value = "some_correlation_id"
        mock_add_step.return_value = MagicMock()
        yield mock_get_path, mock_get_ci, mock_add_step


def test_step_name_parameter(mock_helpers):
    """Test that step_name parameter is passed through correctly"""
    mock_get_path, mock_get_ci, mock_add_step = mock_helpers

    attribution_model_results.tasks(
        step_name="CustomStepName",
        journey_type="aisle",
        attribution_pre_requisite="attribution_prerequisite",
        output_path="attribution_model_results",
    )

    mock_add_step.assert_called_once()
    call_args = mock_add_step.call_args[1]
    assert call_args['step_name'] == "CustomStepName"


def test_return_value(mock_helpers):
    """Test that the function returns the result from add_and_watch_step"""
    mock_get_path, mock_get_ci, mock_add_step = mock_helpers
    expected_return_value = MagicMock()
    mock_add_step.return_value = expected_return_value

    result = attribution_model_results.tasks(
        step_name="AttributionModelResult",
        journey_type="offer",
        attribution_pre_requisite="attribution_prerequisite",
        output_path="attribution_model_results",
    )

    assert result == expected_return_value
