from unittest import mock
from mockito import when
from steps.attribution_pre_requisite import attribution_pre_requisite

from helpers.constants import JOURNEY_TYPE


@mock.patch("steps.attribution_pre_requisite.attribution_pre_requisite.add_and_watch_step")
def test_attribution_pre_requisite(mock_run_step: mock.MagicMock):

    when(attribution_pre_requisite).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(attribution_pre_requisite).get_path("user_journey_aisle").thenReturn("user_journey_aisle")
    when(attribution_pre_requisite).get_path("attribution_pre_requisite_aisle").thenReturn("attribution_pre_requisite_aisle")
    when(attribution_pre_requisite).get_ci().thenReturn("some_correlation_id")
    when(attribution_pre_requisite).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--user-journey-path", "user_journey_aisle"),
        ("--output-path", "attribution_pre_requisite_aisle"),
        ("--journey-type", JOURNEY_TYPE["aisle"]),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "some_correlation_id"),
        ('--slack-topic-arn', "slack_topic_arn")
    ]

    attribution_pre_requisite.tasks('AttributionPreRequisiteAisle', "user_journey_aisle", JOURNEY_TYPE["aisle"], "attribution_pre_requisite_aisle")

    step_name = "AttributionPreRequisiteAisle"
    step_script = "attribution_pre_requisite.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=8,
        executor_cores=4,
        executor_memory="20g",
    )
