from unittest import mock
from mockito import when
from steps.sku_level_attributed_sales_and_units.sku_level_attributed_sales_and_units import tasks
import steps.sku_level_attributed_sales_and_units.sku_level_attributed_sales_and_units as sku_level_attributed_sales_and_units
from helpers.constants import PRODUCT_TYPE, DTP_RUN_TYPE, POLLEN_RUN_TYPE
import json
from helpers.channel_hierarchy import SUBCHANNELS_CODE


@mock.patch("steps.sku_level_attributed_sales_and_units.sku_level_attributed_sales_and_units.add_and_watch_step")
def test_tasks_without_offer(mock_run_step: mock.MagicMock):

    when(sku_level_attributed_sales_and_units).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(sku_level_attributed_sales_and_units).get_path("customer_data_collection").thenReturn("customer_data_collection")
    when(sku_level_attributed_sales_and_units).get_path("attribution_model_results_brand_path").thenReturn("attribution_model_results_brand_path")
    when(sku_level_attributed_sales_and_units).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("sku_level_attributed_sales_and_units_offer")
    when(sku_level_attributed_sales_and_units).get_path("out_path").thenReturn("out_path")
    when(sku_level_attributed_sales_and_units).get_path("measurement_marketing_channel_hierarchy").thenReturn("measurement_marketing_channel_hierarchy")
    when(sku_level_attributed_sales_and_units).get_path("previous_measurement_campaign_reporting").thenReturn("previous_measurement_campaign_reporting")
    when(sku_level_attributed_sales_and_units).pipeline_run_type().thenReturn(DTP_RUN_TYPE)
    when(sku_level_attributed_sales_and_units).get_ci().thenReturn("some_ci")
    when(sku_level_attributed_sales_and_units).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    subchannel_hierarchy_json = json.dumps(SUBCHANNELS_CODE)
    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--customer-data-collection-path", "customer_data_collection"),
        ("--attribution-model-results-level-path", "attribution_model_results_brand_path"),
        ("--sku-level-attributed-sales-and-units-offer-path", "sku_level_attributed_sales_and_units_offer"),
        ("--output-path", "out_path"),
        ("--product-type", PRODUCT_TYPE["brand"]),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--pipeline-run-type", DTP_RUN_TYPE),
        ("--correlation-id", "some_ci"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--measurement-marketing-channel-hierarchy-path", "measurement_marketing_channel_hierarchy"),
        ("--previous-measurement-campaign-reporting", sku_level_attributed_sales_and_units.get_path("previous_measurement_campaign_reporting")),
        ("--subchannel-hierarchy-codes", f"'{subchannel_hierarchy_json}'")
    ]

    tasks("SkuLevelAttributedSalesAndUnitsBrand", "attribution_model_results_brand_path", "brand", "out_path")

    mock_run_step.assert_called_with(
        step_name="SkuLevelAttributedSalesAndUnitsBrand",
        step_script="sku_level_attributed_sales_and_units.py",
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g"
    )


@mock.patch("steps.sku_level_attributed_sales_and_units.sku_level_attributed_sales_and_units.add_and_watch_step")
def test_tasks_with_offer(mock_run_step):
    when(sku_level_attributed_sales_and_units).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(sku_level_attributed_sales_and_units).get_path("customer_data_collection").thenReturn("customer_data_collection")
    when(sku_level_attributed_sales_and_units).get_path("attribution_model_results_offer_path").thenReturn("attribution_model_results_offer_path")
    when(sku_level_attributed_sales_and_units).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("sku_level_attributed_sales_and_units_offer")
    when(sku_level_attributed_sales_and_units).get_path("out_path").thenReturn("out_path")
    when(sku_level_attributed_sales_and_units).get_path("reach_engagement").thenReturn("reach_engagement")
    when(sku_level_attributed_sales_and_units).get_path("attribution_pre_requisite_offer").thenReturn("attribution_pre_requisite_offer")
    when(sku_level_attributed_sales_and_units).get_path("measurement_marketing_channel_hierarchy").thenReturn("measurement_marketing_channel_hierarchy")
    when(sku_level_attributed_sales_and_units).get_path("previous_measurement_campaign_reporting").thenReturn("previous_measurement_campaign_reporting")
    when(sku_level_attributed_sales_and_units).pipeline_run_type().thenReturn(POLLEN_RUN_TYPE)
    when(sku_level_attributed_sales_and_units).get_ci().thenReturn("some_ci")
    when(sku_level_attributed_sales_and_units).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    subchannel_hierarchy_json = json.dumps(SUBCHANNELS_CODE)
    base_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--customer-data-collection-path", "customer_data_collection"),
        ("--attribution-model-results-level-path", "attribution_model_results_offer_path"),
        ("--sku-level-attributed-sales-and-units-offer-path", "sku_level_attributed_sales_and_units_offer"),
        ("--output-path", "out_path"),
        ("--product-type", PRODUCT_TYPE["offer"]),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--pipeline-run-type", POLLEN_RUN_TYPE),
        ("--correlation-id", "some_ci"),
        ("--slack-topic-arn", "slack_topic_arn"),
        ("--measurement-marketing-channel-hierarchy-path", "measurement_marketing_channel_hierarchy"),
        ("--previous-measurement-campaign-reporting", sku_level_attributed_sales_and_units.get_path("previous_measurement_campaign_reporting")),
        ("--subchannel-hierarchy-codes", f"'{subchannel_hierarchy_json}'")
    ]
    offer_args = [
        ("--reach-engagement-path", "reach_engagement"),
        ("--attribution-pre-requisite-offer-path", "attribution_pre_requisite_offer")
    ]
    expected_args = base_args + offer_args

    tasks("SkuLevelAttributedSalesAndUnitsOffer", "attribution_model_results_offer_path", "offer", "out_path")

    mock_run_step.assert_called_with(
        step_name="SkuLevelAttributedSalesAndUnitsOffer",
        step_script="sku_level_attributed_sales_and_units.py",
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g"
    )
