from unittest import mock
from mockito import when
from steps.normalisation import youtube_normalise_pollen


@mock.patch("steps.normalisation.youtube_normalise_pollen.add_and_watch_step")
def test_youtube_normalise_pollen(mock_run_step: mock.MagicMock):

    when(youtube_normalise_pollen).get_path("campaign_booking_media_channel").thenReturn("campaign_booking_media_channels")
    when(youtube_normalise_pollen).get_path("youtube_normalize_pollen").thenReturn("youtube_normalize_pollen")
    when(youtube_normalise_pollen).get_ci().thenReturn("test-correlation-id-123")

    expected_args = [
        ("--source-table-path", "campaign_booking_media_channels"),
        ("--output-path", "youtube_normalize_pollen"),
        ("--correlation-id", "test-correlation-id-123"),
    ]

    execs = 8
    youtube_normalise_pollen.tasks(execs)

    step_name = "YoutubePollenNormalised"
    step_script = "youtube_normalise_pollen.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
