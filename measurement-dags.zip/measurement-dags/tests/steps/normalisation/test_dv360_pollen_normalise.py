from unittest import mock
from mockito import when
from steps.normalisation import dv360_normalise_pollen


@mock.patch("steps.normalisation.dv360_normalise_pollen.add_and_watch_step")
def test_dv360_normalise_pollen(mock_run_step: mock.MagicMock):

    when(dv360_normalise_pollen).get_path("dv360_pollen_campaign").thenReturn("dv360_pollen_campaign")
    when(dv360_normalise_pollen).get_path("dv360_normalised_pollen").thenReturn("dv360_normalised_pollen")

    expected_args = [
        ("--dv360-pollen-campaign", "dv360_pollen_campaign"),
        ("--output-path", "dv360_normalised_pollen"),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    execs = 8
    dv360_normalise_pollen.tasks(execs)

    step_name = "DV360NormalisePollen"
    step_script = "dv360_normalise_pollen.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
