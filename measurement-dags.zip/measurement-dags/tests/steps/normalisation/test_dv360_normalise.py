from unittest import mock
from mockito import when
from steps.normalisation import dv360_normalise


@mock.patch("steps.normalisation.dv360_normalise.add_and_watch_step")
def test_dv360_normalise(mock_run_step: mock.MagicMock):

    when(dv360_normalise).get_path("dv360_campaign").thenReturn("dv360_campaigns")
    when(dv360_normalise).get_path("dv360_normalised").thenReturn("dv360_normalised")

    expected_args = [
        ("--dv360-campaign", "dv360_campaigns"),
        ("--output-path", "dv360_normalised"),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    execs = 8
    dv360_normalise.tasks(execs)

    step_name = "DV360Normalise"
    step_script = "dv360_normalise.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
