from unittest import mock
from mockito import when
from steps.normalisation import fb_campaign_normalized_pollen


@mock.patch("steps.normalisation.fb_campaign_normalized_pollen.add_and_watch_step")
def test_fb_campaign_normalized_pollen(mock_run_step: mock.MagicMock):

    when(fb_campaign_normalized_pollen).get_path("campaign_booking_media_channel").thenReturn("campaign_booking_media_channel_path")
    when(fb_campaign_normalized_pollen).get_path("fb_campaign_normalized_pollen").thenReturn("fb_campaign_normalized_pollen")
    when(fb_campaign_normalized_pollen).get_ci().thenReturn("test-correlation-id-123")

    expected_args = [
        ("--campaign-bookings-path", "campaign_booking_media_channel_path"),
        ("--output-path", "fb_campaign_normalized_pollen"),
        ("--correlation-id", "test-correlation-id-123"),
    ]

    execs = 8
    fb_campaign_normalized_pollen.tasks(execs)

    step_name = "FbCampaignNormalisedPollen"
    step_script = "fb_campaign_normalized_pollen.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
