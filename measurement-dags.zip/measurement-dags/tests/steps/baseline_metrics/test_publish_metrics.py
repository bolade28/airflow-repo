from unittest import mock
from mockito import when
from helpers.constants import RUN_BASELINE_MANUALLY
from steps.metrics import baseline_metrics


@mock.patch("steps.metrics.baseline_metrics.add_and_watch_step")
def test_publish_metrics(mock_run_step: mock.MagicMock):

    when(baseline_metrics).get_path("campaign_selection").thenReturn("campaign_selection")
    when(baseline_metrics).get_sns("metrics_topic_arn").thenReturn("metrics_topic_arn")
    when(baseline_metrics).get_ci().thenReturn("some_correlation_id")
    when(baseline_metrics).get_path("unified_campaigns").thenReturn("unified_campaigns")
    when(baseline_metrics).get_manual_campaigns_list().thenReturn(["manual_campaign_1", "manual_campaign_2"])

    expected_args = [
        ("--campaign-selection", "campaign_selection"),
        ("--manual-run-flag", f'\"{str(RUN_BASELINE_MANUALLY)}\"'),
        ("--manual-campaign-list", f'\"{["manual_campaign_1", "manual_campaign_2"]}"'),
        ("--metrics-topic-arn", "metrics_topic_arn"),
        ("--correlation-id", "some_correlation_id"),
        ("--unified-campaign-path", "unified_campaigns"),
    ]

    execs = 8
    baseline_metrics.tasks(executors=execs)

    step_name = "BaselineMetrics"
    step_script = "publish_baseline_metrics.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
