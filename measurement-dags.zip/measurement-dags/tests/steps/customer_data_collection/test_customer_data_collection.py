from unittest import mock
from mockito import when
from steps.customer_data_collection import customer_data_collection


@mock.patch("steps.customer_data_collection.customer_data_collection.add_and_watch_step")
def test_customer_data_collection_tasks(mock_run_step: mock.MagicMock):
    when(customer_data_collection).get_path("youtube_data").thenReturn("youtube_data")
    when(customer_data_collection).get_path("dv360_data").thenReturn("dv360_data")
    when(customer_data_collection).get_path("citrus_data").thenReturn("citrus_data")
    when(customer_data_collection).get_path("instore_data").thenReturn("instore_data")
    when(customer_data_collection).get_path("meta_data").thenReturn("meta_data")
    when(customer_data_collection).get_path("magazine_data").thenReturn("magazine_data")
    when(customer_data_collection).get_path("ecoupon_data").thenReturn("ecoupon_data")
    when(customer_data_collection).get_path("coupon_at_till_data").thenReturn("coupon_at_till_data")
    when(customer_data_collection).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(customer_data_collection).get_path("measurement_marketing_channel_hierarchy").thenReturn("measurement_marketing_channel_hierarchy")
    when(customer_data_collection).get_path("customer_data_collection").thenReturn("customer_data_collection")
    when(customer_data_collection).get_ci().thenReturn("Corr-1")
    when(customer_data_collection).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")
    when(customer_data_collection).get_pipeline_run_type().thenReturn('{{task_instance.xcom_pull(task_ids="setup_tasks.configure_run_type", key="return_value")}}')

    expected_args = [
        ("--youtube-data", "youtube_data"),
        ("--dv360-data", "dv360_data"),
        ("--citrus-data", "citrus_data"),
        ("--instore-data", "instore_data"),
        ("--meta-data", "meta_data"),
        ("--magazine-data", "magazine_data"),
        ("--ecoupon-data", "ecoupon_data"),
        ("--coupon-at-till-data", "coupon_at_till_data"),
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--output-path", "customer_data_collection"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--run-type", '{{task_instance.xcom_pull(task_ids="setup_tasks.configure_run_type", key="return_value")}}'),
        ("--correlation-id", "Corr-1"),
        ("--slack-topic-arn", "slack_topic_arn"),
    ]

    execs = 48
    customer_data_collection.tasks(execs)

    step_name = "CustomerDataCollection"
    step_script = "customer_data_collection.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
