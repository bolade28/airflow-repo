from unittest import mock
from mockito import when
from steps.refactoring import refactoring


@mock.patch("steps.refactoring.refactoring.add_and_watch_step")
def test_refactoring(mock_run_step: mock.MagicMock):

    when(refactoring).get_path("weekly_dates").thenReturn("weekly_dates")
    when(refactoring).get_path("sku_cluster_mapping_features_output").thenReturn("sku_clust_map_feats")
    when(refactoring).get_path("campaign_selection").thenReturn("campaign_selection")
    when(refactoring).get_path("unified_product").thenReturn("unified_product")
    # when(refactoring).get_path("cluster_features").thenReturn("cluster_features")
    when(refactoring).get_path("processed_fact_sales_transaction_item_agg").thenReturn("processed_fact_sales_transaction_item_agg")
    when(refactoring).get_path("sales_data_transaction").thenReturn("sales_data_transaction")
    when(refactoring).get_path("refactoring").thenReturn("refactoring")
    when(refactoring).get_ci().thenReturn("some_correlation_id")
    when(refactoring).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates"),
        ("--sku-cluster-mapping-path", "sku_clust_map_feats"),
        ("--campaign-selection-path", "campaign_selection"),
        ("--unified-product-path", "unified_product"),
        # ("--cluster-features-path", "cluster_features"),
        ("--processed-fact-sales-transaction-item-path", "processed_fact_sales_transaction_item_agg"),
        ("--sales-data-transaction-path", "sales_data_transaction"),
        ("--correlation-id", "some_correlation_id"),
        ("--output-path", "refactoring"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ('--slack-topic-arn', "slack_topic_arn")
    ]

    execs = 8
    refactoring.tasks(execs)

    step_name = "Refactoring"
    step_script = "refactoring.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
