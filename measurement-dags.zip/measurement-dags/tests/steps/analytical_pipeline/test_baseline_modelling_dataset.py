from unittest import mock
from mockito import when
from steps.analytical_pipeline import baseline_modelling_dataset


@mock.patch("steps.analytical_pipeline.baseline_modelling_dataset.add_and_watch_step")
def test_baseline_modelling_dataset(mock_run_step: mock.MagicMock):

    when(baseline_modelling_dataset).get_path("weekly_dates").thenReturn("weekly_dates")
    when(baseline_modelling_dataset).get_path("channel_processed_data").thenReturn("channel_processed_data")
    when(baseline_modelling_dataset).get_path("three_letter_coding").thenReturn("three_letter_coding")
    when(baseline_modelling_dataset).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(baseline_modelling_dataset).get_ci().thenReturn("some_correlation_id")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates"),
        ('--channel-processed-data-path', "channel_processed_data"),
        ('--three-letter-coding-path', "three_letter_coding"),
        ("--correlation-id", "some_correlation_id"),
        ("--output-path", "baseline_modelling_dataset_output"),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    execs = 8
    baseline_modelling_dataset.tasks(execs)

    step_name = "BaselineModellingDataset"
    step_script = "baseline_modelling_dataset.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
