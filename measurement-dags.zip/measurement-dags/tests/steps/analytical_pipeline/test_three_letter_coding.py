from unittest import mock
from mockito import when
from steps.analytical_pipeline import three_letter_coding


@mock.patch("steps.analytical_pipeline.three_letter_coding.add_and_watch_step")
def test_three_letter_coding_dataset(mock_run_step: mock.MagicMock):

    when(three_letter_coding).get_path("channel_processed_data").thenReturn("channel_processed_data")
    when(three_letter_coding).get_path("previous_baseline_modelling_dataset").thenReturn("previous_baseline_modelling_dataset")
    when(three_letter_coding).get_path("three_letter_coding").thenReturn("three_letter_coding")
    when(three_letter_coding).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--channel-processed-data-path", "channel_processed_data"),
        ("--baseline-modelling-dataset-path", "previous_baseline_modelling_dataset"),
        ("--output-path", "three_letter_coding"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1"),
    ]

    execs = 8
    three_letter_coding.tasks(execs)

    step_name = "ThreeLetterCoding"
    step_script = "three_letter_coding.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
