from unittest import mock
from mockito import when
from steps.user_journey import user_journey

from helpers.constants import PRODUCT_TYPE, JOURNEY_TYPE


@mock.patch("steps.user_journey.user_journey.add_and_watch_step")
def test_user_journey(mock_run_step: mock.MagicMock):

    when(user_journey).get_path("campaign_product_type").thenReturn("campaign_product_type")
    when(user_journey).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(user_journey).get_path("customer_data_collection").thenReturn("customer_data_collection")
    when(user_journey).get_path("user_journey_aisle").thenReturn("user_journey_aisle")
    when(user_journey).get_ci().thenReturn("some_correlation_id")
    when(user_journey).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--campaign-product-type-path", "campaign_product_type"),
        ("--customer-data-collection-path", "customer_data_collection"),
        ("--output-path", "user_journey_aisle"),
        ("--product-type", PRODUCT_TYPE["aisle"]),
        ("--journey-type", JOURNEY_TYPE["aisle"]),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "some_correlation_id"),
        ('--slack-topic-arn', "slack_topic_arn")
    ]

    user_journey.tasks('UserJourneyAisle', PRODUCT_TYPE["aisle"], JOURNEY_TYPE["aisle"], "user_journey_aisle")

    step_name = "UserJourneyAisle"
    step_script = "user_journey.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )
