from unittest import mock
from mockito import when
from steps.measurement_campaign_reporting import measurement_campaign_reporting


@mock.patch("steps.measurement_campaign_reporting.measurement_campaign_reporting.add_and_watch_step")
def test_measurement_campaign_reporting(mock_run_step: mock.MagicMock):
    """
    Test that measurement_campaign_reporting.tasks() correctly configures and calls add_and_watch_step
    with all required input paths, output path, and executor configuration.
    """
    # Mock the xcom path lookups
    when(measurement_campaign_reporting).get_path("ucm_output_data").thenReturn("s3://bucket/baseline/output")
    when(measurement_campaign_reporting).get_path("measurement_campaign_execution").thenReturn("s3://bucket/campaign/execution")
    when(measurement_campaign_reporting).get_path("unified_campaigns").thenReturn("s3://bucket/unified/campaign")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_brand").thenReturn("s3://bucket/sku/attributed/sales/units/brand")
    when(measurement_campaign_reporting).get_path("sku_level_attributed_sales_and_units_offer").thenReturn("s3://bucket/sku/attributed/sales/units/offer")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_brand").thenReturn("s3://bucket/pre/mta/brand")
    when(measurement_campaign_reporting).get_path("attribution_pre_requisite_offer").thenReturn("s3://bucket/pre/mta/offer")
    when(measurement_campaign_reporting).get_path("measurement_campaign_reporting").thenReturn("s3://bucket/measurement/campaign/reporting")
    when(measurement_campaign_reporting).get_path("base_price_data").thenReturn("s3://bucket/base_price")
    when(measurement_campaign_reporting).get_path("measurement_marketing_channel_hierarchy").thenReturn("s3://bucket/measurement/marketing/channel/hierarchy")
    when(measurement_campaign_reporting).get_ci().thenReturn("test_correlation_id")
    when(measurement_campaign_reporting).get_sns("slack_topic_arn").thenReturn("test_slack_topic_arn")

    expected_args = [
        ("--baseline-output-path", "s3://bucket/baseline/output"),
        ("--campaign-execution-path", "s3://bucket/campaign/execution"),
        ("--unified-campaign-path", "s3://bucket/unified/campaign"),
        ("--sku-level-attributed-sales-units-brand-path", "s3://bucket/sku/attributed/sales/units/brand"),
        ("--sku-level-attributed-sales-units-offer-path", "s3://bucket/sku/attributed/sales/units/offer"),
        ("--pre-mta-brand-path", "s3://bucket/pre/mta/brand"),
        ("--pre-mta-offer-path", "s3://bucket/pre/mta/offer"),
        ("--base-price-path", "s3://bucket/base_price"),
        ("--measurement-marketing-channel-hierarchy-path", "s3://bucket/measurement/marketing/channel/hierarchy"),
        ("--output-path", "s3://bucket/measurement/campaign/reporting"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "test_correlation_id"),
        ("--slack-topic-arn", "test_slack_topic_arn"),
    ]

    # Call the tasks function with default parameters
    measurement_campaign_reporting.tasks()

    step_name = "MeasurementCampaignReporting"
    step_script = "measurement_campaign_reporting.py"

    # Verify add_and_watch_step was called with correct arguments
    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=8,
        executor_cores=4,
        executor_memory="20g",
    )
