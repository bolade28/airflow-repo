from unittest import mock
from mockito import when
from steps.timeseries_data import instore_processed_data


@mock.patch("steps.timeseries_data.instore_processed_data.add_and_watch_step")
def test_instore_processed_data(mock_run_step: mock.MagicMock):
    when(instore_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(instore_processed_data).get_path("ie_location").thenReturn("ie_location")
    when(instore_processed_data).get_path("ie_product").thenReturn("ie_product")
    when(instore_processed_data).get_path("ie_campaign_filt").thenReturn("ie_campaign_filt")
    when(instore_processed_data).get_path("cust_by_location").thenReturn("cust_by_location")
    when(instore_processed_data).get_path("media_instore_init").thenReturn("media_instore_init")
    when(instore_processed_data).get_path("temp_unified_product").thenReturn("temp_unified_product")
    when(instore_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(instore_processed_data).get_path("unified_channel_active_media").thenReturn("unified_channel_active_media")
    when(instore_processed_data).get_path("processed_fact_sales_transaction_basket").thenReturn("processed_fact_sales_transaction_basket")
    when(instore_processed_data).get_path("processed_fact_sales_transaction_item").thenReturn("processed_fact_sales_transaction_item")
    when(instore_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(instore_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(instore_processed_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(instore_processed_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(instore_processed_data).get_path("instore_processed_data").thenReturn("instore_processed_data")
    when(instore_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--campaign-selection-path", "campaign_selection"),
        ("--ie-location-path", "ie_location"),
        ("--ie-product-path", "ie_product"),
        ("--ie-campaign-filt-path", "ie_campaign_filt"),
        ("--cust-by-location-path", "cust_by_location"),
        ("--media-instore-init-path", "media_instore_init"),
        ("--temp-unified-product-path", "temp_unified_product"),
        ("--unified-product-path", "unified_product"),
        ("--is-active-filter-path", "unified_channel_active_media"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--output-path", "instore_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1")
    ]

    execs = 8
    instore_processed_data.tasks(execs)

    step_name = "InstoreProcessedData"
    step_script = "instore_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
