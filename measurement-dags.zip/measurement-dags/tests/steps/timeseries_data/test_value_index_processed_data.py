from unittest import mock
from mockito import when
from steps.timeseries_data import value_index_processed_data


@mock.patch("steps.timeseries_data.value_index_processed_data.add_and_watch_step")
def test_value_index_processed_data(mock_run_step: mock.MagicMock):

    when(value_index_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(value_index_processed_data).get_path("agg_value_index_dashboard_w").thenReturn("agg_value_index_dashboard_w")
    when(value_index_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(value_index_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(value_index_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(value_index_processed_data).get_path("value_index_processed_data").thenReturn("value_index_processed_data")
    when(value_index_processed_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(value_index_processed_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(value_index_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--campaign-selection-python-path", "campaign_selection"),
        ("--agg-value-index-dashboard-w-path", "agg_value_index_dashboard_w"),
        ("--unified-product-path", "unified_product"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--output-path", "value_index_processed_data"),
        ("--correlation-id", "Corr-1"),
        ('--start-date', "2023-06-12"),
        ('--end-date', "2025-06-30"),
        ("--run-date", "{{ data_interval_end | ds }}")

    ]

    execs = 8
    value_index_processed_data.tasks(execs)

    step_name = "ValueIndexProcessedData"
    step_script = "value_index_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
