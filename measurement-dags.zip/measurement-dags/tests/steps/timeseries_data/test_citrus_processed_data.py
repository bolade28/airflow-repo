from unittest import mock
from mockito import when
from steps.timeseries_data import citrus_processed_data


@mock.patch("steps.timeseries_data.citrus_processed_data.add_and_watch_step")
def test_citrus_processed_data(mock_run_step: mock.MagicMock):

    when(citrus_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(citrus_processed_data).get_path("advertise_request_realised").thenReturn("advertise_request_realised")
    when(citrus_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(citrus_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(citrus_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(citrus_processed_data).get_path("citrus_processed_data").thenReturn("citrus_processed_data")
    when(citrus_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--campaign-selection-path", "campaign_selection"),
        ("--advertise-request-realised-path", "advertise_request_realised"),
        ("--unified-product-path", "unified_product"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--output-path", "citrus_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1"),

    ]

    execs = 8
    citrus_processed_data.tasks(execs)

    step_name = "CitrusProcessedData"
    step_script = "citrus_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
