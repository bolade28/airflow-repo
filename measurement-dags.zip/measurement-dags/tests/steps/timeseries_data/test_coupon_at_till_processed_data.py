from unittest import mock
from mockito import when
from steps.timeseries_data import coupon_at_till_processed_data


@mock.patch("steps.timeseries_data.coupon_at_till_processed_data.add_and_watch_step")
def test_coupon_at_till_processed_data(mock_run_step: mock.MagicMock):

    when(coupon_at_till_processed_data).get_path("base_finance_assets").thenReturn("base_finance_assets")
    when(coupon_at_till_processed_data).get_path("campaign").thenReturn("campaign")
    when(coupon_at_till_processed_data).get_path("cell").thenReturn("cell")
    when(coupon_at_till_processed_data).get_path("coupon_cell").thenReturn("coupon_cell")
    when(coupon_at_till_processed_data).get_path("coupon_to_product").thenReturn("coupon_to_product")
    when(coupon_at_till_processed_data).get_path("coupon").thenReturn("coupon")
    when(coupon_at_till_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(coupon_at_till_processed_data).get_path("temp_unified_product").thenReturn("temp_unified_product")
    when(coupon_at_till_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(coupon_at_till_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(coupon_at_till_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(coupon_at_till_processed_data).get_path("coupon_at_till_processed_data").thenReturn("coupon_at_till_processed_data")
    when(coupon_at_till_processed_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(coupon_at_till_processed_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(coupon_at_till_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--base-finance-assets-path", "base_finance_assets"),
        ("--campaign-path", "campaign"),
        ("--cell-path", "cell"),
        ("--coupon-cell-path", "coupon_cell"),
        ("--coupon-to-product-path", "coupon_to_product"),
        ("--coupon-path", "coupon"),
        ("--unified-product-path", "unified_product"),
        ("--temp-unified-product-path", "temp_unified_product"),
        ("--campaign-selection-path", "campaign_selection"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--output-path", "coupon_at_till_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1"),
    ]

    execs = 8
    coupon_at_till_processed_data.tasks(execs)

    step_name = "CouponAtTillProcessedData"
    step_script = "coupon_at_till_processed.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
