from unittest import mock
from mockito import when
from steps.timeseries_data import sales_processed_data


@mock.patch("steps.timeseries_data.sales_processed_data.add_and_watch_step")
def test_promotional_discount_processed_data(mock_run_step: mock.MagicMock):

    when(sales_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(sales_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(sales_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(sales_processed_data).get_path("sales_data_transaction").thenReturn("sales_data_transaction")
    when(sales_processed_data).get_path("sales_processed_data").thenReturn("sales_processed_data")
    when(sales_processed_data).get_ci().thenReturn("123")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--sku-cluster-mapping", "sku_cluster_mapping"),
        ("--campaign-selection", "campaign_selection"),
        ("--sales-data-transaction", "sales_data_transaction"),
        ("--output-path", "sales_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "123"),
    ]

    execs = 8
    sales_processed_data.tasks(execs)

    step_name = "SalesProcessedData"
    step_script = "sales_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
