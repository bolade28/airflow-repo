from unittest import mock
from mockito import when
from steps.timeseries_data import dv360_processed_data


@mock.patch("steps.timeseries_data.dv360_processed_data.add_and_watch_step")
def test_dv360_processed_data(mock_run_step: mock.MagicMock):

    when(dv360_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(dv360_processed_data).get_path("dv360_normalised").thenReturn("dv360_normalised")
    when(dv360_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(dv360_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(dv360_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(dv360_processed_data).get_path("dv360_media_report").thenReturn("dv360_media_report")
    when(dv360_processed_data).get_path("dv360_processed_data").thenReturn("dv360_processed_data")
    when(dv360_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--campaign-selection-python-path", "campaign_selection"),
        ("--dv360-normalised-path", "dv360_normalised"),
        ("--unified-product-path", "unified_product"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--dv360-media-report-path", "dv360_media_report"),
        ("--output-path", "dv360_processed_data"),
        ("--correlation-id", "Corr-1"),
        ("--run-date", "{{ data_interval_end | ds }}")

    ]

    execs = 8
    dv360_processed_data.tasks(execs)

    step_name = "Dv360ProcessedData"
    step_script = "dv360_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
