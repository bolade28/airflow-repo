from unittest import mock
from mockito import when
from steps.timeseries_data import ecoupon_processed_data_pollen


@mock.patch("steps.timeseries_data.ecoupon_processed_data_pollen.add_and_watch_step")
def test_ecoupon_processed_data_pollen(mock_run_step: mock.MagicMock):

    when(ecoupon_processed_data_pollen).get_path("campaign_selection").thenReturn("campaign_selection")
    when(ecoupon_processed_data_pollen).get_path("campaign_booking_media_channel").thenReturn("campaign_booking_media_channel")
    when(ecoupon_processed_data_pollen).get_path("unified_product").thenReturn("unified_product")
    when(ecoupon_processed_data_pollen).get_path("oc_customer_selection").thenReturn("oc_customer_selection")
    when(ecoupon_processed_data_pollen).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(ecoupon_processed_data_pollen).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(ecoupon_processed_data_pollen).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(ecoupon_processed_data_pollen).get_path("ecoupon_processed_data").thenReturn("ecoupon_processed_data")
    when(ecoupon_processed_data_pollen).get_path("ecoupon_processed_data_pollen").thenReturn("ecoupon_processed_data_pollen")
    when(ecoupon_processed_data_pollen).get_ci().thenReturn("Corr-1")

    expected_args = [

        ("--campaign-selection-path", "campaign_selection"),
        ("--campaign-booking-media-channel-path", "campaign_booking_media_channel"),
        ("--historic-ecoupon-processed-data", "ecoupon_processed_data"),
        ("--unified-product-path", "unified_product"),
        ("--oc-customer-selection-path", "oc_customer_selection"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--output-path", "ecoupon_processed_data_pollen"),
        ("--correlation-id", "Corr-1"),
        ("--run-date", "{{ data_interval_end | ds }}")

    ]

    execs = 8
    ecoupon_processed_data_pollen.tasks(execs)

    step_name = "ECouponProcessedDataPollen"
    step_script = "ecoupon_processed_data_pollen.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
