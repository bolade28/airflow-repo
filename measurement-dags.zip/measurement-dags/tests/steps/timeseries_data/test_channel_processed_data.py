from unittest import mock
from mockito import when
from steps.timeseries_data import channel_processed_data


@mock.patch("steps.timeseries_data.channel_processed_data.add_and_watch_step")
def test_channel_processed_data(mock_run_step: mock.MagicMock):

    when(channel_processed_data).get_path("instore_processed_data").thenReturn("instore_processed_data")
    when(channel_processed_data).get_path("meta_processed_data").thenReturn("meta_processed_data")
    when(channel_processed_data).get_path("dv360_processed_data").thenReturn("dv360_processed_data")
    when(channel_processed_data).get_path("citrus_processed_data").thenReturn("citrus_processed_data")
    when(channel_processed_data).get_path("external_processed_data_output").thenReturn("external_processed_data_output")
    when(channel_processed_data).get_path("coupon_at_till_processed_data").thenReturn("coupon_at_till_processed_data")
    when(channel_processed_data).get_path("promotional_discount_processed_data").thenReturn("promotional_discount_processed_data")
    when(channel_processed_data).get_path("value_index_processed_data").thenReturn("value_index_processed_data")
    when(channel_processed_data).get_path("sales_processed_data").thenReturn("sales_processed_data")
    when(channel_processed_data).get_path("youtube_processed_data").thenReturn("youtube_processed_data")
    when(channel_processed_data).get_path("base_price_data").thenReturn("base_price_data")
    when(channel_processed_data).get_path("secondary_space_processed_data").thenReturn("secondary_space_processed_data")
    when(channel_processed_data).get_path("ecoupon_processed_data").thenReturn("secondary_space_processed_data")
    when(channel_processed_data).get_path("weekly_dates").thenReturn("weekly_dates")
    when(channel_processed_data).get_path("ecoupon_processed_data").thenReturn("ecoupon_processed_data")
    when(channel_processed_data).get_path("channel_processed_data").thenReturn("channel_processed_data")
    when(channel_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--external-processed-data-output-path", "external_processed_data_output"),
        ("--promotional-discount-processed-data-path", "promotional_discount_processed_data"),
        ("--value-index-processed-data-path", "value_index_processed_data"),
        ("--sales-processed-data-path", "sales_processed_data"),
        ("--base-price-data-path", "base_price_data"),
        ("--secondary-space-data-path", "secondary_space_processed_data"),
        ("--weekly-dates-path", "weekly_dates"),
        ("--output-path", "channel_processed_data"),
        ("--correlation-id", "Corr-1"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--instore-processed-data-path", "instore_processed_data"),
        ("--coupon-at-till-processed-data-path", "coupon_at_till_processed_data"),
        ("--meta-processed-data-path", "meta_processed_data"),
        ("--dv360-processed-data-path", "dv360_processed_data"),
        ("--youtube-processed-data-path", "youtube_processed_data"),
        ("--citrus-processed-data-path", "citrus_processed_data"),
        ("--ecoupon-processed-data-path", "ecoupon_processed_data"),
    ]

    execs = 8
    channel_processed_data.tasks(executors=execs)

    step_name = "ChannelProcessedData"
    step_script = "channel_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
