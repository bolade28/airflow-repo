
from unittest import mock
from mockito import when
from steps.timeseries_data import ecoupon_processed_data


@mock.patch("steps.timeseries_data.ecoupon_processed_data.add_and_watch_step")
def test_ecoupon_processed_data(mock_run_step: mock.MagicMock):

    when(ecoupon_processed_data).get_path("campaign_selection").thenReturn("campaign_selection")
    when(ecoupon_processed_data).get_path("base_finance_assets").thenReturn("base_finance_assets")
    when(ecoupon_processed_data).get_path("oc_campaign").thenReturn("oc_campaign")
    when(ecoupon_processed_data).get_path("oc_products").thenReturn("oc_products")
    when(ecoupon_processed_data).get_path("oc_customer_selection").thenReturn("oc_customer_selection")
    when(ecoupon_processed_data).get_path("unified_product").thenReturn("unified_product")
    when(ecoupon_processed_data).get_path("temp_unified_product").thenReturn("temp_unified_product")
    when(ecoupon_processed_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(ecoupon_processed_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(ecoupon_processed_data).get_model_start_end_dates('start_date').thenReturn("2023-06-12")
    when(ecoupon_processed_data).get_model_start_end_dates('end_date').thenReturn("2025-06-30")
    when(ecoupon_processed_data).get_path("ecoupon_processed_data").thenReturn("ecoupon_processed_data")
    when(ecoupon_processed_data).get_ci().thenReturn("Corr-1")

    expected_args = [

        ("--campaign-selection-path", "campaign_selection"),
        ("--base-finance-assets-path", "base_finance_assets"),
        ("--oc-campaign-path", "oc_campaign"),
        ("--oc-products-path", "oc_products"),
        ("--oc-customer-selection-path", "oc_customer_selection"),
        ("--unified-product-path", "unified_product"),
        ("--temp-unified-product-path", "temp_unified_product"),
        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--start-date", "2023-06-12"),
        ("--end-date", "2025-06-30"),
        ("--output-path", "ecoupon_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "Corr-1"),

    ]

    execs = 8
    ecoupon_processed_data.tasks(execs)

    step_name = "ECouponProcessedData"
    step_script = "ecoupon_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="20g",
    )
