from unittest import mock
from mockito import when
from steps.timeseries_data import secondary_space_data
from helpers.xcom import get_model_start_end_dates


@mock.patch("steps.timeseries_data.secondary_space_data.add_and_watch_step")
def test_secondary_space_data(mock_run_step: mock.MagicMock):

    when(secondary_space_data).get_path("weekly_dates_extended").thenReturn("weekly_dates_extended")
    when(secondary_space_data).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(secondary_space_data).get_path("planogram_campaigns").thenReturn("planogram_campaigns")
    when(secondary_space_data).get_path("dim_section").thenReturn("dim_section")
    when(secondary_space_data).get_path("secondary_space_processed_data").thenReturn("secondary_space_processed_data")
    when(secondary_space_data).get_ci().thenReturn("Corr-1")

    expected_args = [

        ("--weekly-dates-path", "weekly_dates_extended"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--plngrm-campaign-item-postn-daily-path", "planogram_campaigns"),
        ("--dim-section-path", "dim_section"),
        ("--output-path", "secondary_space_processed_data"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--start-date", str(get_model_start_end_dates('start_date'))),
        ("--end-date", str(get_model_start_end_dates('end_date'))),
        ("--correlation-id", "Corr-1"),


    ]

    execs = 8
    secondary_space_data.tasks(execs)

    step_name = "SecondarySpaceProccessedData"
    step_script = "secondary_space_processed_data.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
