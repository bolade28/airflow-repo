from unittest import mock
from mockito import when
from steps.incremental_shrinkage import incremental_shrinkage
from helpers import xcom as helpers_xcom


@mock.patch("steps.incremental_shrinkage.incremental_shrinkage.add_and_watch_step")
def test_incremental_shrinkage(mock_run_step: mock.MagicMock):
    """
    Test that incremental_shrinkage.tasks() correctly configures and calls add_and_watch_step
    with all required input paths, output path, and executor configuration.
    """
    # Mock the xcom path lookups
    when(incremental_shrinkage).get_path("ucm_output_data").thenReturn("s3://bucket/baseline/output")
    when(incremental_shrinkage).get_path("unified_campaigns").thenReturn("s3://bucket/unified/campaign")
    when(incremental_shrinkage).get_path("incremental_shrinkage").thenReturn("s3://bucket/incremental/shrinkage")
    when(incremental_shrinkage).get_path("campaign_selection").thenReturn("s3://bucket/campaign/selection")
    when(incremental_shrinkage).get_ci().thenReturn("test_correlation_id")
    when(helpers_xcom).pipeline_run_type().thenReturn("DTP")

    expected_args = [
        ("--baseline-output-path", "s3://bucket/baseline/output"),
        ("--campaign-selection-path", "s3://bucket/campaign/selection"),
        ("--output-path", "s3://bucket/incremental/shrinkage"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "test_correlation_id"),
        ("--unified-campaign-path", "s3://bucket/unified/campaign"),
    ]

    # Call the tasks function with required parameters
    incremental_shrinkage.tasks(step_name="IncrementalShrinkage", pipeline_run_type="DTP")

    step_name = "IncrementalShrinkage"
    step_script = "incremental_shrinkage.py"

    # Verify add_and_watch_step was called with correct arguments
    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )
