from unittest import mock
from mockito import when
from steps.baseline_attribution_integration_sku_level import baseline_attribution_integration_sku_level


@mock.patch("steps.baseline_attribution_integration_sku_level.baseline_attribution_integration_sku_level.add_and_watch_step")
def test_baseline_attribution_integration_sku_level(mock_run_step: mock.MagicMock):

    when(baseline_attribution_integration_sku_level).get_path("unified_product").thenReturn("unified_product")
    when(baseline_attribution_integration_sku_level).get_path("ucm_output_data").thenReturn("ucm_output_data")
    when(baseline_attribution_integration_sku_level).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(baseline_attribution_integration_sku_level).get_path("sales_data_transaction").thenReturn("sales_data_transaction")
    when(baseline_attribution_integration_sku_level).get_path("campaign_product_type").thenReturn("campaign_product_type")
    when(baseline_attribution_integration_sku_level).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(baseline_attribution_integration_sku_level).get_path("sku_level_attributed_sales_and_units_level_offer").thenReturn("sku_level_attributed_sales_and_units_level_offer")
    when(baseline_attribution_integration_sku_level).get_path("output_path").thenReturn("output_path")
    when(baseline_attribution_integration_sku_level).get_path("mta_baseline_integration_missing_data_offer").thenReturn("mta_baseline_integration_missing_data_offer")
    when(baseline_attribution_integration_sku_level).get_path("mta_baseline_integration_zero_or_incrementality_offer").thenReturn("mta_baseline_integration_zero_or_incrementality_offer")
    when(baseline_attribution_integration_sku_level).get_ci().thenReturn("some_correlation_id")
    when(baseline_attribution_integration_sku_level).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--unified-product-path", "unified_product"),
        ("--baseline-modelling-output-path", "ucm_output_data"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--sales-data-transformation-path", "sales_data_transaction"),
        ("--campaign-product-type-path", "campaign_product_type"),
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--sku-level-attributed-sales-and-units-level-path", "sku_level_attributed_sales_and_units_level_offer"),
        ("--output-path", "output_path"),
        ("--mta-baseline-integration-missing-data-output-path", "mta_baseline_integration_missing_data_offer"),
        ("--mta-baseline-integration-zero-or-incrementality-output-path", "mta_baseline_integration_zero_or_incrementality_offer"),
        ("--product-type", "Offer"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--correlation-id", "some_correlation_id"),
        ('--slack-topic-arn', "slack_topic_arn")
    ]

    baseline_attribution_integration_sku_level.tasks(
        'BaselineAttributionSkuLevel',
        'sku_level_attributed_sales_and_units_level_offer',
        'Offer',
        'output_path',
        'mta_baseline_integration_missing_data_offer',
        'mta_baseline_integration_zero_or_incrementality_offer',
    )

    step_name = "BaselineAttributionSkuLevel"
    step_script = "baseline_attribution_integration_sku_level.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=48,
        executor_cores=4,
        executor_memory="32g",
    )
