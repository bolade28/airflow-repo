from unittest import mock
from mockito import when
from steps.baseline_forecasting_call import baseline_forecasting_call


@mock.patch("steps.baseline_forecasting_call.baseline_forecasting_call.add_and_watch_step")
def test_baseline_forecasting_call_tasks(mock_run_step: mock.MagicMock):
    # Mock all the get_path calls with the EXACT keys used in the actual code
    when(baseline_forecasting_call).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(baseline_forecasting_call).get_path("ucm_output_data").thenReturn("ucm_output_data")
    when(baseline_forecasting_call).get_path("ucm_intermediate_data").thenReturn("ucm_intermediate_data")
    when(baseline_forecasting_call).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(baseline_forecasting_call).get_path("external_processed_data_output").thenReturn("external_processed_data_output")
    when(baseline_forecasting_call).get_path("sales_data_transaction").thenReturn("sales_data_transaction")
    # when(baseline_forecasting_call).get_path("cluster_features").thenReturn("cluster_features")
    when(baseline_forecasting_call).get_path("campaign_selection").thenReturn("campaign_selection")
    when(baseline_forecasting_call).get_path("baseline_forecasting_call_output").thenReturn("baseline_forecasting_call_output")
    when(baseline_forecasting_call).get_ci().thenReturn("CI-123")

    expected_args = [
        ("--baseline-modelling-dataset-path", "baseline_modelling_dataset_output"),
        ("--baseline-forecast-path", "ucm_output_data"),
        ("--baseline-summary-path", "ucm_intermediate_data"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--external-variables-path", "external_processed_data_output"),
        ("--sales-data-path", "sales_data_transaction"),
        # ("--cluster-features-path", "cluster_features"),
        ("--campaign-selection-path", "campaign_selection"),
        ("--output-path", "baseline_forecasting_call_output"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--job-run-id", "CI-123")
    ]

    execs = 48
    baseline_forecasting_call.tasks(execs)

    step_name = "BaselineForecastingCall"
    step_script = "baseline_forecasting_call.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
