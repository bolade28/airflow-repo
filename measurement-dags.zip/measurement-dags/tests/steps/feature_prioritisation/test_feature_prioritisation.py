from unittest import mock
from mockito import when
from steps.feature_prioritisation import feature_prioritisation


@mock.patch("steps.feature_prioritisation.feature_prioritisation.add_and_watch_step")
def test_feature_prioritisation_tasks(mock_run_step: mock.MagicMock):
    when(feature_prioritisation).get_path("weekly_dates").thenReturn("weekly_dates")
    when(feature_prioritisation).get_path("baseline_modelling_dataset_output").thenReturn("baseline_modelling_dataset_output")
    when(feature_prioritisation).get_path("baseline_primary_metric").thenReturn("baseline_primary_metric")
    when(feature_prioritisation).get_path("sku_cluster_mapping").thenReturn("sku_cluster_mapping")
    when(feature_prioritisation).get_path("campaign_selection").thenReturn("campaign_selection")
    when(feature_prioritisation).get_path("feature_prioritisation").thenReturn("feature_prioritisation")
    when(feature_prioritisation).get_ci().thenReturn("Corr-1")

    expected_args = [
        ("--weekly-dates-path", "weekly_dates"),
        ("--baseline-modelling-dataset-path", "baseline_modelling_dataset_output"),
        ("--baseline-primary-metric-path", "baseline_primary_metric"),
        ("--sku-cluster-mapping-path", "sku_cluster_mapping"),
        ("--campaign-selection-path", "campaign_selection"),
        ("--output-path-feature-prioritisation", "feature_prioritisation"),
        ("--correlation-id", "Corr-1"),
        ("--run-date", "{{ data_interval_end | ds }}"),
    ]

    execs = 48
    feature_prioritisation.tasks(execs)

    step_name = "FeaturePrioritisation"
    step_script = "feature_prioritisation.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
