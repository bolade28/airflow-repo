from unittest import mock
from mockito import when
from steps.reach_engagement import reach_engagement


@mock.patch("steps.reach_engagement.reach_engagement.add_and_watch_step")
def test_reach_engagement(mock_run_step: mock.MagicMock):

    when(reach_engagement).get_path("measurement_campaign_execution").thenReturn("measurement_campaign_execution")
    when(reach_engagement).get_path("digital_trading_campaign_sat").thenReturn("digital_trading_campaign_sat")
    when(reach_engagement).get_path("digital_trading_campaign_link").thenReturn("digital_trading_campaign_link")

    when(reach_engagement).get_path("digital_trading_lineitem_facebook_insight").thenReturn("digital_trading_lineitem_facebook_insight")
    when(reach_engagement).get_path("dv360_media_report").thenReturn("media_report")
    when(reach_engagement).get_path("unique_reach_lineitem_report").thenReturn("unique_reach_lineitem_report")

    when(reach_engagement).get_path("floodlight_report").thenReturn("floodlight_report")
    when(reach_engagement).get_path("user_journey_offer").thenReturn("user_journey_offer")
    when(reach_engagement).get_path("advertise_request_realised").thenReturn("advertise_request_realised")
    when(reach_engagement).get_path("meta_data").thenReturn("meta_data")

    when(reach_engagement).get_path("unified_campaigns").thenReturn("unified_campaigns")
    when(reach_engagement).get_path("advertising_campaign_citcam_sat").thenReturn("advertising_campaign_citcam_sat")
    when(reach_engagement).get_path("reach_engagement").thenReturn("reach_engagement")
    when(reach_engagement).get_path("reach_engagement_reporting").thenReturn("reach_engagement_reporting")

    when(reach_engagement).get_ci().thenReturn("some_correlation_id")
    when(reach_engagement).get_sns("slack_topic_arn").thenReturn("slack_topic_arn")

    expected_args = [
        ("--measurement-campaign-execution-path", "measurement_campaign_execution"),
        ("--digital-trading-campaign-dmfbca-sat-path", "digital_trading_campaign_sat"),
        ("--digital-trading-campaign-channel-dmfbca-link-path", "digital_trading_campaign_link"),

        ("--digital-trading-lineitem-insight-dmfbin-link-path", "digital_trading_lineitem_facebook_insight"),
        ("--media-report-path", "media_report"),
        ("--unique-reach-lineitem-report-path", "unique_reach_lineitem_report"),

        ("--floodlight-report-path", "floodlight_report"),
        ("--user-journey-offer-path", "user_journey_offer"),
        ("--advertising-campaign-request-realised-link-path", "advertise_request_realised"),

        ("--advertising-campaign-citcam-sat-path", "advertising_campaign_citcam_sat"),
        ("--meta-data-path", "meta_data"),
        ("--output-path", "reach_engagement"),
        ("--output-reporting-path", "reach_engagement_reporting"),
        ("--correlation-id", "some_correlation_id"),
        ("--run-date", "{{ data_interval_end | ds }}"),
        ("--run-type", "DTP"),
        ('--slack-topic-arn', "slack_topic_arn"),
        ("--unified-campaigns-path", "unified_campaigns")
    ]

    execs = 8
    reach_engagement.tasks(executors=execs)

    step_name = "ReachEngagement"
    step_script = "reach_engagement.py"

    mock_run_step.assert_called_with(
        step_name=step_name,
        step_script=step_script,
        step_args=expected_args,
        num_executors=execs,
        executor_cores=4,
        executor_memory="32g",
    )
