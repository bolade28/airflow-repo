import re

from task_groups.slack_alert import (
    build_blacklist_alert_message,
    _format_campaign_table,
    build_campaign_end_alert_message,
    build_post_period_end_alert_message,
)


def test_build_blacklist_alert_message_no_rows_returns_success_message():
    message = build_blacklist_alert_message(rows=[], execution_date="2024-01-15")

    assert message == ":white_check_mark: No blacklist records found in this validation run."


def test_build_blacklist_alert_message_counts_distinct_and_formats_today_list():
    rows = [
        ("BOOKING_001", "CID1", "SEARCH", "Booking One", "ACTIVE", "invalid_campaign_id", "2024-01-15"),
        ("BOOKING_001", "CID1", "SEARCH", "Booking One", "ACTIVE", "invalid_campaign_id", "2024-01-15"),  # duplicate
        ("BOOKING_002", "CID2", "SOCIAL", "Booking Two", "COMPLETED", "invalid_marketing_channel", "2024-01-20"),
        ("BOOKING_003", "CID3", "DISPLAY", "Booking Three", "ACTIVE", "invalid_channel_type", "2024-02-14"),
        ("BOOKING_004", "CID4", "DISPLAY", "Booking Four", "COMPLETED", "invalid_skuId", "2024-03-01"),  # out of next-30
    ]

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15")

    assert ":warning: *Data issue detected:*" in message
    assert "- Finishing today: BOOKING_001" in message
    assert "- Finishing in next 10 days (distinct bookings): 2" in message
    assert "BOOKING_001" in message
    assert "BOOKING_002" in message
    assert "- Finishing in next 30 days (distinct bookings): 3" in message
    assert "*Booking ID:* BOOKING_001" in message
    assert "*Status:* ACTIVE" in message
    assert "*Booking Name:* Booking One" in message
    assert "*Booking ID:* BOOKING_002" in message
    assert "*Booking ID:* BOOKING_003" in message
    assert "*Booking ID:* BOOKING_004" not in message


def test_build_blacklist_alert_message_includes_10_and_30_day_boundaries():
    rows = [
        ("BOOKING_TODAY", "CID1", "SEARCH", "Today Booking", "ACTIVE", "invalid_campaign_id", "2024-01-15"),
        ("BOOKING_DAY10", "CID2", "SOCIAL", "Day10 Booking", "COMPLETED", "invalid_campaign_id", "2024-01-25"),
        ("BOOKING_DAY30", "CID3", "DISPLAY", "Day30 Booking", "ACTIVE", "invalid_campaign_id", "2024-02-14"),
    ]

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15")

    assert "- Finishing in next 10 days (distinct bookings): 2" in message
    assert "- Finishing in next 30 days (distinct bookings): 3" in message


def test_build_blacklist_alert_message_skips_invalid_end_date_and_normalizes_reason():
    rows = [
        ("BOOKING_001", "CID1", "SEARCH", "Booking One", "ACTIVE", "[502]|[504]", "2024-01-20"),
        ("BOOKING_002", "CID2", "SEARCH", "Booking Two", "COMPLETED", "[501]\n[508]", "not-a-date"),
    ]

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15")

    assert "*Reason:* [502]/[504]" in message
    assert "BOOKING_002" not in message
    assert "- Finishing in next 30 days (distinct bookings): 1" in message


def test_build_blacklist_alert_message_truncates_display_to_30_rows_with_notice():
    rows = []
    for idx in range(31):
        booking = f"BOOKING_{idx:03d}"
        rows.append((booking, f"CID{idx}", "SEARCH", f"Booking {idx}", "ACTIVE", "invalid_campaign_id", "2024-01-20"))

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15")

    displayed_booking_lines = re.findall(r"-> \*Booking ID:\*", message)
    assert len(displayed_booking_lines) == 30
    assert "_Showing first 30 of 31 upcoming records._" in message


# Tests for _format_campaign_table
def test_format_campaign_table_empty_records():
    result = _format_campaign_table([], "campaign_end_dt", "days_until_end", 10)
    assert result == ""


def test_format_campaign_table_single_record():
    records = [
        {
            "booking_id": "12345",
            "booking_name": "Test Campaign",
            "campaign_end_dt": "2024-03-20",
            "channel_name": "Social Media",
            "marketing_type": "Display, Social",
            "days_until_end": 5,
        }
    ]

    result = _format_campaign_table(records, "campaign_end_dt", "days_until_end", 10)

    assert "```" in result
    assert "Booking ID                 | Booking Name" in result
    assert "Channel" in result
    assert "Marketing Type" in result
    assert "Evaluation Due In" in result
    assert "12345" in result
    assert "Test Campaign" in result
    assert "Social Media" in result
    assert "Display, Social" in result
    assert "5d" in result


def test_format_campaign_table_multiple_records():
    records = [
        {
            "booking_id": "12345",
            "booking_name": "Campaign One",
            "campaign_end_dt": "2024-03-20",
            "channel_name": "TV",
            "marketing_type": "Display",
            "days_until_end": 5,
        },
        {
            "booking_id": "67890",
            "booking_name": "Campaign Two",
            "campaign_end_dt": "2024-03-25",
            "channel_name": "Digital",
            "marketing_type": "Social",
            "days_until_end": 10,
        },
    ]

    result = _format_campaign_table(records, "campaign_end_dt", "days_until_end", 10)

    assert "12345" in result
    assert "67890" in result
    assert "Campaign One" in result
    assert "Campaign Two" in result
    assert "TV" in result
    assert "Digital" in result
    assert "5d" in result
    assert "10d" in result


def test_format_campaign_table_truncates_long_fields():
    records = [
        {
            "booking_id": "12345678901234567890123456789012",  # 32 chars, should be truncated to 26
            "booking_name": "A" * 100,  # 100 chars, should be truncated to 43
            "campaign_end_dt": "2024-03-20",
            "channel_name": "B" * 50,  # Should be truncated to 27
            "marketing_type": "Display, Social, Video, Email, SMS",  # Should be truncated to 15
            "days_until_end": 5,
        }
    ]

    result = _format_campaign_table(records, "campaign_end_dt", "days_until_end", 10)

    # Check that fields are properly truncated
    lines = result.split("\n")
    data_line = [line for line in lines if "12345678901234567890123456" in line][0]

    # Each field should be padded/truncated to its specified width
    assert "12345678901234567890123456" in data_line  # 26 chars of booking_id
    assert len([c for c in data_line if c == '|']) == 4  # Should have 4 pipe separators


def test_format_campaign_table_shows_limit_notice():
    records = [
        {
            "booking_id": f"JOB{i:05d}",
            "booking_name": f"Campaign {i}",
            "campaign_end_dt": "2024-03-20",
            "channel_name": "TV",
            "marketing_type": "Display",
            "days_until_end": i,
        }
        for i in range(15)
    ]

    result = _format_campaign_table(records, "campaign_end_dt", "days_until_end", 10)

    assert "_Showing top 10 of 15 campaigns_" in result
    assert "JOB00000" in result
    assert "JOB00009" in result
    assert "JOB00014" not in result  # Should not show 15th record


def test_format_campaign_table_handles_none_values():
    records = [
        {
            "booking_id": "12345",
            "booking_name": None,  # None should become 'N/A'
            "campaign_end_dt": "2024-03-20",
            "channel_name": "",
            "marketing_type": "",
            "days_until_end": 5,
        }
    ]

    result = _format_campaign_table(records, "campaign_end_dt", "days_until_end", 10)

    assert "N/A" in result
    assert "12345" in result


# Tests for build_campaign_end_alert_message
def test_build_campaign_end_alert_message_no_rows():
    result = build_campaign_end_alert_message(rows=None, execution_date="2024-01-15", days_threshold=20)
    assert result == ":white_check_mark: No ongoing campaigns ending in the next 20 days."


def test_build_campaign_end_alert_message_empty_rows():
    result = build_campaign_end_alert_message(rows=[], execution_date="2024-01-15", days_threshold=20)
    assert result == ":white_check_mark: No ongoing campaigns ending in the next 20 days."


def test_build_campaign_end_alert_message_single_campaign():
    rows = [
        ("JOB123", "Test Campaign", "2024-03-20", "Display, Social", "TV", 5)
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "📊 *Booking Evaluation - During*" in result
    assert "JOB123" in result
    assert "Test Campaign" in result
    assert "TV" in result
    assert "Display, Social" in result
    assert "5d" in result
    assert "_1 unique campaigns active in 20 days_" in result


def test_build_campaign_end_alert_message_multiple_campaigns():
    rows = [
        ("JOB123", "Campaign One", "2024-03-20", "Display", "TV", 5),
        ("JOB456", "Campaign Two", "2024-03-25", "Social", "Digital", 10),
        ("JOB789", "Campaign Three", "2024-03-30", "Video", "Radio", 15),
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "📊 *Booking Evaluation - During*" in result
    assert "JOB123" in result
    assert "JOB456" in result
    assert "JOB789" in result
    assert "_3 unique campaigns active in 20 days_" in result


def test_build_campaign_end_alert_message_duplicate_job_bags():
    rows = [
        ("JOB123", "Campaign One", "2024-03-20", "Display", "TV", 5),
        ("JOB123", "Campaign One", "2024-03-20", "Social", "Digital", 5),  # Same job bag
        ("JOB456", "Campaign Two", "2024-03-25", "Video", "Radio", 10),
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Should count only 2 unique campaigns (JOB123 counted once despite appearing twice)
    assert "_2 unique campaigns active in 20 days_" in result


def test_build_campaign_end_alert_message_skips_invalid_rows():
    rows = [
        ("JOB123", "Valid Campaign", "2024-03-20", "Display", "TV", 5),
        (None, None, None, None, None),  # Invalid row - too short after filtering
        ("JOB456", "Another Valid", "2024-03-25", "Social", "Digital", 10),
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Should only process valid rows
    assert "JOB123" in result
    assert "JOB456" in result


def test_build_campaign_end_alert_message_shows_top_10_only():
    rows = [
        (f"JOB{i:03d}", f"Campaign {i}", "2024-03-20", "Display", "TV", i)
        for i in range(15)
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "JOB000" in result
    assert "JOB009" in result
    assert "_Showing top 10 of 15 campaigns_" in result
    assert "_15 unique campaigns active in 20 days_" in result


def test_build_campaign_end_alert_message_handles_none_days():
    rows = [
        ("JOB123", "Test Campaign", "2024-03-20", "Display", "TV", None),
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Should default to 0 days
    assert "0d" in result


# Tests for build_post_period_end_alert_message
def test_build_post_period_end_alert_message_no_rows():
    result = build_post_period_end_alert_message(rows=None, execution_date="2024-01-15", days_threshold=20)
    assert result == ":white_check_mark: No post-period campaigns ending in the next 20 days."


def test_build_post_period_end_alert_message_empty_rows():
    result = build_post_period_end_alert_message(rows=[], execution_date="2024-01-15", days_threshold=20)
    assert result == ":white_check_mark: No post-period campaigns ending in the next 20 days."


def test_build_post_period_end_alert_message_single_campaign():
    rows = [
        ("JOB123", "Post Campaign Test", "2024-04-20", "Display, Email", "Digital", 8)
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "📊 *Booking Evaluation - Post*" in result
    assert "JOB123" in result
    assert "Post Campaign Test" in result
    assert "Digital" in result
    assert "Display, Email" in result
    assert "8d" in result
    assert "_1 unique campaigns active in 20 days_" in result


def test_build_post_period_end_alert_message_multiple_campaigns():
    rows = [
        ("JOB123", "Post Campaign One", "2024-04-20", "Display", "TV", 8),
        ("JOB456", "Post Campaign Two", "2024-04-25", "Social", "Digital", 13),
        ("JOB789", "Post Campaign Three", "2024-04-30", "Video", "Radio", 18),
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "📊 *Booking Evaluation - Post*" in result
    assert "JOB123" in result
    assert "JOB456" in result
    assert "JOB789" in result
    assert "_3 unique campaigns active in 20 days_" in result


def test_build_post_period_end_alert_message_duplicate_job_bags():
    rows = [
        ("JOB123", "Post Campaign", "2024-04-20", "Display", "TV", 8),
        ("JOB123", "Post Campaign", "2024-04-20", "Social", "Digital", 8),  # Duplicate
        ("JOB456", "Another Post Campaign", "2024-04-25", "Video", "Radio", 13),
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Should count only 2 unique campaigns
    assert "_2 unique campaigns active in 20 days_" in result


def test_build_post_period_end_alert_message_skips_invalid_rows():
    rows = [
        ("JOB123", "Valid Post", "2024-04-20", "Display", "TV", 8),
        (None, None, None, None),  # Too short
        ("JOB456", "Another Valid", "2024-04-25", "Social", "Digital", 13),
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "JOB123" in result
    assert "JOB456" in result


def test_build_post_period_end_alert_message_shows_top_10_only():
    rows = [
        (f"JOB{i:03d}", f"Post Campaign {i}", "2024-04-20", "Display", "TV", i + 5)
        for i in range(12)
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    assert "JOB000" in result
    assert "JOB009" in result
    assert "_Showing top 10 of 12 campaigns_" in result
    assert "_12 unique campaigns active in 20 days_" in result


def test_build_post_period_end_alert_message_handles_none_days():
    rows = [
        ("JOB123", "Post Test", "2024-04-20", "Display", "TV", None),
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Should default to 0 days
    assert "0d" in result


def test_build_campaign_end_alert_message_formats_table_correctly():
    rows = [
        ("JOB123456", "My Campaign Name", "2024-03-20", "Display, Social", "TV", 7),
    ]

    result = build_campaign_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Check table structure
    assert "```" in result
    assert "Booking ID                 | Booking Name" in result
    assert "Channel" in result
    assert "Marketing Type" in result
    assert "Evaluation Due In" in result
    assert "---|" in result  # Table separator


def test_build_post_period_end_alert_message_formats_table_correctly():
    rows = [
        ("JOB123456", "My Post Campaign", "2024-04-20", "Video, Email", "Digital", 12),
    ]

    result = build_post_period_end_alert_message(rows=rows, execution_date="2024-01-15", days_threshold=20)

    # Check table structure
    assert "```" in result
    assert "Booking ID                 | Booking Name" in result
    assert "Channel" in result
    assert "Marketing Type" in result
    assert "Evaluation Due In" in result
    assert "---|" in result  # Table separator
# Tests for task_groups/slack_alert.py
