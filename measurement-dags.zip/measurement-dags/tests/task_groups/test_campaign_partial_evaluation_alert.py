from task_groups.campaign_partial_evaluation_alert import format_campaign_mismatch_alert_table, create_mismatch_alert_message


def test_format_campaign_mismatch_alert_table_empty_rows():
    """Test that an empty list of rows returns an empty string."""
    result = format_campaign_mismatch_alert_table([])
    assert result == ""


def test_format_campaign_mismatch_alert_table_single_row():
    """Test that a single row is formatted correctly as a table with metadata."""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1", 3, 2, "2026-02-28")
    ]
    result = format_campaign_mismatch_alert_table(rows)

    # Checks unified table format
    assert "```" in result
    assert "+-" in result
    assert "|" in result
    assert "BOOKING_1" in result
    assert "Booking Name 1" in result
    assert "SUBCHANNEL_1" in result
    assert "2026-02-28" in result

    # Check message is present
    assert "*Total campaigns with mismatches:*" in result
    assert "*Action Required:*" in result
    assert "CHECK_CAMPAIGN_MISMATCH" in result


def test_format_campaign_mismatch_alert_table_with_none_values():
    """Test that None values in the rows are handled gracefully in table format with metadata."""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", None, 3, 2, "2026-02-28")
    ]
    result = format_campaign_mismatch_alert_table(rows)

    # Check None handling
    assert "Unknown" in result
    # Check unified table format is used
    assert "+-" in result

    # Check message is present
    assert "*Total campaigns with mismatches:*" in result
    assert "*Action Required:*" in result


def test_format_campaign_mismatch_alert_table_with_limit():
    """Test that the limit parameter correctly restricts the number of rows displayed."""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1", 5, 2, "2026-02-28"),
        ("BOOKING_2", "Booking Name 2", "CAMPAIGN_2", "SUBCHANNEL_2", 4, 1, "2026-03-15"),
        ("BOOKING_3", "Booking Name 3", "CAMPAIGN_3", "SUBCHANNEL_3", 3, 0, "2026-04-10"),
    ]
    result = format_campaign_mismatch_alert_table(rows, limit=2)

    # Should show first 2 rows in unified table format
    assert "BOOKING_1" in result
    assert "BOOKING_2" in result
    assert "BOOKING_3" not in result
    assert "+-" in result

    # Should show "Showing top X of Y" message
    assert "Showing top 2 of 3" in result
    assert "*Total campaigns with mismatches:* 3" in result


def test_create_mismatch_alert_message_no_mismatch_returns_empty_string():
    """Tests that the campaign evaluation alert returns an empty string when there are no mismatches."""
    result = create_mismatch_alert_message([])
    assert result == ""


def test_create_mismatch_alert_message_with_mismatches():
    """Test alert message formatting with mismatches"""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1", 3, 2, "2026-02-28")
    ]
    result = create_mismatch_alert_message(rows=rows)

    assert ":warning: *Campaign Only Partially Evaluated*" in result
    # Check that unified format table is included
    assert "```" in result
    assert "+-" in result  # Unified table separator
    assert "BOOKING_1" in result
    assert "Booking Name 1" in result


def test_create_mismatch_alert_message_with_limit():
    """Test that the limit parameter correctly restricts table rows shown in the message"""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1", 5, 2, "2026-02-28"),
        ("BOOKING_2", "Booking Name 2", "CAMPAIGN_2", "SUBCHANNEL_2", 4, 1, "2026-03-15"),
        ("BOOKING_3", "Booking Name 3", "CAMPAIGN_3", "SUBCHANNEL_3", 3, 0, "2026-04-10"),
        ("BOOKING_4", "Booking Name 4", "CAMPAIGN_4", "SUBCHANNEL_4", 2, 0, "2026-05-20"),
    ]
    result = create_mismatch_alert_message(rows=rows, limit=2)

    # Shows only the first 2 rows in table due to the set limit
    assert "BOOKING_1" in result
    assert "BOOKING_2" in result
    # Should not show rows beyond the limit
    assert "BOOKING_3" not in result
    assert "BOOKING_4" not in result
    # Check unified table format
    assert "+-" in result
    # Should show message about additional campaigns
    assert "2 more campaigns not shown" in result
    assert "CHECK_CAMPAIGN_MISMATCH" in result


def test_create_mismatch_alert_message_with_none_rows():
    """Test that None rows are handled correctly."""
    result = create_mismatch_alert_message(None)
    assert result == ""


def test_format_campaign_mismatch_alert_table_with_short_rows():
    """Tests campaigns with missing fields"""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1"),
        ("BOOKING_2", "Booking Name 2"),
    ]
    result = format_campaign_mismatch_alert_table(rows)

    # Asserts that missing fields are filled in with "Unknown"
    assert "BOOKING_1" in result
    assert "BOOKING_2" in result
    assert "Unknown" in result


def test_format_campaign_mismatch_alert_table_with_long_field_values():
    """Test that very long field values are handled correctly in the table."""
    rows = [
        (
            "BOOKING_" + "X" * 100,
            "Campaign Name " + "Y" * 200,
            "CAMPAIGN_1",
            "SUBCHANNEL_" + "Z" * 50,
            5,
            2,
            "2026-02-28"
        )
    ]
    result = format_campaign_mismatch_alert_table(rows)

    # Should not crash and should produce a table
    assert "```" in result
    assert "+-" in result
    assert "BOOKING_" in result
    assert "Campaign Name" in result


def test_format_campaign_mismatch_alert_table_unified_format_markers():
    """Test that the unified format table markers are present."""
    rows = [
        ("BOOKING_1", "Booking Name 1", "CAMPAIGN_1", "SUBCHANNEL_1", 3, 2, "2026-02-28"),
        ("BOOKING_2", "Booking Name 2", "CAMPAIGN_2", "SUBCHANNEL_2", 4, 1, "2026-03-15"),
    ]
    result = format_campaign_mismatch_alert_table(rows)

    # Ensures that the table is in the right format
    assert "+-" in result  # Row separator start
    assert "-+-" in result  # Column separator in row separator
    assert "| " in result  # Column data start
    assert " |" in result  # Column data end
    assert "```\n" in result  # Code block markers

    # Checks that the headers are present
    assert "Booking ID" in result
    assert "Booking Name" in result
    assert "Sub-channel Name" in result
    assert "Campaign End Date" in result


def test_create_mismatch_alert_message_none_in_row_elements():
    """Tests that None values can be handled"""
    rows = [
        (None, None, None, None, None, None, None),
        ("BOOKING_1", None, "CAMPAIGN_1", None, 3, 2, None),
    ]
    result = create_mismatch_alert_message(rows=rows)

    assert ":warning:" in result
    assert "Unknown" in result
    assert "+-" in result
