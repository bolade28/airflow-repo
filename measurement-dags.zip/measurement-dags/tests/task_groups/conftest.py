from unittest.mock import patch

import pytest


@pytest.fixture(autouse=True)
def mock_get_environment():
    with patch("task_groups.slack_alert.get_environment", return_value="dev"), \
         patch("task_groups.validation_slack_alerts.get_environment", return_value="dev"):
        yield
