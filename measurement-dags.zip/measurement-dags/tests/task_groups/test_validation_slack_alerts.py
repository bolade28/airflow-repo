import task_groups.validation_slack_alerts as vsa
from task_groups.validation_slack_alerts import (
    build_blacklist_alert_message,
    build_end_alert_message,
    unified_format_table_rows,
)


def _safe_unified_format_table_rows(headers, keys, records, display_limit):
    limited = records[:display_limit]
    if not headers:
        return ""

    col_widths = [len(h) for h in headers]
    for record in limited:
        for i, key in enumerate(keys):
            col_widths[i] = max(col_widths[i], len(str(record.get(key, "") or "")))

    def format_row(values):
        return "| " + " | ".join(str(v).ljust(w) for v, w in zip(values, col_widths)) + " |"

    separator = "+-" + "-+-".join("-" * w for w in col_widths) + "-+"
    lines = [separator, format_row(headers), separator]
    for record in limited:
        lines.append(format_row([str(record.get(k, "") or "") for k in keys]))
    lines.append(separator)

    return "```\n" + "\n".join(lines) + "\n```"


def test_build_blacklist_alert_message_no_rows_returns_success_message():
    message = build_blacklist_alert_message(rows=[], execution_date="2024-01-15", correlation_id="")
    assert message == ":white_check_mark: No blacklist records found in this validation run."


def test_build_blacklist_alert_message_formats_table_and_footer():
    rows = [
        ("BOOKING_001", "CID1", "SEARCH", "Booking One", "ACTIVE", "invalid_campaign_id", "2024-01-15"),
        ("BOOKING_001", "CID1", "SEARCH", "Booking One", "ACTIVE", "invalid_campaign_id", "2024-01-15"),
        ("BOOKING_002", "CID2", "SOCIAL", "Booking Two", "COMPLETED", "invalid_marketing_channel", "2024-01-20"),
    ]

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15", correlation_id="CI-999")

    assert ":warning:" in message
    assert "Correlation ID: CI-999" in message
    assert "| Booking ID" in message
    assert "BOOKING_001" in message
    assert "BOOKING_002" in message
    assert "Full details can be found in" in message


def test_build_blacklist_alert_message_truncates_display_to_default_limit():
    rows = []
    for idx in range(31):
        booking = f"BOOKING_{idx:03d}"
        rows.append((booking, f"CID{idx}", "SEARCH", f"Booking {idx}", "ACTIVE", "invalid_campaign_id", "2024-01-20"))

    message = build_blacklist_alert_message(rows=rows, execution_date="2024-01-15", correlation_id="CI-TRUNC")

    displayed_rows = [line for line in message.splitlines() if "| BOOKING_" in line]
    assert len(displayed_rows) == 10
    assert "_Showing 10 of 31 records._" in message


def test_unified_format_table_rows_campaign_like_single_record():
    headers = ["Booking ID", "Booking Name", "Channel", "Marketing Type", "Evaluation Due In"]
    keys = ["booking_id", "booking_name", "channel_name", "marketing_type", "days_until_end"]
    records = [
        {
            "booking_id": "12345",
            "booking_name": "Test Campaign",
            "channel_name": "Social Media",
            "marketing_type": "Display, Social",
            "days_until_end": "5d",
        }
    ]

    result = unified_format_table_rows(headers, keys, records, 10)

    assert "```" in result
    assert "| Booking ID" in result
    assert "12345" in result
    assert "Test Campaign" in result
    assert "Social Media" in result
    assert "Display, Social" in result
    assert "5d" in result


def test_unified_format_table_rows_campaign_like_single_record_with_int_values():
    headers = ["Booking ID", "Booking Name", "Channel", "Marketing Type", "Evaluation Due In"]
    keys = ["booking_id", "booking_name", "channel_name", "marketing_type", "days_until_end"]
    records = [
        {
            "booking_id": "12345",
            "booking_name": "Test Campaign",
            "channel_name": "Social Media",
            "marketing_type": "Display, Social",
            "days_until_end": 19,
        }
    ]

    result = unified_format_table_rows(headers, keys, records, 10)

    assert "```" in result
    assert "| Booking ID" in result
    assert "12345" in result
    assert "Test Campaign" in result
    assert "Social Media" in result
    assert "Display, Social" in result
    assert "19" in result


def test_unified_format_table_rows_campaign_like_limit():
    headers = ["Booking ID", "Booking Name", "Channel", "Marketing Type", "Evaluation Due In"]
    keys = ["booking_id", "booking_name", "channel_name", "marketing_type", "days_until_end"]
    records = [
        {
            "booking_id": f"JOB{i:05d}",
            "booking_name": f"Campaign {i}",
            "channel_name": "TV",
            "marketing_type": "Display",
            "days_until_end": f"{i}d",
        }
        for i in range(15)
    ]

    result = unified_format_table_rows(headers, keys, records, 10)

    assert "JOB00000" in result
    assert "JOB00009" in result
    assert "JOB00014" not in result


def test_unified_format_table_rows_handles_empty_records_with_headers():
    headers = ["Booking ID", "Booking Name"]
    keys = ["booking_id", "booking_name"]

    result = unified_format_table_rows(headers, keys, [], 10)

    assert "```" in result
    assert "Booking ID" in result
    assert "Booking Name" in result


def test_build_end_alert_message_no_rows():
    result = build_end_alert_message(
        rows=None,
        days_threshold=20,
        date_key="campaign_end_dt",
        days_key="days_until_end",
        empty_label="ongoing",
        header="During",
    )
    assert result == ":white_check_mark: No ongoing campaigns ending in the next 20 days."


def test_build_end_alert_message_formats_table_and_count(monkeypatch):
    monkeypatch.setattr(vsa, "unified_format_table_rows", _safe_unified_format_table_rows)

    rows = [
        ("JOB123", "Campaign One", "2024-03-20", "Display", "TV", 5),
        ("JOB456", "Campaign Two", "2024-03-25", "Social", "Digital", 10),
    ]

    result = build_end_alert_message(
        rows=rows,
        days_threshold=20,
        date_key="campaign_end_dt",
        days_key="days_until_end",
        empty_label="ongoing",
        header="During",
    )

    assert "📊 *Booking Evaluation - During*" in result
    assert "JOB123" in result
    assert "JOB456" in result
    assert "_2 unique campaigns active in 20 days_" in result


def test_build_post_period_end_alert_message_formats_table_and_count(monkeypatch):
    monkeypatch.setattr(vsa, "unified_format_table_rows", _safe_unified_format_table_rows)

    rows = [
        ("JOB123", "Post Campaign", "2024-04-20", "Display", "TV", 8),
        ("JOB123", "Post Campaign", "2024-04-20", "Social", "Digital", 8),
        ("JOB456", "Another Post Campaign", "2024-04-25", "Video", "Radio", 13),
    ]

    result = build_end_alert_message(
        rows=rows,
        days_threshold=20,
        date_key="post_campaign_dt",
        days_key="days_until_post_end",
        empty_label="post-period",
        header="Post",
    )

    assert "📊 *Booking Evaluation - Post*" in result
    assert "JOB123" in result
    assert "JOB456" in result
    assert "_2 unique campaigns active in 20 days_" in result
