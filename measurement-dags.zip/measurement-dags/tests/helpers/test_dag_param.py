from helpers.dag_param import compute_units_param


def test_compute_units_param():
    cores = 32
    description = "The number of cores to use for EMR cluster (in multiples of 8)"
    param_type = "integer"
    title = "EMR Compute Units"
    description_md = f"""
        The number of cores to use for the EMR cluster. Since the smallest instance size we use has 8 cores,
        the number of cores requested should be a multiple of 8.

        If not specified it will default to **{cores}** cores.
        """

    actual_param = compute_units_param(cores=cores)

    assert actual_param.serialize() == {
        "value": cores,
        "description": description,
        "schema": {
            'description_md': description_md,
            'title': title,
            'type': param_type},
    }
