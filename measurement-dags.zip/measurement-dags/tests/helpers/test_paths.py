from unittest import mock

from helpers.paths import Paths


def test_paths_all():
    """Test that the method calls in the all method work correctly."""
    env_vars = {"MEASUREMENT_ENVIRONMENT": "dev"}
    with mock.patch("helpers.paths.Variable") as MockVariable:
        MockVariable.get = lambda x: env_vars[x]
        p = Paths(correlation_id="abcd", dt=None)
    assert p.paths
