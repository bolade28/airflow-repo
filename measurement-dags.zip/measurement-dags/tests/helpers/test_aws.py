import json
from unittest import mock

import boto3
import moto
import pytest
from helpers.aws import (
    assume_role,
    convert_rundate,
    get_secret,
    split_s3_path,
    split_s3_path_task,
    write_json_to_s3,
    get_ssm_parameter
)
from helpers.setup import configure_aws_user


def test_assume_role():
    correlation_id = "25464fd8-f63e-4eaa-ab30-f46ed3de5989"
    credentials = "credentials"
    role_arn = "role_arn"
    session_name = "a_looooooooooooonnnnnnnnnnnnng_session_name"

    with mock.patch("helpers.aws.boto3") as boto3:
        boto3.client("sts").assume_role.return_value = {
            "AssumedRoleUser": "user",
            "Credentials": credentials,
        }
        output = assume_role(
            role_arn=role_arn,
            correlation_id=correlation_id,
            session_name=session_name
        )
        assert output == "credentials"

        boto3.client("sts").assume_role.assert_called_with(
            RoleArn=role_arn,
            RoleSessionName=f"{session_name}_25464fd8-f63e-4eaa-a"
        )


@moto.mock_aws
def test_write_json_to_s3():
    bucket, key = "mybucket", "data.json"
    data = {"json": "data"}
    client = boto3.client("s3", region_name="us-east-1")
    client.create_bucket(Bucket=bucket)
    write_json_to_s3(json_data=data, s3_path=f"s3://{bucket}/{key}")
    assert client.get_object(Bucket=bucket, Key=key)["Body"].read() == b'{"json": "data"}'


@moto.mock_aws
def test_get_secret():
    """Test get_secret returns secret from AWS secrets manager."""
    secret_name = "secret_name"
    secret_value = json.dumps({"secret": "value"})

    client = boto3.client("secretsmanager", region_name="eu-west-1")
    client.create_secret(Name=secret_name, SecretString=secret_value)

    assert get_secret(secret_name) == json.loads(secret_value)


def test_split_s3_path():
    s3_path = "s3://bucket/path1/path2/path3"
    assert split_s3_path(s3_path) == ("bucket", "path1/path2/path3")


def test_split_s3_path_with_filename():
    s3_path = "s3://bucket/path1/path2/path3"
    assert split_s3_path(s3_path, filename="file.csv") == ("bucket", "path1/path2/path3/file.csv")


def test_split_s3_path_task():
    s3_path = "s3://bucket/path1/path2/path3"
    result = split_s3_path_task.__wrapped__(s3_path, filename="file.csv")
    assert result == {
        "bucket": "bucket",
        "key": "path1/path2/path3/file.csv"
    }


def test_convert_run_date():
    with pytest.raises(ValueError):
        convert_rundate("05-2092-01")

    with pytest.raises(ValueError):
        convert_rundate("01-03-2092")

    with pytest.raises(ValueError):
        convert_rundate("2092")

    with pytest.raises(ValueError):
        convert_rundate("")

    assert convert_rundate("2092-05-01") == ('2092', '05', '01')


def test_get_current_aws_user():
    with mock.patch("helpers.setup.boto3") as boto3:
        boto3.client("sts").get_caller_identity.return_value = {
            "Arn": "arn:aws:sts::123456789012:assumed-role/RoleName/John.Doe"
        }
        actual = configure_aws_user.__wrapped__()
        expected = "john-doe"
        assert actual == expected

    with mock.patch("helpers.setup.boto3") as boto3:
        boto3.client("sts").get_caller_identity.return_value = {
            "Arn": "arn:aws:sts::123456789012:assumed-role/measurement-dev-airflow-instance-role/some_instance_id"
        }
        actual = configure_aws_user.__wrapped__()
        expected = "airflow-aws"
        assert actual == expected


@mock.patch('helpers.aws.SsmHook')
def test_get_ssm_parameter_success(mock_ssm_hook):
    """Test successfully retrieving an SSM parameter"""
    # Arrange
    parameter_name = '/measurement/dev/pipelines/commit-hash'
    expected_value = 'abc123def456'

    mock_hook_instance = mock.Mock()
    mock_hook_instance.get_parameter_value.return_value = expected_value
    mock_ssm_hook.return_value = mock_hook_instance

    result = get_ssm_parameter(parameter_name)

    # Assert
    assert result == expected_value
    mock_ssm_hook.assert_called_once_with()
    mock_hook_instance.get_parameter_value.assert_called_once_with(parameter_name)


@mock.patch('helpers.aws.SsmHook')
def test_get_ssm_parameter_not_found(mock_ssm_hook):
    """Test handling of parameter not found"""
    parameter_name = '/measurement/dev/pipelines/nonexistent'

    mock_hook_instance = mock.Mock()
    mock_hook_instance.get_parameter_value.side_effect = Exception('ParameterNotFound')
    mock_ssm_hook.return_value = mock_hook_instance

    # Assert error is raised
    with pytest.raises(ValueError, match="Parameter '/measurement/dev/pipelines/nonexistent' not found"):
        get_ssm_parameter(parameter_name)
