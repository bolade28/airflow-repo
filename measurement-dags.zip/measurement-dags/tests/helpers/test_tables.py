from helpers.tables import Snowflake


def test_snowflake_all():
    """Test that the method calls in the all method work correctly."""
    s = Snowflake(env="dev", correlation_id="test_correlation_id")
    assert s.tables
