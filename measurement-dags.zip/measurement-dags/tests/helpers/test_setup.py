from unittest import mock
from uuid import UUID

from freezegun import freeze_time
import pendulum
import pytest


from helpers.constants import (
    DEV,
    DEV_ACCOUNT_NUMBER,
    PROD,
    PROD_ACCOUNT_NUMBER,
)
from helpers.setup import (
    configure_correlation_id,
    configure_pipelines_version,
    get_account_number,
    get_environment,
    job_flow_start_time,
)

from helpers.setup import configure_model_start_end_dates


def test_get_environment():
    with mock.patch.dict('os.environ', AIRFLOW_VAR_MEASUREMENT_ENVIRONMENT="some_env"):
        assert get_environment() == "some_env"


@pytest.mark.parametrize("env,account_number", [
    (DEV, DEV_ACCOUNT_NUMBER),
    (PROD, PROD_ACCOUNT_NUMBER),
])
def test_get_account_number(env: str, account_number: str):
    with mock.patch("helpers.setup.get_environment") as mock_get_env:
        mock_get_env.return_value = env
        assert get_account_number() == account_number


def test_configure_correlation_id():
    with mock.patch("helpers.setup.uuid", autospec=True) as uuid:
        uuid.uuid4.return_value = UUID("ad2afce0-b838-469f-a727-89c52ad8b6ac")
        correlation_id = configure_correlation_id.__wrapped__()
    assert correlation_id == "ad2afce0-b838-469f-a727-89c52ad8b6ac"


@mock.patch("helpers.setup.get_current_context")
def test_configure_pipelines_version(get_current_context: mock.MagicMock):
    dag_run = mock.MagicMock()

    dag_run.conf = {"pipelines_hash": "abcd1234"}
    get_current_context.return_value = {"dag_run": dag_run}
    assert configure_pipelines_version.__wrapped__() == "abcd1234"

    dag_run.conf = {}
    get_current_context.return_value = {"dag_run": dag_run}
    assert configure_pipelines_version.__wrapped__() == "latest"


def test_job_flow_start_time():
    t = "2020-10-20 10:20:30.54"
    with freeze_time(t):
        start_time = job_flow_start_time.__wrapped__()
        assert start_time == "2020-10-20T10:20:30"


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates(get_current_context: mock.MagicMock):
    run_date = '2025-06-29'

    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": run_date,
    }
    get_current_context.return_value = {"dag_run": dag_run}

    # Valid case: No manual end date
    model_start_date = '2020-01-01'

    actual = configure_model_start_end_dates.__wrapped__(
        run_date=run_date,
        default_model_start_date=model_start_date
    )

    date_three_years_ago = pendulum.parse(run_date).date().subtract(years=3)

    expected_start_end_dates = {
        # Go back three years and pick Monday as starting date
        "start_date": date_three_years_ago.subtract(days=date_three_years_ago.day_of_week).strftime("%Y-%m-%d"),
        "end_date": '2025-06-29',
    }

    assert actual == expected_start_end_dates


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_invalid_campaign_end_date_raises(
    get_current_context: mock.MagicMock,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": "not-a-date",
    }
    get_current_context.return_value = {"dag_run": dag_run}

    with pytest.raises(ValueError, match="Invalid model_end_date provided"):
        configure_model_start_end_dates.__wrapped__(
            run_date="2025-06-29",
            default_model_start_date="2020-01-01",
        )


@mock.patch("helpers.setup.get_current_context")
def test_configure_model_start_end_dates_daily_etl_uses_default_start_date(
    get_current_context: mock.MagicMock,
):
    dag_run = mock.MagicMock()
    dag_run.conf = {
        "campaign_end_date": "2025-06-29",
    }
    get_current_context.return_value = {"dag_run": dag_run}

    actual = configure_model_start_end_dates.__wrapped__(
        run_date="2025-06-29",
        default_model_start_date="2023-01-01",  # When running daily ETL, we want to use the default start date rather than going back three years
        daily_etl_flag=True,
    )

    assert actual == {
        "start_date": "2023-01-01",
        "end_date": "2025-06-29",
    }
