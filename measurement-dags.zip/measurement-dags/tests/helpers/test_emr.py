import unittest
from unittest import mock

from airflow.task.trigger_rule import TriggerRule

from helpers.constants import REGION_NAME, MASTER_INSTANCE_TYPES
from helpers.emr import launch_cluster, terminate_cluster, add_and_watch_step, EmrAddAndWatchStep
from helpers.setup import configure_master_instance_type


class TestEmrFunctions(unittest.TestCase):

    @mock.patch("helpers.emr.pipeline_run_type_name")
    @mock.patch("helpers.emr.get_ci")
    @mock.patch("helpers.emr.Variable.get")
    @mock.patch("helpers.emr.job_flow")
    @mock.patch("helpers.emr.EmrCreateJobFlowOperator")
    def test_launch_cluster(self, mock_emr_create, mock_job_flow, mock_variable_get, mock_get_ci, mock_get_pipeline_run_type):
        mock_variable_get.return_value = "test_env"
        mock_get_ci.return_value = "test_ci"
        mock_job_flow.return_value = {"JobFlow": "config"}
        mock_emr_create.return_value = "emr_cluster"
        mock_get_pipeline_run_type.return_value = "dtp"

        result = launch_cluster(name="test_name")

        mock_variable_get.assert_called_with("MEASUREMENT_ENVIRONMENT")
        mock_get_ci.assert_called_once()
        mock_job_flow.assert_called_once_with(
            name="test_name-test_env-test_ci-dtp",
            master_ebs_config=mock.ANY,
            master_instance_type="r6in.8xlarge",
            core_instance_types=mock.ANY,
            tags={"Name": "test_name-test_env"}
        )
        mock_emr_create.assert_called_once_with(
            task_id='create_emr_cluster',
            job_flow_overrides={"JobFlow": "config"},
            region_name=REGION_NAME,
            wait_for_completion=True,
            waiter_delay=10,
            waiter_max_attempts=90
        )
        self.assertEqual(result, "emr_cluster")

    @mock.patch("helpers.emr.EmrTerminateJobFlowOperator")
    def test_terminate_cluster(self, mock_emr_terminate):
        mock_emr_terminate.return_value = "terminate_cluster"

        result = terminate_cluster(job_flow_id="test_job_flow_id")

        mock_emr_terminate.assert_called_once_with(
            task_id="terminate_emr_cluster",
            job_flow_id="test_job_flow_id",
            trigger_rule=TriggerRule.ALL_DONE
        )
        self.assertEqual(result, "terminate_cluster")

    @mock.patch("helpers.emr.get_cluster_id")
    @mock.patch("helpers.emr.get_pipelines_version")
    @mock.patch("helpers.emr.step_config")
    @mock.patch("helpers.emr.EmrAddAndWatchStep")
    @mock.patch("helpers.emr.Variable.get")
    def test_add_and_watch_step(
            self,
            mock_variable_get,
            mock_emr_add_and_watch,
            mock_step_config,
            mock_get_pipelines_version,
            mock_get_cluster_id,
    ):
        mock_variable_get.return_value = "test_env"
        mock_get_pipelines_version.return_value = "test_pipelines_version"
        mock_get_cluster_id.return_value = "test_cluster_id"
        mock_step_config.return_value = {"StepConfig": "config"}
        mock_emr_add_and_watch.return_value = "add_and_watch_step"

        result = add_and_watch_step(
            step_args=[("--arg1", "value1"), ("--arg2", "value2")],
            step_name="test_step",
            step_script="test_script.py",
            default_parallelism=1000
        )

        mock_variable_get.assert_called_with("MEASUREMENT_ENVIRONMENT")
        mock_step_config.assert_called_once_with(
            step_args=[("--arg1", "value1"), ("--arg2", "value2")],
            step_name="test_step",
            step_script="test_script.py",
            cpus_per_task=1,
            default_parallelism=1000,
            environment="test_env",
            executor_cores=5,
            use_iceberg=False,
            glue_warehouse="s3://measurement-test_env-etl-output",
            executor_memory="30g",
            num_executors=10,
            pipelines_commit_hash="test_pipelines_version",
            packages=None
        )
        mock_emr_add_and_watch.assert_called_once_with(
            trigger_rule=TriggerRule.ALL_SUCCESS,
            task_id="test_step",
            steps=[{"StepConfig": "config"}],
            job_flow_id="test_cluster_id",
            poke_interval=15
        )
        self.assertEqual(result, "add_and_watch_step")


class TestEmrAddAndWatchStep(unittest.TestCase):

    @mock.patch("helpers.emr.EmrAddStepsOperator.__init__", return_value=None)
    def test_emr_add_and_watch_step_init(self, mock_add_steps_init):
        kwargs = {
            'job_flow_id': 'test_job_flow_id',
            'steps': [{'Name': 'test_step'}],
            'task_id': 'test_task_id',
            'default_args': {},
            'step_id': None,
            'job_flow_id2': 'test_job_flow_id',
        }
        EmrAddAndWatchStep(**kwargs)

        mock_add_steps_init.assert_called_once_with(**kwargs)

    @mock.patch("helpers.emr.EmrStepSensor.execute")
    @mock.patch("helpers.emr.EmrAddStepsOperator.execute")
    def test_emr_add_and_watch_step_execute(self, mock_add_steps_execute, mock_step_sensor_execute):
        context = {}
        mock_add_steps_execute.return_value = ['test_step_id']

        kwargs = {
            'job_flow_id': 'test_job_flow_id',
            'steps': [{'Name': 'test_step'}],
            'task_id': 'test_task_id',
        }
        step = EmrAddAndWatchStep(**kwargs)
        result = step.execute(context)

        mock_add_steps_execute.assert_called_once_with(context)
        mock_step_sensor_execute.assert_called_once_with(context)
        self.assertEqual(result, 'test_step_id')


class TestGetRandomMasterInstanceType(unittest.TestCase):

    def test_returns_valid_instance_type(self):
        """Test that function returns a valid instance type from MASTER_INSTANCE_TYPES."""
        result = configure_master_instance_type.__wrapped__()

        self.assertIn(result, MASTER_INSTANCE_TYPES.keys())
        self.assertIsInstance(result, str)

    def test_returns_string_type(self):
        """Test that function always returns a string."""
        result = configure_master_instance_type.__wrapped__()
        self.assertIsInstance(result, str)

    @mock.patch('helpers.setup.random.choices')
    def test_uses_correct_parameters(self, mock_choices):
        """Test that function calls random.choices with correct instances and weights."""
        mock_choices.return_value = ['r6in.8xlarge']

        # Call the function
        configure_master_instance_type.__wrapped__()

        # Verify random.choices was called once
        mock_choices.assert_called_once()

        # Get the call arguments
        call_args = mock_choices.call_args
        instances_arg = call_args[0][0]  # First positional argument
        weights_arg = call_args[1]['weights']  # weights keyword argument

        # Verify correct parameters were passed
        self.assertEqual(instances_arg, list(MASTER_INSTANCE_TYPES.keys()))
        self.assertEqual(weights_arg, list(MASTER_INSTANCE_TYPES.values()))

    def test_multiple_calls_produce_valid_results(self):
        """Test that multiple calls always produce valid instance types."""
        for _ in range(10):
            result = configure_master_instance_type.__wrapped__()
            self.assertIn(result, MASTER_INSTANCE_TYPES.keys())
            self.assertIsInstance(result, str)

    @mock.patch('helpers.setup.MASTER_INSTANCE_TYPES', {'single_instance': 100})
    def test_single_instance_type(self):
        """Test function behavior with only one instance type."""
        result = configure_master_instance_type.__wrapped__()
        self.assertEqual(result, 'single_instance')

    @mock.patch('helpers.setup.MASTER_INSTANCE_TYPES', {})
    def test_empty_instance_types_raises_error(self):
        """Test that empty MASTER_INSTANCE_TYPES raises an IndexError."""
        with self.assertRaises(IndexError):
            configure_master_instance_type.__wrapped__()


if __name__ == "__main__":
    unittest.main()
