#!/bin/bash

#
# This script uses AWS SSM Session Manager to forward the remote Airflow UI port to your local machine.
# Prerequisites:
#   - AWS CLI v2 installed and configured with proper credentials.
#   - AWS Session Manager plugin installed.
#
# Usage:
#   This should be used via Makefile - details in Readme.

set -e

# Check that AWS CLI is installed
if ! command -v aws > /dev/null; then
    echo "Error: AWS CLI is not installed. Install AWS CLI v2 and try again."
    exit 1
fi

# Default values, as no need to pass the arguments.
AIRFLOW_INSTANCE_ID=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$AWS_PROFILE-airflow" "Name=instance-state-name,Values=running" --query "Reservations[0].Instances[0].InstanceId" --output text)
AIRFLOW_EC2_PORT="8080"
LOCAL_PORT="8081" # Keeping it different than our docker based Airflow UI port to avoid conflicts


echo "Airflow EC2 Instance ID: $AIRFLOW_INSTANCE_ID"
echo "Access Airflow at http://localhost:$LOCAL_PORT"
echo "Press Ctrl+C to terminate the session."

# SSM session start with port forwarding using default AWS-StartPortForwardingSession document.
aws ssm start-session \
    --target "$AIRFLOW_INSTANCE_ID" \
    --document-name AWS-StartPortForwardingSession \
    --parameters "portNumber=[$AIRFLOW_EC2_PORT],localPortNumber=[$LOCAL_PORT]"
