# Shared cluster script

## Install: first time installation

This shared cluster script requires `Python 3.11`. To set up your local Python environment, use [krang-python-env](https://github.com/JSainsburyPLC/krang-python-env)

Once your environment is created (e.g., measurement-cluster), activate it with the following command:

    pyenv activate measurement-cluster

Install dependencies

    pip install -r ./scripts/requirements.txt

## Running the script

Login via `AWS CLI` before running the following:

python -m scripts.start_shared_cluster
