#!/usr/bin/env python
import getpass

import boto3
import typer
from typing_extensions import Annotated
from dags.helpers.constants import INSTANCE_TYPES
from dags.templates.emr.ebs_config import ebs_config


def is_cluster_running(emr_client, name: str) -> bool:
    response = emr_client.list_clusters(ClusterStates=["STARTING", "BOOTSTRAPPING", "RUNNING", "WAITING"])
    clusters = {cluster["Name"] for cluster in response.get("Clusters", [])}
    return name in clusters


def main(
    name: Annotated[str, typer.Argument(help="The name of the EMR cluster.")] = f"shared-cluster-started-by-{getpass.getuser()}",
    min_compute: Annotated[int, typer.Option(help="The minimum core compute units of the EMR cluster.")] = 128,
    max_compute: Annotated[int, typer.Option(help="The maximum core compute units of the EMR cluster.")] = 512,
    core_on_demand_capacity: Annotated[int, typer.Option(help="The maximum core on demand compute units of the EMR cluster.")] = 64,
    task_spot_capacity: Annotated[int, typer.Option(help="The maximum task spot compute units of the EMR cluster.")] = 64,
    pipelines_version: Annotated[str, typer.Option(help="The Git hash version of the measurement pipelines code to run.")] = "latest",
):
    """Create an EMR cluster in the dev environment for ad-hoc analysis purposes.

    The cluster will be configured with `min_compute` spot compute units, and
    will automatically scale up to `max_compute` units when required.

    Raises a NameError if the cluster has already been created.

    See https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/emr/client/run_job_flow.html
    """
    if max_compute < min_compute:
        raise ValueError("Max compute units must be greater than min compute units.")

    session = boto3.Session(profile_name="measurement-dev")
    emr_client = session.client("emr")

    if is_cluster_running(emr_client, name=name):
        raise NameError(f"Cluster with name {name} is already running!")

    response = emr_client.run_job_flow(
        Name=name,
        LogUri="s3n://aws-logs-277707132387-eu-west-1/elasticmapreduce/",
        ReleaseLabel="emr-7.8.0",
        JobFlowRole="EMR_EC2_DefaultRole",
        ServiceRole="arn:aws:iam::277707132387:role/EMR_DefaultRole",
        SecurityConfiguration="measurement-dev-IMDSv2",
        ScaleDownBehavior="TERMINATE_AT_TASK_COMPLETION",
        EbsRootVolumeSize=100,
        StepConcurrencyLevel=2,
        AutoTerminationPolicy={
            "IdleTimeout": 1800
        },
        Instances={
            "Ec2KeyName": "measurement-dev-key",
            "Ec2SubnetIds": [
                "subnet-04819b6a006117513",  # measurement-dev-emr-private-a
                "subnet-0eafe65261833d3e3",  # measurement-dev-emr-private-b
                "subnet-0a320fec7a82e0084",  # measurement-dev-emr-private-c
            ],
            "EmrManagedMasterSecurityGroup": "sg-0df9dba16d8c1cb78",
            "EmrManagedSlaveSecurityGroup": "sg-0c8346d032fd480e1",
            "ServiceAccessSecurityGroup": "sg-009979bf2e59514e9",
            "KeepJobFlowAliveWhenNoSteps": True,
            "InstanceFleets": [
                {
                    "Name": "Master",
                    "InstanceFleetType": "MASTER",
                    "TargetSpotCapacity": 0,
                    "TargetOnDemandCapacity": 1,
                    "LaunchSpecifications": {
                        "OnDemandSpecification": {
                            "AllocationStrategy": "LOWEST_PRICE"
                        }
                    },
                    "InstanceTypeConfigs": [
                        {
                            "WeightedCapacity": 1,
                            "EbsConfiguration": {
                                "EbsOptimized": True,
                                "EbsBlockDeviceConfigs": [
                                    {
                                        "VolumeSpecification": {
                                            "VolumeType": "gp2",
                                            "SizeInGB": 64
                                        }
                                    },
                                    {
                                        "VolumeSpecification": {
                                            "VolumeType": "gp2",
                                            "SizeInGB": 64
                                        }
                                    }
                                ]
                            },
                            "BidPriceAsPercentageOfOnDemandPrice": 100,
                            "InstanceType": "r6i.xlarge"
                        }
                    ]
                },
                {
                    "Name": "Core",
                    "InstanceFleetType": "CORE",
                    "TargetSpotCapacity": 0,
                    "TargetOnDemandCapacity": core_on_demand_capacity,
                    "LaunchSpecifications": {
                        "SpotSpecification": {
                            "TimeoutDurationMinutes": 60,
                            "TimeoutAction": "TERMINATE_CLUSTER",
                            "AllocationStrategy": "PRICE_CAPACITY_OPTIMIZED"
                        },
                        "OnDemandSpecification": {
                            "AllocationStrategy": "LOWEST_PRICE"
                        }
                    },
                    "InstanceTypeConfigs": [
                        {
                            "InstanceType": instance["type"],
                            "BidPriceAsPercentageOfOnDemandPrice": 100.0,
                            "WeightedCapacity": instance["weight"],
                            "EbsConfiguration": ebs_config(instance["ebs_vol_size"] // 2, 4)
                        } for instance in INSTANCE_TYPES
                    ],
                },
                {
                    "Name": "Task",
                    "InstanceFleetType": "TASK",
                    "TargetSpotCapacity": task_spot_capacity,
                    "TargetOnDemandCapacity": 0,
                    "LaunchSpecifications": {
                        "SpotSpecification": {
                            "TimeoutDurationMinutes": 60,
                            "TimeoutAction": "TERMINATE_CLUSTER",
                            "AllocationStrategy": "PRICE_CAPACITY_OPTIMIZED"
                        },
                        "OnDemandSpecification": {
                            "AllocationStrategy": "LOWEST_PRICE"
                        }
                    },
                    "InstanceTypeConfigs": [
                        {
                            "InstanceType": instance["type"],
                            "BidPriceAsPercentageOfOnDemandPrice": 100.0,
                            "WeightedCapacity": instance["weight"],
                            "EbsConfiguration": ebs_config(instance["ebs_vol_size"] // 2, 4)
                        } for instance in INSTANCE_TYPES
                    ],
                }
            ]
        },
        ManagedScalingPolicy={
            # This config will create a cluster with Core nodes up to MaximumCoreCapacityUnits
            # and the rest will be Task units.
            "ComputeLimits": {
                "UnitType": "InstanceFleetUnits",
                "MaximumCapacityUnits": max_compute,
                "MaximumCoreCapacityUnits": min_compute,
                "MaximumOnDemandCapacityUnits": min_compute // 2,  # 1 unit will be used for the Master node weighted capacity
                "MinimumCapacityUnits": min_compute,

            }
        },
        BootstrapActions=[
            {
                "Name": "Custom action",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-dev-artefacts/pipelines/{pipelines_version}/emr_bootstrap_ssm.sh",
                    'Args': []
                }
            },
            {
                "Name": "Custom action",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-dev-artefacts/pipelines/{pipelines_version}/emr_bootstrap_shared_cluster.sh",
                    'Args': [
                        "latest"
                    ]
                }
            },
            {
                "Name": "Auto terminate cluster",
                "ScriptBootstrapAction": {
                    "Path": f"s3://measurement-dev-artefacts/pipelines/{pipelines_version}/emr_cronjob_terminatecluster.sh",
                    "Args": ["30 18 * * *"],
                }
            },
        ],
        Applications=[
            {"Name": "Hadoop"},
            {"Name": "JupyterEnterpriseGateway"},
            {"Name": "JupyterHub"},
            {"Name": "Livy"},
            {"Name": "Spark"},
            {"Name": "Zeppelin"},
        ],
        Configurations=[
            {
                "Classification": "spark-defaults",
                "Properties": {
                    "spark.jars.packages": "net.snowflake:snowflake-jdbc:3.24.2,net.snowflake:spark-snowflake_2.12:3.1.3",
                    "spark.pyspark.python": "python311",
                    "spark.pyspark.virtualenv.bin.path": "/usr/bin/virtualenv",
                    "spark.pyspark.virtualenv.enabled": "true",
                    "spark.pyspark.virtualenv.type": "native"
                }
            },
            {
                "Classification": "spark",
                "Properties": {
                    "spark.pyspark.python": "python3",
                    "spark.pyspark.virtualenv.bin.path": "/usr/bin/virtualenv",
                    "spark.pyspark.virtualenv.enabled": "true",
                    "spark.pyspark.virtualenv.type": "native"
                }
            }
        ],
        Tags=[
            {
                "Key": "owner",
                "Value": "measurement"
            },
            {
                "Key": "for-use-with-amazon-emr-managed-policies",
                "Value": "true"
            },
            {
                "Key": "dataRetention",
                "Value": "1-month"
            },
            {
                "Key": "environment",
                "Value": "dev"
            },
            {
                "Key": "dataClassification",
                "Value": "highlySensitive"
            },
            {
                "Key": "costcentre",
                "Value": "PD8634"
            },
            {
                "Key": "project",
                "Value": "measurement"
            },
            {
                "Key": "servicename",
                "Value": "N360 Measurement"
            },
            {
                "Key": "servicecatalogueID",
                "Value": "001071675"
            },
            {
                "Key": "email",
                "Value": "measurement@sainsburys.co.uk"
            },
            {
                "Key": "live",
                "Value": "no"
            },
            {
                "Key": "Name",
                "Value": "measurement-dev-shared-cluster"
            },
            {
                "Key": "created_by",
                "Value": getpass.getuser()
            },
        ],
    )

    print(f"Cluster created with job flow ID: {response['JobFlowId']}")


if __name__ == "__main__":
    typer.run(main)
