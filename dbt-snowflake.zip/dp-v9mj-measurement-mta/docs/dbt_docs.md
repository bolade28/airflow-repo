# DBT Technical Documentation

DBT Docs is used to auto-generate full descriptions of the models in this repository.
- The description of each model is provided
- The lineage of each model is provided

Please see [DBT Docs]({{ dbt_docs_url }}/index.html)
