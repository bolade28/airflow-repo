import pytest
from dp_v9mj_measurement_mta.transforms.stage_files.ucm_integration_functions import calculate_recaliberated_sales, get_campaign_start_end_date, calculate_aggregated_sales
from python_tests.test_utils.mock_dbt import create_snowflake_session
from datetime import datetime


@pytest.fixture
def session(request):
    """
    Fixture to create a Snowflake session.

    Parameters:
    - request: pytest request object to access test parameters.

    Returns:
    - A Snowflake session object based on the session type ("live" or "test").
    """
    session_type = getattr(request, "param", "live")
    return create_snowflake_session(session_type)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_factor_df(session):
    """
    Fixture to create a mock DataFrame for the `factor` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock factor data.
    """
    data = [
        {"CHANNEL_NAME": "Meta", "CAMPAIGN_ID": "262253", "FACTOR": 0.8}
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_sku_level_results_df(session):
    """
    Fixture to create a mock DataFrame for the `sku_level_results` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock SKU-level results data.
    """
    data = [
        {
            "CAMPAIGN_ID": "262253",
            "CHANNEL_NAME": "Meta",
            "USERJOURNEY_ID": "b90a77fdfc4d600460210fbb22a006666f99a9d191c25150f10cb3cc0ad90d85_3",
            "LOYALTY_ID": "b90a77fdfc4d600460210fbb22a006666f99a9d191c25150f10cb3cc0ad90d85",
            "BOOKING_ID": "f506ce4c-33ed-4aac-88b2-e25a1c483637",
            "CUSTOMER_JOURNEY_TYPE": "Direct",
            "JOURNEY_TYPE": "Offer",
            "ISCONVERSION": 1,
            "NORMALIZED_WEIGHTS": 1,
            "CAMPAIGN_DURATION": "During",
            "EVENT_DT": "2023-01-23",
            "ITEM_CD": "2347479.00000",
            "NET_SALES_AMT": 1.5,
            "UNITS_QTY": 1.0,
            "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc",
            "WEEK_START_DT": "2023-01-23",
            "REGRESSION_VARIABLE": "OFFSITE_META_LACTOFREESPCLOOKALIKESPCSHOPPERS_262253",
            "SUBCHANNEL_NAME": "LactoFree lookalike shoppers",
            "ATTRIBUTED_SALES_AMT": 1.5,
            "ATTRIBUTED_UNITS_QTY": 1,
            "ATTRIBUTED_RECALIBERATED_SALES_AMT": 1.5,
            "ATTRIBUTED_RECALIBERATED_UNITS_QTY": 1,
            "JOB_RUN_ID": "ff0ba805-5146-4556-98e5-c5a551575971",
            "LOAD_TS": "2025-01-21 10:51:21.590",
            "MARKETING_TYPE": "Offsite",
            "RECALIBERATION_FACTOR": 1,
        },
        {
            "CAMPAIGN_ID": "262253",
            "CHANNEL_NAME": "Entrance Gates",
            "USERJOURNEY_ID": "bfdc4e64e0172ed0f3743b41d41f56351e51a0682ce149c5c3a9a52ebe53f65a_3",
            "LOYALTY_ID": "bfdc4e64e0172ed0f3743b41d41f56351e51a0682ce149c5c3a9a52ebe53f65a",
            "BOOKING_ID": "f506ce4c-33ed-4aac-88b2-e25a1c483637",
            "CUSTOMER_JOURNEY_TYPE": "Direct",
            "JOURNEY_TYPE": "Offer",
            "ISCONVERSION": 1,
            "NORMALIZED_WEIGHTS": 1,
            "CAMPAIGN_DURATION": "During",
            "EVENT_DT": "2023-02-05",
            "ITEM_CD": "2188027.00000",
            "NET_SALES_AMT": 1.95,
            "UNITS_QTY": 1.0,
            "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc",
            "WEEK_START_DT": "2023-01-30",
            "REGRESSION_VARIABLE": "INHASHSTORE_ENTRANCESPCGATES_NA_262253",
            "SUBCHANNEL_NAME": "NA",
            "ATTRIBUTED_SALES_AMT": 1.95,
            "ATTRIBUTED_UNITS_QTY": 1,
            "ATTRIBUTED_RECALIBERATED_SALES_AMT": 1.95,
            "ATTRIBUTED_RECALIBERATED_UNITS_QTY": 1,
            "JOB_RUN_ID": "ff0ba805-5146-4556-98e5-c5a551575971",
            "LOAD_TS": "2025-01-21 10:51:21.590",
            "MARKETING_TYPE": "In-store",
            "RECALIBERATION_FACTOR": 1,
        },
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_calculate_recaliberated_sales(mock_factor_df, mock_sku_level_results_df):
    """
    Test the `calculate_recaliberated_sales` function to ensure it correctly recalibrates
    attributed sales and units based on attribution factors.

    Parameters:
    - mock_factor_df: Mock DataFrame containing factor data.
    - mock_sku_level_results_df: Mock DataFrame containing SKU-level results data.

    This test verifies:
    - Correct calculation of `ATTRIBUTED_SALES_AMT` and `ATTRIBUTED_UNITS_QTY`.
    - Proper application of recalibration factors for specific channels.
    """
    # Call the function under test
    result_df = calculate_recaliberated_sales(mock_factor_df, mock_sku_level_results_df)
    # Collect the results for assertions
    result_data = result_df.collect()

    # Assertions for recalibrated sales and units
    for row in result_data:
        if row["CHANNEL_NAME"] == "Meta":
            assert row["ATTRIBUTED_RECALIBERATED_SALES_AMT"] == pytest.approx(1.20)
            assert row["ATTRIBUTED_RECALIBERATED_UNITS_QTY"] == pytest.approx(0.8)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_campaign_data(session):
    """
    Fixture to create a mock DataFrame for campaign data.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock campaign data.
    """
    data = [
        {
            "CAMPAIGN_ID": "C1",
            "BOOKING_ID": "BID_1",
            "JOB_BAG_NUMBER": "C1",
            "MARKETING_TYPE": "Offsite",
            "CHANNEL_NAME": "Meta",
            "SUBCHANNEL_NAME": "SC1",
            "CAMPAIGN_NAME": "C15_Elmlea_Veganuary",
            "CAMPAIGN_START_DT": datetime.strptime("2023-01-08", "%Y-%m-%d").date(),
            "CAMPAIGN_END_DT": datetime.strptime("2023-01-08", "%Y-%m-%d").date(),
            "CAMPAIGN_DURATION": "During",
            "JOB_STATUS": "In-progress",
            "LOAD_TS": "2023-03-27 06:39:26.265",
        },
        {
            "CAMPAIGN_ID": "C2",
            "BOOKING_ID": "BID_2",
            "JOB_BAG_NUMBER": "C2",
            "MARKETING_TYPE": "In-store",
            "CHANNEL_NAME": "YouTube",
            "SUBCHANNEL_NAME": "SC2",
            "CAMPAIGN_NAME": "C16_Pepsi_Summer",
            "CAMPAIGN_START_DT": datetime.strptime("2023-01-15", "%Y-%m-%d").date(),
            "CAMPAIGN_END_DT": datetime.strptime("2023-01-21", "%Y-%m-%d").date(),
            "CAMPAIGN_DURATION": "Post",
            "JOB_STATUS": "Completed",
            "LOAD_TS": "2023-03-27 06:39:26.265",
        },
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_get_campaign_start_end_date_during(mock_campaign_data):
    """
    Test the `get_campaign_start_end_date` function for a "During" campaign.

    Parameters:
    - mock_campaign_data: Mock DataFrame containing campaign data.

    This test verifies:
    - Correct filtering of campaign data based on booking ID.
    - Proper alignment of start and end dates to week boundaries for "During" campaigns.
    """
    booking_id = "BID_1"
    is_post_campaign = False

    # Call the function under test
    campaign_start_date, campaign_end_date = get_campaign_start_end_date(
        mock_campaign_data, is_post_campaign, booking_id
    )

    print(f"Start Date: {campaign_start_date}, End Date: {campaign_end_date}")
    # Assertions
    assert campaign_start_date == "2023-01-02"
    assert campaign_end_date == "2023-01-02"


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_get_campaign_start_end_date_post(mock_campaign_data):
    """
    Test the `get_campaign_start_end_date` function for a "Post" campaign.

    Parameters:
    - mock_campaign_data: Mock DataFrame containing campaign data.

    This test verifies:
    - Correct filtering of campaign data based on booking ID.
    - Proper alignment of start and end dates to week boundaries for "Post" campaigns.
    """
    booking_id = "BID_2"
    is_post_campaign = True

    # Call the function under test
    campaign_start_date, campaign_end_date = get_campaign_start_end_date(
        mock_campaign_data, is_post_campaign, booking_id
    )
    print(f"Start Date: {campaign_start_date}, End Date: {campaign_end_date}")
    # Assertions
    assert campaign_start_date == "2023-01-09"
    assert campaign_end_date == "2023-01-16"


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_dtp_sales_df(session):
    """
    Fixture to create a mock DataFrame for the `dtp_sales_df` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock sales data.
    """
    data = [
        {"CHANNEL_NAME": "Meta", "CAMPAIGN_ID": "C1", "SUM_SALES_AMT": 1000.0},
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_attribution_df(session):
    """
    Fixture to create a mock DataFrame for the `attribution_df` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock attribution data.
    """
    data = [
        {
            "USERJOURNEY_ID": "3c4e40ca7aad01f10024d8ca95faca639a11500756b6ebd94ba9cd0db567ffcf_1",
            "LOYALTY_ID": "3c4e40ca7aad01f10024d8ca95faca639a11500756b6ebd94ba9cd0db567ffcf",
            "TRANSACTION_KEY": "88db1592-ff24-407a-8c66-06df6f430a55",
            "BOOKING_ID": "43885528-c197-4f99-9301-7b33917be750",
            "CUSTOMER_JOURNEY_TYPE": "Direct",
            "JOURNEY_TYPE": "Offer",
            "ISCONVERSION": 1,
            "REGRESSION_VARIABLE": "Offsite_Meta_RedemptionSPCandSPCBrand_C1",
            "NORMALIZED_WEIGHTS": 1.0,
            "CAMPAIGN_ID": "C1",
            "AVG_F1_SCORE_TEST": 0.9212,
            "CAMPAIGN_DURATION": "During",
            "JOB_RUN_ID": "54ebbce6-500b-41bc-a372-44f2fd9aa9d3",
            "LOAD_TS": "2025-05-02 16:28:38.391",
            "CHANNEL_NAME": "Meta",
            "SUBCHANNEL_NAME": "Redemption and Brand",
            "MARKETING_TYPE": "Offsite",
            "AVG_F1_SCORE_TRAIN": 0.9197,
        },
        {
            "USERJOURNEY_ID": "4d5e60fa8bbd02f20035e9db06fbdc740b22611867c7fcf05cbad1ed6789abcd_2",
            "LOYALTY_ID": "4d5e60fa8bbd02f20035e9db06fbdc740b22611867c7fcf05cbad1ed6789abcd",
            "TRANSACTION_KEY": "99ec2603-gg35-518b-9d77-17ef7g541b66",
            "BOOKING_ID": "54996639-d308-5faa-0412-8c44028cf861",
            "CUSTOMER_JOURNEY_TYPE": "Non-direct",
            "JOURNEY_TYPE": "Offer",
            "ISCONVERSION": 1,
            "REGRESSION_VARIABLE": "Offsite_Meta_AwarenessSPCandSPCBrand_C1",
            "NORMALIZED_WEIGHTS": 0.8,
            "CAMPAIGN_ID": "C1",
            "AVG_F1_SCORE_TEST": 0.8754,
            "CAMPAIGN_DURATION": "During",
            "JOB_RUN_ID": "65ffcde7-611c-52cd-b483-55f3ge0bbad4",
            "LOAD_TS": "2025-05-03 12:45:22.500",
            "CHANNEL_NAME": "Meta",
            "SUBCHANNEL_NAME": "Awareness and Brand",
            "MARKETING_TYPE": "Offsite",
            "AVG_F1_SCORE_TRAIN": 0.8721,
        },
        {
            "USERJOURNEY_ID": "4d5e60fa8bbd02f20035e9db06fbdc740b22611867c7fcf05cbad1ed6789abcd_2",
            "LOYALTY_ID": "4d5e60fa8bbd02f20035e9db06fbdc740b22611867c7fcf05cbad1ed6789abcd",
            "TRANSACTION_KEY": "99ec2603-gg35-518b-9d77-17ef7g541b66",
            "BOOKING_ID": "54996639-d308-5faa-0412-8c44028cf861",
            "CUSTOMER_JOURNEY_TYPE": "Non-direct",
            "JOURNEY_TYPE": "Offer",
            "ISCONVERSION": 1,
            "REGRESSION_VARIABLE": "InHASHstore_EntranceSPCGates_NA_C1",
            "NORMALIZED_WEIGHTS": 0.2,
            "CAMPAIGN_ID": "C1",
            "AVG_F1_SCORE_TEST": 0.8754,
            "CAMPAIGN_DURATION": "During",
            "JOB_RUN_ID": "65ffcde7-611c-52cd-b483-55f3ge0bbad4",
            "LOAD_TS": "2025-05-03 12:45:22.500",
            "CHANNEL_NAME": "Entrance Gates",
            "SUBCHANNEL_NAME": "NA",
            "MARKETING_TYPE": "In-store",
            "AVG_F1_SCORE_TRAIN": 0.8721,
        }
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_calculate_aggregated_sales_no_overlap(mock_dtp_sales_df, mock_attribution_df):
    """
    Test the `calculate_aggregated_sales` function when there is no channel overlap.

    Parameters:
    - mock_dtp_sales_df: Mock DataFrame containing sales data.
    - mock_attribution_df: Mock DataFrame containing attribution data.

    This test verifies:
    - Correct calculation of attributed and recalibrated sales amounts.
    - Proper handling of weights and factors when channel overlap is 0.
    """
    total_sales = 2500.0
    channel_overlap = 0

    # Call the function under test
    result_df = calculate_aggregated_sales(
        mock_dtp_sales_df, mock_attribution_df, total_sales, channel_overlap
    )

    # Collect the results for assertions
    result_data = result_df.collect()

    # Assertions for recalibrated sales and factors
    for row in result_data:
        if row["CHANNEL_NAME"] == "Meta":
            assert round(row["FACTOR"], 4) == pytest.approx(0.4444, rel=1e-4)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_calculate_aggregated_sales_with_overlap(mock_dtp_sales_df, mock_attribution_df):
    """
    Test the `calculate_aggregated_sales` function when there is channel overlap.

    Parameters:
    - mock_dtp_sales_df: Mock DataFrame containing sales data.
    - mock_attribution_df: Mock DataFrame containing attribution data.

    This test verifies:
    - Correct calculation of attributed and recalibrated sales amounts.
    - Proper handling of weights and factors when channel overlap is 1.
    """
    total_sales = 2500.0
    channel_overlap = 1

    # Call the function under test
    result_df = calculate_aggregated_sales(
        mock_dtp_sales_df, mock_attribution_df, total_sales, channel_overlap
    )

    # Collect the results for assertions
    result_data = result_df.collect()

    # Assertions for recalibrated sales and factors
    for row in result_data:
        if row["CHANNEL_NAME"] == "Meta":
            assert row["FACTOR"] == pytest.approx(0.4)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_baseline_output(session):
    """
    Fixture to create a mock DataFrame for the `baseline_output` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock baseline output data.
    """
    data = [
        {"WEEK_START_DT": "2022-01-03", "SUPER_CATEGORY_NAME": "CRISPS & SNACKS", "MANUFACTURER": "PEPSICO", "CLUSTER_NUM": "CL1", "SALES": 2044262.41, "TOTAL_SALES_AMT": 2044262.41, "TOTAL_BASELINE_AMT": 2028375.987, "INCREMENTAL": 15886.42321, "ITERATION": "Iteration:7:PEPSICO|CRISPS & SNACKS|CL1-level_variance:0.20-cycle:True-cycle_period_bounds:[26, 104]_pass_1", "JOB_RUN_ID": "JRID_1", "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc"},
        {"WEEK_START_DT": "2022-01-10", "SUPER_CATEGORY_NAME": "CRISPS & SNACKS", "MANUFACTURER": "PEPSICO", "CLUSTER_NUM": "CL2", "SALES": 1990473.07, "TOTAL_SALES_AMT": 1990473.07, "TOTAL_BASELINE_AMT": 1984390.504, "INCREMENTAL": 6082.565685, "ITERATION": "Iteration:7:PEPSICO|CRISPS & SNACKS|CL1-level_variance:0.20-cycle:True-cycle_period_bounds:[26, 104]_pass_1", "JOB_RUN_ID": "JRID_2", "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc"},
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_sku_cluster_mapping(session):
    """
    Fixture to create a mock DataFrame for the `sku_cluster_mapping` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock SKU cluster mapping data.
    """
    data = [
        {"ITEM_CD": "12345", "SUPER_CATEGORY_NAME": "CRISPS & SNACKS", "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc", "CLUSTER_NUM": "CL1", "JOB_RUN_ID": "job_123", "LOAD_TS": "2023-01-01 10:00:00", "MODELLING_TYPE": "Baseline"},
        {"ITEM_CD": "67890", "SUPER_CATEGORY_NAME": "CRISPS & SNACKS", "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc", "CLUSTER_NUM": "CL2", "JOB_RUN_ID": "job_124", "LOAD_TS": "2023-01-01 10:00:00", "MODELLING_TYPE": "Baseline"},
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.fixture
def mock_sales_data_transformations_output(session):
    """
    Fixture to create a mock DataFrame for the `sales_data_transformations_output` input.

    Parameters:
    - session: Snowflake session object.

    Returns:
    - A Snowflake DataFrame containing mock sales data transformations output.
    """
    data = [
        {
            "WEEK_START_DT": "2022-01-03",
            "SUPER_CATEGORY_NAME": "CRISPS & SNACKS",
            "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc",
            "ITEM_CD": "12345",
            "TOTAL_SALES_AMT": 2044262.41,
            "NECTAR_SALES_AMT": 1500000.0,
            "NON_NECTAR_SALES_AMT": 544262.41,
            "FREQUENCY_OF_PURCHASE": 10,
            "DISTINCT_CUSTOMER_CNT": 5000,
            "AVG_PURCHASE_PER_CUSTOMER_CNT": 408.85,
            "ONLINE_SALES_PCT": 20.0,
            "SUPERMARKET_SALES_PCT": 50.0,
            "CONVENIENCE_SALES_PCT": 30.0,
            "JOB_RUN_ID": "job_123",
            "PACK_SIZE": "Large",
            "PRICE_PER_POINT": 1.5,
            "LOAD_TS": "2023-01-01 10:00:00",
            "BASE_PRICE_AMT": 2.0,
        },
        {
            "WEEK_START_DT": "2022-01-10",
            "SUPER_CATEGORY_NAME": "CRISPS & SNACKS",
            "UNIQUE_BRAND_NAME": "Walkers|PepsiCo Inc",
            "ITEM_CD": "67890",
            "TOTAL_SALES_AMT": 1990473.07,
            "NECTAR_SALES_AMT": 1400000.0,
            "NON_NECTAR_SALES_AMT": 590473.07,
            "FREQUENCY_OF_PURCHASE": 8,
            "DISTINCT_CUSTOMER_CNT": 4000,
            "AVG_PURCHASE_PER_CUSTOMER_CNT": 497.62,
            "ONLINE_SALES_PCT": 25.0,
            "SUPERMARKET_SALES_PCT": 45.0,
            "CONVENIENCE_SALES_PCT": 30.0,
            "JOB_RUN_ID": "job_124",
            "PACK_SIZE": "Medium",
            "PRICE_PER_POINT": 1.2,
            "LOAD_TS": "2023-01-01 10:00:00",
            "BASE_PRICE_AMT": 1.8,
        },
    ]
    return session.create_dataframe(data)


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
def test_mmm_mta_integration(mock_baseline_output, mock_sku_cluster_mapping, mock_sales_data_transformations_output):
    """
    Test the `mmm_mta_integration` function to ensure it correctly integrates MMM and MTA data.

    Parameters:
    - mock_baseline_output: Mock DataFrame containing baseline output data.
    - mock_sku_cluster_mapping: Mock DataFrame containing SKU cluster mapping data.
    - mock_sales_data_transformations_output: Mock DataFrame containing sales data transformations output.

    This test verifies:
    - Proper joining of baseline output, SKU cluster mapping, and sales data transformations.
    - Correct calculation of baseline and incremental sales at the SKU level.
    - Proper handling of edge cases where cluster sales are zero.
    """
    # ToDo This needs to be updated as the mmm_mta_integration is no longer used in the pipeline
    pass
