import pytest
import numpy as np
import warnings


def pytest_configure(config):
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)


@pytest.fixture(scope="session", autouse=True)
def patch_numpy_types():
    """
    Auto-applied fixture to patch Snowpark to handle NumPy types.
    This runs automatically before any tests.
    """
    print("Applying NumPy type patches to Snowpark...")
    # Patch Literal class
    from snowflake.snowpark._internal.analyzer.expression import Literal
    # Store original method
    original_init = Literal.__init__

    def patched_init(self, value, datatype=None):
        if hasattr(np, 'int64') and isinstance(value, np.int64):
            value = int(value)
        elif hasattr(np, 'integer') and isinstance(value, np.integer):
            value = int(value)
        elif hasattr(np, 'floating') and isinstance(value, np.floating):
            value = float(value)
        elif hasattr(np, 'bool_') and isinstance(value, np.bool_):
            value = bool(value)
        elif hasattr(np, 'ndarray') and isinstance(value, np.ndarray):
            value = value.tolist()
        # Call original with converted value
        original_init(self, value, datatype)
    # Apply patch
    Literal.__init__ = patched_init
    # Patch lit function
    from snowflake.snowpark.functions import lit as original_lit

    def safe_lit(value, _emit_ast=False, **kwargs):
        """
        Safe version of lit that handles NumPy types.
        Now supports the _emit_ast parameter that Snowpark passes.
        """
        if hasattr(np, 'int64') and isinstance(value, np.int64):
            return original_lit(int(value), _emit_ast=_emit_ast, **kwargs)
        elif hasattr(np, 'integer') and isinstance(value, np.integer):
            return original_lit(int(value), _emit_ast=_emit_ast, **kwargs)
        elif hasattr(np, 'floating') and isinstance(value, np.floating):
            return original_lit(float(value), _emit_ast=_emit_ast, **kwargs)
        elif hasattr(np, 'bool_') and isinstance(value, np.bool_):
            return original_lit(bool(value), _emit_ast=_emit_ast, **kwargs)
        elif hasattr(np, 'ndarray') and isinstance(value, np.ndarray):
            return original_lit(value.tolist(), _emit_ast=_emit_ast, **kwargs)
        else:
            return original_lit(value, _emit_ast=_emit_ast, **kwargs)
    import snowflake.snowpark.functions
    snowflake.snowpark.functions.lit = safe_lit
    print("NumPy type patches applied successfully")
    yield  # Run tests
    # Restore original methods (optional)
    Literal.__init__ = original_init
    snowflake.snowpark.functions.lit = original_lit
