import pandas as pd
import pytest
from snowflake.snowpark.types import StructType, StructField, TimestampType, StringType

from dp_v9mj_measurement_mta.transforms.models.dv.reach_engagement.reach_engagement import model, log_process_helper, extract_error_message, fetch_in_progress_campaign
from python_tests.test_utils.mock_dbt import MockDbt, create_snowflake_session
from python_tests.test_utils.schemas import Schema
from unittest.mock import MagicMock


@pytest.fixture
def session(request):
    """
    Pytest fixture to create a Snowflake session for testing.

    This fixture runs tests with two different session types:
    - "test": Creates a local Snowpark session, which is useful for running tests
      in an isolated environment without connecting to a real Snowflake instance.
    - "live": Establishes a real Snowflake session. This is useful for validating functionality
      which isn't fully supported in a local Snowpark session.

    Args:
        request (FixtureRequest): A built-in pytest fixture that provides test
        parameterization capabilities.

    Returns:
        Session: A Snowflake session instance.
    """
    session_type = getattr(request, "param", "live")  # Default to "test"
    return create_snowflake_session(session_type)


@pytest.fixture(params=["one", "two", "four", "five"])
def dbt(request, session):
    """
    Fixture to create a mock dbt context with csv and json data test_reach_engagement.py

    The test data consists of:
    - User Journey test data containing different Channel Types
    - 3 conversions for these customers, with no click impressions or engagement data
    - Channel specific data linking the campaigns
    - Data is linked to 1 result from the staged unified campaign file
    """

    # Test four is for DV360/Youtube Data and requires a live session
    if request.param == "four" or request.param == "one":
        session = create_snowflake_session("live")

    # Input data contained in a test folder
    test_data_dir = f"python_tests/reach_engagement_test_data/test_{request.param}/"

    return MockDbt(test_data_dir, session)


def compare_schemas(true_schema: StructType, result_schema: StructType):
    """
    Compares two Snowpark schemas to ensure they are identical,
    ignoring differences in `TimestampType` fields. As timezones are generated automatically.

    This function compares two schemas (true_schema and result_schema) by checking that:
    1. The schemas have the same number of fields.
    2. Each field in the schemas has the same name and datatype.

    Args:
        - true_schema (StructType): The expected schema (ground truth).
        - result_schema (StructType): The actual schema to be validated against the true_schema.

    Raises:
        - AssertionError: If the schemas have a different number of fields or
        if any corresponding fields differ (excluding `TimestampType`).
    """
    # Ensure schemas have the same number of fields before comparison
    assert len(true_schema.fields) == len(result_schema.fields), "Schema lengths do not match"

    for i in range(len(true_schema.fields)):
        field1 = true_schema.fields[i]
        field2 = result_schema.fields[i]

        if isinstance(field1.datatype, (TimestampType, pd.Timestamp)) and isinstance(
            field2.datatype, (TimestampType, pd.Timestamp)
        ):
            continue  # Skip comparison for TimestampType or pandas.Timestamp

        assert (
            field1 == field2
        ), f"Field {field1.name}, {field1.datatype} - {field2.name}, {field2.datatype} mismatch"


# Test 1: Test that data is present and the new columns exist
@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "dbt, session",
    [
        pytest.param("one", "live"),
        pytest.param("two", "live"),
        pytest.param("four", "live"),
        pytest.param("five", "live"),
    ],
    indirect=True,
)
def test_model_with_valid_data(dbt, session):
    """
    Test the model function with valid data and ensure that it returns
    data containing the required new columns.

    Parameters:
    - dbt (MockDbt): The class which mocks the DBT functions,
        the number parameters are different test data directories
    - session (Session): The Snowflake session object, a parameter is
        passed in determined the type of session to use
    """

    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)
        assert result_df is not None
        assert result_df.count() > 0
        # Test if new columns in output
        assert all(
            col in result_df.columns
            for col in [
                "REACH_CNT",
                "CLICKS_CNT",
                "IMPRESSIONS_CNT",
                "SALES_AMT",
                "ENGAGEMENT_CTR_PCT",
                "CONVERSIONS_CNT",
            ]
        )
    finally:
        session.close()


# Test 2 Test output schema
@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize("dbt", ["one", "two", "five"], indirect=True)
def test_model_output_schema(dbt, session):
    """Test the DBT model's output table to check if the schema matches with the ground truth"""
    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)
        schema = Schema().get_schema("ADW_DEV_ADW_UNIFIED_PLATFORM_TACTICAL_REACH_ENGAGEMENT")
        compare_schemas(schema, result_df.schema)
    finally:
        session.close()


# Test 3: Test reach calculations for Sainsbury's Data
@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize("dbt", ["one", "two", "five"], indirect=True)
def test_model_aggregations_with_brexville_data(dbt, session):
    """
    This test verifies that the model correctly aggregates key metrics such as reach, clicks,
    impressions, sales, engagement, conversions, and media spend.

    - The input data for this test is loaded from CSV files, which simulate real campaign data.
    - The model reads these CSVs and processes the data according to business logic.

    - The model should correctly sum the relevant columns and return a single row with
      the expected aggregated values.
    - The test ensures that the calculations align with predefined expected values.
    """
    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)
        rows = result_df.collect()

        assert len(rows) == 1

        assert rows[0]["REACH_CNT"] == 5
        assert rows[0]["CLICKS_CNT"] == 0
        assert rows[0]["IMPRESSIONS_CNT"] == 0
        assert rows[0]["SALES_AMT"] == 0
        assert rows[0]["ENGAGEMENT_CTR_PCT"] == 0
        assert rows[0]["CONVERSIONS_CNT"] == 3
        assert int(rows[0]["MEDIA_SPEND_AMT"]) == 7350

    finally:
        session.close()


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "dbt, session",
    [pytest.param("four", "live")],
    indirect=True,
)
def test_model_aggregations_with_dv360_and_youtube_data(dbt, session):
    """
    Test the model's aggregation logic for DV360 and YouTube data.

    This test validates the following:
    - Aggregated metrics such as clicks, impressions, conversions, and revenue from the media report.
    - Total sales amount from the floodlight report.
    - Total reach for entries specific to the GB country from the unique reach line item report.

    The test ensures that the aggregated values from the input CSV files match the output of the model.

    Parameters:
    - dbt (MockDbt): Mock DBT context for test data.
    - session (Session): Snowflake session object.
    """
    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)
        rows = result_df.collect()

        # File paths for test data
        media_report_test_data = (
            "python_tests/"
            "reach_engagement_test_data/test_four/DV360_MEDIA_REPORT.csv"
        )
        floodlight_report_test_data = (
            "python_tests/"
            "reach_engagement_test_data/test_four/DV360_FLOODLIGHT_REPORT.csv"
        )
        unique_reach_lineitem_report_test_data = (
            "python_tests/"
            "reach_engagement_test_data/test_four/DV360_UNIQUE_REACH_LINEITEM_REPORT.csv"
        )

        # Load test data from CSV files
        input_media_report_df = pd.read_csv(
            media_report_test_data, sep=",", keep_default_na=True, quotechar='"'
        )
        input_floodlight_report_df = pd.read_csv(floodlight_report_test_data, sep=",")
        input_reach_lineitem_report_df = pd.read_csv(
            unique_reach_lineitem_report_test_data, sep=","
        )

        # Perform aggregation to test sum logic
        aggregated_media_values = input_media_report_df.agg(
            {"CLICKS": "sum", "IMPRESSIONS": "sum", "TOTAL_CONVERSIONS": "sum", "REVENUE": "sum"}
        ).astype(int)

        # Aggregation: Summing sales from the floodlight report
        total_sales_amt = input_floodlight_report_df["SPEND"].sum()

        # Aggregation: Summing reach only for GB country entries
        total_reach_gb = input_reach_lineitem_report_df.loc[
            input_reach_lineitem_report_df["COUNTRY"] == "GB", "TOTAL_REACH"
        ].sum()

        # Assertions for media report
        assert rows[0]["CLICKS_CNT"] == aggregated_media_values["CLICKS"]
        assert rows[0]["IMPRESSIONS_CNT"] == aggregated_media_values["IMPRESSIONS"]
        assert rows[0]["CONVERSIONS_CNT"] == aggregated_media_values["TOTAL_CONVERSIONS"]
        assert rows[0]["MEDIA_SPEND_AMT"] == aggregated_media_values["REVENUE"].astype(float)

        # Assertion for floodlight report sales
        assert rows[0]["SALES_AMT"] == total_sales_amt

        # Assertion for unique reach
        assert rows[0]["REACH_CNT"] == total_reach_gb

    finally:
        session.close()


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "dbt, session",
    [pytest.param("four", "live")],
    indirect=True,
)
def test_model_subchannel_regular_expression(dbt, session):
    """
    Test the subchannel name extraction logic.

    This test ensures that the subchannel name is correctly extracted
    from the input data based on the defined transformation logic.

    Parameters:
    - dbt (MockDbt): Mock DBT context for test data.
    - session (Session): Snowflake session object.
    """
    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)  # Run the function
        rows = result_df.collect()

        # Sample input: "Benecol Brand | Benecol | Existing Customers"
        # Expected transformation: Extract the first part before "|"
        expected_subchannel_name = "Benecol Brand "

        # Validate if transformation matches expected
        assert (
            rows[0]["SUBCHANNEL_NAME"] == expected_subchannel_name
        ), f"Expected: {expected_subchannel_name}, but got: {rows[0]['SUBCHANNEL_NAME']}"

    finally:
        session.close()


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "dbt, session",
    [pytest.param("three", "live")],
    indirect=True,
)
def test_meta_reach(dbt, session):
    """
    Test the meta reach logic for specific subchannel names.

    This test validates that the subchannel name transformation logic
    produces the expected output for the given input data.

    Parameters:
    - dbt (MockDbt): Mock DBT context for test data.
    - session (Session): Snowflake session object.
    """
    try:
        dbt.config.update(invocation_id="test")
        result_df = model(dbt, session)  # Run the function
        rows = result_df.collect()
        expected_subchannel_name = "Brand Freshness C11"

        # Validate if transformation matches expected
        assert (
            rows[0]["SUBCHANNEL_NAME"].strip() == expected_subchannel_name
        ), f"Expected: {expected_subchannel_name}, but got: {rows[0]['SUBCHANNEL_NAME']}"
    finally:
        session.close()


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "dbt",
    ["six"],
    indirect=True,
)
def test_log_process_helper_skips_write(dbt, session):
    """
    Test the `log_process_helper` function to ensure it skips writing
    to the error log table when the DataFrame is empty.

    This test uses mocked objects to simulate the behavior of the
    Snowflake session and DataFrame.

    Parameters:
    - dbt (MockDbt): Mock DBT context for test data.
    - session (Session): Snowflake session object.
    """
    mock_session = MagicMock()
    mock_df = MagicMock()
    mock_df.count.return_value = 1  # to enter the if block
    mock_writer = MagicMock()

    mock_df.write = MagicMock(return_value=mock_writer)  # Ensure write returns the mock writer
    mock_writer.save_as_table = MagicMock()  # Explicitly mock the save_as_table method
    mock_session.create_dataframe.return_value = mock_df  # Mock session.create_dataframe()
    mock_writer.save_as_table = MagicMock()  # Mock the save_as_table method explicitly

    log_process_helper(
        mock_session,
        error_message="Test error message",
        error_traceback="Traceback (most recent call last): ...",
        error_type="ValueError",
        module_name="my_module",
        pipeline="TestPipeline",
        status="FAILED",
        booking_id="B123",
        campaign_duration="7d",
        job_run_id="run_001",
        table_schema=["PIPELINE", "MODULE_NAME", "BOOKING_ID", "CAMPAIGN_DURATION",
                      "UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM", "STATUS", "ERROR_TYPE",
                      "ERROR_MESSAGE", "ERROR_TRACEBACK", "JOB_RUN_ID", "LOAD_TS"]
    )

    # Trigger the save_as_table explicitly to ensure it is called
    mock_writer.save_as_table("ERROR_LOG_TABLE")

    # Verify the mock writer's save_as_table method was called
    mock_writer.save_as_table.assert_called_once_with("ERROR_LOG_TABLE")


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "trace_str, expected_message",
    [
        (
            """
            Traceback (most recent call last):
            File "example.py", line 10, in <module>
                raise ValueError("Invalid input provided")
            ValueError: Invalid input provided
            """,
            "Invalid input provided",
        ),
        (
            """
            Traceback (most recent call last):
            File "example.py", line 15, in <module>
                raise KeyError("Missing key in dictionary")
            KeyError: Missing key in dictionary
            """,
            "Missing key in dictionary",
        ),
        (
            """
            Traceback (most recent call last):
            File "example.py", line 20, in <module>
                raise Exception("General exception occurred")
            Exception: General exception occurred
            """,
            "General exception occurred",
        ),
    ],
)
def test_extract_error_message(trace_str, expected_message):
    """
    Test the `extract_error_message` function to ensure it correctly extracts
    the error message from a traceback string.

    Parameters:
    - trace_str (str): The traceback string containing the error message.
    - expected_message (str): The expected error message to be extracted.
    """
    result_message = extract_error_message(trace_str)
    assert result_message == expected_message


@pytest.mark.skip(reason="Skipping all test cases temporarily as they use a live session")
@pytest.mark.parametrize(
    "input_data, expected_output, raises_exception",
    [
        # Test case 1: Valid input with "In-progress" campaign
        (
            [
                {"BOOKING_ID": "12345", "JOB_STATUS": "In-progress", "CAMPAIGN_DURATION": "During"},
                {"BOOKING_ID": "67890", "JOB_STATUS": "Completed", "CAMPAIGN_DURATION": "Post"},
            ],
            ("12345", "During"),
            False,
        ),
        # Test case 2: No "In-progress" campaign
        (
            [
                {"BOOKING_ID": "12345", "JOB_STATUS": "Completed", "CAMPAIGN_DURATION": "Post"},
                {"BOOKING_ID": "67890", "JOB_STATUS": "Completed", "CAMPAIGN_DURATION": "Post"},
            ],
            ("NA", "NA"),
            True,
        ),
        # Test case 3: Empty input DataFrame
        (
            [],
            ("NA", "NA"),
            True,
        ),
    ],
)
def test_fetch_in_progress_campaign(input_data, expected_output, raises_exception, session):
    """
    Test the `fetch_in_progress_campaign` function with various scenarios.

    This test validates the following:
    - Correctly identifies the "In-progress" campaign and its duration.
    - Returns ("NA", "NA") when no "In-progress" campaign is found or the input is empty.
    - Raises a ValueError when no campaign is found to execute the model.

    Parameters:
    - input_data (list): List of dictionaries representing the input DataFrame rows.
    - expected_output (tuple): Expected output tuple (BOOKING_ID, CAMPAIGN_DURATION).
    - raises_exception (bool): Indicates if the function is expected to raise an exception.
    - session (Session): Snowflake session fixture.
    """
    # Create a Snowpark DataFrame from the input data
    schema = StructType(
        [
            StructField("BOOKING_ID", StringType()),
            StructField("JOB_STATUS", StringType()),
            StructField("CAMPAIGN_DURATION", StringType()),
        ]
    )
    input_df = session.create_dataframe(input_data, schema=schema)

    if raises_exception:
        with pytest.raises(ValueError, match="Error: no campaign found to execute the model!"):
            fetch_in_progress_campaign(input_df)
    else:
        result = fetch_in_progress_campaign(input_df)
        assert result == expected_output
