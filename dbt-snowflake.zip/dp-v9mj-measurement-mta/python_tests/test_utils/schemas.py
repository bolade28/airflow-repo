from typing import Union

from snowflake.snowpark import types as T


class Schema:
    def get_schema(self, source_name: str) -> Union[T.StructType, None]:
        """
        Returns the schema based on the source name.

        This function matches the provided source name to a predefined schema function
        and returns the corresponding schema.
        If no matching source name is found, it returns None.

        Args:
        - source_name: The name of the source to retrieve the schema for.

        Returns:
        - StructType: The schema for the source if found, else None.
        """
        source_name = source_name.upper()

        schema_map = {
            "USER_JOURNEY_OFFER": (self.adw_dev_adw_unified_platform_tactical_user_journey_offer),
            "MEASUREMENT_CAMPAIGN_EXECUTION": (
                self.adw_unified_platform_tactical_measurement_campaign_execution
            ),
            "ATTRIBUTION_PRE_REQUISITE_OFFER": (
                self.adw_unified_platform_tactical_attribution_pre_requisite_offer
            ),
            "ATTRIBUTION_PRE_REQUISITE_BRAND": (
                self.adw_unified_platform_tactical_attribution_pre_requisite_offer
            ),
            "ATTRIBUTION_PRE_REQUISITE_AISLE": (
                self.adw_unified_platform_tactical_attribution_pre_requisite_offer
            ),
            "CUSTOMER_DATA_COLLECTION": (
                self.adw_unified_platform_tactical_customer_data_collection
            ),
            "REACH_ENGAGEMENT": (self.adw_dev_adw_unified_platform_tactical_reach_engagement),
            "ADW_UNIFIED_PLATFORM_TACTICAL_SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER": (
                self.adw_unified_platform_tactical_sku_level_attributed_sales_and_units_offer
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND": (
                self.adw_unified_platform_tactical_sku_level_attributed_sales_and_units_brand
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE": (
                self.adw_unified_platform_tactical_sku_level_attributed_sales_and_units_brand
            ),
            "SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS": (
                self.adw_unified_platform_tactical_sku_level_attributed_sales_and_units_offer
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_UNIFIED_CAMPAIGN": (
                self.adw_dev_adw_unified_platform_tactical_unified_campaign
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_BASELINE_INTEGRATION_SKU": (
                self.adw_unified_platform_tactical_baseline_integration_sku
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_CAMPAIGN_PRODUCT_TYPE": (
                self.adw_unified_platform_tactical_campaign_product_type
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_REACH_ENGAGEMENT": (
                self.adw_dev_adw_unified_platform_tactical_reach_engagement
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_SKU_CLUSTER_MAPPING": (
                self.adw_dev_adw_unified_platform_tactical_sku_cluster_mapping
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_BASELINE_MODELLING_OUTPUT": (
                self.adw_unified_platform_tactical_baseline_modelling_output
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_SALES_DATA_TRANSFORMATION_OUTPUT": (
                self.adw_unified_platform_tactical_sales_data_transformation_output
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_UNIFIED_PRODUCT": (
                self.adw_dev_adw_unified_platform_tactical_unified_product
            ),
            "DV360_MEDIA_REPORT": self.rtd_prod_dv360_media_report,
            "DV360_UNIQUE_REACH_LINEITEM_REPORT": self.rtd_prod_dv360_unique_reach_lineitem_report,
            "DV360_FLOODLIGHT": self.rtd_prod_dv360_floodlight_report,
            "ADW_RDV_ADVERTISING_CAMPAIGN_CITCAM_SAT": (
                self.adw_prod_adw_rdv_advertising_campaign_citcam_sat
            ),
            "ADW_RDV_ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK": (
                self.adw_prod_adw_rdv_advertising_campaign_request_realised_link
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_ATTRIBUTION_MODEL_RESULTS_OFFER": (
                self.adw_unified_platform_tactical_attribution_model_results_offer
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_ATTRIBUTION_MODEL_RESULTS_BRAND": (
                self.adw_unified_platform_tactical_attribution_model_results_offer
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_ATTRIBUTION_MODEL_RESULTS_AISLE": (
                self.adw_unified_platform_tactical_attribution_model_results_offer
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_MEASUREMENT_CAMPAIGN_REPORTING": (
                self.adw_dev_adw_unified_platform_tactical_measurement_campaign_reporting
            ),
            "ADW_UNIFIED_PLATFORM_TACTICAL_ERROR_LOG_TABLE": (
                self.adw_dev_adw_unified_platform_tactical_error_log_table
            ),
            "ADW_RDV_DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT": (
                self.adw_rdv_digital_trading_campaign_dmfbca_sat
            ),
            "ADW_RDV_DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK": (
                self.adw_rdv_digital_trading_campaign_channel_dmfbca_link
            ),
            "ADW_RDV_DIGITAL_TRADING_LINEITEM_INSIGHT_DMFBIN_LINK": (
                self.adw_rdv_digital_trading_lineitem_insight_dmfbin_link
            ),
        }

        # Handle multiple keys mapping to the same function
        baseline_keys = {
            "ADW_UNIFIED_PLATFORM_TACTICAL_BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_OFFER",
            "ADW_UNIFIED_PLATFORM_TACTICAL_BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_BRAND",
            "ADW_UNIFIED_PLATFORM_TACTICAL_BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE",
            "BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_OFFER",
            "BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_BRAND",
            "BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE",
        }

        # Return matching schema function if found
        for key, func in schema_map.items():
            if key in source_name:
                return func()

        if any(key in source_name for key in baseline_keys):
            return self.adw_unified_platform_tactical_baseline_attribution_integration_sku_level()

        return None

    def adw_dev_adw_unified_platform_tactical_user_journey_offer(self) -> T.StructType:
        """
        Returns the schema for the ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.USER_JOURNEY_OFFER table.

        This schema defines the structure of user journeys for
        all customers belonging to a campaign/booking
        where customers who have bought products with product types
        marked as offer are marked as converted (1),
        and other transactions are marked as non-converted (0).

        Columns:
        - LOYALTY_ID: Hashed nectar id identifying the customer (String, 128).
        - TRANSACTION_KEY: Unique transaction id for each purchase (String, 250).
        - EVENT_DT: Date of the transaction (Date).
        - EVENT_TS: Timestamp of the event (Timestamp).
        - CHANNEL_NAME: Name of the channel where the campaign ran (String, 18).
        - SUBCHANNEL_NAME: Specific subchannel where the campaign ran (String, 1000).
        - EVENT_NAME: Describes the event type (String, 20).
        - BOOKING_ID: Unique identifier for the booking related to the campaign (String, 36).
        - CAMPAIGN_ID: Identifier for the campaign (String, 1000).
        - SUB_PATH: Unique number for each customer transaction path (Integer).
        - USERJOURNEY_ID: Unique identifier for the user's journey (String, 1000).
        - RANK: Sequence number of the touchpoints in the customer journey (Integer).
        - POSITION: Defines where the customer journey was initiated (String, 9).
        - ISCONVERSION: Indicates if the journey resulted in a conversion (Integer, 1).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - CAMPAIGN_DURATION: Duration of the campaign defined as Post or During (String, 6).
        - JOB_RUN_ID: Identifier for the job execution (String, 100).
        - MARKETING_TYPE: Type of marketing campaign (String, 100).
        - NET_SALES_AMT: Total sales attributed to the journey (Decimal, 38, 4).
        - UNITS_QTY: Quantity of units sold (Decimal, 38, 4).
        - JOURNEY_TYPE: Type of customer journey (String, 100).
        """
        return T.StructType(
            [
                T.StructField("LOYALTY_ID", T.StringType()),
                T.StructField("TRANSACTION_KEY", T.StringType()),
                T.StructField("EVENT_DT", T.DateType()),
                T.StructField("EVENT_TS", T.TimestampType()),
                T.StructField("CHANNEL_NAME", T.StringType()),
                T.StructField("SUBCHANNEL_NAME", T.StringType()),
                T.StructField("EVENT_NAME", T.StringType()),
                T.StructField("BOOKING_ID", T.StringType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("SUB_PATH", T.LongType()),
                T.StructField("USERJOURNEY_ID", T.StringType()),
                T.StructField("RANK", T.LongType()),
                T.StructField("POSITION", T.StringType()),
                T.StructField("ISCONVERSION", T.IntegerType()),
                T.StructField("LOAD_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_DURATION", T.StringType()),
                T.StructField("JOB_RUN_ID", T.StringType()),
                T.StructField("MARKETING_TYPE", T.StringType()),
                T.StructField("NET_SALES_AMT", T.DecimalType(38, 4)),
                T.StructField("UNITS_QTY", T.DecimalType(38, 4)),
                T.StructField("JOURNEY_TYPE", T.StringType()),
            ]
        )

    def adw_dev_adw_unified_platform_tactical_reach_engagement(self) -> T.StructType:
        """
        Returns the schema for the ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.REACH_ENGAGEMENT table.

        This schema defines the structure of the reach and engagement metrics
        related to campaigns, including impressions, clicks, conversions, and financial data.

        Columns:
        - CAMPAIGN_ID: Unique identifier for a campaign (String, 100).
        - CHANNEL_NAME: Name of the channel where the campaign ran (String, 1000).
        - REACH_CNT: Number of unique users reached by the campaign (Integer).
        - CLICKS_CNT: Total number of clicks received (Integer).
        - IMPRESSIONS_CNT: Total number of times the campaign was displayed (Integer).
        - SALES_AMT: Total sales attributed to the campaign (Decimal, 38,4).
        - ENGAGEMENT_CNT: Total engagements recorded (Integer).
        - CONVERSIONS_CNT: Number of conversions achieved (Integer).
        - BOOKING_ID: Unique identifier for a booking related to the campaign (String, 100).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - JOB_RUN_ID: Identifier for the job execution (String, 100).
        - MARKETING_TYPE: Type of marketing campaign (String, 100).
        - SUBCHANNEL_NAME: Specific subchannel within the main channel (String, 100).
        - MEDIA_SPEND_AMT: Amount spent on media (Decimal, 38,2).
        """
        return T.StructType(
            [
                T.StructField("CAMPAIGN_ID", T.StringType(100)),
                T.StructField("CHANNEL_NAME", T.StringType(100)),
                T.StructField("REACH_CNT", T.LongType()),
                T.StructField("CLICKS_CNT", T.LongType()),
                T.StructField("IMPRESSIONS_CNT", T.LongType()),
                T.StructField("SALES_AMT", T.DecimalType(38, 4)),
                T.StructField("CONVERSIONS_CNT", T.LongType()),
                T.StructField("BOOKING_ID", T.StringType(100)),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("JOB_RUN_ID", T.StringType(100), False),
                T.StructField("MARKETING_TYPE", T.StringType(100)),
                T.StructField("SUBCHANNEL_NAME", T.StringType(100)),
                T.StructField("MEDIA_SPEND_AMT", T.DecimalType(38, 2), True),
                T.StructField("ENGAGEMENT_CTR_PCT", T.DecimalType(38, 2), True)
            ]
        )

    def adw_dev_adw_unified_platform_tactical_unified_campaign(self) -> T.StructType:
        """
        Returns the schema for the ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_CAMPAIGN table.

        This schema defines the structure of the unified campaign data, consolidating
        campaign details across various channels, including spend, targeting, and performance.

        Columns:
        - JOB_BAG_NUMBER: Unique identifier for a campaign (String, 1000).
        - CAMPAIGN_ID: Identifier for a campaign across different channel tables (String, 1000).
        - MEDIA_SPEND_AMT: Total media spend for the campaign (Float).
        - CAMPAIGN_START_DT: Start date of the campaign (Date).
        - CAMPAIGN_END_DT: End date of the campaign (Date).
        - SUBCHANNEL_NAME: The subchannel where the campaign was launched (String, 1000).
        - ITEM_CD_LIST: List of targeted SKU codes (String, 1000).
        - SUPER_CATEGORY_NAME: Super category of the targeted products (String, 1000).
        - SUB_CATEGORY_NAME: Subcategory of the targeted SKUs (String, 1000).
        - CHANNEL_NAME: Media channel of the campaign (String, 1000).
        - CAMPAIGN_NAME: Name of the campaign (String, 1000).
        - BOOKING_ID: Booking ID for the campaign (String, 1000).
        - CAMPAIGN_STATUS: Status of the campaign (Past, In Progress, Future) (String, 1000).
        - IS_MULTI_CHANNEL: Boolean flag indicating if the campaign runs
                            across multiple channels (Boolean).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - JOB_RUN_ID: Unique job run identifier (String, 36).
        - UNIQUE_BRAND_NAME: Unique brand name associated with the campaign (String, 1000).
        - MARKETING_TYPE: Type of marketing campaign (String, 100).
        - POST_CAMPAIGN_DT: Date indicating post-campaign analysis period (Date).
        """
        return T.StructType(
            [
                T.StructField("JOB_BAG_NUMBER", T.StringType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("BOOKING_ID", T.StringType()),
                T.StructField("MEDIA_SPEND_AMT", T.DecimalType(38, 2)),
                T.StructField("CAMPAIGN_START_DT", T.DateType()),
                T.StructField("CAMPAIGN_END_DT", T.DateType()),
                T.StructField("SUBCHANNEL_NAME", T.StringType()),
                T.StructField("ITEM_CD_LIST", T.StringType()),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType()),
                T.StructField("SUB_CATEGORY_NAME", T.StringType()),
                T.StructField("CHANNEL_NAME", T.StringType()),
                T.StructField("CAMPAIGN_NAME", T.StringType()),
                T.StructField("CAMPAIGN_STATUS", T.StringType()),
                T.StructField("IS_MULTI_CHANNEL", T.BooleanType()),
                T.StructField("MARKETING_TYPE", T.StringType()),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType()),
                T.StructField("POST_CAMPAIGN_DT", T.DateType()),
                T.StructField("LOAD_TS", T.TimestampType())
            ]
        )

    def adw_rdv_digital_trading_campaign_dmfbca_sat(self) -> T.StructType:
        """
        Returns the schema for the ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT table.

        This Satellite table contains unique natural keys for
        digital trading campaigns along with descriptive attributes.

        Columns:
        - DIGITAL_TRADING_CAMPAIGN_NK1, NK2, NK3: Unique campaign Keys assigned by DTP
                                                (String, 128).
        - RECORD_ARRIVAL_TS: Timestamp of when the record arrived (Timestamp).
        - CAMPAIGN_NAME: Display name of the campaign (String, 255).
        - CREATED_UTC_TS: Timestamp of campaign creation (Timestamp).
        - UPDATE_UTC_TS: Timestamp of last update (Timestamp).
        - JOB_BAG_ID: Associated job bag ID (String, 50).
        - PO_NUM: Purchase Order (PO) number (String, 255).
        - MEASUREMENT_SKU_LIST: Variant column containing SKUs for the campaign (Variant).
        - BILLING_ID: Billing ID for the campaign (String, 128).
        - APPROVAL_STATUS: Campaign approval status (String, 100).
        - CAMPAIGN_START_TS: Start date and time of the Facebook campaign (Timestamp).
        - CAMPAIGN_END_TS: End date and time of the Facebook campaign (Timestamp).
        - OFFLINE_EVENT_SET_ID: Offline event set ID (Decimal).
        - CUSTOM_CONVERSION_EVENT: Variant column for Facebook custom conversion events (Variant).
        - TECHNICAL_METADATA: JSON message of support fields per Aspire standards (Variant).
        """
        return T.StructType(
            [
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK3", T.StringType()),
                T.StructField("RECORD_ARRIVAL_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_NAME", T.StringType()),
                T.StructField("CREATED_UTC_TS", T.TimestampType()),
                T.StructField("UPDATE_UTC_TS", T.TimestampType()),
                T.StructField("JOB_BAG_ID", T.StringType()),
                T.StructField("PO_NUM", T.StringType()),
                T.StructField("MEASUREMENT_SKU_LIST", T.VariantType()),
                T.StructField("BILLING_ID", T.StringType()),
                T.StructField("APPROVAL_STATUS", T.StringType()),
                T.StructField("CAMPAIGN_START_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_END_TS", T.TimestampType()),
                T.StructField("OFFLINE_EVENT_SET_ID", T.DecimalType(38, 0)),
                T.StructField("CUSTOM_CONVERSION_EVENT", T.VariantType()),
                T.StructField("TECHNICAL_METADATA", T.VariantType()),
            ]
        )

    def adw_rdv_digital_trading_campaign_channel_dmfbca_link(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_PROD.ADW_RDV.DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK table.

        This table links digital trading campaigns with advertisers,
        brands, and associated channels.

        Columns:
        - DIGITAL_TRADING_CAMPAIGN_NK1, NK2, NK3: Unique campaign keys
                                                assigned by DTP (String, 128).
        - DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1, NK2, NK3: Unique channel keys for
                                                         campaign display (String, 128).
        - DIGITAL_TRADING_ADVERTISER_NK1, NK2, NK3: Unique advertiser keys assigned
                                                by DTP (String, 128).
        - DIGITAL_TRADING_BRAND_NK1, NK2, NK3: Unique brand keys assigned by DTP (String, 128).
        - RECORD_ARRIVAL_TS: Timestamp when the record arrived (Timestamp).
        - CHANNEL_DATA: Variant column containing linked channel dataset information (Variant).
        - TECHNICAL_METADATA: JSON message of support fields per Aspire standards (Variant).
        """
        return T.StructType(
            [
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_ADVERTISER_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_ADVERTISER_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_ADVERTISER_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK3", T.StringType()),
                T.StructField("RECORD_ARRIVAL_TS", T.TimestampType()),
                T.StructField("CHANNEL_DATA", T.VariantType()),
                T.StructField("TECHNICAL_METADATA", T.VariantType()),
            ]
        )

    def adw_rdv_digital_trading_lineitem_insight_dmfbin_link(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_PROD.ADW_RDV.DIGITAL_TRADING_LINEITEM_INSIGHT_DMFBIN_LINK table.

        This table contains metrics such as clicks and impressions on ads with different breakdowns
        (e.g., age, gender, device) at the item (ad set), campaign,
        and brand levels for Meta audiences.

        Columns:
        - DIGITAL_TRADING_CAMPAIGN_NK1, NK2, NK3: Unique campaign IDs assigned by Meta
                                                (String, 128).
        - DIGITAL_TRADING_BRAND_NK1, NK2, NK3: Unique brand IDs assigned
                                            by Meta or DV360 (String, 128).
        - DIGITAL_TRADING_LINEITEM_NK1, NK2, NK3: Unique ad set/line item IDs (String, 128).
        - DIGITAL_TRADING_INSIGHT_ID: Unique ID of the insight reporting (String, 128).
        - RECORD_ARRIVAL_TS: Timestamp of when the record arrived from the source (Timestamp).
        - LINEITEM_NAME: Name of the ad set (String, 255).
        - REPORTING_START_DT: Start date for reporting data (Date).
        - REPORTING_END_DT: End date for reporting data (Date).
        - BREAKDOWNS: JSON object with breakdowns like age, gender, and device (Variant).
        - MEASURES: JSON object containing metrics like clicks and impressions (Variant).
        - TECHNICAL_METADATA: JSON object with support fields (Variant).
        """
        return T.StructType(
            [
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_CAMPAIGN_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_BRAND_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_LINEITEM_NK1", T.StringType()),
                T.StructField("DIGITAL_TRADING_LINEITEM_NK2", T.StringType()),
                T.StructField("DIGITAL_TRADING_LINEITEM_NK3", T.StringType()),
                T.StructField("DIGITAL_TRADING_INSIGHT_ID", T.StringType()),
                T.StructField("RECORD_ARRIVAL_TS", T.TimestampType()),
                T.StructField("LINEITEM_NAME", T.StringType()),
                T.StructField("REPORTING_START_DT", T.DateType()),
                T.StructField("REPORTING_END_DT", T.DateType()),
                T.StructField("BREAKDOWNS", T.VariantType()),
                T.StructField("MEASURES", T.VariantType()),
                T.StructField("TECHNICAL_METADATA", T.VariantType()),
            ]
        )

    def rtd_prod_dv360_media_report(self) -> T.StructType:
        """
        Returns the schema for the RTD_PROD.DV360.MEDIA_REPORT table.

        This table contains impressions, views, and interactions such as clicks and video starts
        per campaign, item, and creative for each advertiser on a particular day.

        Columns:
        - RUN_AT: Timestamp when the report was generated (Timestamp).
        - CAMPAIGN_ID: Unique identifier for the campaign (String).
        - CAMPAIGN_NAME: Name of the campaign (String).
        - CAMPAIGN_DATE: Date of the campaign (Date).
        - TIME_OF_DAY: Time of the day in numeric format (Decimal).
        - ADVERTISER_ID: Unique identifier for the advertiser (String).
        - ADVERTISER_NAME: Name of the advertiser (String).
        - APP_URL: URL of the associated app (String).
        - CREATIVE_ID: Unique identifier for the creative (String).
        - CREATIVE_NAME: Name of the creative (String).
        - CREATIVE_SIZE: Size of the creative (String).
        - DEVICE_TYPE: Type of device used for the ad (String).
        - INSERTION_ORDER_ID: Unique ID for the insertion order (String).
        - INSERTION_ORDER_NAME: Name of the insertion order (String).
        - LINE_ITEM_ID: Unique identifier for the line item (String).
        - LINE_ITEM_NAME: Name of the line item (String).
        - ADVERTISER_CURRENCY: Currency used by the advertiser (String).
        - INSERTION_ORDER_INTEGRATION_CODE: Integration code for the insertion order (String).
        - JOBBAG_ID: ID associated with the job bag (String).
        - MEASURABLE_IMPRESSIONS: Number of measurable impressions (Decimal).
        - VIEWABLE_IMPRESSIONS: Number of viewable impressions (Decimal).
        - CLICKS: Number of clicks (Decimal).
        - IMPRESSIONS: Total number of impressions (Decimal).
        - REVENUE: Revenue generated (Decimal, precision 38, scale 6).
        - VIDEO_STARTED: Number of video starts (Decimal).
        - VIDEO_COMPLETED: Number of videos completed (Decimal).
        - TOTAL_CONVERSIONS: Total number of conversions (Decimal).
        """
        return T.StructType(
            [
                T.StructField("RUN_AT", T.TimestampType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("CAMPAIGN_NAME", T.StringType()),
                T.StructField("CAMPAIGN_DATE", T.DateType()),
                T.StructField("TIME_OF_DAY", T.DecimalType(38, 0)),
                T.StructField("ADVERTISER_ID", T.StringType()),
                T.StructField("ADVERTISER_NAME", T.StringType()),
                T.StructField("APP_URL", T.StringType()),
                T.StructField("CREATIVE_ID", T.StringType()),
                T.StructField("CREATIVE_NAME", T.StringType()),
                T.StructField("CREATIVE_SIZE", T.StringType()),
                T.StructField("DEVICE_TYPE", T.StringType()),
                T.StructField("INSERTION_ORDER_ID", T.StringType()),
                T.StructField("INSERTION_ORDER_NAME", T.StringType()),
                T.StructField("LINE_ITEM_ID", T.StringType()),
                T.StructField("LINE_ITEM_NAME", T.StringType()),
                T.StructField("ADVERTISER_CURRENCY", T.StringType()),
                T.StructField("INSERTION_ORDER_INTEGRATION_CODE", T.StringType()),
                T.StructField("JOBBAG_ID", T.StringType()),
                T.StructField("MEASURABLE_IMPRESSIONS", T.DecimalType(38, 0)),
                T.StructField("VIEWABLE_IMPRESSIONS", T.DecimalType(38, 0)),
                T.StructField("CLICKS", T.DecimalType(38, 0)),
                T.StructField("IMPRESSIONS", T.DecimalType(38, 0)),
                T.StructField("REVENUE", T.DecimalType(38, 6)),
                T.StructField("VIDEO_STARTED", T.DecimalType(38, 0)),
                T.StructField("VIDEO_COMPLETED", T.DecimalType(38, 0)),
                T.StructField("TOTAL_CONVERSIONS", T.DecimalType(38, 0)),
            ]
        )

    def rtd_prod_dv360_unique_reach_lineitem_report(self) -> T.StructType:
        """
        Returns the schema for the RTD_PROD.DV360.UNIQUE_REACH_LINEITEM_REPORT table.

        This table contains impression reach data at the line item level, providing insights into
        how many impressions a specific advertisement (line item) received over a given period.

        Columns:
        - RUN_AT: Timestamp when the report was generated (Timestamp).
        - DATE_FROM: Start date for the report period (Date).
        - DATE_UNTIL: End date for the report period (Date).
        - INSERTION_ORDER_ID: Unique identifier for the insertion order (String).
        - LINE_ITEM_ID: Unique identifier for the line item (String).
        - LINE_ITEM_NAME: Name of the line item (String).
        - AVERAGE_IMPRESSION_FREQUENCY: Average number of times an impression was served
                                        (Decimal, precision 38, scale 6).
        - CLICK_REACH: Unique number of users who clicked on the ad
                    (Decimal, precision 38, scale 6).
        - IMPRESSION_REACH: Unique number of users who saw the ad (Decimal, precision 38, scale 6).
        - TOTAL_REACH: Total unique reach of the ad (Decimal, precision 38, scale 6).
        - COUNTRY: Country in which the impressions were served (String).
        """
        return T.StructType(
            [
                T.StructField("RUN_AT", T.TimestampType()),
                T.StructField("DATE_FROM", T.DateType()),
                T.StructField("DATE_UNTIL", T.DateType()),
                T.StructField("INSERTION_ORDER_ID", T.StringType()),
                T.StructField("LINE_ITEM_ID", T.StringType()),
                T.StructField("LINE_ITEM_NAME", T.StringType()),
                T.StructField("AVERAGE_IMPRESSION_FREQUENCY", T.DecimalType(38, 6)),
                T.StructField("CLICK_REACH", T.DecimalType(38, 6)),
                T.StructField("IMPRESSION_REACH", T.DecimalType(38, 6)),
                T.StructField("TOTAL_REACH", T.DecimalType(38, 6)),
                T.StructField("COUNTRY", T.StringType()),
            ]
        )

    def rtd_prod_dv360_floodlight_report(self) -> T.StructType:
        """
        Returns the schema for the RTD_PROD.DV360.FLOODLIGHT_REPORT table.

        This table stores conversions per insertion order ID (Google campaign identifier)
        per customer type (online, offline) along with the overall spend per customer type.

        Columns:
        - RUN_AT: Timestamp when the report was generated (Timestamp).
        - CAMPAIGN_DATE: Date when the campaign was run (Date).
        - FLOODLIGHT_ID: Unique identifier for the floodlight event (String).
        - INSERTION_ORDER_ID: Unique identifier for the insertion order (String).
        - INSERTION_ORDER_NAME: Name of the insertion order (String).
        - LINE_ITEM_ID: Unique identifier for the line item (String).
        - LINE_ITEM_NAME: Name of the line item (String).
        - CREATIVE_ID: Unique identifier for the creative (String).
        - CREATIVE_NAME: Name of the creative (String).
        - ORDER_ID: Unique order identifier (String).
        - UVAR_ONLINE: Number of online conversions (Decimal, precision 38, scale 6).
        - UVAR_OFFLINE: Number of offline conversions (Decimal, precision 38, scale 6).
        - UVAR_LAPSED: Number of lapsed customer conversions (Decimal, precision 38, scale 6).
        - UVAR_RETAINED: Number of retained customer conversions (Decimal, precision 38, scale 6).
        - UVAR_ACQUIRED: Number of acquired customer conversions (Decimal, precision 38, scale 6).
        - UVAR_TRANSACTION: Number of transactions from users (Decimal, precision 38, scale 6).
        - TOTAL_CONVERSIONS: Total number of conversions (Decimal, precision 38, scale 6).
        - SPEND: Total spend on the campaign (Decimal, precision 38, scale 6).
        """
        return T.StructType(
            [
                T.StructField("RUN_AT", T.TimestampType()),
                T.StructField("CAMPAIGN_DATE", T.DateType()),
                T.StructField("FLOODLIGHT_ID", T.StringType()),
                T.StructField("INSERTION_ORDER_ID", T.StringType()),
                T.StructField("INSERTION_ORDER_NAME", T.StringType()),
                T.StructField("LINE_ITEM_ID", T.StringType()),
                T.StructField("LINE_ITEM_NAME", T.StringType()),
                T.StructField("CREATIVE_ID", T.StringType()),
                T.StructField("CREATIVE_NAME", T.StringType()),
                T.StructField("ORDER_ID", T.StringType()),
                T.StructField("UVAR_ONLINE", T.DecimalType(38, 6)),
                T.StructField("UVAR_OFFLINE", T.DecimalType(38, 6)),
                T.StructField("UVAR_LAPSED", T.DecimalType(38, 6)),
                T.StructField("UVAR_RETAINED", T.DecimalType(38, 6)),
                T.StructField("UVAR_ACQUIRED", T.DecimalType(38, 6)),
                T.StructField("UVAR_TRANSACTION", T.DecimalType(38, 6)),
                T.StructField("TOTAL_CONVERSIONS", T.DecimalType(38, 6)),
                T.StructField("SPEND", T.DecimalType(38, 6)),
            ]
        )

    def adw_unified_platform_tactical_campaign_product_type(self) -> T.StructType:
        """
        Returns the schema for the CAMPAIGN_PRODUCT_TYPE table.

        Columns:
        - ITEM_CD: Unique identifier for the item (Integer).
        - PRODUCT_TYPE: Type of the product (String).
        - CHANNEL_NAME: Name of the channel where the campaign ran (String).
        - SUBCHANNEL_NAME: Specific subchannel within the main channel (String).
        - BOOKING_ID: Unique identifier for a booking related to the campaign (String).
        - CAMPAIGN_ID: Unique identifier for a campaign (String).
        - JOB_RUN_ID: Identifier for the job execution (String).
        - SKU_NAME: Name of the SKU (String).
        - SUB_CAT_NAME: Name of the subcategory for the product (String).
        - BRAND_NAME: Name of the brand (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - UNIQUE_BRAND_NAME: Unique name of the brand (String).
        - BRAND_OWNER_NAME: Name of the brand owner (String).
        """
        return T.StructType(
            [
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("PRODUCT_TYPE", T.StringType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), True),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("BOOKING_ID", T.StringType(), True),
                T.StructField("CAMPAIGN_ID", T.StringType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("SKU_NAME", T.StringType(), True),
                T.StructField("SUB_CAT_NAME", T.StringType(), True),
                T.StructField("BRAND_NAME", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("BRAND_OWNER_NAME", T.StringType(), True),
            ]
        )

    def adw_prod_adw_rdv_advertising_campaign_request_realised_link(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_PROD.ADW_RDV.ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK table.

        This table contains aggregated data for both advertising requests and realised ads,
        tracking metrics like impressions, clicks, conversions, and revenue across
        different campaigns and placements.

        Columns Sumamry:
        - Campaign NK1-3: Identifiers for the advertising campaign, where NK1 is the CitrusAds UUID
        - Wallet NK1-3: Identifiers for the advertising wallet
        - Request counts (total, with ads, without ads, etc.)
        - Performance metrics (impressions, clicks, conversions)
        - Financial metrics (revenue, spend) in both local and USD currency
        - Ad serving metrics (ads considered, served, requested)
        - Category and search term targeting indicators
        - Platform and placement details
        - Geographic and timezone data
        - Record tracking (arrival timestamp, hash diff)
        - Load tracking (load timestamp)
        - Technical metadata (JSON variant)
        """
        return T.StructType(
            [
                # Campaign Natural Keys
                T.StructField("ADVERTISING_CAMPAIGN_NK1", T.StringType()),
                T.StructField("ADVERTISING_CAMPAIGN_NK2", T.StringType()),
                T.StructField("ADVERTISING_CAMPAIGN_NK3", T.StringType()),
                # Wallet Natural Keys
                T.StructField("ADVERTISING_WALLET_NK1", T.StringType()),
                T.StructField("ADVERTISING_WALLET_NK2", T.StringType()),
                T.StructField("ADVERTISING_WALLET_NK3", T.StringType()),
                # Date and ID Fields
                T.StructField("INGRESSED_AT_DT", T.DateType()),
                T.StructField("CATALOG_ID", T.StringType()),
                T.StructField("CONTENT_STANDARD_ID", T.StringType()),
                T.StructField("ITEM_ID", T.StringType()),
                T.StructField("TARGET_ITEM_ID", T.StringType()),
                # Targeting Fields
                T.StructField("CATEGORY_ID", T.StringType()),
                T.StructField("SEARCH_TERM", T.StringType()),
                T.StructField("GENERIC_SEARCH_TERM", T.StringType()),
                T.StructField("PLACEMENT", T.StringType()),
                T.StructField("ADVERTISING_TYPE", T.StringType()),
                T.StructField("PAGE_TYPE", T.StringType()),
                T.StructField("SLOT_ID", T.StringType()),
                T.StructField("PLATFORM", T.StringType()),
                # Indicator Fields
                T.StructField("SEARCH_TERM_IND", T.IntegerType()),
                T.StructField("CATEGORY_IND", T.IntegerType()),
                T.StructField("FILTER_MODE", T.StringType()),
                # Advertisement Count Metrics
                T.StructField("ADVERTISEMENT_CONSIDERED_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_SERVED_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_REQUESTED_CNT", T.IntegerType()),
                T.StructField("CAP_ADVERTISEMENT_SERVED_CNT", T.IntegerType()),
                T.StructField("CAP_ADVERTISEMENT_REQUESTED_CNT", T.IntegerType()),
                T.StructField("CAP_REQ_SERVING_MAX_ADVERTISEMENT_CNT", T.IntegerType()),
                T.StructField("REQ_SERVING_MAX_ADVERTISEMENT_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_REQ_SERVING_NO_ADS_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_REQ_SERVING_SOME_ADS_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_REQ_CNT", T.IntegerType()),
                T.StructField("ADVERTISEMENT_REQ_WITH_SAT_CNT", T.IntegerType()),
                # Financial Metrics (Local Currency)
                T.StructField("SALES_REVENUE_AMT", T.DecimalType(38, 6)),
                T.StructField("ADVERTISING_REVENUE_AMT", T.DecimalType(38, 6)),
                T.StructField("ADVERTISING_SPEND_AMT", T.DecimalType(38, 6)),
                # Performance Metrics
                T.StructField("IMPRESSIONS_CNT", T.IntegerType()),
                T.StructField("CLICKS_CNT", T.IntegerType()),
                T.StructField("CONVERSIONS_CNT", T.IntegerType()),
                T.StructField("UNIT_SALES_CNT", T.IntegerType()),
                # Spend Breakdowns
                T.StructField("CLICKS_SPEND_AMT", T.DecimalType(38, 6)),
                T.StructField("IMPRESSIONS_SPEND_AMT", T.DecimalType(38, 6)),
                # Financial Metrics (USD)
                T.StructField("SALES_REVENUE_USD_AMT", T.DecimalType(38, 6)),
                T.StructField("ADVERTISING_REVENUE_USD_AMT", T.DecimalType(38, 6)),
                T.StructField("ADVERTISING_SPEND_USD_AMT", T.DecimalType(38, 6)),
                # Geographic and Timezone Information
                T.StructField("GEO_REGION", T.StringType()),
                T.StructField("LOCAL_TIMEZONE", T.StringType()),
                # Technical Fields
                T.StructField("RECORD_ARRIVAL_TS", T.TimestampType()),
                T.StructField("HASH_DIFF", T.StringType()),
                T.StructField("LOAD_TS", T.TimestampType()),
                T.StructField("TECHNICAL_METADATA", T.VariantType()),
            ]
        )

    def adw_prod_adw_rdv_advertising_campaign_citcam_sat(self) -> T.StructType:
        """
        Returns the schema for the ADW_PROD.ADW_RDV.ADVERTISING_CAMPAIGN_CITCAM_SAT table.

        This satellite table contains detailed campaign information from CitrusAds including
        campaign settings, budgets, targeting criteria, and status information.

        Columns Sumamry:
        - Campaign Identification (NK1-3 and basic info)
        - Campaign Settings (type, subtype, placements)
        - Financial Information (budgets, spend limits, FTA details)
        - Temporal Data (start/end dates, creation/update timestamps)
        - Status Information (valid state, active state)
        - Targeting Information (filters, categories, search terms)
        - Operational Metrics (catalog counts, product lists)
        - Geographic and Currency Information
        - Row tracking (current row, active, deleted indicators)
        - Load tracking (hash diff, load timestamp)
        - Technical metadata (JSON variant)
        """
        return T.StructType(
            [
                # Natural Keys
                T.StructField("ADVERTISING_CAMPAIGN_NK1", T.StringType()),
                T.StructField("ADVERTISING_CAMPAIGN_NK2", T.StringType()),
                T.StructField("ADVERTISING_CAMPAIGN_NK3", T.StringType()),
                # Timestamp Fields
                T.StructField("CAMPAIGN_UPDATED_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_CREATED_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_START_TS", T.TimestampType()),
                T.StructField("CAMPAIGN_END_TS", T.TimestampType()),
                # Basic Campaign Information
                T.StructField("TEAM_ID", T.StringType()),
                T.StructField("CAMPAIGN_NAME", T.StringType()),
                T.StructField("CAMPAIGN_TYPE", T.StringType()),
                T.StructField("CAMPAIGN_SUBTYPE", T.StringType()),
                T.StructField("CAMPAIGN_PLACEMENTS", T.StringType()),
                # Campaign Status
                T.StructField("CAMPAIGN_VALID_STATE", T.StringType()),
                T.StructField("CAMPAIGN_ACTIVE_STATE", T.StringType()),
                # Fixed Tenancy Agreement
                T.StructField("FIXED_TENANCY_AGREEMENT_IND", T.BooleanType()),
                T.StructField("CAMPAIGN_FTA_AMT", T.DecimalType(38, 6)),
                # Financial Metrics
                T.StructField("CAMPAIGN_TOTAL_SPEND_AMT", T.DecimalType(38, 6)),
                T.StructField("CAMPAIGN_TOTAL_SPEND_USD_AMT", T.DecimalType(38, 6)),
                T.StructField("CAMPAIGN_MAX_COST_PER_CLICK_AMT", T.DecimalType(38, 6)),
                T.StructField("CAMPAIGN_MAX_TOTAL_SPEND_AMT", T.DecimalType(38, 6)),
                T.StructField("CAMPAIGN_MAX_DAILY_SPEND_AMT", T.DecimalType(38, 6)),
                T.StructField("CAMPAIGN_BUDGET_AMT", T.DecimalType(38, 6)),
                # Campaign Goals and Metrics
                T.StructField("CAMPAIGN_IMPRESSION_GOAL_CNT", T.IntegerType()),
                # Product and Catalog Information
                T.StructField("CAMPAIGN_CATALOG_PRODUCT_LIST", T.StringType()),
                T.StructField("CATALOG_CNT", T.IntegerType()),
                T.StructField("CATALOG_ID_LIST", T.StringType()),
                # User Defined Fields
                T.StructField("CAMPAIGN_USER_DEFINED_TEXT", T.StringType()),
                # Targeting Settings
                T.StructField("TARGETED_FILTERS", T.StringType()),
                T.StructField("LOCATION_FILTERS", T.StringType()),
                T.StructField("FILTER_WHITELISTS", T.StringType()),
                T.StructField("CROSS_SELL_SETTINGS", T.StringType()),
                T.StructField("UPSELL_SETTINGS", T.StringType()),
                # Category Information
                T.StructField("CATEGORY_ID_LIST", T.StringType()),
                # Search Terms
                T.StructField("SEARCH_TERM_LIST", T.StringType()),
                T.StructField("SEARCH_TERM_IND", T.BooleanType()),
                T.StructField("SUGGESTED_SEARCH_TERM_LIST", T.StringType()),
                T.StructField("SUGGESTED_SEARCH_TERM_IND", T.BooleanType()),
                # Geographic and Timezone
                T.StructField("GEO_REGION", T.StringType()),
                T.StructField("LOCAL_TIMEZONE", T.StringType()),
                # Additional Campaign Attributes
                T.StructField("PRODUCT_TYPE_CD", T.StringType()),
                T.StructField("CALL_TO_ACTION", T.StringType()),
                T.StructField("LAST_SPEND_DT", T.DateType()),
                T.StructField("CURRENCY_CD", T.StringType()),
                # Record Status Indicators
                T.StructField("CURRENT_ROW_IND", T.BooleanType()),
                T.StructField("ACTIVE_IND", T.BooleanType()),
                T.StructField("DELETED_IND", T.BooleanType()),
                # Technical Fields
                T.StructField("HASH_DIFF", T.StringType()),
                T.StructField("LOAD_TS", T.TimestampType()),
                T.StructField("TECHNICAL_METADATA", T.VariantType()),
            ]
        )

    def adw_unified_platform_tactical_baseline_integration_sku(self) -> T.StructType:
        """
        Returns the schema for the BASELINE_INTEGRATION_SKU table.

        Columns:
        - ITEM_CD: Unique identifier for the item (Integer).
        - BOOKING_ID: Unique identifier for a booking (String).
        - JOURNEY_TYPE: Specifies the type of journey (String).
        - COMMENT: Additional comments or notes (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - JOB_RUN_ID: Identifier for the job execution (String).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        """
        return T.StructType(
            [
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("BOOKING_ID", T.StringType(), True),
                T.StructField("JOURNEY_TYPE", T.StringType(), True),
                T.StructField("COMMENT", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
            ]
        )

    def adw_unified_platform_tactical_baseline_modelling_output(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_MODELLING_OUTPUT table.

        This table contains weekly baseline sales, which are the results of baseline modelling.

        Columns:
        - WEEK_START_DT: Start date of the week (Date).
        - SUPER_CATEGORY_NAME: The super-category of the cluster (String).
        - UNIQUE_BRAND_NAME: Brand of the cluster (String).
        - CLUSTER_NUM: Cluster of items (String).
        - ITERATION: Defines the best iteration chosen for the next step (String).
        - MODELLING_TYPE: Defines whether baseline is from Baseline
                        Modelling or Forecasting (String).
        - JOB_RUN_ID: Specifies the job run ID associated with this job (String).
        - METRIC_NAME: Defines output variable (String).
        - LOAD_TS: Date/time on which the record was loaded (Timestamp).
        - CLUSTER_TYPE: Defined characteristics of the cluster (String).
        - BEST_ITERATION: Flag representing if it is the best iteration (String).
        - METRIC_VALUE: Value of the output variable given in METRIC_NAME (Float).
        """
        return T.StructType(
            [
                T.StructField("WEEK_START_DT", T.DateType(), False),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType(), False),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), False),
                T.StructField("CLUSTER_NUM", T.StringType(), False),
                T.StructField("ITERATION", T.StringType(), True),
                T.StructField("MODELLING_TYPE", T.StringType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("METRIC_NAME", T.StringType(), False),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("CLUSTER_TYPE", T.StringType(), True),
                T.StructField("BEST_ITERATION", T.StringType(), True),
                T.StructField("METRIC_VALUE", T.FloatType(), True),
            ]
        )

    def adw_dev_adw_unified_platform_tactical_sku_cluster_mapping(self) -> T.StructType:
        """
        Returns the schema for the ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SKU_CLUSTER_MAPPING table.

        This table contains ITEM_CDs placed into various clusters.

        Columns:
        - ITEM_CD: The code of the item (Integer, Primary Key).
        - SUPER_CATEGORY_NAME: The super-category of the cluster (String).
        - UNIQUE_BRAND_NAME: Brand of the cluster (String).
        - CLUSTER_NUM: Cluster of items (String).
        - JOB_RUN_ID: Specifies the job run ID associated with this job (String).
        - LOAD_TS: Date/time on which the record was loaded (Timestamp).
        - MODELLING_TYPE: Rank assigned to each variable based on
                        importance from modelling (String).
        """
        return T.StructType(
            [
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("CLUSTER_NUM", T.StringType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("MODELLING_TYPE", T.StringType(), True),
            ]
        )

    def adw_unified_platform_tactical_sales_data_transformation_output(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SALES_DATA_TRANSFORMATION_OUTPUT table.

        This table contains aggregated weekly sales data at the SKU level.
        It includes metrics such as total sales amount, base price,
        and various percentages representing sales through different
        channels (online, supermarket, convenience store).
        The table also captures customer transaction counts and sales frequency.

        Columns:
        - WEEK_START_DT: Date at weekly level (Date, Primary Key).
        - SUPER_CATEGORY_NAME: The super-category of the item (String).
        - UNIQUE_BRAND_NAME: Unique Brand of the item (String).
        - ITEM_CD: Unique identifier of the item (Integer, Primary Key).
        - TOTAL_SALES_AMT: The weekly sales for the item (Decimal, precision 38, scale 4).
        - FREQUENCY_OF_PURCHASE: Distinct count of transactions in a week
                                (Decimal, precision 30, scale 0).
        - DISTINCT_CUSTOMER_CNT: Distinct count of customers purchasing item in a week
                                (Decimal, precision 30, scale 0).
        - AVG_PURCHASE_PER_CUSTOMER_CNT: Number of transactions per customer in a week
                                (Decimal, precision 36, scale 6).
        - ONLINE_SALES_PCT: Percentage of transactions taking place in online channels
                                (Decimal, precision 38, scale 10).
        - SUPERMARKET_SALES_PCT: Percentage of transactions taking place in supermarkets
                                (Decimal, precision 38, scale 10).
        - CONVENIENCE_SALES_PCT: Percentage of transactions taking place in convenience stores
                                (Decimal, precision 38, scale 10).
        - JOB_RUN_ID: Specifies the job run ID associated with this job (String).
        - PACK_SIZE: Pack size of the SKU (Decimal, precision 38, scale 12).
        - PRICE_PER_POINT: Base price divided by the pack size (Decimal, precision 38, scale 12).
        - LOAD_TS: Date/time on which the record was loaded (Timestamp).
        - BASE_PRICE_AMT: Price per unit for the item (Decimal, precision 38, scale 12).
        """
        return T.StructType(
            [
                T.StructField("WEEK_START_DT", T.DateType(), False),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType(), False),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), False),
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("TOTAL_SALES_AMT", T.DecimalType(38, 4), True),
                T.StructField("FREQUENCY_OF_PURCHASE", T.IntegerType(), True),
                T.StructField("DISTINCT_CUSTOMER_CNT", T.IntegerType(), True),
                T.StructField("AVG_PURCHASE_PER_CUSTOMER_CNT", T.DecimalType(36, 6), True),
                T.StructField("ONLINE_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("SUPERMARKET_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("CONVENIENCE_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("JOB_RUN_ID", T.StringType(), False),
                T.StructField("PACK_SIZE", T.DecimalType(38, 12), True),
                T.StructField("PRICE_PER_POINT", T.DecimalType(38, 12), True),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("BASE_PRICE_AMT", T.DecimalType(38, 12), True),
            ]
        )

    def adw_unified_platform_tactical_sku_level_attributed_sales_and_units_offer(
        self,
    ) -> T.StructType:
        """
        Returns the schema for the
        UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
        table

        This table contains SKU-level attribution results.

        Columns:
        - CAMPAIGN_ID: Identifies a campaign across different channel tables (String).
        - CHANNEL_NAME: Specifies the media channel where the campaign was run (String).
        - USERJOURNEY_ID: Unique ID for every customer journey (String, Primary Key).
        - LOYALTY_ID: Hashed Nectar ID to identify a customer with a Nectar card (String).
        - BOOKING_ID: UUID to identify campaigns that can be run together (String, Primary Key).
        - CUSTOMER_JOURNEY_TYPE: Specifies whether the journey is Direct/Non-Direct (String).
        - JOURNEY_TYPE: Specifies whether the SKU belongs to Offer, Brand, or Aisle (String).
        - ISCONVERSION: Specifies purchase/non-purchase label (Integer).
        - NORMALIZED_WEIGHTS: Attribution weights for each regression variable (Float).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        - EVENT_DT: Date of the transaction and opportunity to see the campaign (Date).
        - ITEM_CD: SKU number (Decimal, precision 18, scale 5, Primary Key).
        - NET_SALES_AMT: Actual sales value for the item purchased (Decimal, precision 30, scale 4).
        - UNITS_QTY: Actual units purchased (Decimal, precision 30, scale 4).
        - UNIQUE_BRAND_NAME: Name of the brand (String).
        - WEEK_START_DT: Week start date of the event (String).
        - REGRESSION_VARIABLE: Concatenated campaign, channel,
                            and subchannel value (String, Primary Key).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String).
        - ATTRIBUTED_SALES_AMT: Attributed sales amount (Float).
        - ATTRIBUTED_UNITS_QTY: Attributed units quantity (Float).
        - ATTRIBUTED_RECALIBERATED_SALES_AMT: Attributed sales refactored for
                                            offsite channels only (Float).
        - ATTRIBUTED_RECALIBERATED_UNITS_QTY: Attributed units refactored for
                                            offsite channels only (Float).
        - JOB_RUN_ID: Job run ID associated with this job (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - MARKETING_TYPE: Marketing type of the campaign (String).
        - RECALIBERATION_FACTOR: Recalibration factor for attribution (Float).
        """
        return T.StructType(
            [
                T.StructField("CAMPAIGN_ID", T.StringType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), True),
                T.StructField("USERJOURNEY_ID", T.StringType(), False),
                T.StructField("LOYALTY_ID", T.StringType(), True),
                T.StructField("BOOKING_ID", T.StringType(), False),
                T.StructField("CUSTOMER_JOURNEY_TYPE", T.StringType(), True),
                T.StructField("JOURNEY_TYPE", T.StringType(), True),
                T.StructField("ISCONVERSION", T.IntegerType(), True),
                T.StructField("NORMALIZED_WEIGHTS", T.FloatType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("EVENT_DT", T.DateType(), True),
                T.StructField("ITEM_CD", T.DecimalType(18, 5), False),
                T.StructField("NET_SALES_AMT", T.DecimalType(30, 4), True),
                T.StructField("UNITS_QTY", T.DecimalType(30, 4), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("WEEK_START_DT", T.StringType(), True),
                T.StructField("REGRESSION_VARIABLE", T.StringType(), False),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("ATTRIBUTED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_UNITS_QTY", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_UNITS_QTY", T.FloatType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
                T.StructField("MARKETING_TYPE", T.StringType(), True),
                T.StructField("RECALIBERATION_FACTOR", T.FloatType(), True),
            ]
        )

    def adw_unified_platform_tactical_sku_level_attributed_sales_and_units_brand(
        self,
    ) -> T.StructType:
        """
        Returns the schema for the
        UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
        table

        This table contains SKU-level attribution results.

        Columns:
        - CAMPAIGN_ID: Identifies a campaign across different channel tables (String).
        - CHANNEL_NAME: Specifies the media channel where the campaign was run (String).
        - USERJOURNEY_ID: Unique ID for every customer journey (String, Primary Key).
        - LOYALTY_ID: Hashed Nectar ID to identify a customer with a Nectar card (String).
        - BOOKING_ID: UUID to identify campaigns that can be run together (String, Primary Key).
        - CUSTOMER_JOURNEY_TYPE: Specifies whether the journey is Direct/Non-Direct (String).
        - JOURNEY_TYPE: Specifies whether the SKU belongs to Offer, Brand, or Aisle (String).
        - ISCONVERSION: Specifies purchase/non-purchase label (Integer).
        - NORMALIZED_WEIGHTS: Attribution weights for each regression variable (Float).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        - EVENT_DT: Date of the transaction and opportunity to see the campaign (Date).
        - ITEM_CD: SKU number (Decimal, precision 18, scale 5, Primary Key).
        - NET_SALES_AMT: Actual sales value for the item purchased (Decimal, precision 30, scale 4).
        - UNITS_QTY: Actual units purchased (Decimal, precision 30, scale 4).
        - UNIQUE_BRAND_NAME: Name of the brand (String).
        - WEEK_START_DT: Week start date of the event (String).
        - REGRESSION_VARIABLE: Concatenated campaign, channel,
                            and subchannel value (String, Primary Key).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String).
        - ATTRIBUTED_SALES_AMT: Attributed sales amount (Float).
        - ATTRIBUTED_UNITS_QTY: Attributed units quantity (Float).
        - ATTRIBUTED_RECALIBERATED_SALES_AMT: Attributed sales refactored for
                                            offsite channels only (Float).
        - ATTRIBUTED_RECALIBERATED_UNITS_QTY: Attributed units refactored for
                                            offsite channels only (Float).
        - JOB_RUN_ID: Job run ID associated with this job (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - MARKETING_TYPE: Marketing type of the campaign (String).
        - RECALIBERATION_FACTOR: Recalibration factor for attribution (Float).
        """
        return T.StructType(
            [
                T.StructField("CAMPAIGN_ID", T.StringType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), True),
                T.StructField("USERJOURNEY_ID", T.StringType(), False),
                T.StructField("LOYALTY_ID", T.StringType(), True),
                T.StructField("BOOKING_ID", T.StringType(), False),
                T.StructField("CUSTOMER_JOURNEY_TYPE", T.StringType(), True),
                T.StructField("JOURNEY_TYPE", T.StringType(), True),
                T.StructField("ISCONVERSION", T.IntegerType(), True),
                T.StructField("NORMALIZED_WEIGHTS", T.FloatType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("EVENT_DT", T.DateType(), True),
                T.StructField("ITEM_CD", T.DecimalType(18, 5), False),
                T.StructField("NET_SALES_AMT", T.DecimalType(30, 4), True),
                T.StructField("UNITS_QTY", T.DecimalType(30, 4), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("WEEK_START_DT", T.StringType(), True),
                T.StructField("REGRESSION_VARIABLE", T.StringType(), False),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("ATTRIBUTED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_UNITS_QTY", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_UNITS_QTY", T.FloatType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
                T.StructField("MARKETING_TYPE", T.StringType(), True),
            ]
        )

    def adw_unified_platform_tactical_measurement_campaign_execution(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_EXECUTION table.

        This table contains details of the campaigns that need to be executed.

        Columns:
        - CAMPAIGN_ID: Unique identifier for a campaign across
                    different channel tables (String, Primary Key).
        - BOOKING_ID: ID assigned to campaigns targeting the
                    same SKUs within the same timeframe (String).
        - JOB_BAG_NUMBER: Identifier for the campaign in the
                        base table (String, Primary Key).
        - MARKETING_TYPE: Type of marketing campaign (String).
        - CHANNEL_NAME: Media channel where the campaign was run (String, Primary Key).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String).
        - CAMPAIGN_NAME: Name of the campaign (String).
        - CAMPAIGN_START_DT: Start date of the campaign (Date, Primary Key).
        - CAMPAIGN_END_DT: End date of the campaign (Date, Primary Key).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        - JOB_STATUS: Status of the job (String).
        - LOAD_TS: Timestamp of when the record was loaded (Timestamp).
        """
        return T.StructType(
            [
                T.StructField("CAMPAIGN_ID", T.StringType(), False),
                T.StructField("BOOKING_ID", T.StringType(), True),
                T.StructField("JOB_BAG_NUMBER", T.StringType(), False),
                T.StructField("MARKETING_TYPE", T.StringType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), False),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("CAMPAIGN_NAME", T.StringType(), True),
                T.StructField("CAMPAIGN_START_DT", T.DateType(), False),
                T.StructField("CAMPAIGN_END_DT", T.DateType(), False),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("JOB_STATUS", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
            ]
        )

    def adw_unified_platform_tactical_baseline_attribution_integration_sku_level(
        self,
    ) -> T.StructType:
        """
        Returns the schema for the
        UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL
        table.

        This table contains baseline and attribution-integrated results.

        Columns:
        - USERJOURNEY_ID: Unique ID for each customer journey (String, Primary Key).
        - BOOKING_ID: UUID to identify campaigns run together (String, Primary Key).
        - REGRESSION_VARIABLE: Concatenated campaign, channel, and subchannel value
                            (String, Primary Key).
        - ITEM_CD: SKU number (Integer, Primary Key).
        - CAMPAIGN_ID: Identifier for a campaign across different channels (String).
        - LOYALTY_ID: Hashed Nectar ID for identifying a customer (String).
        - CUSTOMER_JOURNEY_TYPE: Specifies whether the journey is Direct/Non-Direct (String).
        - JOURNEY_TYPE: Specifies whether the SKU belongs to Offer, Brand, or Aisle (String).
        - ISCONVERSION: Purchase/non-purchase label (Integer).
        - NORMALIZED_WEIGHTS: Attribution weights for each regression variable (Float).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        - EVENT_DT: Date of transaction and opportunity to see the campaign (Date).
        - NET_SALES_AMT: Actual sales value for the item purchased (Decimal).
        - UNITS_QTY: Actual units purchased (Decimal).
        - ATTRIBUTED_SALES_AMT: Attributed sales amount (Float).
        - ATTRIBUTED_UNITS_QTY: Attributed units quantity (Float).
        - FREQUENCY_OF_PURCHASE: Frequency of purchase (Integer).
        - ONLINE_SALES_PCT: Online sales percentage (Decimal).
        - SUPERMARKET_SALES_PCT: Supermarket sales percentage (Decimal).
        - CONVENIENCE_SALES_PCT: Convenience sales percentage (Decimal).
        - JOB_RUN_ID: Job run ID associated with this job (String).
        - SUM_BASELINE_AMT: Sum of baseline amount (Float).
        - SUM_OF_SALES_AMT: Sum of sales amount (Decimal).
        - SUM_OF_ATTR_SALES_AMT: Sum of attributed sales amount (Float).
        - SUM_OF_INCR_AMT: Sum of incremental amount (Float).
        - CHANNEL_NAME: Media channel where the campaign was run (String).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String).
        - LOAD_TS: Timestamp of when the record was loaded (Timestamp).
        - WEEK_START_DT: Week start date of the event date (Date).
        - INCREMENTALITY_TOTAL: Incrementality total proportion (Float).
        - INCREMENTALITY_EXPOSED: Incrementality exposed proportion (Float).
        - ATTRIBUTED_RECALIBERATED_SALES_AMT: Recalibrated sales amount (Float).
        - ATTRIBUTED_RECALIBERATED_UNITS_QTY: Recalibrated unit quantity (Float).
        - UNIQUE_BRAND_NAME: Unique brand name (String).
        - BASELINE: Default baseline value (Float).
        - MARKETING_TYPE: Marketing type of the campaign (String).
        - TOTAL_SALES_AMT: Total sales amount of the campaign (Decimal).
        - INCREMENTAL_SALES_AMT_EXPOSED: Incremental sales amount exposed (Decimal).
        - INCREMENTAL_SALES_AMT_TOTAL: Total incremental sales amount (Decimal).
        - INCREMENTAL_UNITS_QTY_TOTAL: Total incremental unit quantity (Float).
        - INCREMENTAL_UNITS_QTY_EXPOSED: Exposed incremental unit quantity (Float).
        - RECALIBERATION_FACTOR: Recalibration factor for the campaign (Float).
        """
        return T.StructType(
            [
                T.StructField("CAMPAIGN_ID", T.StringType(), True),
                T.StructField("USERJOURNEY_ID", T.StringType(), False),
                T.StructField("LOYALTY_ID", T.StringType(), True),
                T.StructField("BOOKING_ID", T.StringType(), False),
                T.StructField("CUSTOMER_JOURNEY_TYPE", T.StringType(), True),
                T.StructField("JOURNEY_TYPE", T.StringType(), True),
                T.StructField("ISCONVERSION", T.IntegerType(), True),
                T.StructField("NORMALIZED_WEIGHTS", T.FloatType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("EVENT_DT", T.DateType(), True),
                T.StructField("NET_SALES_AMT", T.DecimalType(30, 4), True),
                T.StructField("UNITS_QTY", T.DecimalType(30, 4), True),
                T.StructField("REGRESSION_VARIABLE", T.StringType(), False),
                T.StructField("ATTRIBUTED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_UNITS_QTY", T.FloatType(), True),
                T.StructField("FREQUENCY_OF_PURCHASE", T.IntegerType(), True),
                T.StructField("ONLINE_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("SUPERMARKET_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("CONVENIENCE_SALES_PCT", T.DecimalType(38, 10), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("SUM_BASELINE_AMT", T.FloatType(), True),
                T.StructField("SUM_OF_SALES_AMT", T.DecimalType(38, 4), True),
                T.StructField("SUM_OF_ATTR_SALES_AMT", T.FloatType(), True),
                T.StructField("SUM_OF_INCR_AMT", T.FloatType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), True),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
                T.StructField("WEEK_START_DT", T.DateType(), True),
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("INCREMENTALITY_TOTAL", T.FloatType(), True),
                T.StructField("INCREMENTALITY_EXPOSED", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_UNITS_QTY", T.FloatType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("BASELINE", T.FloatType(), True),
                T.StructField("MARKETING_TYPE", T.StringType(), True),
                T.StructField("TOTAL_SALES_AMT", T.DecimalType(38, 4), True),
                T.StructField("INCREMENTAL_SALES_AMT_EXPOSED", T.FloatType(), True),
                T.StructField("INCREMENTAL_SALES_AMT_TOTAL", T.FloatType(), True),
                T.StructField("INCREMENTAL_UNITS_QTY_TOTAL", T.FloatType(), True),
                T.StructField("INCREMENTAL_UNITS_QTY_EXPOSED", T.FloatType(), True),
                T.StructField("RECALIBERATION_FACTOR", T.FloatType(), True),
            ]
        )

    def adw_dev_adw_unified_platform_tactical_unified_product(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.UNIFIED_PRODUCT table.

        This table contains detailed information about each
        SKU, including codes, names, categories, weights, prices, and other attributes.

        Columns:
        - ITEM_CD: Unique identifier for each item (Number, Primary Key).
        - ITEM_NAME: Name of the item (String).
        - SEGMENT_NAME: The segment in which the item is categorized (String).
        - SUB_CAT_NAME: The sub-category of the item (String).
        - CAT_NAME: The category to which the item belongs (String).
        - SUPER_CAT_NAME: The super-category of the item (String).
        - ITEM_WEIGHT_OR_VOL_UOM_CD: Unit of measure code for item weight or volume (String).
        - UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY: Weight or volume quantity of the item (Decimal).
        - ITEM_TOTAL_WEIGHT_OR_VOL_QTY: Total weight or volume quantity of the item (Decimal).
        - BASE_PRICE_AMT: Base price amount of the item (Decimal).
        - STD_ITEM_WGT_OR_VOL_QTY_UOM_CD: Standard unit of measure code for item weight
                                        or volume quantity (String).
        - STD_ITEM_TOTAL_WGT_OR_VOL_QTY: Standard total weight or volume quantity of the item
                                        (Decimal).
        - UNIQUE_BRAND_NAME: The unique brand of the item (String).
        - LOAD_TS: Date/time on which the record was loaded (Timestamp).
        - JOB_RUN_ID: Job run ID associated with this job (String).
        - RAW_UNIQUE_BRAND_NAME: Raw unique brand name (String).
        """
        return T.StructType(
            [
                T.StructField("ITEM_CD", T.IntegerType(), False),
                T.StructField("ITEM_NAME", T.StringType(), True),
                T.StructField("SEGMENT_NAME", T.StringType(), True),
                T.StructField("SUB_CAT_NAME", T.StringType(), True),
                T.StructField("CAT_NAME", T.StringType(), True),
                T.StructField("SUPER_CAT_NAME", T.StringType(), False),
                T.StructField("ITEM_WEIGHT_OR_VOL_UOM_CD", T.StringType(), True),
                T.StructField("UNIT_OR_ITEM_WEIGHT_OR_VOL_QTY", T.StringType(), True),
                T.StructField("ITEM_TOTAL_WEIGHT_OR_VOL_QTY", T.StringType(), True),
                T.StructField("BASE_PRICE_AMT", T.StringType(), True),
                T.StructField("STD_ITEM_WGT_OR_VOL_QTY_UOM_CD", T.StringType(), True),
                T.StructField("STD_ITEM_TOTAL_WGT_OR_VOL_QTY", T.StringType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), False),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("JOB_RUN_ID", T.StringType(), False),
                T.StructField("RAW_UNIQUE_BRAND_NAME", T.StringType(), True),
            ]
        )

    def adw_unified_platform_tactical_attribution_model_results_offer(self) -> T.StructType:
        """
        Returns the schema for the
        UNIFIED_PLATFORM_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_MODEL_RESULTS_OFFER table.

        This schema defines the structure of attribution model results at the offer level.

        Columns:
        - USERJOURNEY_ID: Unique identifier for each customer journey (String, 1000).
        - LOYALTY_ID: Hashed Nectar ID identifying the customer (String, 1000).
        - TRANSACTION_KEY: Unique identifier for each transaction (String, 1000).
        - BOOKING_ID: UUID identifying campaigns that can be run together (String, 1000).
        - CUSTOMER_JOURNEY_TYPE: Specifies whether the journey is Direct/Non-Direct (String, 1000).
        - JOURNEY_TYPE: Specifies whether the SKU belongs to Offer, Brand, or Aisle for the campaign
          (String, 1000).
        - ISCONVERSION: Purchase (1) or non-purchase (0) label (Integer).
        - REGRESSION_VARIABLE: Concatenated campaign, channel, and subchannel value (String, 1000).
        - NORMALIZED_WEIGHTS: Attribution weights for each regression variable (Float).
        - CAMPAIGN_ID: Identifier for the campaign in different channel tables (String, 1000).
        - AVG_F1_SCORE: Average F1 score of the model (Float).
        - CAMPAIGN_DURATION: Duration of the campaign (String, 10).
        - JOB_RUN_ID: Identifier for the job execution (String, 100).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - CHANNEL_NAME: Specifies the campaign's channel (String, 1000).
        - SUBCHANNEL_NAME: Specifies the campaign's subchannel (String, 1000).
        - MARKETING_TYPE: Specifies the campaign's marketing type (String, 1000).
        """
        return T.StructType(
            [
                T.StructField("USERJOURNEY_ID", T.StringType()),
                T.StructField("LOYALTY_ID", T.StringType()),
                T.StructField("TRANSACTION_KEY", T.StringType()),
                T.StructField("BOOKING_ID", T.StringType()),
                T.StructField("CUSTOMER_JOURNEY_TYPE", T.StringType()),
                T.StructField("JOURNEY_TYPE", T.StringType()),
                T.StructField("ISCONVERSION", T.IntegerType()),
                T.StructField("REGRESSION_VARIABLE", T.StringType()),
                T.StructField("NORMALIZED_WEIGHTS", T.FloatType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("AVG_F1_SCORE", T.FloatType()),
                T.StructField("CAMPAIGN_DURATION", T.StringType()),
                T.StructField("JOB_RUN_ID", T.StringType()),
                T.StructField("LOAD_TS", T.TimestampType()),
                T.StructField("CHANNEL_NAME", T.StringType()),
                T.StructField("SUBCHANNEL_NAME", T.StringType()),
                T.StructField("MARKETING_TYPE", T.StringType()),
            ]
        )

    def adw_unified_platform_tactical_attribution_pre_requisite_offer(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_PRE_REQUISITE_OFFER table.

        This schema defines the structure of preprocessed data for attribution modeling.

        Columns:
        - LOYALTY_ID: Hashed nectar ID identifying the customer (String, 128).
        - CHANNEL_NAME: Media channel on which the campaign was run (String, 18).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String, 1000).
        - EVENT_TS: Timestamp of the event (Timestamp).
        - EVENT_NAME: Type of event (e.g., touchpoint or purchase transaction) (String, 20).
        - NET_SALES_AMT: Actual sales value for the item purchased (Decimal, 38, 4).
        - JOURNEY_TYPE: SKU category in the campaign (Offer, Brand, or Aisle) (String, 5).
        - TRANSACTION_KEY: Unique ID for each transaction (String, 250).
        - CAMPAIGN_ID: Identifier for the campaign (String, 1000).
        - BOOKING_ID: UUID to identify campaigns run together (String, 36).
        - POSITION: User journey type based on event name or rank (String, 9).
        - CAMPAIGN_DURATION: Duration of the campaign (String, 10).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - JOB_RUN_ID: Identifier for the job execution (String, 36).
        - USERJOURNEY_ID: Unique identifier for the customer journey (String, 1000).
        - REGRESSION_VARIABLE: Concatenated campaign, channel, marketing type,
          and subchannel (String, 1000).
        - CUSTOMER_JOURNEY_TYPE: Specifies whether the journey is Direct/Non-Direct (String, 100).
        - ISCONVERSION: Indicates if the journey resulted in a conversion (Integer, 1).
        - MARKETING_TYPE: Type of marketing campaign (String, 100).
        """
        return T.StructType(
            [
                T.StructField("LOYALTY_ID", T.StringType()),
                T.StructField("CHANNEL_NAME", T.StringType()),
                T.StructField("SUBCHANNEL_NAME", T.StringType()),
                T.StructField("EVENT_TS", T.TimestampType()),
                T.StructField("EVENT_NAME", T.StringType()),
                T.StructField("NET_SALES_AMT", T.DecimalType(38, 4)),
                T.StructField("JOURNEY_TYPE", T.StringType()),
                T.StructField("TRANSACTION_KEY", T.StringType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("BOOKING_ID", T.StringType()),
                T.StructField("POSITION", T.StringType()),
                T.StructField("CAMPAIGN_DURATION", T.StringType()),
                T.StructField("LOAD_TS", T.TimestampType()),
                T.StructField("JOB_RUN_ID", T.StringType()),
                T.StructField("USERJOURNEY_ID", T.StringType()),
                T.StructField("REGRESSION_VARIABLE", T.StringType()),
                T.StructField("CUSTOMER_JOURNEY_TYPE", T.StringType()),
                T.StructField("ISCONVERSION", T.IntegerType()),
                T.StructField("MARKETING_TYPE", T.StringType()),
            ]
        )

    def adw_unified_platform_tactical_customer_data_collection(self) -> T.StructType:
        """
        Returns the schema for the ADW_UNIFIED_PLATFORM_TACTICAL.CUSTOMER_DATA_COLLECTION table.

        This schema defines the structure of transaction and customer touchpoint data for campaigns.

        Columns:
        - LOYALTY_ID: Hashed nectar ID identifying the customer (String).
        - TRANSACTION_KEY: Unique ID for each transaction (String).
        - EVENT_DT: Date of transaction or campaign touchpoint (Date).
        - EVENT_TS: Timestamp of the event (Timestamp).
        - CHANNEL_NAME: Media channel on which the campaign was run (String).
        - SUBCHANNEL_NAME: Subchannel where the campaign was launched (String).
        - CAMPAIGN_NAME: Name of the campaign (String).
        - CAMPAIGN_ID: Identifier for the campaign (String).
        - EVENT_NAME: Type of event (e.g., touchpoint or purchase transaction) (String).
        - BOOKING_ID: UUID to identify campaigns run together (String).
        - ITEM_CD: SKU of the purchased campaign item (Decimal, 18, 5).
        - PRODUCT_TYPE: Specifies whether the SKU belongs to Offer, Brand, or Aisle (String).
        - NET_SALES_AMT: Actual sales value for the item purchased (Decimal, 30, 4).
        - UNITS_QTY: Actual quantity of the purchased item (Decimal, 30, 4).
        - JOB_RUN_ID: Identifier for the job execution (String).
        - UNIQUE_BRAND_NAME: Unique brand name associated with the item (String).
        - MARKETING_TYPE: Type of marketing campaign (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        """
        return T.StructType(
            [
                T.StructField("LOYALTY_ID", T.StringType()),
                T.StructField("TRANSACTION_KEY", T.StringType()),
                T.StructField("EVENT_DT", T.DateType()),
                T.StructField("EVENT_TS", T.TimestampType()),
                T.StructField("CHANNEL_NAME", T.StringType()),
                T.StructField("SUBCHANNEL_NAME", T.StringType()),
                T.StructField("CAMPAIGN_NAME", T.StringType()),
                T.StructField("CAMPAIGN_ID", T.StringType()),
                T.StructField("EVENT_NAME", T.StringType()),
                T.StructField("BOOKING_ID", T.StringType()),
                T.StructField("ITEM_CD", T.DecimalType(18, 5)),
                T.StructField("PRODUCT_TYPE", T.StringType()),
                T.StructField("NET_SALES_AMT", T.DecimalType(30, 4)),
                T.StructField("UNITS_QTY", T.DecimalType(30, 4)),
                T.StructField("JOB_RUN_ID", T.StringType()),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType()),
                T.StructField("MARKETING_TYPE", T.StringType()),
                T.StructField("LOAD_TS", T.TimestampType()),
            ]
        )

    def adw_dev_adw_unified_platform_tactical_measurement_campaign_reporting(self) -> T.StructType:
        """
        Returns the schema for the
        ADW_DEV.ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_REPORTING table.

        This schema defines the structure of the measurement and campaign reporting metrics,
        including various sales, conversions, and marketing data.

        Columns:
        - BOOKING_ID: Unique identifier for a booking related to the campaign (String, 16777216).
        - CAMPAIGN_ID: Unique identifier for a campaign (String, 16777216).
        - UNIQUE_BRAND_NAME: Name of the unique brand associated with the campaign (String, 1000).
        - CAMPAIGN_DURATION: Duration of the campaign (String, 16777216).
        - JOURNEY_TYPE: Type of journey the customer took (String, 16777216).
        - MARKETING_TYPE: Type of marketing campaign (String, 1000).
        - CHANNEL_NAME: Name of the channel where the campaign ran (String, 16777216).
        - SUBCHANNEL_NAME: Specific subchannel within the main channel (String, 16777216).
        - SUB_CATEGORY_NAME: Name of the subcategory for the product (String, 1000).
        - CONVERSIONS: Number of conversions achieved (Float).
        - INCREMENTAL_SALES_AMT_TOTAL: Total incremental sales amount (Decimal, 38, 4).
        - MEDIA_SPEND_AMT: Amount spent on media (Decimal, 38, 2).
        - BASE_SALES_AMT_TOTAL: Total base sales amount (Float).
        - CAMPAIGN_START_DT: Start date of the campaign (Date).
        - CAMPAIGN_END_DT: End date of the campaign (Date).
        - CAMPAIGN_NAME: Name of the campaign (String, 1000).
        - ATTRIBUTED_RECALIBERATED_SALES_AMT: Recalibrated attributed sales amount (Float).
        - ATTRIBUTED_RECALIBERATED_UNITS_QTY: Recalibrated attributed units quantity (Float).
        - INCREMENTAL_UNITS_QTY_TOTAL: Total incremental units quantity (Float).
        - CONVERSIONS_RECALIBERATED: Recalibrated conversions (Float).
        - RECALIBERATION_FACTOR: Factor for recalibration (Float).
        - ROAS_TOTAL: Return on advertising spend (Decimal, 38, 10).
        - JOB_RUN_ID: Identifier for the job execution (String, 36).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        - JOB_BAG_NUMBER: Unique identifier for the job bag (String, 1000).
        - SUPER_CATEGORY_NAME: Name of the super category (String, 1000).
        - CAMPAIGN_TYPE: Type of campaign (String, 14).
        - ATTRIBUTED_SALES_AMT: Attributed sales amount (Float).
        - ATTRIBUTED_UNITS_QTY: Attributed units quantity (Float).
        - INCREMENTAL_SALES_AMT_EXPOSED: Exposed incremental sales amount (Decimal, 38, 4).
        - BASE_SALES_AMT_EXPOSED: Exposed base sales amount (Float).
        - ROAS_EXPOSED: Exposed return on advertising spend (Decimal, 38, 10).
        - INCREMENTAL_UNITS_QTY_EXPOSED: Exposed incremental units quantity (Float).
        - IROAS_TOTAL: Incremental return on advertising spend total (Decimal, 38, 10).
        - IROAS_EXPOSED: Exposed incremental return on advertising spend (Decimal, 38, 10).
        - CONVERSION_RATE: Conversion rate (Float).
        - UPLIFT_TOTAL: Total uplift (Float).
        - UPLIFT_EXPOSED: Exposed uplift (Float).
        """
        return T.StructType(
            [
                T.StructField("BOOKING_ID", T.StringType(), True),
                T.StructField("CAMPAIGN_ID", T.StringType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("JOURNEY_TYPE", T.StringType(), True),
                T.StructField("MARKETING_TYPE", T.StringType(), True),
                T.StructField("CHANNEL_NAME", T.StringType(), True),
                T.StructField("SUBCHANNEL_NAME", T.StringType(), True),
                T.StructField("SUB_CATEGORY_NAME", T.StringType(), True),
                T.StructField("CONVERSIONS", T.FloatType(), True),
                T.StructField("INCREMENTAL_SALES_AMT_TOTAL", T.DecimalType(38, 4), True),
                T.StructField("MEDIA_SPEND_AMT", T.DecimalType(38, 2), True),
                T.StructField("BASE_SALES_AMT_TOTAL", T.FloatType(), True),
                T.StructField("CAMPAIGN_START_DT", T.DateType(), True),
                T.StructField("CAMPAIGN_END_DT", T.DateType(), True),
                T.StructField("CAMPAIGN_NAME", T.StringType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_RECALIBERATED_UNITS_QTY", T.FloatType(), True),
                T.StructField("INCREMENTAL_UNITS_QTY_TOTAL", T.FloatType(), True),
                T.StructField("CONVERSIONS_RECALIBERATED", T.FloatType(), True),
                T.StructField("RECALIBERATION_FACTOR", T.FloatType(), True),
                T.StructField("ROAS_TOTAL", T.DecimalType(38, 10), True),
                T.StructField("JOB_RUN_ID", T.StringType(), False),
                T.StructField("LOAD_TS", T.TimestampType(), False),
                T.StructField("JOB_BAG_NUMBER", T.StringType(), True),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
                T.StructField("CAMPAIGN_TYPE", T.StringType(), True),
                T.StructField("ATTRIBUTED_SALES_AMT", T.FloatType(), True),
                T.StructField("ATTRIBUTED_UNITS_QTY", T.FloatType(), True),
                T.StructField("INCREMENTAL_SALES_AMT_EXPOSED", T.DecimalType(38, 4), True),
                T.StructField("BASE_SALES_AMT_EXPOSED", T.FloatType(), True),
                T.StructField("ROAS_EXPOSED", T.DecimalType(38, 10), True),
                T.StructField("INCREMENTAL_UNITS_QTY_EXPOSED", T.FloatType(), True),
                T.StructField("IROAS_TOTAL", T.DecimalType(38, 10), True),
                T.StructField("IROAS_EXPOSED", T.DecimalType(38, 10), True),
                T.StructField("CONVERSION_RATE", T.FloatType(), False),
                T.StructField("UPLIFT_TOTAL", T.FloatType(), True),
                T.StructField("UPLIFT_EXPOSED", T.FloatType(), True),
            ]
        )

    def adw_dev_adw_unified_platform_tactical_error_log_table(self) -> T.StructType:
        """
        Returns the schema for the error log table.

        Columns:
        - PIPELINE: Name of the pipeline (String).
        - MODULE_NAME: Name of the module where the error occurred (String).
        - BOOKING_ID: Unique identifier for a booking (String).
        - CAMPAIGN_DURATION: Duration of the campaign (String).
        - UNIQUE_BRAND_NAME: Name of the unique brand (String).
        - SUPER_CATEGORY_NAME: Name of the super category (String).
        - CLUSTER_NUM: Cluster number (String).
        - STATUS: Status of the process (String).
        - ERROR_TYPE: Type of the error (String).
        - ERROR_MESSAGE: Error message (String).
        - ERROR_TRACEBACK: Traceback of the error (String).
        - JOB_RUN_ID: Identifier for the job execution (String).
        - LOAD_TS: Timestamp when the record was loaded (Timestamp).
        """
        return T.StructType(
            [
                T.StructField("PIPELINE", T.StringType(), True),
                T.StructField("MODULE_NAME", T.StringType(), True),
                T.StructField("BOOKING_ID", T.StringType(), True),
                T.StructField("CAMPAIGN_DURATION", T.StringType(), True),
                T.StructField("UNIQUE_BRAND_NAME", T.StringType(), True),
                T.StructField("SUPER_CATEGORY_NAME", T.StringType(), True),
                T.StructField("CLUSTER_NUM", T.StringType(), True),
                T.StructField("STATUS", T.StringType(), True),
                T.StructField("ERROR_TYPE", T.StringType(), True),
                T.StructField("ERROR_MESSAGE", T.StringType(), True),
                T.StructField("ERROR_TRACEBACK", T.StringType(), True),
                T.StructField("JOB_RUN_ID", T.StringType(), True),
                T.StructField("LOAD_TS", T.TimestampType(), True),
            ]
        )
