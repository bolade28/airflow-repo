import os

import pandas as pd
import snowflake.snowpark as snowpark
from snowflake.snowpark import Session
from snowflake.snowpark.types import (DecimalType, FloatType, StringType,
                                      StructField, StructType)

from python_tests.test_utils.schemas import Schema


def create_snowflake_session(session_type: str = "live"):
    """
    Creates a Snowflake session based on the specified session type.

    This function initializes a Snowflake session either
    for local testing (mock session) or for connecting to a
    real Snowflake database using environment variables.

    Args:
        session_type (str):
            - "test" (default): Creates a local testing session that does not require credentials.
            - "live" or any other value: Establishes a real Snowflake session using
              credentials from environment variables.

    Returns:
        Session: A Snowflake session object.

    Raises:
        ValueError: If required environment variables are missing when creating a real session.
    """
    connection_parameters = {
        "account": os.getenv("SF_ACCOUNT"),
        "user": os.getenv("SF_USER"),
        "password": os.getenv("SF_PASSWORD"),
        "authenticator": os.getenv("SF_AUTHENTICATOR"),
        "role": os.getenv("SF_ROLE"),
        "warehouse": os.getenv("SF_WAREHOUSE"),
        "database": os.getenv("SF_DATABASE"),
        "schema": os.getenv("SF_SCHEMA"),
    }

    if session_type == "test":
        return Session.builder.config("local_testing", True).create()
    else:
        # Validate all required environment variables are set
        # for key, value in connection_parameters.items():
        #     if value is None:
        #         raise ValueError(f"Missing environment variable: {key}")

        return Session.builder.configs(connection_parameters).create()


def get_data_from_file(files: list[str]) -> pd.DataFrame:
    """
    Reads data from a list of csv or json files and returns the first valid Pandas DataFrame.

    This function iterates through the provided list of file paths,
    checking if each file exists and contains data. It supports:
    - **CSV files**: Reads using `pd.read_csv()`, replacing missing values with "NA".
    - **JSON files**: Reads using `pd.read_json()`, assuming standard JSON format.
    - **Empty files**: Returns an empty DataFrame.
    - **Unsupported file types**: Raises a `ValueError`.

    Args:
        files (list[str]): A list of file paths to check and load.

    Returns:
        pd.DataFrame:
            - A DataFrame containing data from the first valid CSV or JSON file.
            - An empty DataFrame if all files are empty or do not exist.

    Raises:
        ValueError: If a file is not a CSV or JSON.
    """
    for mock_file in files:

        if os.path.isfile(mock_file):
            if mock_file.endswith(".csv") and os.path.getsize(mock_file) > 0:
                df_pandas = pd.read_csv(mock_file, sep=",", keep_default_na=True, quotechar='"')
                df_pandas = df_pandas.fillna("NA")
                df_pandas = df_pandas.map(lambda x: pd.to_datetime(x).to_pydatetime() if isinstance(x, pd.Timestamp) else x)
                return df_pandas
            elif mock_file.endswith(".json") and os.path.getsize(mock_file) > 0:
                df_pandas = pd.read_json(mock_file, lines=False)
                return df_pandas
            elif os.path.getsize(mock_file) == 0:
                df_pandas = pd.DataFrame()
                return df_pandas
            else:
                raise ValueError(f"Unsupported file type: {mock_file}")

    return pd.DataFrame()


class MockDbt:
    """
    This is a utility class for pytest that mocks a dbt (data build tool) object.

    This class is designed to simulate dbt's behavior for testing purposes.
    It provides mocked implementations of `config`, `source`, `ref` and `this` functions.
    The class can handle input data from CSV and JSON files or read from a manually passed-in
    dictionary of test data when using the ref or source function.

    Attributes:
        this (MockThis): A mock object representing `this` in dbt.
        dir (str): The directory path where test data files are stored.
        _session (snowpark.Session): A Snowpark session for creating DataFrames.
        schema (Schema): A schema object used to retrieve table structures.
        config (MockConfig): A mock object representing dbt's configuration settings.
        manually_passed_in_test_data (dict): A dictionary of manually provided test data.
    """

    def __init__(self, dir, session: snowpark.Session, manually_passed_in_test_data=None):
        self.this = MockThis()
        self.dir = dir
        self._session = session
        self.schema = Schema()
        self.config = MockConfig()

        if manually_passed_in_test_data is not None:
            self.manually_passed_in_test_data = manually_passed_in_test_data
        else:
            self.manually_passed_in_test_data = {}

    def read_data(
        self,
        files: list[str],
        schema_reference: str,
        call_type: str,
        manual_data_input: bool = False,
    ) -> snowpark.dataframe.DataFrame:

        """
        Reads data from CSV/JSON files or manually passed-in test data and
        returns a Snowpark DataFrame.

        Args:
            files (list[str]): A list of file paths to read data from.
            schema_reference (str): The schema to use for the test input.
            call_type (str): The type of function calling this method (e.g., "ref" or "source").
            manual_data_input (bool, optional): If True, reads data from the
            manually passed-in dictionary.

        Returns:
            snowpark.dataframe.DataFrame: A Snowpark DataFrame containing the input data.

        Raises:
            ValueError: If an unexpected error occurs while retrieving the schema
            or processing data.
        """
        if manual_data_input:
            data = self.manually_passed_in_test_data[schema_reference]
            # If no data is found return an empty Dataframe
            if data is None:
                return self._session.create_dataframe(
                    [], schema=StructType([StructField("TEST", StringType())])
                )
            # Package the data up to be converted into a Dataframe later
            if self.is_single_list(data):
                input_data = [] if len(data) == 0 else [tuple(data)]
            else:
                input_data = [
                    tuple(row) for row in self.manually_passed_in_test_data[schema_reference]
                ]
        else:
            df_pandas = get_data_from_file(files)
            input_data = list(df_pandas.itertuples(index=False, name=None))
        try:
            # If the schema_reference does not exist inside of schema this will throw an error
            table_schema = self.schema.get_schema(schema_reference)
            # Create Snowpark DataFrame
            if len(input_data) == 0:
                if table_schema is None:
                    table_schema = StructType([StructField("DEFAULT_COLUMN", StringType())])
                df = self._session.create_dataframe([], schema=table_schema)
            else:
                df = self._session.create_dataframe(
                    convert_data_to_python_typing(input_data, table_schema), schema=table_schema
                )
            return df

        except Exception as e:
            raise ValueError(f"Unexpected {call_type} call: {e}") from e

    def check_if_manual_data_was_passed_in(self, model_name: str) -> bool:
        """
        Checks whether manual test data was provided for a given dbt model.

        Args:
            model_name (str): The name of the dbt model.

        Returns:
            bool: True if manual test data was provided, otherwise False.
        """
        return (
            self.manually_passed_in_test_data is not None and model_name in self.manually_passed_in_test_data
        )

    def is_single_list(self, list_obj):
        """
         Utility function to check if the input is a list of items or a list of lists.

        This function provides flexibility in how users define dictionaries for test data.
        It checks if the provided object is a list and ensures that none of the items within
        the list are themselves lists. This allows users to pass either a single list or
        a list of items where each item is not a list.

        Args:
            list_obj (object): The list of items or lists to check

        Returns:
            bool: True if `list_obj` is a list and contains no nested lists,
                  False if it's not a list or contains nested lists.
        """
        return isinstance(list_obj, list) and all(not isinstance(i, list) for i in list_obj)

    def ref(self, model_name):
        """
        Mocks the dbt `ref` function by fetching data from a file or manually passed-in test data.

        Args:
            model_name (str): The name of the dbt model being referenced.

        Returns:
            snowpark.dataframe.DataFrame: A DataFrame containing the reference data.
        """
        print(f"Ref: {model_name}")

        if self.check_if_manual_data_was_passed_in(model_name):
            return self.read_data([], model_name, "ref", True)

        file = os.path.join(self.dir, f"{model_name}.csv")
        file_2 = os.path.join(self.dir, f"{model_name}.json")
        return self.read_data([file, file_2], model_name, "ref", False)

    def source(self, schema, table_name):
        """
        Mocks the dbt `source` function by fetching data from a file.

        Args:
            schema (str): The schema name.
            table_name (str): The table name.

        Returns:
            snowpark.dataframe.DataFrame: A DataFrame containing the source data.
        """
        schema = f"{schema}_{table_name}"
        print(f"Source: {schema}")

        if self.check_if_manual_data_was_passed_in(schema):
            return self.read_data([], schema, "source", True)

        file = os.path.join(self.dir, f"{schema}.csv")
        file_2 = os.path.join(self.dir, f"{schema}.json")
        return self.read_data([file, file_2], schema, "source")


class MockConfig:
    def __init__(self):
        self._config = {}

    def update(self, **kwargs):
        self._config.update(kwargs)

    def get(self, key, default=None):
        return self._config.get(key, default)

    def __call__(self, **kwargs):
        """
        This is a mock function for pytest.

        We define it to be callable, but it intentionally does nothing
        because it serves as a placeholder for testing purposes.
        """
        pass


class MockThis:
    def __init__(self):
        self.database = None
        self.schema = None


def convert_data_to_floats(data, schema: StructType):
    # Get the indices of the columns that are of type FloatType or DecimalType
    float_columns = [
        index
        for index, field in enumerate(schema.fields)
        if isinstance(field.datatype, (FloatType, DecimalType))
    ]

    # Convert the data
    converted_data = []
    for row in data:
        converted_row = [
            (float(value) if idx in float_columns and value not in (None, "") else value)
            for idx, value in enumerate(row)
        ]
        converted_data.append(converted_row)

    return converted_data


def convert_data_to_python_typing(input_data, schema: StructType):
    """
    Convert specific columns in the data to Python-native types (string, float)
    based on the Snowpark schema. This prevents conversion errors when loading
    data into a Snowpark dataframe.

    Args:
        data (list[tuple]): The input data as a list of tuples (or rows).
        schema (StructType): The Snowpark schema defining the column data types.

    Returns:
        list[tuple]: The converted data, with StringType columns as Python strings
                    and FloatType/DecimalType columns as Python floats.
    """
    # Identify columns that are of type FloatType, DecimalType, or StringType in the schema
    float_columns = [
        index
        for index, field in enumerate(schema.fields)
        if isinstance(field.datatype, (FloatType, DecimalType))
    ]
    string_columns = [
        index for index, field in enumerate(schema.fields) if isinstance(field.datatype, StringType)
    ]

    # Prepare a list to store the converted data
    converted_data = []

    for row in input_data:
        converted_row = []
        # Iterate over each value in the row and convert based on its column type
        for idx, value in enumerate(row):
            # Convert to string if the column is of type StringType
            if idx in string_columns and value not in (None, ""):
                converted_row.append(str(value))
            # Convert to float if the column is of type FloatType or DecimalType
            elif idx in float_columns and value not in (None, ""):
                converted_row.append(float(value))
            else:
                # Leave the value unchanged if it is neither of the above
                converted_row.append(value)

        # Add the converted row to the list
        converted_data.append(tuple(converted_row))
    return converted_data
