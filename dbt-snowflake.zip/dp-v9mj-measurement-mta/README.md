# DP-V9MJ-MEASUREMENT-MTA

This project will collect customer touchpoints and run attribution/modelling for each successful campaign execution and to be evaluated

## 📝 User documentation

The full user guide can be found on the GitHub pages
[GRID DBT](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/about/)
<br>
[GRID DDL](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-ddl/about/)

## ✔️ Prerequisites

Before you get started, make sure you are ready to transform by checking our list of
[grid prerequisites](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/getting-started/1_pre_requisites/)

A useful guide for using Python virtual environments to run copier and dbt can be found under **'Local Setup📍'**
[here](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/getting-started/1_pre_requisites/)

## ❄️ Connecting to Snowflake

The guide on locally connecting to Snowflake through dbt can be found
[here](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/using-grid-dbt/3_connect_to_snowflake/)

If you are struggling to connect to Snowflake, a troubleshooting guide can be found at the link previously provided.

## 🧪 Build and Test with dbt

A quick guide on how to run models and tests in dbt can be found
[here](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/using-grid-dbt/4_run_dbt_locally/)

But for a comprehensive guide of dbt, please refer to the
[official dbt docs](https://docs.getdbt.com/reference/dbt-commands)

## 🚀 DBT Deployment

Before you deploy, make sure you are ready by checking our list of
[deployment prerequisites](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/getting-started/1_pre_requisites/)

Deployment is easy! For a quick explanation, see
[here](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/using-grid-dbt/5_deploy_using_grid_dbt/)

## 🚀 DDL Deployment

Managing Snowflake objects is easy with GRID DDL and SqlDBM.
Data model is managed in SqlDBM and GRID DDL then pulls the DDL for your objects from SqlDBM and deploys it to Snowflake.
See [here](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-ddl/about/)

## 🚧 Project Maintenance

This project uses copier, which allows automatic updates using the base template.
When a new release is made in the [template repo](https://github.com/brexville-tech/grid-pipeline-template)
run one of the following commands to perform an upgrade depending on your version
of copier (check your version with `copier --version`):

```shell
# copier version < 8.0.0
SKIP=no-commit-to-branch copier --vcs-ref <tag-to-update-to> update

# copier version >= 8.0.0
SKIP=no-commit-to-branch copier update --vcs-ref <tag-to-update-to> --UNSAFE
```

## ❓Grid Queries

Common questions and answers can be found
[grid-dbt](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-dbt/help-and-support/faqs/)
[grid-ddl](https://grid-user-guide.docs.aspire.js-devops.co.uk/latest/grid-ddl/help-and-support/faqs/)

For general queries, please use the Slack channel **_#data-grid-queries_**

## Building Docs Locally

```shell
# DBT Docs Generate and Serve
# This will generate the DBT documentation for the project and serve it locally
# Run at the root of the project
dbt docs generate --project-dir dp_v9mj_measurement_mta/transforms --profiles-dir . --target local --empty-catalog
dbt docs serve --project-dir dp_v9mj_measurement_mta/transforms --profiles-dir . --target local

# mkdocs Docs Generate and Serve
# This will generate the mkdocs documentation for the project and serve it locally
# Run at the root of the project
mkdocs build --config-file ./mkdocs.yml --site-dir ./site
mkdocs serve --config-file ./mkdocs.yml
```

## Project Documentation

The hosted project documentation can be found [here](https://urban-train-vmkpq9m.pages.github.io/)
