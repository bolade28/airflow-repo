#!/usr/bin/env bash
set -e -o pipefail

RED="\033[0;31m"
GREEN="\033[0;32m"
ORANGE="\033[0;33m"
BLUE="\033[0;34m"
CYAN="\033[0;36m"
YELLOW="\033[1;33m"
LIGHT_PURPLE="\033[1;34m"
END_COLOUR="\033[0m"

DV_DIRECTORY="dp_v9mj_measurement_mta_dv"
FED_DIRECTORY="dp_v9mj_measurement_mta_fed"
PL_DIRECTORY="dp_v9mj_measurement_mta_pl"

NEW_PROJECT_DIRECTORY="dp_v9mj_measurement_mta"
TEMP_DIRECTORY=temp

# MIGRATE EXISTING PIPELINE ASSETS TO NEW FOLDER

echo ""
echo -e "${ORANGE}--AUTO-MIGRATION STARTING--${END_COLOUR}"
echo ""
echo -e "${CYAN}This script will update the repo to use a single dbt project...${END_COLOUR}"
echo ""

migrate () {
  if [ -f "$TEMP_DIRECTORY"/"$1"/configs/ddl_config.yml ]; then
    echo "Copying $TEMP_DIRECTORY/$1/configs/ddl_config.yml to $NEW_PROJECT_DIRECTORY/configs/shared/ddl_config.yml"
    cat "$TEMP_DIRECTORY"/"$1"/configs/ddl_config.yml >> "$NEW_PROJECT_DIRECTORY"/configs/shared/ddl_config.yml && echo -e "${GREEN}copy passed${END_COLOUR}"
    echo "Deleting $TEMP_DIRECTORY/$1/configs/ddl_config.yml"
    rm -rf "$TEMP_DIRECTORY"/"$1"/configs/ddl_config.yml && echo -e "${GREEN}deleted temp ddl_config.yml${END_COLOUR}" || echo -e "${RED}failed to delete temp ddl_config.yml${END_COLOUR}"
  else
    echo "$TEMP_DIRECTORY/$1/configs/ddl_config.yml does not exist"
    echo -e "${BLUE}copy skipped${END_COLOUR}"
  fi
  echo ""

  echo "Copying grid-dbt configs from $TEMP_DIRECTORY/$1/configs to $NEW_PROJECT_DIRECTORY/configs/$2"
  cp "$TEMP_DIRECTORY"/"$1"/configs/* "$NEW_PROJECT_DIRECTORY"/configs/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
  echo ""

  echo "Deleting grid-dbt configs from $TEMP_DIRECTORY/$1/configs"
  rm -rf "$TEMP_DIRECTORY"/"$1"/configs && echo -e "${GREEN}deleted temp dbt configs${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt configs${END_COLOUR}"

  echo "Copying ddl folder from $TEMP_DIRECTORY/$1/ddl to $NEW_PROJECT_DIRECTORY/ddl/"
  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/ddl)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/ddl -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/ddl -type f)" == "$TEMP_DIRECTORY"/"$1"/ddl/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/ddl/ is empty. No copies to make..." && echo -e "${BLUE}copy skipped${END_COLOUR}"
      rm -rf "$TEMP_DIRECTORY"/"$1"/ddl && echo -e "${GREEN}deleted temp ddl files${END_COLOUR}" || echo -e "${RED}failed to delete temp ddl files${END_COLOUR}"
    else
      cp -r "$TEMP_DIRECTORY"/"$1"/ddl/** "$NEW_PROJECT_DIRECTORY"/ddl/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
      echo "Deleting grid-ddl files from $TEMP_DIRECTORY/$1/ddl"
      rm -rf "$TEMP_DIRECTORY"/"$1"/ddl && echo -e "${GREEN}deleted temp ddl files${END_COLOUR}" || echo -e "${RED}failed to delete temp ddl files${END_COLOUR}"
    fi
  fi
  echo ""

  echo "Copying dbt analyses from $TEMP_DIRECTORY/$1/transforms/analyses to $NEW_PROJECT_DIRECTORY/transforms/analyses/$2"
  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/transforms/analyses)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/analyses -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/analyses -type f)" == "$TEMP_DIRECTORY"/"$1"/transforms/analyses/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/transforms/analyses/ is empty. No copies to make..." && echo -e "${BLUE}copy skipped${END_COLOUR}"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/analyses && echo -e "${GREEN}deleted temp dbt analyses${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt analyses${END_COLOUR}"
    else
      cp -r "$TEMP_DIRECTORY"/"$1"/transforms/analyses/** "$NEW_PROJECT_DIRECTORY"/transforms/analyses/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
      echo "Deleting dbt analyses from $TEMP_DIRECTORY/$1/transforms/analyses"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/analyses && echo -e "${GREEN}deleted temp dbt analyses${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt analyses${END_COLOUR}"
    fi
  fi
  echo ""

  echo "Copying dbt macros from $TEMP_DIRECTORY/$1/transforms/macros to $NEW_PROJECT_DIRECTORY/transforms/macros"
  cp -r "$TEMP_DIRECTORY"/"$1"/transforms/macros/** "$NEW_PROJECT_DIRECTORY"/transforms/macros/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
  echo "Deleting dbt macros from $TEMP_DIRECTORY/$1/transforms/macros"
  rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/macros && echo -e "${GREEN}deleted temp dbt macros${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt macros${END_COLOUR}"
  echo ""

  echo "Copying dbt models from $TEMP_DIRECTORY/$1/transforms/models to $NEW_PROJECT_DIRECTORY/transforms/models/$2"
  rm -rf "$NEW_PROJECT_DIRECTORY"/transforms/models/"$2" && echo -e "${GREEN}deleted example models${END_COLOUR}" || echo -e "${RED}failed to delete example models${END_COLOUR}"
  cp -r "$TEMP_DIRECTORY"/"$1"/transforms/models "$NEW_PROJECT_DIRECTORY"/transforms/models/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
  echo "Deleting dbt models from $TEMP_DIRECTORY/$1/transforms/models"
  rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/models && echo -e "${GREEN}deleted temp dbt models${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt models${END_COLOUR}"
  echo ""

  echo "Copying dbt seeds from $TEMP_DIRECTORY/$1/transforms/seeds to $NEW_PROJECT_DIRECTORY/transforms/seeds/$2"
  rm -rf "$NEW_PROJECT_DIRECTORY"/transforms/seeds/"$2"/** && echo -e "${GREEN}deleted example seeds${END_COLOUR}" || echo -e "${RED}failed to delete example seeds${END_COLOUR}"
  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/transforms/seeds)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/seeds -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/seeds -type f)" == "$TEMP_DIRECTORY"/"$1"/transforms/seeds/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/transforms/seeds/ is empty. No copies to make..." && echo -e "${BLUE}copy skipped${END_COLOUR}"
      touch "$NEW_PROJECT_DIRECTORY"/transforms/seeds/"$2"/.gitkeep && echo -e "${LIGHT_PURPLE}created .gitkeep file${END_COLOUR}" || echo -e "${RED}failed to create .gitkeep file${END_COLOUR}"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/seeds && echo -e "${GREEN}deleted temp dbt seeds${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt seeds${END_COLOUR}"
    else
      cp -r "$TEMP_DIRECTORY"/"$1"/transforms/seeds/** "$NEW_PROJECT_DIRECTORY"/transforms/seeds/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
      echo "Deleting dbt seeds from $TEMP_DIRECTORY/$1/transforms/seeds"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/seeds && echo -e "${GREEN}deleted temp dbt seeds${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt seeds${END_COLOUR}"
    fi
  fi
  echo ""

  echo "Copying dbt snapshots from $TEMP_DIRECTORY/$1/transforms/snapshots to $NEW_PROJECT_DIRECTORY/transforms/snapshots/$2"
  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/transforms/snapshots)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/snapshots -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/snapshots -type f)" == "$TEMP_DIRECTORY"/"$1"/transforms/snapshots/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/transforms/snapshots/ is empty. No copies to make..." && echo -e "${BLUE}copy skipped${END_COLOUR}"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/snapshots && echo -e "${GREEN}deleted temp dbt snapshots${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt snapshots${END_COLOUR}"
    else
      cp -r "$TEMP_DIRECTORY"/"$1"/transforms/snapshots/** "$NEW_PROJECT_DIRECTORY"/transforms/snapshots/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
      echo "Deleting dbt snapshots from $TEMP_DIRECTORY/$1/transforms/snapshots"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/snapshots && echo -e "${GREEN}deleted temp dbt snapshots${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt snapshots${END_COLOUR}"
    fi
  fi
  echo ""

  echo "Copying dbt tests from $TEMP_DIRECTORY/$1/transforms/tests to $NEW_PROJECT_DIRECTORY/transforms/tests/$2"
  rm -rf "$NEW_PROJECT_DIRECTORY"/transforms/tests/"$2"/** && echo -e "${GREEN}deleted example tests${END_COLOUR}" || echo -e "${RED}failed to delete example tests${END_COLOUR}"
  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/transforms/tests)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/tests -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/transforms/tests -type f)" == "$TEMP_DIRECTORY"/"$1"/transforms/tests/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/transforms/tests/ is empty. No copies to make..." && echo -e "${BLUE}copy skipped${END_COLOUR}"
      touch "$NEW_PROJECT_DIRECTORY"/transforms/tests/"$2"/.gitkeep && echo -e "${LIGHT_PURPLE}created .gitkeep file${END_COLOUR}" || echo -e "${RED}failed to create .gitkeep file${END_COLOUR}"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/tests && echo -e "${GREEN}deleted temp dbt tests${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt tests${END_COLOUR}"
    else
      cp -r "$TEMP_DIRECTORY"/"$1"/transforms/tests/** "$NEW_PROJECT_DIRECTORY"/transforms/tests/"$2"/ && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
      echo "Deleting dbt tests from $TEMP_DIRECTORY/$1/transforms/tests"
      rm -rf "$TEMP_DIRECTORY"/"$1"/transforms/tests && echo -e "${GREEN}deleted temp dbt tests${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt tests${END_COLOUR}"
    fi
  fi
  echo ""

  echo "Creating $2__dbt_project.yml file in $NEW_PROJECT_DIRECTORY/transforms using dbt_project.yml file in $1"
  cp "$TEMP_DIRECTORY"/"$1"/transforms/dbt_project.yml "$NEW_PROJECT_DIRECTORY"/transforms/"$2"__dbt_project.yml && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
  echo "Deleting $TEMP_DIRECTORY/$1/transforms/dbt_project.yml"
  rm "$TEMP_DIRECTORY"/"$1"/transforms/dbt_project.yml && echo -e "${GREEN}deleted temp dbt_project.yml file${END_COLOUR}" || echo -e "${RED}failed to delete temp dbt_project.yml file${END_COLOUR}"
  echo ""

  echo "Creating $2__packages.yml file in $NEW_PROJECT_DIRECTORY/transforms using packages.yml file in $1"
  cp "$TEMP_DIRECTORY"/"$1"/transforms/packages.yml "$NEW_PROJECT_DIRECTORY"/transforms/"$2"__packages.yml && echo -e "${GREEN}copy passed${END_COLOUR}" || echo -e "${RED}copy failed${END_COLOUR}"
  echo "Deleting $TEMP_DIRECTORY/$1/transforms/packages.yml"
  rm "$TEMP_DIRECTORY"/"$1"/transforms/packages.yml && echo -e "${GREEN}deleted temp packages.yml file${END_COLOUR}" || echo -e "${RED}failed to delete temp packages.yml file${END_COLOUR}"
  echo ""

  if [ -n "$(ls -A "$TEMP_DIRECTORY"/"$1"/dq)" ]; then
    if [ "$(find "$TEMP_DIRECTORY"/"$1"/dq -type f | wc -l)" -eq "1" ] \
    && [ "$(find "$TEMP_DIRECTORY"/"$1"/dq -type f)" == "$TEMP_DIRECTORY"/"$1"/dq/.gitkeep ]; then
      echo "$TEMP_DIRECTORY/$1/dq/ is an unused folder that is being removed from the template repo in v3"
      rm -rf "$TEMP_DIRECTORY"/"$1"/dq && echo -e "${GREEN}deleted temp dq folder${END_COLOUR}" || echo -e "${RED}failed to delete temp dq folder${END_COLOUR}"
    fi
  fi
  echo ""
}

remove_empty_dir () {
  if [ -d "$1" ]; then
    echo -e "${CYAN}$1 folder exists${END_COLOUR}"
    if [ -z "$(ls -A "$1")" ]; then
      echo "Deleting $1 folder"
      rm -rf "$1" && echo -e "${GREEN}deletion passed${END_COLOUR}" || echo -e "${RED}deletion failed${END_COLOUR}"
    else
      echo -e "${CYAN} The $1 folder contains files that the template did not expect - please review them manually${END_COLOUR}"
    fi
  else
    echo "$1 does not exist" && echo -e "${BLUE}skipping deletion${END_COLOUR}"
  fi
  echo ""
}

if [ -d "$TEMP_DIRECTORY"/"$DV_DIRECTORY" ]; then
  echo -e "${ORANGE}--Migrating DV Folder--${END_COLOUR}"
  migrate "$DV_DIRECTORY" dv
  remove_empty_dir "$TEMP_DIRECTORY"/"$DV_DIRECTORY"/transforms
  remove_empty_dir "$TEMP_DIRECTORY"/"$DV_DIRECTORY"
fi

if [ -d "$TEMP_DIRECTORY"/"$FED_DIRECTORY" ]; then
  echo -e "${ORANGE}--Migrating FED Folder--${END_COLOUR}"
  migrate "$FED_DIRECTORY" fed
  remove_empty_dir "$TEMP_DIRECTORY"/"$FED_DIRECTORY"/transforms
  remove_empty_dir "$TEMP_DIRECTORY"/"$FED_DIRECTORY"
fi

if [ -d "$TEMP_DIRECTORY"/"$PL_DIRECTORY" ]; then
  echo -e "${ORANGE}--Migrating PL Folder--${END_COLOUR}"
  migrate "$PL_DIRECTORY" pl
  remove_empty_dir "$TEMP_DIRECTORY"/"$PL_DIRECTORY"/transforms
  remove_empty_dir "$TEMP_DIRECTORY"/"$PL_DIRECTORY"
fi

# REMOVE REDUNDANT FOLDERS

echo -e "${ORANGE}--AUTO-MIGRATION CLEAN-UP--${END_COLOUR}"
echo ""
echo -e "${CYAN}Removing redundant folders and files from repo...${END_COLOUR}"
echo ""

if [ -d "$TEMP_DIRECTORY" ]; then
  remove_empty_dir "$TEMP_DIRECTORY"
fi

if [ -d "$DV_DIRECTORY" ]; then
  echo "Deleting $DV_DIRECTORY folder"
  rm -rf "$DV_DIRECTORY" && echo -e "${GREEN}deletion passed${END_COLOUR}" || echo -e "${RED}deletion failed${END_COLOUR}"
  echo ""
fi

if [ -d "$FED_DIRECTORY" ]; then
  echo "Deleting $FED_DIRECTORY folder"
  rm -rf "$FED_DIRECTORY" && echo -e "${GREEN}deletion passed${END_COLOUR}" || echo -e "${RED}deletion failed${END_COLOUR}"
  echo ""
fi

if [ -d "$PL_DIRECTORY" ]; then
  echo "Deleting $PL_DIRECTORY folder"
  rm -rf "$PL_DIRECTORY" && echo -e "${GREEN}deletion passed${END_COLOUR}" || echo -e "${RED}deletion failed${END_COLOUR}"
  echo ""
fi

# ACTION FOR USERS

echo -e "${ORANGE}--AUTO-MIGRATION COMPLETED--${END_COLOUR}"
echo ""
echo -e "${CYAN}Please review the following files and resolve into single copies of the dbt_project.yml file and packages.yml file:${END_COLOUR}"
echo ""
printf '%s\n' "$NEW_PROJECT_DIRECTORY"/transforms/*dbt_project.yml
echo "--------------------------------------------"
printf '%s\n' "$NEW_PROJECT_DIRECTORY"/transforms/*packages.yml
echo ""
echo -e "${YELLOW}TIP 1: Focus on converging the models and vars dictionaries in the dbt_project.yml file${END_COLOUR}"
echo -e "${YELLOW}TIP 2: Double-check all of your macros have been copied over to ${NEW_PROJECT_DIRECTORY}/transforms/macros${END_COLOUR}"
echo -e "${YELLOW}TIP 3: If you still have a 'temp' folder it is because there are files the template did not expect - please review them manually${END_COLOUR}"
