#!/usr/bin/env bash
set -e

RED="\033[0;31m"
GREEN="\033[0;32m"
ORANGE="\033[0;33m"
CYAN="\033[0;36m"
LIGHT_PURPLE="\033[1;34m"
ENDCOLOR="\033[0m"

DV_DIRECTORY="dp_v9mj_measurement_mta_dv"
FED_DIRECTORY="dp_v9mj_measurement_mta_fed"
PL_DIRECTORY="dp_v9mj_measurement_mta_pl"

TEMP_DIRECTORY=temp

# COPY LEGACY FOLDERS TO TEMP LOCATION
echo ""
echo -e "${ORANGE}--MIGRATION SET-UP STARTING--${ENDCOLOR}"
echo ""
echo -e "${CYAN}Copying existing dbt projects into temp location...${ENDCOLOR}"
echo ""

echo -e "${CYAN}Creating temp folder...${ENDCOLOR}"
mkdir -p "$TEMP_DIRECTORY" && echo -e "${LIGHT_PURPLE}created temp folder${ENDCOLOR}" || echo -e "${RED}failed to create temp folder${ENDCOLOR}"

temp_copy () {
  echo ""
  echo "Found $2 folder in repository..."
  mkdir -p "$TEMP_DIRECTORY/$1" && echo -e "${LIGHT_PURPLE}created temp $2 folder${ENDCOLOR}" || echo -e "${RED}failed to create temp $2 folder${ENDCOLOR}"
  echo "Copying $1 to $TEMP_DIRECTORY"
  cp -r "$1"/** "$TEMP_DIRECTORY"/"$1" && echo -e "${GREEN}copy passed${ENDCOLOR}" || echo -e "${RED}copy failed${ENDCOLOR}"
  echo ""
}

if [ -d "$DV_DIRECTORY" ]; then
  temp_copy "$DV_DIRECTORY" DV
fi

if [ -d "$FED_DIRECTORY" ]; then
  temp_copy "$FED_DIRECTORY" FED
fi

if [ -d "$PL_DIRECTORY" ]; then
  temp_copy "$PL_DIRECTORY" PL
fi

echo ""
echo -e "${ORANGE}--MIGRATION SET-UP COMPLETED--${ENDCOLOR}"
echo ""
