#!/usr/bin/env bash

set -e -o pipefail

# You can modify this repository name if needed.
# This indicates you are not following the standard naming convention
# and should only be changed by exception.
REPO_NAME="dp-v9mj-measurement-mta"


RED="\033[0;31m"
GREEN="\033[0;32m"
ORANGE="\033[0;33m"
BLUE="\033[0;34m"
CYAN="\033[0;36m"
YELLOW="\033[1;33m"
LIGHT_PURPLE="\033[1;34m"
END_COLOUR="\033[0m"

echo -e "${CYAN}Checking GitHub CLI installation and configuration...${END_COLOUR}"

display_error() {
    echo -e "${YELLOW}⚠️  Error: GitHub CLI configuration required${END_COLOUR}"
    echo -e "${BLUE}------------------------------------------------${END_COLOUR}"
    echo -e "${RED}To deploy DDL, you need to configure the GitHub CLI.${END_COLOUR}"
    echo ""
    echo -e "${CYAN}Manual steps required:${END_COLOUR}"
    echo -e "${LIGHT_PURPLE}1. Install GitHub CLI: https://github.com/cli/cli#installation${END_COLOUR}"
    echo -e "   - For macOS: ${GREEN}brew install gh${END_COLOUR}"
    echo -e "   - For Linux: ${GREEN}sudo apt install gh${END_COLOUR}"
    echo -e "   - For Windows: ${GREEN}choco install gh${END_COLOUR}"
    echo -e "${LIGHT_PURPLE}2. Login to GitHub: ${GREEN}gh auth login${END_COLOUR}"
    echo -e "   Follow the prompts to authenticate with your GitHub account"
    echo ""
    echo -e "${LIGHT_PURPLE}3. After installation and authentication, run this script again:${END_COLOUR}"
    echo -e "   ${GREEN}./migrations/gh/configure_oidc.sh${END_COLOUR}"
    echo -e "${BLUE}------------------------------------------------${END_COLOUR}"
    exit 0
}

display_manual_oidc() {
    echo -e "${YELLOW}⚠️  Error: OIDC configuration failed${END_COLOUR}"
    echo -e "${BLUE}------------------------------------------------${END_COLOUR}"
    echo -e "${RED}The automatic OIDC configuration failed.${END_COLOUR}"
    echo ""
    echo -e "${CYAN}Please verify the repository name:${END_COLOUR}"
    echo -e "   Current repository name: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"
    echo ""
    echo -e "${CYAN}If the repository name is incorrect:${END_COLOUR}"
    echo -e "   1. Edit this script (${GREEN}./migrations/gh/configure_oidc.sh${END_COLOUR})"
    echo -e "   2. Look for ${LIGHT_PURPLE}REPO_NAME=<value>${END_COLOUR} at the top of the file"
    echo -e "   3. Change it to match your GitHub repository name"
    echo ""
    echo -e "${CYAN}After correcting the repository name, run this script again:${END_COLOUR}"
    echo -e "   ${GREEN}./migrations/gh/configure_oidc.sh${END_COLOUR}"
    echo ""
    echo -e "${BLUE}------------------------------------------------${END_COLOUR}"
    echo -e "${ORANGE}NOTE: Manually changing the repository name here indicates you're not following${END_COLOUR}"
    echo -e "${ORANGE}the standard naming convention. When possible, it's recommended to:${END_COLOUR}"
    echo -e "   - Rename your GitHub repository to match the standard format"
    echo -e "   - OR update your project_name to follow the standard pattern"
    echo ""
    echo -e "${ORANGE}The standard naming format is: dp-xxxx-name-of-project${END_COLOUR}"
    echo ""
    echo -e "${CYAN}If you continue to encounter issues, contact Grid support ${ORANGE}#data-grid-queries${END_COLOUR}"
    echo -e "${BLUE}------------------------------------------------${END_COLOUR}"
}

if ! command -v gh &> /dev/null; then
    echo -e "${RED}❌ GitHub CLI is not installed.${END_COLOUR}"
    display_error
fi

if ! gh auth status &> /dev/null; then
    echo -e "${RED}❌ Not logged in to GitHub.${END_COLOUR}"
    display_error
fi

echo -e "${GREEN}✅ GitHub CLI is installed and authenticated.${END_COLOUR}"

echo -e "${CYAN}Configuring OIDC for repository: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"

if ! gh api --method PUT -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28" \
   /repos/brexville-tech/$REPO_NAME/actions/oidc/customization/sub -F "use_default=false" \
   -f "include_claim_keys[]=repo" -f "include_claim_keys[]=context" -f "include_claim_keys[]=job_workflow_ref" &> /dev/null; then
    display_manual_oidc
    echo -e "${RED}❌ Failed to configure OIDC for repository.${END_COLOUR}"
else
    echo -e "${GREEN}✅ Successfully configured OIDC for repository: ${LIGHT_PURPLE}$REPO_NAME${END_COLOUR}"
fi

# We always exit with success, as we don't want this to block the copier operation
exit 0
