## Description:

*Include a summary of the change and which issue is fixed, and include relevant motivation
and context, and links to design documentation.*

## JIRA Ticket Number:

[NUP-XXXX](https://brexville-tech.atlassian.net/browse/NUP-XXXX)

## Type of Change:

*Delete types that don't apply.*

- Bug fix (non-breaking change which fixes an issue)
- New/Updates/Removes feature (non-breaking change which adds/updates/removes functionality)
- Documentation

## Checklist:

- [ ] The PR title and commit starts with the JIRA number (e.g. 'NUP-XXXX - Add a new feature'), if applicable.
- [ ] It follows the engineering standards and style guidelines of this project.
- [ ] I have commented my code, particularly in hard-to-understand areas.
- [ ] I have made corresponding changes to the documentation (GitHub or Confluence), where applicable.
- [ ] I have added new tests that prove my fix is effective or that my feature works.
- [ ] All existing unit tests pass.
- [ ] UAT has been completed by an engineer or data scientist, if applicable.
- [ ] sqllinting to be checked before checkin to repository
- [ ] No Hard codings within the code, use configuration file - dbt-project.yaml
- [ ] No repetitive code inside multiple files
- [ ] Identify the usage of repetitive code and accordingly add a new macro or dbt data model
- [ ] Follow Sainsbury's Column naming conventions
- [ ] Follow Alias naming convention as per Sainsbury's
- [ ] Python linting check to be enabled and verified for Python files
- [ ] When using incremental strategy, identify the use case is for merge or overwrite and accordingly use and test before checkin
- [ ] DQ checks should pass before checking in any code
- [ ] DBT docs to be generated for each new data model introduced
- [ ] Unit Test to be added for each new data model and verified using dbt test before checkin
- [ ] DBT Artefacts if used should be verified for data consistency during model run

## UAT:

*Describe the tests and UAT that you ran to verify your changes and list any
relevant details for your test configuration


<!---
Provide a short summary in the Title above. Examples of good PR titles:
* ABC-123: Update column X in sales table
* "Update: dbt version 0.13.0"
-->

## Description & motivation

<!---
Describe your changes, and why you're making them. Is this linked to an open
issue, a Jira ticket, or another pull request? Link it here.
-->

## To-do before merge

<!---
(Optional -- remove this section if not needed)
Include any notes about things that need to happen before this PR is merged, e.g.:
- [ ] Ensure PR #56 is merged
-->

## Screenshots:

<!---
Include a screenshot of the local testing of the scripts
-->

## Validation of models:

<!---
Include any output that confirms that the models do what is expected. This might
be a link to an in-development dashboard in Microstrategy, or a query that
compares an existing model with a new one.
-->

## Changes to existing models:

<!---
Include this section if you are changing any existing models. Give instructions
for merge (e.g. whether old models should be dropped after merge, or whether a
full-refresh run is required)
-->

## Checklist:

<!---
This checklist is mostly useful as a reminder of small things that can easily be
forgotten – it is meant as a helpful tool rather than hoops to jump through.
Put an `x` in all the items that apply, make notes next to any that haven't been
addressed, and remove any items that are not relevant to this PR.
-->
