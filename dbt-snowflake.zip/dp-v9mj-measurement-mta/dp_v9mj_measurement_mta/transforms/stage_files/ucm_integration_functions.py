"""
Objective:
This script provides a comprehensive set of functions for integrating Marketing Mix Modeling (MMM)
and Multi-Touch Attribution (MTA) data, filtering datasets, calculating SKU-level baselines, and
performing sales recalibration and aggregation. It is designed to handle large-scale marketing and
sales data, enabling data-driven decision-making by integrating and processing data from multiple sources.

The module is designed to handle large-scale marketing and sales data, enabling
data-driven decision-making by integrating and processing data from multiple sources.

Used in:
    This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle and baseline_attribution_integration_sku_level_offer/brand/aisle.

Functions:
    calculate_sales_proportion(sales_data_output, sku_cluster_mapping_filtered, campaign_start_date, campaign_end_date, pre_campaign_weeks=6):
        Computes the sales proportion for each SKU within its cluster based on sales data
        for the pre-campaign or campaign period. If pre-campaign sales data is not sufficient,
        the default campaign sales proportion is used for all SKUs in the cluster.

    sku_level_baseline_scaler(integrated_df):
        Computes the sales proportion, baseline, and incremental sales at the SKU level
        based on cluster-level sales and baseline data.

    mmm_mta_integration(baseline_output, sku_cluster_mapping, sales_data_transformations_output):
        Integrates MMM and MTA data by joining baseline output, SKU cluster mapping,
        and sales data transformations to produce an SKU-level integrated dataset.

    filter_data(baseline_output, sku_cluster_mapping, sales_data_transformations_output, final_cluster, super_category_name, brand):
        Filters the input DataFrames based on specified cluster numbers, super category,
        and brand names to prepare data for further analysis.

    get_campaign_start_end_date(df, is_post_campaign, booking_id):
        Extracts the start and end dates of a campaign based on the booking ID and
        campaign type (post-campaign or during-campaign).

    calculate_recaliberated_sales(factor, sku_level_results):
        Recalibrates attributed sales and units by applying attribution factors,
        accounting for channel-specific adjustments and regression variables.

    calculate_aggregated_sales(dtp_sales_df, attribution_df, total_sales, channel_overlap):
        Aggregates sales data and calculates recalibrated sales based on channel overlap,
        normalizing weights and distributing sales across channels.
"""

from snowflake.snowpark.functions import (
    date_trunc, max, min, to_char, col, lower, when, sum, lit, length,
    regexp_replace, avg, expr, rank
)
from snowflake.snowpark.window import Window
from snowflake.snowpark.types import DateType
from datetime import datetime, timedelta


def calculate_sales_proportion(sales_data_output, sku_cluster_mapping_filtered, campaign_start_date, campaign_end_date, pre_campaign_weeks, min_pre_camp_sales_threshold):
    # Sales proportions base on sales data

    # converting the WEEK_START_DT to date for comparison
    sales_data_output = sales_data_output.withColumn(
        "WEEK_START_DT", col("WEEK_START_DT").cast(DateType()))

    # adding the cluster number to the sales data
    sales_data_output = sales_data_output.join(
        sku_cluster_mapping_filtered,
        on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "ITEM_CD"],
        how="left",
    ).filter(col("CLUSTER_NUM").is_not_null())

    # creating a window on cluster, as sales proportion is calculated on cluster level
    cluster_window = Window.partition_by("UNIQUE_BRAND_NAME", "SUPER_CATEGORY_NAME", "CLUSTER_NUM")

    # Calculating default campaign sales proportions
    # filter data for campaign period
    campaign_sales = sales_data_output.filter(
        (col("WEEK_START_DT") >= campaign_start_date) &
        (col("WEEK_START_DT") <= campaign_end_date)
    )

    # compute overall total sales amount for campaign period
    campaign_sales = campaign_sales.with_column("CAMPAIGN_TOTAL_SALES_AMT", sum("TOTAL_SALES_AMT").over(cluster_window))

    # getting the dafult campaign sales proportions
    sales_proportions = campaign_sales.groupBy("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD", "CAMPAIGN_TOTAL_SALES_AMT").agg(
        when(col("CAMPAIGN_TOTAL_SALES_AMT") == 0, 0).otherwise(sum(col("TOTAL_SALES_AMT")) / col("CAMPAIGN_TOTAL_SALES_AMT")).alias("CAMPAIGN_SALES_PROPORTION")
    )

    # Calculating the sales proportion based on 6 weeks prior to campaign start, if sales data is available.

    # calculating the date pre-campaign period before campaign start date - pre_campaign_weeks (default 6 weeks)
    six_weeks_prior_date = datetime.strptime(campaign_start_date, "%Y-%m-%d").date() - timedelta(weeks=pre_campaign_weeks)

    # finding oldest sales data available for SKU
    min_sales_date = sales_data_output.select(min(col("WEEK_START_DT"))).collect()[0][0]

    if min_sales_date <= six_weeks_prior_date:
        pre_campaign_sales_data_exists = True

        # filter pre-campaign sales data
        pre_campaign_sales_df = sales_data_output.filter(
            (col("WEEK_START_DT") >= six_weeks_prior_date) &
            (col("WEEK_START_DT") < campaign_start_date)
        )

        # finding avg weeky sales for the campaign period
        avg_weekly_sales = sales_data_output.filter(
            (col("WEEK_START_DT") >= campaign_start_date) &
            (col("WEEK_START_DT") <= campaign_end_date)
        ).groupBy("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD").agg(
            avg(col("TOTAL_SALES_AMT")).alias("AVG_WEEKLY_SALES")
        )

        # checking if the pre-campaign period has at least 10% of the avg. campaign period sales available
        sales_per_sku = pre_campaign_sales_df.join(
            avg_weekly_sales,
            on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD"],
            how="left"
        ).with_column(
            "SUFFICIENT_PRE_CAMPAIGN_SALES",
            when(col("TOTAL_SALES_AMT") >= col("AVG_WEEKLY_SALES") * min_pre_camp_sales_threshold, 1).otherwise(0)
        ).group_by(
            "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM"
        ).agg(
            min(col("SUFFICIENT_PRE_CAMPAIGN_SALES")).alias("SUFFICIENT_PRE_CAMPAIGN_SALES")
        )

        # add SUFFICIENT_PRE_CAMPAIGN_SALES to sales proportions table on cluster level,
        # if any SKU in cluster does not have sufficient pre-campaign sales, the default campaign proportion is used for all SKUs in the cluster
        sales_proportions = sales_proportions.join(
            sales_per_sku,
            on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM"],
            how="left"
        )

        # total pre-campaign period sales amount
        filtered_sales_with_cluster = pre_campaign_sales_df.with_column("PRE_CAMPAIGN_TOTAL_SALES_AMT", sum("TOTAL_SALES_AMT").over(cluster_window))

        # calculate pre-campaign sales proportion
        pre_campaign_sales_proportion = filtered_sales_with_cluster.groupBy("SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD", "PRE_CAMPAIGN_TOTAL_SALES_AMT").agg(
            when(col("PRE_CAMPAIGN_TOTAL_SALES_AMT") == 0, 0).otherwise(sum(col("TOTAL_SALES_AMT")) / col("PRE_CAMPAIGN_TOTAL_SALES_AMT")).alias("PRE_CAMPAIGN_SALES_PROPORTION")
        )

        # adding the pre-campaign sales proportion to the sales proportions table
        sales_proportions = sales_proportions.join(
            pre_campaign_sales_proportion,
            on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD"],
            how="left"
        )
    else:
        pre_campaign_sales_data_exists = False

    return sales_proportions, pre_campaign_sales_data_exists


def baseline_sku_level_calculation(integrated_df, pre_campaign_sales_data_exists):
    """
    Computes the sales proportion, baseline, and incremental sales at the SKU level.

    Objective:
    This function scales the baseline and incremental sales to SKU level using cluster sales proportions.

    Proportions are calculated based on sales data for the pre-campaign or campaign period.
    If the pre-campaign sales data doesn't exist or not sufficient for any SKU in the cluster (less than 10% of the average campaign sales),
    the default campaign sales proportion is used for all SKUs in the cluster. Ensuring that proportions add up to 100% at the cluster level.

    Used in:
        This function is called within the method baseline_sku_level_integration.

    Args:
        integrated_df (DataFrame): Input DataFrame containing sales and baseline data.

    Returns:
        DataFrame: Updated DataFrame with baseline and incremental sales scaled from cluster to SKU level.
    """

    # Calculate the sales proportion for each SKU within its cluster
    # if sales data for pre-campaign period exists, if not use the default campaign sales proportion
    if pre_campaign_sales_data_exists:
        # checking to see if pre-campaign sales data is sufficient to use for SKU proportions
        integrated_df = integrated_df.withColumn(
            "SALES_PROPORTION",
            when(col("SUFFICIENT_PRE_CAMPAIGN_SALES") < 1, col("CAMPAIGN_SALES_PROPORTION"))
            .otherwise(col("PRE_CAMPAIGN_SALES_PROPORTION"))
        )
    else:
        integrated_df = integrated_df.withColumn(
            "SALES_PROPORTION",
            col("CAMPAIGN_SALES_PROPORTION")
        )

    # Calculate the baseline sales for each SKU
    integrated_df = integrated_df.withColumn(
        "BASELINE", integrated_df["SALES_PROPORTION"] * integrated_df["CLUSTER_BASELINE"]
    )

    # Calculate the incremental sales for each SKU
    integrated_df = integrated_df.withColumn(
        "INCREMENTAL", integrated_df["TOTAL_SALES_AMT"] - integrated_df["BASELINE"]
    )

    return integrated_df


def baseline_sku_level_integration(baseline, sku_mapping, sales, sales_proportions, pre_campaign_sales_data_exists):
    """
    Integrates cluster-level baseline data with SKU-level mappings and sales data.

    Objective:
    By merging cluster-level baseline data, SKU-level mappings,
    and sales data, it enables detailed analysis of sales performance at the SKU level. The integration
    ensures accurate distribution of baseline and incremental sales across SKUs.

    This function combines cluster-level baseline data with SKU-level mappings and
    sales data to produce an integrated dataset. It calculates the baseline and
    incremental sales at the SKU level.

    Used in:
        This function is called within the model baseline_attribution_integration_sku_level_offer/brand/aisle.

    Args:
        baseline_output (DataFrame): Baseline output DataFrame containing cluster-level sales and baseline data.
        sku_cluster_mapping (DataFrame): SKU cluster mapping DataFrame containing SKU-to-cluster mappings.
        sales_data_transformations_output (DataFrame): Sales data transformations DataFrame containing SKU-level sales data.

    Returns:
        DataFrame: Integrated DataFrame with calculated baseline and incremental sales at the SKU level.
    """

    # Rename columns in the baseline output for consistency
    baseline = baseline.rename(
        {"TOTAL_SALES_AMT": "CLUSTER_SALES", "TOTAL_BASELINE_AMT": "CLUSTER_BASELINE"}
    )

    # We calculate incrementality post integration with MTA results for the targetted SKUs for the campaign in the later
    # part of the code hence this column coming from baseline output is not required
    baseline = baseline.drop(["TOTAL_INCREMENTAL_AMT"])

    # Join baseline output with SKU cluster mapping
    baseline_w_skus = baseline.join(
        sku_mapping,
        on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM"],
        how="left",
    )

    # Join the result with sales data transformations
    baseline_and_sales = baseline_w_skus.join(
        sales,
        on=["WEEK_START_DT", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "ITEM_CD"],
        how="left",
    )

    # Join sku proportions, that are calculated based on sales data for the pre-campaign or campaign period
    integrated_df = baseline_and_sales.join(
        sales_proportions,
        on=["SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITEM_CD"],
        how="left"
    )

    # Scale the baseline and calculate incremental sales
    integrated_df = baseline_sku_level_calculation(integrated_df, pre_campaign_sales_data_exists)

    # Drop unnecessary columns from the final integrated DataFrame
    integrated_df = integrated_df.drop(
        [
            "CLUSTER_SALES",
            "CLUSTER_BASELINE",
            "BRAND",
            "PACK_SIZE",
            "PRICE_PER_UNIT",
            "FREQ_OF_PURCH",
            "DISTINCT_CUSTOMERS",
            "PERC_ONL_CONV",
            "PERC_SUPER_CONV",
            "PERC_SUPER_ONL",
            "SALES_PROPORTION",
            "CAMPAIGN_TOTAL_SALES_AMT",
            "CAMPAIGN_SALES_PROPORTION",
            "SUFFICIENT_PRE_CAMPAIGN_SALES",
            "PRE_CAMPAIGN_TOTAL_SALES_AMT",
            "PRE_CAMPAIGN_SALES_PROPORTION"
        ]
    )

    return integrated_df


def filter_data(
    baseline_output,
    sku_cluster_mapping,
    sales_data_transformations_output,
    final_cluster,
    super_category_name,
    brand,
):
    """
    Filters the input DataFrames based on the provided cluster, super category, and brand.

    Objective:
    This function ensures that the input DataFrames are filtered to include only the relevant
    data for analysis. By applying the specified filtering conditions, it prepares the data
    for further processing and integration, focusing on specific clusters, super categories,
    and brands.

    This function applies filtering conditions to the baseline output, SKU cluster mapping,
    and sales data transformations DataFrames based on the specified cluster numbers,
    super category name, and brand names.

    Used in:
        This function is called within the model baseline_attribution_integration_sku_level_offer/brand/aisle.

    Args:
        baseline_output (DataFrame): Baseline output DataFrame.
        sku_cluster_mapping (DataFrame): SKU cluster mapping DataFrame.
        sales_data_transformations_output (DataFrame): Sales data transformations DataFrame.
        final_cluster (list): List of cluster numbers to filter.
        super_category_name (str): Super category name to filter.
        brand (list): List of brand names to filter.

    Returns:
        tuple: Filtered DataFrames:
            - `baseline_output`: Filtered baseline output DataFrame.
            - `sku_cluster_mapping`: Filtered SKU cluster mapping DataFrame.
            - `sales_data_transformations_output`: Filtered sales data transformations DataFrame.
    """
    print(baseline_output.columns)
    print("clusters", final_cluster)

    # Define filtering conditions for each DataFrame
    filter_condition1 = (
        (baseline_output["UNIQUE_BRAND_NAME"].isin(brand)) &
        (baseline_output["SUPER_CATEGORY_NAME"] == super_category_name) &
        (baseline_output["CLUSTER_NUM"].isin(final_cluster))
    )

    filter_condition2 = (
        (sku_cluster_mapping["UNIQUE_BRAND_NAME"].isin(brand)) &
        (sku_cluster_mapping["SUPER_CATEGORY_NAME"] == super_category_name) &
        (sku_cluster_mapping["CLUSTER_NUM"].isin(final_cluster))
    )

    filter_condition3 = (
        (sales_data_transformations_output["UNIQUE_BRAND_NAME"].isin(brand)) &
        (sales_data_transformations_output["SUPER_CATEGORY_NAME"] == super_category_name)
    )
    print("Filtering Cluster Completed")

    # Apply filtering conditions to the DataFrames
    baseline_output = baseline_output.filter(filter_condition1)
    sku_cluster_mapping = sku_cluster_mapping.filter(filter_condition2)
    sales_data_transformations_output = sales_data_transformations_output.filter(filter_condition3)

    # Select relevant columns from the filtered DataFrames
    sku_cluster_mapping = sku_cluster_mapping[
        ["ITEM_CD", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM"]
    ]
    sales_data_transformations_output = sales_data_transformations_output.drop(["BRAND_NAME"])
    return baseline_output, sku_cluster_mapping, sales_data_transformations_output


def get_campaign_start_end_date(df, is_post_campaign, booking_id):
    """
    Retrieves the start and end dates of a campaign based on the booking ID.

    Objective:
    This function aims to provide the start and end dates of a campaign, adjusted to align
    with week boundaries. It ensures accurate date alignment for post-campaign or during-campaign
    analysis, facilitating consistent reporting and data aggregation.

    This function filters the input DataFrame to extract campaign data for a specific
    booking ID. It calculates the start and end dates of the campaign, grouped by
    channel name, booking ID, and campaign duration. Depending on whether the campaign
    is post-campaign or during-campaign, it adjusts the start and end dates to align
    with the week boundaries.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle and baseline_attribution_integration_sku_level_offer/brand/aisle.

    Args:
        df (DataFrame): Input DataFrame containing campaign data.
        is_post_campaign (bool): Whether the campaign is post-campaign or during-campaign.
        booking_id (str): Booking ID to filter the campaign.

    Returns:
        tuple: A tuple containing:
            - `campaign_start_date` (str): Campaign start date aligned to the week start.
            - `campaign_end_date` (str): Campaign end date aligned to the week end.
    """
    # Filter the DataFrame for the specified booking ID
    filtered_df = df.filter(df["BOOKING_ID"] == booking_id)

    # Group the filtered data by channel, booking ID, and campaign duration
    filtered_df_grouped = filtered_df.groupBy("CHANNEL_NAME", "BOOKING_ID", "CAMPAIGN_DURATION").agg(
        min(filtered_df["CAMPAIGN_START_DT"]).alias("CAMPAIGN_STARTDATE"),
        max(filtered_df["CAMPAIGN_END_DT"]).alias("CAMPAIGN_ENDDATE"),
    )

    # Select relevant columns from the grouped DataFrame
    unified_ampaign_df = filtered_df_grouped.select(
        "CAMPAIGN_STARTDATE", "CAMPAIGN_ENDDATE", "CHANNEL_NAME", "CAMPAIGN_DURATION", "BOOKING_ID"
    )

    # Adjust dates based on whether the campaign is post-campaign or during-campaign
    if is_post_campaign:
        # Filter for post-campaign data
        unified_ampaign_df = unified_ampaign_df.filter(unified_ampaign_df["CAMPAIGN_DURATION"] == 'Post')

        # Align the campaign end date to the week boundary
        unified_ampaign_df = unified_ampaign_df.with_column(
            "CAMPAIGNWEEKENDDATE",
            to_char(
                date_trunc("WEEK", max(unified_ampaign_df["CAMPAIGN_ENDDATE"])),
                "YYYY-MM-DD",
            ),
        )
    else:
        # Filter for during-campaign data
        unified_ampaign_df = unified_ampaign_df.filter(unified_ampaign_df["CAMPAIGN_DURATION"] == 'During')

        # Align the campaign end date to the week boundary
        unified_ampaign_df = unified_ampaign_df.with_column(
            "CAMPAIGNWEEKENDDATE",
            to_char(date_trunc("WEEK", max(unified_ampaign_df["CAMPAIGN_ENDDATE"])), "YYYY-MM-DD"),
        )

    # Align the campaign start date to the week boundary
    unified_ampaign_df = unified_ampaign_df.with_column(
        "CAMPAIGNWEEKSTARTDATE",
        to_char(date_trunc("WEEK", min(unified_ampaign_df["CAMPAIGN_STARTDATE"])), "YYYY-MM-DD"),
    )

    # Extract the start and end dates as strings
    campaign_start_date = unified_ampaign_df.select("CAMPAIGNWEEKSTARTDATE").collect()[0][0]
    campaign_end_date = unified_ampaign_df.select("CAMPAIGNWEEKENDDATE").collect()[0][0]

    return campaign_start_date, campaign_end_date


def calculate_recaliberated_sales(factor, sku_level_results):
    """
    Calculates recalibrated sales and units based on attribution factors.

    Objective:
    This function recalibrates attributed sales and units by applying attribution factors
    to SKU-level results. It ensures accurate adjustments for channel-specific platforms
    like Meta, YouTube, and DV360, while also handling regression variables and offsite
    campaign recalibrations. The recalibration process accounts for normalized weights,
    regression variable complexity, and campaign-specific factors to produce refined
    sales and unit metrics.

    This function joins SKU-level results with attribution factors to calculate
    recalibrated sales and units. It applies channel-specific adjustments for
    platforms like Meta, YouTube, and DV360. Additionally, it handles regression
    variables and calculates recalibrated values for offsite campaigns.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle.

    Args:
        factor (DataFrame): DataFrame containing attribution factors.
        sku_level_results (DataFrame): DataFrame containing SKU-level results.

    Returns:
        DataFrame: Updated DataFrame with recalibrated sales and units.
    """
    # Join SKU-level results with attribution factors
    dtp_attr_join = sku_level_results.join(factor, on=["CHANNEL_NAME", "CAMPAIGN_ID"], how="left")

    # Calculate the average factor for specific channels
    average_factor = factor.filter(lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360")).group_by("CAMPAIGN_ID").agg(avg("FACTOR").alias("AVG_FACTOR"))

    # Calculate attributed sales and units
    dtp_attr_join = dtp_attr_join.with_column(
        "ATTRIBUTED_SALES_AMT", col("NORMALIZED_WEIGHTS") * col("NET_SALES_AMT")
    )
    dtp_attr_join = dtp_attr_join.with_column(
        "ATTRIBUTED_UNITS_QTY", col("NORMALIZED_WEIGHTS") * col("UNITS_QTY")
    )

    # Apply recalibration for specific channels
    dtp_attr_join = dtp_attr_join.with_column(
        "ATTRIBUTED_RECALIBERATED_SALES_AMT",
        when(
            lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
            col("ATTRIBUTED_SALES_AMT") * col("FACTOR"),
        ).otherwise(col("ATTRIBUTED_SALES_AMT")),
    )

    dtp_attr_join = dtp_attr_join.with_column(
        "ATTRIBUTED_RECALIBERATED_UNITS_QTY",
        when(
            lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
            col("ATTRIBUTED_UNITS_QTY") * col("FACTOR"),
        ).otherwise(col("ATTRIBUTED_UNITS_QTY")),
    )

    # Calculate the number of underscores in regression variables
    underscore_count_col = (
        length('REGRESSION_VARIABLE') - length(regexp_replace('REGRESSION_VARIABLE', '_', ''))
    )
    dtp_attr_join = dtp_attr_join.withColumn("UNDERSCORE_COUNT", underscore_count_col)

    # Join with average factors for recalibration
    dtp_attr_join = dtp_attr_join.join(average_factor, on=["CAMPAIGN_ID"], how="left")

    # Handle offsite campaigns
    distinct_avg = dtp_attr_join.filter(lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360")).select("USERJOURNEY_ID", "AVG_FACTOR").distinct()
    w = Window.partition_by("USERJOURNEY_ID").order_by(col("AVG_FACTOR"))
    distinct_avg = distinct_avg.with_column("RNK", rank().over(w))
    distinct_avg = distinct_avg.filter(col("RNK") == 1).select(col("USERJOURNEY_ID"), col("AVG_FACTOR").alias("AVG_FACTOR_OFFSITE"))
    dtp_attr_join = dtp_attr_join.join(distinct_avg, on="USERJOURNEY_ID", how="left")
    offsite_exp = "LOWER(REGRESSION_VARIABLE) LIKE '%offsite%'"

    # Apply recalibration for offsite campaigns
    dtp_attr_join = dtp_attr_join.withColumn(
        "factor",
        when(
            (lower(col("CAMPAIGN_ID")) == "na") &
            expr(offsite_exp),
            col("AVG_FACTOR_OFFSITE")
        ).otherwise(col("FACTOR"))
    ).drop("AVG_FACTOR_OFFSITE", "RNK")

    dtp_attr_join = dtp_attr_join.withColumn(
        "ATTRIBUTED_RECALIBERATED_UNITS_QTY",
        when(
            (lower(col("CAMPAIGN_ID")) == "na") &
            expr(offsite_exp),
            ((col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") / (col("UNDERSCORE_COUNT") + lit(1))) * col("FACTOR")) +
            (col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") / (col("UNDERSCORE_COUNT") + lit(1)))
        ).otherwise(col("ATTRIBUTED_RECALIBERATED_UNITS_QTY"))
    )

    dtp_attr_join = dtp_attr_join.withColumn(
        "ATTRIBUTED_RECALIBERATED_SALES_AMT",
        when(
            (lower(col("CAMPAIGN_ID")) == "na") &
            expr(offsite_exp),
            ((col("ATTRIBUTED_RECALIBERATED_SALES_AMT") / (col("UNDERSCORE_COUNT") + lit(1))) * col("factor")) +
            (col("ATTRIBUTED_RECALIBERATED_SALES_AMT") / (col("UNDERSCORE_COUNT") + lit(1)))
        ).otherwise(col("ATTRIBUTED_RECALIBERATED_SALES_AMT"))
    )

    return dtp_attr_join


def calculate_aggregated_sales(dtp_sales_df, attribution_df, total_sales, channel_overlap):
    """
    Aggregates sales data and calculates recalibrated sales based on channel overlap.

    Objective:
    This function aims to aggregate sales data and calculate recalibrated sales by
    considering channel-specific overlaps and normalized weights. It ensures accurate
    distribution of sales across channels, accounting for platform-specific adjustments
    and overlap scenarios. The recalibration process refines sales attribution metrics
    for better decision-making.

    Used in:
        This function is called within the model sku_level_attributed_sales_and_units_offer/brand/aisle.

    Args:
        dtp_sales_df (DataFrame): DataFrame containing sales data.
        attribution_df (DataFrame): DataFrame containing attribution data.
        total_sales (float): Total sales amount.
        channel_overlap (int): Indicator for channel overlap (0 or 1).

    Returns:
        DataFrame: DataFrame with aggregated and recalibrated sales data.
    """
    offiste_sales = dtp_sales_df.select("CHANNEL_NAME", "CAMPAIGN_ID", "SUM_SALES_AMT").distinct()
    dtp_attr_join = attribution_df.join(offiste_sales, on=["CHANNEL_NAME", "CAMPAIGN_ID"], how="left")
    dtp_attr_join_recaliberated = dtp_attr_join.groupBy(
        "CHANNEL_NAME", "SUBCHANNEL_NAME", "MARKETING_TYPE", "CAMPAIGN_ID", "SUM_SALES_AMT"
    ).agg(
        sum("NORMALIZED_WEIGHTS").alias("SUM_NORMALIZED_WEIGHTS")
    )

    win_channel = Window.partition_by("CHANNEL_NAME", "CAMPAIGN_ID")
    sum_total_weights = dtp_attr_join_recaliberated.select(sum(col("SUM_NORMALIZED_WEIGHTS"))).collect()[0][0]
    dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
        "weights_percentage", (col("SUM_NORMALIZED_WEIGHTS") / sum_total_weights)
    )
    dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
        "ATTRIBUTED_SALES_AMT", col("weights_percentage") * total_sales
    )
    if channel_overlap == 0:
        dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
            "CHANNEL_WEIGHTS", sum("SUM_NORMALIZED_WEIGHTS").over(win_channel)
        )
        dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
            "SUM_NORMALIZED_WEIGHTS",
            when(
                lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
                col("SUM_NORMALIZED_WEIGHTS") / col("CHANNEL_WEIGHTS")
            ).otherwise(col("SUM_NORMALIZED_WEIGHTS"))
        )
        dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
            "ATTRIBUTED_RECALIBERATED_SALES_AMT",
            when(
                lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
                col("SUM_NORMALIZED_WEIGHTS") * col("SUM_SALES_AMT")
            ).otherwise(col("ATTRIBUTED_SALES_AMT"))
        )
        dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
            "WEIGHTS_PERCENTAGE", col("SUM_NORMALIZED_WEIGHTS")
        )
    else:
        dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
            "ATTRIBUTED_RECALIBERATED_SALES_AMT",
            when(
                lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
                col("WEIGHTS_PERCENTAGE") * col("SUM_SALES_AMT")
            ).otherwise(col("ATTRIBUTED_SALES_AMT"))
        )

    dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
        "SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT",
        sum("ATTRIBUTED_RECALIBERATED_SALES_AMT").over(win_channel)
    )
    dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
        "SUM_ATTRIBUTED_SALES_AMT",
        sum("ATTRIBUTED_SALES_AMT").over(win_channel)
    )
    dtp_attr_join_recaliberated = dtp_attr_join_recaliberated.with_column(
        "FACTOR",
        col("SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT") / col("SUM_ATTRIBUTED_SALES_AMT")
    )
    factor = dtp_attr_join_recaliberated.select("CHANNEL_NAME", "CAMPAIGN_ID", "FACTOR").distinct()
    return factor
