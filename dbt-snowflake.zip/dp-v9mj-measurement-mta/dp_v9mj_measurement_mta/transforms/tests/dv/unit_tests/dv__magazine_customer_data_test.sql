{{ config(tags=['unit-test', 'magazine_customer_data_test']) }}

{% call dbt_unit_testing.test('magazine_customer_data', 'Test for get_magazine_customer_data') %}

    {% call dbt_unit_testing.mock_ref ('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_DURATION | CAMPAIGN_ID | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_NAME | CAMPAIGN_START_DT | CAMPAIGN_END_DT  | JOB_STATUS | LOAD_TS | JOB_RUN_ID  
        'bid_1'    | 'During' | 'nec_123'    | 'nec_123'      | 'Magazine'         | 'Sainsbury Magazine'       | 'NA'  | 'CHECK'| TO_DATE('2025-05-01') | TO_DATE('2025-05-31')  | 'Not Started'| TO_TIMESTAMP('2025-05-01') | 'job_run_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2CUSER', 'MAGAZINE_DATE_LOOKUP', options={"input_format": "csv"}) %}
        START_DATE      | END_DATE        | SKU_NO
        TO_DATE('2025-05-01') | TO_DATE('2025-05-31') | 34567
        TO_DATE('2025-05-01') | TO_DATE('2025-05-31') | 67890
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_PL', 'DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM | CUSTOMER_LOYALTY_CD
        'loyalty_1'               | 'loyalty_1'
        'loyalty_2'               | 'loyalty_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        TRANSACTION_END_TS         | NECTAR_CARD_NUM_HASH | TRANSACTION_ID | TRANSACTION_DT       | SALES_ORIGINATION_CHANNEL_CD
        TO_TIMESTAMP('2025-05-02') | 'loyalty_2'         | 'trans_1'      | TO_DATE('2025-05-02')| 14
        TO_TIMESTAMP('2025-05-03') | 'loyalty_2'         | 'trans_2'      | TO_DATE('2025-05-04')| 16
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT       | ITEM_CD | NET_RETAIL_SALES_AMT | ITEM_QTY | ITEM_SEQUENCE_NUM | STORE_CD
        'trans_2'      | TO_DATE('2025-05-03')| 12345   | 10.00                | 2        | 1                 | 'store_1'
        'trans_1'      | TO_DATE('2025-05-02')| 67890   | 15.00                | 1        | 1                 | 'store_2'
    {% endcall %}


    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE', options={"input_format": "csv"}) %}
        PRODUCT_TYPE  | UNIQUE_BRAND_NAME | ITEM_CD | CAMPAIGN_ID | CHANNEL_NAME       | SUBCHANNEL_NAME | LOAD_TS
        'Offer'      | 'Brand X'         | 12345   | 'nec_123'    | 'Sainsburys Magazine' | 'NA'  | TO_TIMESTAMP('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID |	TRANSACTION_KEY |	EVENT_DT |	EVENT_TS |	MARKETING_TYPE |	CHANNEL_NAME |	SUBCHANNEL_NAME |	CAMPAIGN_NAME |	CAMPAIGN_ID |	EVENT_NAME |	BOOKING_ID |ITEM_CD |	PRODUCT_TYPE |	UNIQUE_BRAND_NAME |	NET_SALES_AMT |	UNITS_QTY 
        'loyalty_2'|	'trans_2'|	TO_DATE('2025-05-03')|	TO_TIMESTAMP('2025-05-03')|	'NA'|	'In-store' |	'TXN' |	'CHECK' |	'nec_123' |	'Purchase Transaction' |'bid_1'  |	12345 |	'Offer' |	'Brand X' |	10 | 2
        'loyalty_2'|	'trans_2' |	TO_DATE('2025-05-02') |	TO_TIMESTAMP('2025-05-02') |'Magazine'|	'Sainsburys Magazine'|	'NA'| 'CHECK'|	'nec_123'|	'Touchpoint'|	'bid_1' |	 	0 |	'NA' |	'NA' |	0 |	0 
    {% endcall %}

{% endcall %}