{{ config(tags=['unit-test', 'instore_customer_data_test']) }}

{% call dbt_unit_testing.test('instore_customer_data', 'Test for instore_customer_data') %}
    
    {% call dbt_unit_testing.mock_ref('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_DURATION | CAMPAIGN_ID | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_NAME | CAMPAIGN_START_DT | CAMPAIGN_END_DT  | JOB_STATUS | LOAD_TS | JOB_RUN_ID  
        'bid_1'    | 'During' | 'camp_1'    | 'job_123'      | 'Offsite'         | 'Meta'       | 'NA'  | 'CHECK'| TO_DATE('2025-05-01') | TO_DATE('2025-05-31')  | 'Not Started'| TO_TIMESTAMP('2025-05-01') | 'job_run_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2C_PL', 'BASE_FINANCE_ASSETS_DATA', options={"input_format": "csv"}) %}
        ASSET_UNIQUE_ID    | CAMPAIGN_STATUS      | TIMEID | MEDIA_HOST_NAME | JOB_BAG_NUMBER | SERVICE_TYPE | ASSET_NAME_MEDIA_HOST_PRF_NAME
        '001-002-003'      | 'campaign completed' | 1      | 'brexville'    | 'nec_123'      | 'In-store'   | 'subchannel_1'
        '004-005-006'      | 'hfss unknown'       | 1      | 'brexville'    | 'nec_123'      | 'In-store'   | 'subchannel_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CUSTOMER_DATA_COLLECTION', options={"input_format": "csv"}) %}
        LOYALTY_ID | CAMPAIGN_ID | CHANNEL_NAME | SUBCHANNEL_NAME | MARKETING_TYPE | EVENT_DT
        'loyalty_1'| 'camp_1'    | 'In-store'   | 'subchannel_1'  | 'Marketing A'  | TO_DATE('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2CEVALS', 'IE_LOCATION', options={"input_format": "csv"}) %}
        LOCATION_KEY | MASTER_CAMPAIGN_ID | MEDIA_NO
        'loc_1'      | 'nec_123'           | 101
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CHANNEL_MAPPING', options={"input_format": "csv"}) %}
        MEDIA_NUMBER | SUBCHANNEL
        1       | 'Barkers'
    {% endcall %}

    
    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE', options={"input_format": "csv"}) %}
        PRODUCT_TYPE  | UNIQUE_BRAND_NAME | ITEM_CD | CAMPAIGN_ID | CHANNEL_NAME | SUBCHANNEL_NAME | LOAD_TS
        'Offer'      | 'Brand X'         | 12345   | 'nec_123'    | 'Barkers'       | 'NA'  | TO_TIMESTAMP('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_PL', 'DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM | CUSTOMER_LOYALTY_CD | HOUSEHOLD_NUM | CUSTOMER_ACCOUNT_TYPE_NAME 
        'loyalty_1'               | 'hash_loy_1'        | 4             | 'Nectar'
        'loyalty_2'               | 'hash_loy_2'        | 5             | 'Nectar'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        TRANSACTION_END_TS         | NECTAR_CARD_NUM_HASH | TRANSACTION_ID | TRANSACTION_DT       | SALES_ORIGINATION_CHANNEL_CD
        TO_TIMESTAMP('2025-05-03') | 'hash_loy_1'         | 'trans_1'      | TO_DATE('2025-05-03')| 14
        TO_TIMESTAMP('2025-05-03') | 'hash_loy_2'         | 'trans_2'      | TO_DATE('2025-05-04')| 16
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT       | ITEM_CD | NET_RETAIL_SALES_AMT | ITEM_QTY | ITEM_SEQUENCE_NUM | STORE_CD
        'trans_1'      | TO_DATE('2025-05-03')| 12345   | 10.00                | 2        | 1                 | 'loc_1'
        'trans_2'      | TO_DATE('2025-05-03')| 67890   | 15.00                | 1        | 1                 | 'loc_2'
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID |	TRANSACTION_KEY |	EVENT_DT |	EVENT_TS |	MARKETING_TYPE |	CHANNEL_NAME |	SUBCHANNEL_NAME |	CAMPAIGN_NAME |	CAMPAIGN_ID |	EVENT_NAME |	BOOKING_ID |ITEM_CD |	PRODUCT_TYPE |	UNIQUE_BRAND_NAME |	NET_SALES_AMT |	UNITS_QTY 
        'loyalty_1'|	'trans_1'|	TO_DATE('2025-05-03')|	TO_TIMESTAMP('2025-05-03')|	'NA'|	'In-store' |	'TXN' |	'CHECK' |	'nec_123' |	'Purchase Transaction' |'bid_1'  |	12345 |	'Offer' |	'Brand X' |	10 | 2
        'loyalty_1'|	'trans_1' |	TO_DATE('2025-05-03') |	TO_TIMESTAMP('2025-05-02 23:59:59.900000') |'In-store'|	'Barkers'|	'NA'| 'CHECK'|	'nec_123'|	'Touchpoint'|	'bid_1' |	 	0 |	'NA' |	'NA' |	0 |	0 
    {% endcall %}

{% endcall %}