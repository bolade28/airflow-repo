-- depends_on: {{ ref('measurement_campaign_execution') }}


{{ config(tags=['unit-test', 'meta_customer_data_test']) }}

{% call dbt_unit_testing.test('meta_customer_data', 'Test model meta_customer_data') %}

    {% call dbt_unit_testing.mock_ref ('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_DURATION | CAMPAIGN_ID | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_NAME | CAMPAIGN_START_DT | CAMPAIGN_END_DT  | JOB_STATUS | LOAD_TS | JOB_RUN_ID  
        'bid_1'    | 'During' | 'nec_123'    | 'nec_123'      | 'Offsite'         | 'Meta'       | 'NA'  | 'CHECK'| TO_DATE('2025-05-01') | TO_DATE('2025-05-31')  | 'Not Started'| TO_TIMESTAMP('2025-05-01') | 'job_run_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT', options={"input_format": "csv"}) %}
        DIGITAL_TRADING_AUDIENCE_GROUP_NK1 | RECORD_ARRIVAL_TS          | AUDIENCES_DATA                                                                   | MODELLED_AUDIENCES_DATA |JOB_BAG_ID
        'aud_group_1'                     | TO_TIMESTAMP('2025-05-01') | '[{"_id": "aud_1", "name": "Audience 1", "channels": [{"documentId": "doc_1"}]}]' | '[{"_id": "aud_1", "name": "Audience 1", "channels": [{"documentId": "doc_1"}]}]' | 'nec_123'
        'aud_group_2'                     | TO_TIMESTAMP('2025-05-02') | '[{"_id": "aud_2", "name": "Audience 2", "channels": [{"documentId": "doc_2"}]}]' | '[{"_id": "aud_2", "name": "Audience 2", "channels": [{"documentId": "doc_2"}]}]' | 'nec_123'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_CHANNEL_DMFBAS_LINK', options={"input_format": "csv"}) %}
        DIGITAL_TRADING_LINEITEM_CHANNEL_NK1 | DIGITAL_TRADING_LINEITEM_NK1 | DIGITAL_TRADING_CAMPAIGN_NK1 | RECORD_ARRIVAL_TS
        'lineitem_channel_1'                | 'lineitem_1'                 | 'campaign_1'                 | TO_TIMESTAMP('2025-05-03')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT',options={"input_format": "csv"}) %}
        DIGITAL_TRADING_CAMPAIGN_NK1 | JOB_BAG_ID | RECORD_ARRIVAL_TS
        'campaign_1'                | 'nec_123'   | TO_TIMESTAMP('2025-05-01') 
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_DMFBAS_SAT',options={"input_format": "csv"}) %}
        DIGITAL_TRADING_CAMPAIGN_NK1 | ADSET_NAME | RECORD_ARRIVAL_TS | DIGITAL_TRADING_LINEITEM_NK1 | TARGET_CUSTOM_AUDIENCE_LIST
        'campaign_1'                | 'ad_name'   | TO_TIMESTAMP('2025-05-01') | 'lineitem_1' | '[{"id": "dig_1"}]'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK',options={"input_format": "csv"}) %}
        DIGITAL_TRADING_AUDIENCE_CHANNEL_NK1 | DIGITAL_TRADING_AUDIENCE_NK1 | RECORD_ARRIVAL_TS
        'dig_1'                | 'doc_1'   | TO_TIMESTAMP('2025-05-01') 
    {% endcall %} 

    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE', options={"input_format": "csv"}) %}
        PRODUCT_TYPE  | UNIQUE_BRAND_NAME | ITEM_CD | CAMPAIGN_ID | CHANNEL_NAME | SUBCHANNEL_NAME | LOAD_TS
        'Offer'      | 'Brand X'         | 12345   | 'nec_123'    | 'Meta'       | 'NA'  | TO_TIMESTAMP('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_PL', 'DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM | CUSTOMER_LOYALTY_CD
        'loyalty_1'               | 'hash_loy_1'
        'loyalty_2'               | 'hash_loy_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        TRANSACTION_END_TS         | NECTAR_CARD_NUM_HASH | TRANSACTION_ID | TRANSACTION_DT       | SALES_ORIGINATION_CHANNEL_CD
        TO_TIMESTAMP('2025-05-03') | 'hash_loy_1'         | 'trans_1'      | TO_DATE('2025-05-03')| 14
        TO_TIMESTAMP('2025-05-04') | 'hash_loy_2'         | 'trans_2'      | TO_DATE('2025-05-04')| 16
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT       | ITEM_CD | NET_RETAIL_SALES_AMT | ITEM_QTY | ITEM_SEQUENCE_NUM | STORE_CD
        'trans_1'      | TO_DATE('2025-05-03')| 12345   | 10.00                | 2        | 1                 | 'store_1'
        'trans_2'      | TO_DATE('2025-05-04')| 67890   | 15.00                | 1        | 1                 | 'store_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('AB', 'AUDIENCE_SNAPSHOT_DEDUPED', options={"input_format": "csv"}) %}
        AUDIENCE_ID   | LOYALTY_ID
        'aud_1'       | 'loyalty_1'
        'aud_2'       | 'loyalty_2'
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID |	TRANSACTION_KEY |	EVENT_DT |	EVENT_TS |	MARKETING_TYPE |	CHANNEL_NAME |	SUBCHANNEL_NAME |	CAMPAIGN_NAME |	CAMPAIGN_ID |	EVENT_NAME |	BOOKING_ID |ITEM_CD |	PRODUCT_TYPE |	UNIQUE_BRAND_NAME |	NET_SALES_AMT |	UNITS_QTY 
        'loyalty_1'|	'trans_1'|	TO_DATE('2025-05-03')|	TO_TIMESTAMP('2025-05-03')|	'NA'|	'In-store' |	'TXN' |	'CHECK' |	'nec_123' |	'Purchase Transaction' |'bid_1'  |	12345 |	'Offer' |	'Brand X' |	10 | 2
        'loyalty_1'|	'trans_1' |	TO_DATE('2025-05-01') |	TO_TIMESTAMP('2025-05-01') |'Offsite'|	'Meta'|	'NA'| 'CHECK'|	'nec_123'|	'Touchpoint'|	'bid_1' |	 	0 |	'NA' |	'NA' |	0 |	0 
    {% endcall %}

{% endcall %}