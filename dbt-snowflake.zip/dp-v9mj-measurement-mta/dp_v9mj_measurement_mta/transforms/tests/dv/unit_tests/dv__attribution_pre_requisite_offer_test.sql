-- depends_on: {{ ref('measurement_campaign_execution') }}
-- depends_on: {{ ref('user_journey_offer') }}

{{ config(tags=['unit-test','attribution_pre_requisite_offer_test']) }}


{% call dbt_unit_testing.test ('attribution_pre_requisite_offer','Test model attribution_pre_requisite_offer') %}

    {% call dbt_unit_testing.mock_ref ('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | JOB_STATUS   | CAMPAIGN_DURATION
        'bid_1'    |'In-progress' | 'During'
        'bid_2'    |'Completed'   | 'During'
    {% endcall %}

    {% call dbt_unit_testing.mock_ref('user_journey_offer', options={"input_format": "csv"}) %}
        LOYALTY_ID | TRANSACTION_KEY | EVENT_DT              | EVENT_TS                                | CHANNEL_NAME       | SUBCHANNEL_NAME            | EVENT_NAME             | BOOKING_ID | CAMPAIGN_ID | SUB_PATH | USERJOURNEY_ID | RANK | POSITION     | ISCONVERSION | CAMPAIGN_DURATION | MARKETING_TYPE | NET_SALES_AMT | UNITS_QTY | JOURNEY_TYPE | LOAD_TS
        'lid_1'    | 'tk_1'          | TO_DATE('2023-05-19') | TO_TIMESTAMP('2023-05-19 17:02:39.000') | 'Coupon At Till'   | 'CaT (Bespoke 8p) - Print' | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_1'        | 1    | 'Initiator'  | 1            | 'During'          | 'Onsite'          | 0.0000     | 0.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')      
        'lid_1'    | 'tk_1'          | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Online'           | 'TXN'                      | 'Purchase Transaction' | 'bid_1'    | '290019'    | 1        | 'lid_1'        | 2    | 'Convertor'  | 1            | 'During'          | 'NA'              | 2.9200     | 1.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
        'lid_2'    | 'tk_2'          | TO_DATE('2023-05-19') | TO_TIMESTAMP('2023-05-19 17:02:39.000') | 'Coupon At Till'   | 'CaT (Bespoke 8p) - Print' | 'Touchpoint'           | 'bid_2'    | '290019'    | 1        | 'lid_1'        | 1    | 'Initiator'  | 1            | 'During'          | 'Onsite'          | 0.0000     | 0.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
        'lid_3'    | 'tk_2'          | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Online'           | 'TXN'                      | 'Purchase Transaction' | 'bid_2'    | '290019'    | 1        | 'lid_1'        | 2    | 'Convertor'  | 1            | 'During'          | 'NA'              | 2.9200     | 1.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
        'lid_4'    | 'tk_3'          | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-23 22:21:51.000') | 'Meta'             | 'Plant based + butter'     | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_4'        | 1    | 'Initiator'  | 1            | 'During'          | 'Offsite'         | 0.0000     | 0.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
        'lid_4'    | 'tk_3'          | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-24 22:21:51.000') | 'Meta'             | 'Plant based + butter'     | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_4'        | 2    | 'Assistor'   | 1            | 'During'          | 'Offsite'         | 0.0000     | 0.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
        'lid_4'    | 'tk_3'          | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 20:25:04.304') | 'In-store'         | 'TXN'                      | 'Purchase Transaction' | 'bid_1'    | '290019'    | 1        | 'lid_4'        | 3    | 'Convertor'  | 1            | 'During'          | 'NA'              | 5.8400     | 2.0000    | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000') 
    {% endcall %}

    {% call dbt_unit_testing.expect ({"input_format": "csv"}) %}
        LOYALTY_ID | CHANNEL_NAME     | SUBCHANNEL_NAME            | EVENT_TS                                | EVENT_NAME             | NET_SALES_AMT | JOURNEY_TYPE | TRANSACTION_KEY | CAMPAIGN_ID | BOOKING_ID | POSITION    | CAMPAIGN_DURATION | USERJOURNEY_ID | REGRESSION_VARIABLE                                                  | CUSTOMER_JOURNEY_TYPE | ISCONVERSION | MARKETING_TYPE
        'lid_1'    | 'Coupon At Till' | 'CaT (Bespoke 8p) - Print' | TO_TIMESTAMP('2023-05-19 17:02:39.000') | 'Touchpoint'           | 0.0000        | 'Offer'      | 'tk_1'          | '290019'    | 'bid_1'    | 'Initiator' | 'During'          | 'lid_1'        | 'Onsite_CouponSPCAtSPCTill_CaTSPCBespokeSPC8pSPCHASHSPCPrint_290019' | 'Direct'              | 1            | 'Onsite'
        'lid_1'    | 'Online'         | 'TXN'                      | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Purchase Transaction' | 2.9200        | 'Offer'      | 'tk_1'          | '290019'    | 'bid_1'    | 'Convertor' | 'During'          | 'lid_1'        | 'NA_Online_TXN_290019'                                               | 'Direct'              | 1            | 'NA'
        'lid_4'    | 'Meta'           | 'Plant based + butter'     | TO_TIMESTAMP('2023-05-23 22:21:51.000') | 'Touchpoint'           | 0.0000        | 'Offer'      | 'tk_3'          | '290019'    | 'bid_1'    | 'Initiator' | 'During'          | 'lid_4'        | 'Offsite_Meta_PlantSPCbasedSPCSPCbutter_290019'                      | 'Non-direct'          | 1            | 'Offsite'
        'lid_4'    | 'Meta'           | 'Plant based + butter'     | TO_TIMESTAMP('2023-05-24 22:21:51.000') | 'Touchpoint'           | 0.0000        | 'Offer'      | 'tk_3'          | '290019'    | 'bid_1'    | 'Assistor'  | 'During'          | 'lid_4'        | 'Offsite_Meta_PlantSPCbasedSPCSPCbutter_290019'                      | 'Non-direct'          | 1            | 'Offsite'
        'lid_4'    | 'In-store'       | 'TXN'                      | TO_TIMESTAMP('2023-05-31 20:25:04.304') | 'Purchase Transaction' | 5.8400        | 'Offer'      | 'tk_3'          | '290019'    | 'bid_1'    | 'Convertor' | 'During'          | 'lid_4'        | 'NA_InHASHstore_TXN_290019'                                          | 'Non-direct'          | 1            | 'NA'
    {% endcall %}

{% endcall %}