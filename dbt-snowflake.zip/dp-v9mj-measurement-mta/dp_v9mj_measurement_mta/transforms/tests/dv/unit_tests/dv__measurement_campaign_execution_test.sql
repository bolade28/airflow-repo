-- depends_on: {{ ref('unified_campaign') }}
-- depends_on: {{ ref('post_campaign_period') }}

{{
    config(
        tags=['unit-test']
    )
}}


{% call dbt_unit_testing.test('measurement_campaign_execution', 'Test model measurement_campaign_execution') %}

    {% call dbt_unit_testing.mock_ref ('measurement_campaign_execution', options={"input_format": "csv"}) %}
            BOOKING_ID | CAMPAIGN_DURATION | JOB_STATUS  | CAMPAIGN_ID    | CHANNEL_NAME     | SUBCHANNEL_NAME | JOB_BAG_NUMBER | MARKETING_TYPE | CAMPAIGN_NAME                   | CAMPAIGN_START_DT     | CAMPAIGN_END_DT
            'bid_1'    | 'During'          | 'no exec'   | 'nec24031148a' | 'Trolleys'       | 'NA'            |'nec24031148a'  | 'Onsite'       | 'C16-C17 Doritos In and In'     | to_date('2024-11-17') | to_date('2024-12-17')
            'bid_2'    | 'During'          | 'Completed' | 'nec24031148b' | 'Meta'           | 'NA'            |'nec24031148b'  | 'Offsite'      | 'C13: Doritos Gaming campaign'  | to_date('2024-11-17') | to_date('2024-12-17')
            'bid_3'    | 'During'          | 'Failed'    | 'nec24031148c' | 'Coupon At Till' | 'NA'            |'nec24031148c'  | 'In-store'     | 'C15_Elmlea_Veganuary'          | to_date('2024-11-17') | to_date('2024-12-17')
            'bid_3'    | 'Post'            | 'Failed'    | 'nec24031148c' | 'Coupon At Till' | 'NA'            |'nec24031148c'  | 'in-store'     | 'C15_Elmlea_Veganuary'          | to_date('2024-11-17') | to_date('2024-12-17')
    {% endcall %}

    {% call dbt_unit_testing.mock_ref('unified_campaign', options={"input_format": "csv"}) %}
        CAMPAIGN_ID    | BOOKING_ID                             | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_START_DT     | POST_CAMPAIGN_DT       | CAMPAIGN_END_DT       |  ITEM_CD_LIST              | CAMPAIGN_NAME                  | CAMPAIGN_STATUS
        'nec24031148b' | 'bid_2' | 'nec24031148b' | 'Offsite'      | 'Meta'       | 'NA'            | to_date('2024-11-17') | to_date('2024-12-17')  | to_date('2024-12-17') | '8206285,3432181,6315011' | 'C13: Doritos Gaming campaign' | 'Completed'
    {% endcall %}

    {% call dbt_unit_testing.mock_ref ('post_campaign_period', options={"input_format": "csv"}) %}
            ITEM_CD   | MEDIAN_PROPOSED_BUCKET_WK
            '8206285' | 2
            '3432181' | 4
    {% endcall %}


    {% call dbt_unit_testing.expect() %}
        SELECT 'nec24031148b' AS CAMPAIGN_ID,
               'bid_2' AS BOOKING_ID,
               'nec24031148b' AS JOB_BAG_NUMBER,
               'Offsite' AS MARKETING_TYPE,
               'Meta' AS CHANNEL_NAME,
               'NA' AS SUBCHANNEL_NAME,
               'C13 Doritos Gaming campaign' AS CAMPAIGN_NAME,
               CAST('2024-11-17' AS DATE) AS CAMPAIGN_START_DT,
               CAST('2024-12-17' AS DATE) AS CAMPAIGN_END_DT,
               'Not Started' AS JOB_STATUS,
               'Post' AS CAMPAIGN_DURATION
    {% endcall %}

{% endcall %}
