{{ config(tags=['unit-test', 'coupon_at_till_customer_data_test']) }}

{% call dbt_unit_testing.test('coupon_at_till_customer_data', 'Test for get_coupon_at_till_customer_data') %}

    {% call dbt_unit_testing.mock_ref('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_DURATION | CAMPAIGN_ID | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_NAME | CAMPAIGN_START_DT | CAMPAIGN_END_DT  | JOB_STATUS | LOAD_TS | JOB_RUN_ID  
        'bid_1'    | 'During' | 'camp_1'    | 'nec_123'      | 'Targeted Media'         | 'Coupon At Till'       | 'CaT Bespoke 8p'  | 'CHECK'| TO_DATE('2025-05-01') | TO_DATE('2025-05-31')  | 'Not Started'| TO_TIMESTAMP('2025-05-01') | 'job_run_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2C_CMPGN_PL', 'CELL', options={"input_format": "csv"}) %}
        CELL_KEY | CAMPAIGN_ID
        'cell_1' | 'camp_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2C_CMPGN_PL', 'COUPON_CELL', options={"input_format": "csv"}) %}
        CELL_KEY | COUPON_KEY
        'cell_1' | 'coupon_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('INC_PL', 'POINTS_COUPON_REDEMPTION', options={"input_format": "csv"}) %}
        TRANSACTION_KEY | COUPON_ID | DATE_KEY
        'trans_1' | '12345678901234' | '2025-05-01'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2C_CMPGN_PL', 'COUPON', options={"input_format": "csv"}) %}
        COUPON_KEY | COUPON_ID | DATE_KEY
        'coupon_1' | '12345678901234' | '2025-05-01'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2C_CMPGN_PL', 'CAT_PLAN_DATA', options={"input_format": "csv"}) %}
        CAMPAIGNCODE | OFFERBARCODE
        'camp_1'     | '12345678901234'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_CUSTOMER_INTERACTIONS_PL', 'FACT_COUPON_AT_TILL', options={"input_format": "csv"}) %}
        HASH_LOYALTY_ID | COUPON_PRINT_DT | COUPON_PRINT_TM | BARCODE
        'loyalty_1'    | '2025-05-01'    | '10:00:00'      | '12345678901234'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        TRANSACTION_END_TS         | NECTAR_CARD_NUM_HASH | TRANSACTION_ID | TRANSACTION_DT       | SALES_ORIGINATION_CHANNEL_CD | TRANSACTION_KEY
        TO_TIMESTAMP('2025-05-03') | 'hash_loy_1'         | 'trans_1'      | TO_DATE('2025-05-03')| 14              | 'trans_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT       | ITEM_CD | NET_RETAIL_SALES_AMT | ITEM_QTY | ITEM_SEQUENCE_NUM | STORE_CD
        'trans_1'      | TO_DATE('2025-05-03')| 12345   | 10.00                | 1        | 1                 | 'store_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE', options={"input_format": "csv"}) %}
        PRODUCT_TYPE  | UNIQUE_BRAND_NAME | ITEM_CD | CAMPAIGN_ID | CHANNEL_NAME       | SUBCHANNEL_NAME | LOAD_TS
        'Offer'      | 'Brand X'         | 12345   | 'camp_1'    | 'Coupon At Till'  | 'CaT Bespoke 8p'  | TO_TIMESTAMP('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_PL', 'DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM | CUSTOMER_LOYALTY_CD
        'loyalty_1'               | 'hash_loy_1'
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID |	TRANSACTION_KEY |	EVENT_DT |	EVENT_TS |	MARKETING_TYPE |	CHANNEL_NAME |	SUBCHANNEL_NAME |	CAMPAIGN_NAME |	CAMPAIGN_ID |	EVENT_NAME |	BOOKING_ID |ITEM_CD |	PRODUCT_TYPE |	UNIQUE_BRAND_NAME |	NET_SALES_AMT |	UNITS_QTY 
        'loyalty_1'|	'trans_1'|	TO_DATE('2025-05-03')|	TO_TIMESTAMP('2025-05-03')|	'NA'|	'In-store' |	'TXN' |	'CHECK' |	'camp_1' |	'Purchase Transaction' |'bid_1'  |	12345 |	'Offer' |	'Brand X' |	10 | 1
        'loyalty_1'|	'trans_1' |	TO_DATE('2025-05-01') |	TO_TIMESTAMP('2025-05-01 10:00:00') |'Targeted Media'|	'Coupon At Till'|	'CaT Bespoke 8p'| 'CHECK'|	'camp_1'|	'Touchpoint'|	'bid_1' |	 	0 |	'NA' |	'NA' |	0 |	0 
    {% endcall %}

{% endcall %}