{{ config(tags=['unit-test','post_campaign_period_test'], test_values=[2023]) }}

{% call dbt_unit_testing.test ('post_campaign_period', 'Test for post_campaign_period') %}

    {% set current_month = run_started_at.strftime("%m") %}

    {% call dbt_unit_testing.mock_source ('ADW_UNIFIED_PLATFORM_TACTICAL','EAN_BR', options={"input_format": "csv"}) %}
        ITEM_NK1 | BRAND_NAME  | BRAND_OWNER_NAME | LOAD_TS                             | VALID_FROM_DT         | VALID_TO_DT           | record_deleted_flag
        8206285  | 'Avian'     | 'Avian Limited'  | TO_TIMESTAMP('2024-01-03 11:33:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        8206287  | 'Avian'     | 'Avian Limited'  | TO_TIMESTAMP('2024-01-01 11:33:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        8206291  | 'Sparklers' | 'Own Label'      | TO_TIMESTAMP('2024-01-01 14:20:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        123562   | 'Buxton'    | 'Nestle'         | TO_TIMESTAMP('2024-01-03 10:30:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        783287   | 'Avian'     | 'Avian Limited'  | TO_TIMESTAMP('2024-01-02 10:30:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        783287   | 'Avian'     | 'Avian Limited'  | TO_TIMESTAMP('2024-01-03 12:00:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'N'
        6345233  | 'Avian'     | 'Avian Limited'  | TO_TIMESTAMP('2024-01-01 10:30:00') | TO_DATE('2022-01-30') | TO_DATE('9999-12-31') | 'Y'
    {% endcall %}

    {% call dbt_unit_testing.mock_source ('ADW_PRODUCT_PL','DIM_ITEM', options={"input_format": "csv"}) %}
        ITEM_CD  | ITEM_NAME             | SUPER_CAT_NAME   | SUB_CAT_NAME      | ITEM_SHORT_NAME
        8206285  | 'Sparkle Water 300ml' | 'Soft Drinks'    | 'Sparkling Water' | 'Avian 6x300ml'
        8206287  | 'Sparkle Water 600ml' | 'Soft Drinks'    | 'Sparkling Water' | 'Avian spr wtr'
        8206291  | 'Sparkle Water 1.5l'  | 'Soft Drinks'    | 'Sparkling Water' | 'Sparkling Water with Cherry'
        123562   | 'Sparkle Water 1l'    | 'Soft Drinks'    | 'Sparkling Water' | 'Buxton mm wtr'
        783287   | 'Premium Water 2l'    | 'Soft Drinks'    | 'Still Water'     | 'Avian P Water 2l'
    {% endcall %}

    {% call dbt_unit_testing.mock_source ('ADW_SALES_PL','FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT        | ITEM_CD
        'tid_1'        | to_date('2024-01-15') | 8206285
        'tid_2'        | to_date('2024-01-12') | 8206287
        'tid_3'        | to_date('2024-01-20') | 8206291
        'tid_4'        | to_date('2024-01-04') | 123562
        'tid_5'        | to_date('2024-01-19') | 783287
        'tid_6'        | to_date('2024-02-01') | 8206285
        'tid_7'        | to_date('2024-02-12') | 8206287
        'tid_8'        | to_date('2024-02-02') | 8206291
        'tid_9'        | to_date('2024-02-04') | 123562
        'tid_10'       | to_date('2024-01-21') | 783287
        'tid_11'       | to_date('2024-02-25') | 8206285
        'tid_12'       | to_date('2024-03-10') | 8206287
        'tid_13'       | to_date('2024-03-01') | 8206291
        'tid_14'       | to_date('2024-03-19') | 123562
        'tid_15'       | to_date('2024-01-24') | 783287
        'tid_16'       | to_date('2024-03-10') | 8206285
        'tid_17'       | to_date('2024-04-20') | 8206287
        'tid_18'       | to_date('2024-04-01') | 8206291
        'tid_19'       | to_date('2024-04-03') | 123562
        'tid_20'       | to_date('2024-01-27') | 783287
        'tid_21'       | to_date('2024-01-14') | 8206285
        'tid_22'       | to_date('2024-01-13') | 8206287
        'tid_23'       | to_date('2024-01-21') | 8206291
        'tid_24'       | to_date('2024-01-03') | 123562
        'tid_25'       | to_date('2024-01-12') | 783287
        'tid_26'       | to_date('2024-02-06') | 8206285
        'tid_27'       | to_date('2024-02-24') | 8206287
        'tid_28'       | to_date('2024-02-07') | 8206291
        'tid_29'       | to_date('2024-02-06') | 123562
        'tid_30'       | to_date('2024-01-29') | 783287
        'tid_31'       | to_date('2024-03-29') | 8206285
        'tid_32'       | to_date('2024-03-10') | 8206287
        'tid_33'       | to_date('2024-03-20') | 8206291
        'tid_34'       | to_date('2024-02-26') | 123562
        'tid_35'       | to_date('2024-02-04') | 783287
        'tid_36'       | to_date('2024-04-02') | 8206285
        'tid_37'       | to_date('2024-04-20') | 8206287
        'tid_38'       | to_date('2024-04-01') | 8206291
        'tid_39'       | to_date('2024-03-03') | 123562
        'tid_40'       | to_date('2024-02-07') | 783287
    {% endcall %}

    {% call dbt_unit_testing.mock_source ('ADW_PL','DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM
        'ncc_num_1'
        'ncc_num_2'
        'ncc_num_3'
        'ncc_num_4'
        'ncc_num_5'
    {% endcall %}

    {% call dbt_unit_testing.mock_source ('ADW_SALES_PL','FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        NECTAR_CARD_NUM_HASH | TRANSACTION_ID
        'ncc_num_1'          | 'tid_1'
        'ncc_num_2'          | 'tid_2'
        'ncc_num_3'          | 'tid_3'
        'ncc_num_4'          | 'tid_4'
        'ncc_num_5'          | 'tid_5'
        'ncc_num_1'          | 'tid_6'
        'ncc_num_2'          | 'tid_7'
        'ncc_num_3'          | 'tid_8'
        'ncc_num_4'          | 'tid_9'
        'ncc_num_5'          | 'tid_10'
        'ncc_num_1'          | 'tid_11'
        'ncc_num_2'          | 'tid_12'
        'ncc_num_3'          | 'tid_13'
        'ncc_num_4'          | 'tid_14'
        'ncc_num_5'          | 'tid_15'
        'ncc_num_1'          | 'tid_16'
        'ncc_num_2'          | 'tid_17'
        'ncc_num_3'          | 'tid_18'
        'ncc_num_4'          | 'tid_19'
        'ncc_num_5'          | 'tid_20'
        'ncc_num_1'          | 'tid_25'
        'ncc_num_1'          | 'tid_30'
        'ncc_num_2'          | 'tid_35'
        'ncc_num_2'          | 'tid_40'
        'ncc_num_3'          | 'tid_21'
        'ncc_num_3'          | 'tid_26'
        'ncc_num_5'          | 'tid_31'
        'ncc_num_1'          | 'tid_23'
        'ncc_num_1'          | 'tid_28'
        'ncc_num_1'          | 'tid_33'
        'ncc_num_1'          | 'tid_38'
        'ncc_num_5'          | 'tid_22'
        'ncc_num_5'          | 'tid_27'
        'ncc_num_5'          | 'tid_32'
        'ncc_num_5'          | 'tid_37'
        'ncc_num_1'          | 'tid_24'
        'ncc_num_2'          | 'tid_29'
        'ncc_num_3'          | 'tid_34'
        'ncc_num_4'          | 'tid_39'
        'ncc_num_5'          | 'tid_36'
    {% endcall %}

    {% call dbt_unit_testing.mock_source ('ADW_PL','LOYALTY_SEGMENTS', options={"input_format": "csv"}) %}
        BATCH_ID     | LOYALTY_SEG | ENTERPRISE_CUSTOMER_NUM
        'ncc_num_1'  | 'GO'        | 'ncc_num_1'
        'ncc_num_2'  | 'PL'        | 'ncc_num_2'
        'ncc_num_3'  | 'PL'        | 'ncc_num_3'
        'ncc_num_4'  | 'BR'        | 'ncc_num_4'
        'ncc_num_5'  | 'GO'        | 'ncc_num_5'
    {% endcall %}

    {% if current_month == '01' %}
        {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
            SUPER_CAT_NAME | ITEM_SHORT_NAME               | ITEM_CD | MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS | TIME_PERIOD_70_PCT_DAYS | TIME_PERIOD_80_PCT_DAYS | TIME_PERIOD_90_PCT_DAYS | MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK | TIME_PERIOD_70_PCT_WK | TIME_PERIOD_80_PCT_WK | TIME_PERIOD_90_PCT_WK | MEDIAN_PROPOSED_BUCKET_WK | YEAR_OF_TRANSACTION
            'Soft Drinks'  | 'Avian 6x300ml'               | 8206285 | 17.000                                | 21.800                  | 23.200                  | 23.600                  | 3                                          | 4                     | 4                     | 4                     | 2                         | 2024
            'Soft Drinks'  | 'Avian spr wtr'               | 8206287 | 36.000                                | 41.000                  | 41.000                  | 41.500                  | 6                                          | 6                     | 6                     | 6                     | 12                        | 2024
            'Soft Drinks'  | 'Sparkling Water with Cherry' | 8206291 | 22.500                                | 29.500                  | 31.000                  | 36.500                  | 4                                          | 5                     | 5                     | 6                     | 4                         | 2024
            'Soft Drinks'  | 'Avian P Water 2l'            | 783287  | 3.000                                 | 3.000                   | 5.800                   | 11.399                  | 1                                          | 1                     | 1                     | 2                     | 2                         | 2024
        {% endcall %}
    {% else %}
        {% call dbt_unit_testing.expect() %}
            SELECT
                CAST(NULL AS VARCHAR) AS super_cat_name,
                CAST(NULL AS VARCHAR) AS item_short_name,
                CAST(NULL AS NUMBER) AS item_cd,
                CAST(NULL AS NUMBER) AS median_time_between_transactions_days,
                CAST(NULL AS NUMBER) AS time_period_70_pct_days,
                CAST(NULL AS NUMBER) AS time_period_80_pct_days,
                CAST(NULL AS NUMBER) AS time_period_90_pct_days,
                CAST(NULL AS NUMBER) AS median_time_period_between_transactions_wk,
                CAST(NULL AS NUMBER) AS time_period_70_pct_wk,
                CAST(NULL AS NUMBER) AS time_period_80_pct_wk,
                CAST(NULL AS NUMBER) AS time_period_90_pct_wk,
                CAST(NULL AS NUMBER) AS median_proposed_bucket_wk,
                CAST('{{ invocation_id }}' AS VARCHAR) AS job_run_id,
                CAST(NULL AS TIMESTAMP_NTZ) AS load_ts,
                CAST(NULL AS NUMBER) AS year_of_transaction
            WHERE false
        {% endcall %}
    {% endif %}
{% endcall %}
