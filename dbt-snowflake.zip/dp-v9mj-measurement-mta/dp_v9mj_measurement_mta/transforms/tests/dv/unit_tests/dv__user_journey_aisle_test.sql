-- depends_on: {{ ref('measurement_campaign_execution') }}
-- depends_on: {{ ref('customer_data_collection') }}
-- depends_on: {{ ref('campaign_product_type') }}

{{ config(tags=['unit-test', 'user_journey_aisle_test']) }}

{% call dbt_unit_testing.test('user_journey_aisle', 'Test model user_journey_aisle') %}

    {% call dbt_unit_testing.mock_ref('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | JOB_STATUS    | CAMPAIGN_DURATION
        'bid_1'    | 'In-progress' | 'During'
        'bid_2'    | 'Completed'   | 'Post'
    {% endcall %}

    {% call dbt_unit_testing.mock_ref('customer_data_collection', options={"input_format": "csv"}) %}
        LOYALTY_ID | TRANSACTION_KEY | EVENT_DT              | EVENT_TS                                | CHANNEL_NAME     | SUBCHANNEL_NAME            | CAMPAIGN_NAME            | CAMPAIGN_ID | EVENT_NAME             | BOOKING_ID | ITEM_CD | PRODUCT_TYPE | NET_SALES_AMT | UNITS_QTY | MARKETING_TYPE | LOAD_TS
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-23 22:21:51.000') | 'Meta'           | 'Plant based + butter'     | 'C10_Flora_Plant_Butter' | '290019'    | 'Touchpoint'           | 'bid_1'    | 0       | 'NA'         | 0.0000        | 0.0000    | 'Offsite'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-24 22:21:51.000') | 'Meta'           | 'Plant based + butter'     | 'C10_Flora_Plant_Butter' | '290019'    | 'Touchpoint'           | 'bid_1'    | 0       | 'NA'         | 0.0000        | 0.0000    | 'Offsite'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 20:25:04.304') | 'In-store'       | 'TXN'                      | 'C10_Flora_Plant_Butter' | '290019'    | 'Purchase Transaction' | 'bid_1'    | 783287  | 'Aisle'      | 5.8400        | 2.0000    | 'NA'           | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_2'    | 'tid_2'         | TO_DATE('2023-05-19') | TO_TIMESTAMP('2023-05-19 17:02:39.000') | 'Coupon At Till' | 'CaT (Bespoke 8p) - Print' | 'C10_Flora_Plant_Butter' | '290019'    | 'Touchpoint'           | 'bid_1'    | 0       | 'NA'         | 0.0000        | 0.0000    | 'Onsite'       | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_2'    | 'tid_2'         | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Online'         | 'TXN'                      | 'C10_Flora_Plant_Butter' | '290019'    | 'Purchase Transaction' | 'bid_1'    | 857443  | 'Aisle'      | 2.9200        | 1.0000    | 'NA'           | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_3'    | 'NA'            | TO_DATE('2023-06-01') | TO_TIMESTAMP('2023-06-01 19:25:04.304') | 'Meta'           | 'Healthier Spreads'        | 'C10_Flora_Plant_Butter' | '290019'    | 'Touchpoint'           | 'bid_1'    | 0       | 'NA'         | 0.0000        | 0.0000    | 'Offsite'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'lid_4'    | 'tid_3'         | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Online'         | 'TXN'                      | 'C10_Flora_Plant_Butter' | '290019'    | 'Purchase Transaction' | 'bid_1'    | 125490  | 'Offer'      | 2.9200        | 1.0000    | 'NA'           | TO_TIMESTAMP('2023-05-23 22:21:51.000')
    {% endcall %}

    {% call dbt_unit_testing.mock_ref('campaign_product_type', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_ID | CHANNEL_NAME     | ITEM_CD | PRODUCT_TYPE | LOAD_TS
        'bid_1'    | '290019'    | 'Meta'           | 783287  | 'Aisle'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'bid_1'    | '290019'    | 'Coupon At Till' | 857443  | 'Aisle'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
        'bid_1'    | '290019'    | 'Coupon At Till' | 125490  | 'Offer'      | TO_TIMESTAMP('2023-05-23 22:21:51.000')
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID | TRANSACTION_KEY | EVENT_DT              | EVENT_TS                                | CHANNEL_NAME       | SUBCHANNEL_NAME            | EVENT_NAME             | BOOKING_ID | CAMPAIGN_ID | SUB_PATH | USERJOURNEY_ID | RANK | POSITION    | ISCONVERSION | CAMPAIGN_DURATION | MARKETING_TYPE | NET_SALES_AMT | UNITS_QTY | JOURNEY_TYPE
        'lid_2'    | 'tid_2'         | TO_DATE('2023-05-19') | TO_TIMESTAMP('2023-05-19 17:02:39.000') | 'Coupon At Till'   | 'CaT (Bespoke 8p) - Print' | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_2_1'      | 1    | 'Initiator' | 1            | 'During'          | 'Onsite'       | 0.0000        | 0.0000    | 'Aisle'
        'lid_2'    | 'tid_2'         | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 22:25:04.304') | 'Online'           | 'TXN'                      | 'Purchase Transaction' | 'bid_1'    | '290019'    | 1        | 'lid_2_1'      | 2    | 'Convertor' | 1            | 'During'          | 'NA'           | 2.9200        | 1.0000    | 'Aisle'
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-23 22:21:51.000') | 'Meta'             | 'Plant based + butter'     | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_1_1'      | 1    | 'Initiator' | 1            | 'During'          | 'Offsite'      | 0.0000        | 0.0000    | 'Aisle'
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-24') | TO_TIMESTAMP('2023-05-24 22:21:51.000') | 'Meta'             | 'Plant based + butter'     | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_1_1'      | 2    | 'Assistor'  | 1            | 'During'          | 'Offsite'      | 0.0000        | 0.0000    | 'Aisle'
        'lid_1'    | 'tid_1'         | TO_DATE('2023-05-31') | TO_TIMESTAMP('2023-05-31 20:25:04.304') | 'In-store'         | 'TXN'                      | 'Purchase Transaction' | 'bid_1'    | '290019'    | 1        | 'lid_1_1'      | 3    | 'Convertor' | 1            | 'During'          | 'NA'           | 5.8400        | 2.0000    | 'Aisle'
        'lid_3'    | 'NA'            | TO_DATE('2023-06-01') | TO_TIMESTAMP('2023-06-01 19:25:04.304') | 'Meta'             | 'Healthier Spreads'        | 'Touchpoint'           | 'bid_1'    | '290019'    | 1        | 'lid_3_1'      | 1    | 'Initiator' | 0            | 'During'          | 'Offsite'      | 0.0000        | 0.0000    | 'Aisle'
    {% endcall %}

{% endcall %}