{{ config(tags=['unit-test', 'ecoupon_customer_data_test']) }}

{% call dbt_unit_testing.test('ecoupon_customer_data', 'Test for ecoupon_customer_data') %}

    {% call dbt_unit_testing.mock_ref('measurement_campaign_execution', options={"input_format": "csv"}) %}
        BOOKING_ID | CAMPAIGN_DURATION | CAMPAIGN_ID | JOB_BAG_NUMBER | MARKETING_TYPE | CHANNEL_NAME | SUBCHANNEL_NAME | CAMPAIGN_NAME | CAMPAIGN_START_DT | CAMPAIGN_END_DT  | JOB_STATUS | LOAD_TS | JOB_RUN_ID  
        'bid_1'    | 'During' | 'camp_1'    | 'nec_123'      | 'Offsite'         | 'eCoupons'       | 'NA'  | 'CHECK'| TO_DATE('2025-05-01') | TO_DATE('2025-05-31')  | 'Not Started'| TO_TIMESTAMP('2025-05-01') | 'job_run_1'
    {% endcall %}


    {% call dbt_unit_testing.mock_source('I2CEVALS', 'OC_CAMPAIGN', options={"input_format": "csv"}) %}
        CAMPAIGN_ID | LOYALTY_SERVICE_CAMPAIGN_ID
        'nec_123'    | 'loy_serv_1'
        'nec_123'    | 'loy_serv_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('I2CEVALS', 'OC_CUSTOMER_SELECTION', options={"input_format": "csv"}) %}
        CAMPAIGN_ID | COUPON_ID | STATUS
        'nec_123'    | 'coupon_1' | 2
        'nec_123'    | 'coupon_2' | 2
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_CUSTOMER_INTERACTIONS_PL', 'DIM_CAMPAIGN', options={"input_format": "csv"}) %}
        BARCODE    | LOYALTY_SERVICE_CAMPAIGN_ID
        'coupon_1' | 'loy_serv_1'
        'coupon_2' | 'loy_serv_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_CUSTOMER_INTERACTIONS_PL', 'FLF_CAMPAIGN_EVENT', options={"input_format": "csv"}) %}
        LOYALTY_ID | APPLIED_STATE | EVENT_UTC_TS          | ONLINE_ORDER_NUM       | LOYALTY_SERVICE_CAMPAIGN_ID
        'loyalty_1'| 'redeemed'    | TO_TIMESTAMP('2025-05-01 10:00:00') | 'order_1' | 'loy_serv_1'
        'loyalty_2'| 'loaded'      | TO_TIMESTAMP('2025-05-02 12:00:00') | 'order_2' | 'loy_serv_2'
        'loyalty_1'| 'loaded'    | TO_TIMESTAMP('2025-05-01 9:00:00') | 'order_1' | 'loy_serv_1'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET', options={"input_format": "csv"}) %}
        TRANSACTION_END_TS         | NECTAR_CARD_NUM_HASH | TRANSACTION_ID | TRANSACTION_DT       | SALES_ORIGINATION_CHANNEL_CD | ORDER_NUMBER 
        TO_TIMESTAMP('2025-05-03') | 'loyalty_1'         | 'trans_1'      | TO_DATE('2025-05-03')| 17                          | 'order_1'                           
        TO_TIMESTAMP('2025-05-04') | 'loyalty_2'         | 'trans_2'      | TO_DATE('2025-05-04')| 17                           | 'order_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM', options={"input_format": "csv"}) %}
        TRANSACTION_ID | TRANSACTION_DT       | ITEM_CD | NET_RETAIL_SALES_AMT | ITEM_QTY | ITEM_SEQUENCE_NUM | STORE_CD
        'trans_1'      | TO_DATE('2025-05-03')| 12345   | 10.00                | 1        | 1                 | 'store_1'
        'trans_2'      | TO_DATE('2025-05-04')| 67890   | 5.00                 | 2        | 1                 | 'store_2'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE', options={"input_format": "csv"}) %}
        PRODUCT_TYPE  | UNIQUE_BRAND_NAME | ITEM_CD | CAMPAIGN_ID | CHANNEL_NAME | SUBCHANNEL_NAME | LOAD_TS
        'Offer'      | 'Brand X'         | 12345   | 'nec_123'    | 'eCoupons'  | 'Sampling ecoupon'  | TO_TIMESTAMP('2025-05-01')
        'Offer'      | 'Brand X'         | 67890   | 'nec_123'    | 'eCoupons'  | 'Sampling ecoupon'  | TO_TIMESTAMP('2025-05-01')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_PL', 'DIM_CUSTOMER_LOYALTY', options={"input_format": "csv"}) %}
        NECTAR_COLLECTOR_CARD_NUM | CUSTOMER_LOYALTY_CD
        'loyalty_1'               | 'hash_1'
        'loyalty_2'               | 'hash_2'
    {% endcall %}

    {% call dbt_unit_testing.expect({"input_format": "csv"}) %}
        LOYALTY_ID |	TRANSACTION_KEY |	EVENT_DT |	EVENT_TS |	MARKETING_TYPE |	CHANNEL_NAME |	SUBCHANNEL_NAME |	CAMPAIGN_NAME |	CAMPAIGN_ID |	EVENT_NAME |	BOOKING_ID |ITEM_CD |	PRODUCT_TYPE |	UNIQUE_BRAND_NAME |	NET_SALES_AMT |	UNITS_QTY 
        'loyalty_2' |	'trans_2' |	TO_DATE('2025-05-04') |	TO_TIMESTAMP('2025-05-04')  | 'NA' | 'Online' |	'TXN' |	'CHECK' |	'nec_123' |	'Purchase Transaction' |'bid_1' | 67890 |	'Offer'  |	'Brand X' |	5 |	2
        'loyalty_1' |	'trans_1' |	TO_DATE('2025-05-03') |	TO_TIMESTAMP('2025-05-03')  |'NA' |	'Online' |	'TXN' | 'CHECK' |	'nec_123' |	'Purchase Transaction' |'bid_1' | 12345 |	'Offer'   |	'Brand X' |	10 |1
        'loyalty_1' |	'trans_1' |	TO_DATE('2025-05-01') |	TO_TIMESTAMP('2025-05-01 9:00:00') |'Onsite'| 'eCoupons'| 'Sampling ecoupon'|'CHECK'| 'nec_123'|	'Touchpoint'|	'bid_1'|	0 |	'NA' |	'NA' |0 |0
        'loyalty_2' |	'trans_2' |	TO_DATE('2025-05-02') |	TO_TIMESTAMP('2025-05-02 12:00:00') | 'Onsite'| 'eCoupons'|'Sampling ecoupon'|'CHECK'| 'nec_123'|	'Touchpoint'|	'bid_1'| 	0 |	'NA' | 'NA'	|0	| 0
    {% endcall %}

{% endcall %}