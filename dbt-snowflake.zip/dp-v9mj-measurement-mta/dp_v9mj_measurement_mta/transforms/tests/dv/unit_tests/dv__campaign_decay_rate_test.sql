-- depends_on: {{ ref('measurement_campaign_execution') }}


{{ config(tags=['unit-test','campaign_decay_rate_test']) }}

{% set column_transformations = {
  "offsite_impressions_pct": "round(##column##, 3)"
} %}

{% call dbt_unit_testing.test ('campaign_decay_rate', options={"column_transformations": column_transformations}) %}

    {% call dbt_unit_testing.mock_ref ('measurement_campaign_execution', options={"input_format": "csv"}) %}
        JOB_BAG_NUMBER | CHANNEL_NAME | CAMPAIGN_START_DT     | CAMPAIGN_END_DT       | JOB_STATUS    | CAMPAIGN_DURATION
        'nec24031148a' | 'Meta'       | TO_DATE('2024-09-11') | TO_DATE('2024-09-13') | 'In-progress' | 'During'
        'nec24031148b' | 'DV360'      | TO_DATE('2024-09-11') | TO_DATE('2024-09-12') | 'In-progress' | 'During'
        'nec24031148c' | 'YouTube'    | TO_DATE('2024-09-11') | TO_DATE('2024-09-15') | 'In-progress' | 'During'
        'nec24031148d' | 'DV360'      | TO_DATE('2024-09-11') | TO_DATE('2024-10-22') | 'In-progress' | 'Post'
        'nec24031148e' | 'YouTube'    | TO_DATE('2024-09-11') | TO_DATE('2024-10-22') | 'Not started' | 'During'
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV','DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK') %}
        SELECT '678a3b8ac5f255d2710d8e8a' AS DIGITAL_TRADING_CAMPAIGN_NK1,
                TO_DATE('2024-09-11') AS REPORTING_START_DT,
                TO_DATE('2024-09-11') AS REPORTING_END_DT,
                TO_TIMESTAMP('2024-07-08 14:57:11.347') AS RECORD_ARRIVAL_TS,
                '{
                    "conversion": {
                        "acquired": 236,
                        "instore": 440,
                        "lapsed": 32,
                        "online": 96,
                        "percentage": 0.006021,
                        "retained": 268,
                        "totals": 536
                    },
                    "engagement": {
                        "comments": 1,
                        "post_engagements": 7619,
                        "post_reactions": 2,
                        "shares": 0
                    },
                    "externals": {
                        "cpa": 0,
                        "media_spend": 761.685
                    },
                    "internals": {
                        "cpa": 0.355914,
                        "cpm_actual": 1.878434,
                        "cpm_booked": 7.5,
                        "media_spend": 190.77
                    },
                    "sales": {
                        "instore": 957.4,
                        "online": 247.8,
                        "spend_per_customer": 2.248507,
                        "total": 1205.2
                    },
                    "summary": {
                        "clicks": 162,
                        "conversionRate": 0.0060208483105679365,
                        "ctr": 0.001595,
                        "frequency": 1.140793,
                        "impressions": 1000,
                        "reach": 89024
                    },
                    "video": {
                        "cost_per_completed_view": 0.07256371243818943,
                        "video_completed_views": 2629,
                        "video_completion_rate": 0.02588668544083184,
                        "video_views": 7545
                    }
                }'::VARIANT AS MEASURES
        UNION ALL
        SELECT '678a3b8ac5f255d2710d8e8a' AS DIGITAL_TRADING_CAMPAIGN_NK1,
                TO_DATE('2024-09-12') AS REPORTING_START_DT,
                TO_DATE('2024-09-12') AS REPORTING_END_DT,
                TO_TIMESTAMP('2024-07-08 14:57:11.347') AS RECORD_ARRIVAL_TS,
                '{
                    "conversion": {
                        "acquired": 236,
                        "instore": 440,
                        "lapsed": 32,
                        "online": 96,
                        "percentage": 0.006021,
                        "retained": 268,
                        "totals": 536
                    },
                    "engagement": {
                        "comments": 1,
                        "post_engagements": 7619,
                        "post_reactions": 2,
                        "shares": 0
                    },
                    "externals": {
                        "cpa": 0,
                        "media_spend": 761.685
                    },
                    "internals": {
                        "cpa": 0.355914,
                        "cpm_actual": 1.878434,
                        "cpm_booked": 7.5,
                        "media_spend": 190.77
                    },
                    "sales": {
                        "instore": 957.4,
                        "online": 247.8,
                        "spend_per_customer": 2.248507,
                        "total": 1205.2
                    },
                    "summary": {
                        "clicks": 162,
                        "conversionRate": 0.0060208483105679365,
                        "ctr": 0.001595,
                        "frequency": 1.140793,
                        "impressions": 3500,
                        "reach": 89024
                    },
                    "video": {
                        "cost_per_completed_view": 0.07256371243818943,
                        "video_completed_views": 2629,
                        "video_completion_rate": 0.02588668544083184,
                        "video_views": 7545
                    }
                }'::VARIANT AS MEASURES
        UNION ALL
        SELECT '678a3b8ac5f255d2710d8e8a' AS DIGITAL_TRADING_CAMPAIGN_NK1,
                TO_DATE('2024-09-13') AS REPORTING_START_DT,
                TO_DATE('2024-09-13') AS REPORTING_END_DT,
                TO_TIMESTAMP('2024-07-08 14:57:11.347') AS RECORD_ARRIVAL_TS,
                '{
                    "conversion": {
                        "acquired": 236,
                        "instore": 440,
                        "lapsed": 32,
                        "online": 96,
                        "percentage": 0.006021,
                        "retained": 268,
                        "totals": 536
                    },
                    "engagement": {
                        "comments": 1,
                        "post_engagements": 7619,
                        "post_reactions": 2,
                        "shares": 0
                    },
                    "externals": {
                        "cpa": 0,
                        "media_spend": 761.685
                    },
                    "internals": {
                        "cpa": 0.355914,
                        "cpm_actual": 1.878434,
                        "cpm_booked": 7.5,
                        "media_spend": 190.77
                    },
                    "sales": {
                        "instore": 957.4,
                        "online": 247.8,
                        "spend_per_customer": 2.248507,
                        "total": 1205.2
                    },
                    "summary": {
                        "clicks": 162,
                        "conversionRate": 0.0060208483105679365,
                        "ctr": 0.001595,
                        "frequency": 1.140793,
                        "impressions": 2000,
                        "reach": 89024
                    },
                    "video": {
                        "cost_per_completed_view": 0.07256371243818943,
                        "video_completed_views": 2629,
                        "video_completion_rate": 0.02588668544083184,
                        "video_views": 7545
                    }
                }'::VARIANT AS MEASURES
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV','DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT', options={"input_format": "csv"}) %}
        JOB_BAG_ID     | DIGITAL_TRADING_CAMPAIGN_NK1 | RECORD_ARRIVAL_TS
        'nec24031148a' | '678a3b8ac5f255d2710d8e8a'  | TO_TIMESTAMP('2024-07-08 14:57:11.347')
    {% endcall %}

    {% call dbt_unit_testing.mock_source('ADW_RDV','DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK') %}
        SELECT '678a3b8ac5f255d2710d8e8a' AS DIGITAL_TRADING_CAMPAIGN_NK1,
               '678a3b8ac5f255d2710d8e8a' AS DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1,
               TO_TIMESTAMP('2024-07-09 14:57:11.347') AS RECORD_ARRIVAL_TS
    {% endcall %}

    {% call dbt_unit_testing.mock_source('DV360','MEDIA_REPORT', options={"input_format": "csv"}) %}
        JOBBAG_ID      | CAMPAIGN_DATE         | IMPRESSIONS
        'nec24031148b' | to_date('2024-09-11') | 25
        'nec24031148b' | to_date('2024-09-12') | 100
        'nec24031148c' | to_date('2024-09-11') | 12
        'nec24031148c' | to_date('2024-09-12') | 24
        'nec24031148c' | to_date('2024-09-13') | 2
        'nec24031148c' | to_date('2024-09-14') | 12
        'nec24031148c' | to_date('2024-09-15') | 36
    {% endcall %}

    {% call dbt_unit_testing.expect() %}
        SELECT 'Offsite' AS MARKETING_TYPE,
               'DV360' AS CHANNEL_NAME,
               'nec24031148b' AS JOB_BAG_NUMBER,
                CAST('2024-09-11' AS DATE) AS REPORTING_DT,
                25 AS IMPRESSIONS_CNT,
                25 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.200 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'DV360' AS CHANNEL_NAME,
               'nec24031148b' AS JOB_BAG_NUMBER,
                CAST('2024-09-12' AS DATE) AS REPORTING_DT,
                100 AS IMPRESSIONS_CNT,
                125 AS CUMULATIVE_IMPRESSIONS_CNT,
                1.000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'Meta' AS CHANNEL_NAME,
               'nec24031148a' AS JOB_BAG_NUMBER,
                CAST('2024-09-11' AS DATE) AS REPORTING_DT,
                1000 AS IMPRESSIONS_CNT,
                1000 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.15384615385 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'Meta' AS CHANNEL_NAME,
               'nec24031148a' AS JOB_BAG_NUMBER,
                CAST('2024-09-12' AS DATE) AS REPORTING_DT,
                3500 AS IMPRESSIONS_CNT,
                4500 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.69230769231 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'Meta' AS CHANNEL_NAME,
               'nec24031148a' AS JOB_BAG_NUMBER,
                CAST('2024-09-13' AS DATE) AS REPORTING_DT,
                2000 AS IMPRESSIONS_CNT,
                6500 AS CUMULATIVE_IMPRESSIONS_CNT,
                1.000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'YouTube' AS CHANNEL_NAME,
               'nec24031148c' AS JOB_BAG_NUMBER,
                CAST('2024-09-11' AS DATE) AS REPORTING_DT,
                12 AS IMPRESSIONS_CNT,
                12 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.13953500000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'YouTube' AS CHANNEL_NAME,
               'nec24031148c' AS JOB_BAG_NUMBER,
                CAST('2024-09-12' AS DATE) AS REPORTING_DT,
                24 AS IMPRESSIONS_CNT,
                36 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.41860500000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'YouTube' AS CHANNEL_NAME,
               'nec24031148c' AS JOB_BAG_NUMBER,
                CAST('2024-09-13' AS DATE) AS REPORTING_DT,
                2 AS IMPRESSIONS_CNT,
                38 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.44186000000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'YouTube' AS CHANNEL_NAME,
               'nec24031148c' AS JOB_BAG_NUMBER,
                CAST('2024-09-14' AS DATE) AS REPORTING_DT,
                12 AS IMPRESSIONS_CNT,
                50 AS CUMULATIVE_IMPRESSIONS_CNT,
                0.58139500000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
        UNION ALL
        SELECT 'Offsite' AS MARKETING_TYPE,
               'YouTube' AS CHANNEL_NAME,
               'nec24031148c' AS JOB_BAG_NUMBER,
                CAST('2024-09-15' AS DATE) AS REPORTING_DT,
                36 AS IMPRESSIONS_CNT,
                86 AS CUMULATIVE_IMPRESSIONS_CNT,
                1.000 AS OFFSITE_IMPRESSIONS_PCT,
                '{{ invocation_id }}' AS JOB_RUN_ID
    {% endcall %}

{% endcall %}