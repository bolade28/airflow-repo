{#
/*********************************************************************************************************************************************
* Objective -  The customer journey in the context of multi-touch attribution (MTA) involves tracking and analyzing customer interactions
* across all marketing channels—offsite, onsite, and instore—to understand how each touchpoint contributes to a customer's path
* to conversion. It involves collecting touchpoint and transaction data during campaigns to create customer journeys for brand
* categorized into conversion/non-conversion journeys based on sales/no-sales.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657653993/Customer+Journey+Creation
* Upstream: customer_data_collection
* Downstream: attribution_pre_requisite_brand
*
* This script will call the macro for the user journey creation brand.
* The macro processes data from various tables to identify and aggregate user interactions, transactions, and touchpoints,
* ultimately creating a detailed user journey dataset.
* The query will be called from the user journey models and brand parameter will be passed to the macro

* Owner : Divya Jain
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*************************************************************************************************************************************************/
#}

-- depends_on: {{ ref('measurement_campaign_execution') }}
-- depends_on: {{ ref('customer_data_collection') }}

{# {{ log("Running user journey for brand", info=True ) }} #}

{{
    config(
        materialized='incremental',
		transient=False,
        incremental_strategy= 'append',
        post_hook="{{ validation_macro_run('user_journey_brand') }}",
        name = 'user_journey_brand',
        unique_key=['booking_id','userjourney_id','channel_name', 'subchannel_name', 'rank','campaign_duration']
    )
}}

{# /*Caling user jouerney macro for offer to get journey related details for brand*/#}
{{ user_journey('Brand', 'Brand') }}
