"""
/**************************************************************************
* Script Name: reach_engagement.py
*
* Objective:
* This script is designed to compute reach and engagement metrics for
* various marketing channels. It processes data from multiple upstream
* sources, applies advanced business logic, and generates detailed results
* for further analysis and reporting. The script calculates metrics such as
* reach, engagement click through rate along with clicks and impression for digital channels,
* sales and noting down the media spend based on the specific requirements of each
* channel. It handles potential errors, and logs issues for troubleshooting.
* Channels Covered:
* - Reach is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - In-store
*   - Ecoupons
*   - Coupon at Till
*   - YouTube
*   - Magazine
* - Engagement is calculated for the following channels:
*   - Meta
*   - DV360
*   - Onsite-GOL
*   - YouTube
*
* Confluence Link: https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657261818/Reach+and+Engagement
*
* Upstream:
* - USER_JOURNEY_OFFER
*
* Downstream:
* - SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
# - MEASUREMENT_CAMPAIGN_REPORTING
*
* Owner: Sahil Arya
* Date: 29/11/2024
*
**************************************************************************/
"""

from functools import reduce

import snowflake.snowpark as snowpark
from snowflake.snowpark.functions import (col, countDistinct,
                                          current_timestamp, expr, get, lit,
                                          lower, max, regexp_replace, sum,
                                          when)
from snowflake.snowpark.types import (DecimalType, IntegerType, StringType,
                                      StructField, StructType, TimestampType)
import traceback
from datetime import datetime


def extract_error_message(trace_str):
    """
    Extracts the most relevant error message from a given traceback string.

    Objective:
    This function scans through the provided traceback (typically from an exception)
    and attempts to find and return the final line that includes a recognizable
    error or exception message. The purpose is to simplify debugging by isolating
    the key error message from the full traceback.

    Used in:
        fetch_in_progress_campaign
        get_latest_source_data
        log_missing_data
        log_negative_or_zero_incrementality
        replace_nulls_with_zero
        find_cluster_details
        model
        log_process_helper

    Parameters:
        trace_str (str): The complete traceback string from an exception.

    Returns:
        str: The extracted error message (text after the last colon in the last matching line),
            or the original traceback if no clear error line is found.

    Example:
        Input:
            trace_str = '''
            Traceback (most recent call last):
            File "example.py", line 10, in <module>
                raise ValueError("Invalid input provided")
            ValueError: Invalid input provided
            '''
        Output:
            "Invalid input provided"

    Raises:
        ValueError: If the input `trace_str` is not a valid string or is empty.
    """

    # Define keywords that indicate an error or exception
    keywords = ["Error", "Exception", "error"]

    # Split the input string into individual lines, trimming whitespace
    lines = trace_str.strip().splitlines()

    # Loop through the lines in reverse order, as the actual error message is usually at the bottom
    for line in reversed(lines):
        # Check if the line contains any of the keywords and a colon (common format for error lines)
        if any(kw in line for kw in keywords) and ":" in line:
            # Extract and return the message part after the first colon
            return line.split(":", 1)[-1].strip()

    # If no error line is found, return the original traceback string as fallback
    return trace_str


def log_process_helper(
    session,
    error_message,
    error_traceback,
    error_type,
    module_name,
    pipeline,
    status,
    booking_id,
    campaign_duration,
    job_run_id,
    table_schema
):
    """
    Logs job failure details into a Snowflake table for tracking and debugging purposes.

    Objective:
    This function captures critical information about job failures, such as the error message,
    traceback, error type, pipeline name, module name, and campaign details. It writes these
    details to a designated logging table in Snowflake to facilitate tracking and debugging.

    Used in:
        - model: Used to log error details when an exception occurs during the
        processing of reach engagement model.

    Parameters:
        session (Session): Snowpark session object used to interact with Snowflake.
        error_message (str): A descriptive error message explaining the failure.
        error_traceback (str): The full traceback of the error for debugging purposes.
        error_type (str): The type or category of the error (e.g., ValueError, KeyError).
        module_name (str): The name of the module or script where the error occurred.
        pipeline (str): The name of the pipeline associated with the job.
        status (str): The status of the job, typically "FAILED" in case of failure.
        booking_id (str): The unique booking ID of the campaign being processed.
        campaign_duration (str): The duration of the campaign being processed.
        job_run_id (str): A unique identifier for the job run to track execution.

    Returns:
        None: This function writes the log entry directly to a Snowflake table
        and does not return any value.

    Example:
        Input:
            session = snowpark.Session.builder.configs(connection_parameters).create()
            error_message = "Division by zero error"
            error_traceback = "Traceback (most recent call last): ..."
            error_type = "ZeroDivisionError"
            module_name = "reach_engagement.py"
            pipeline = "reach_engagement"
            status = "FAILED"
            booking_id = "f108d9e5-57e1-4dfa-b731-8d200f249123"
            campaign_duration = "During"
            job_run_id = "d108d9e5-57e1-4dfa-b731-8d200f2499a7"

        Output:
            Logs the following entry into the ERROR_LOG_TABLE in Snowflake:
            {
                "error_message": "Division by zero error",
                "error_traceback": "Traceback (most recent call last): ...",
                "error_type": "ZeroDivisionError",
                "module_name": "reach_engagement.py",
                "pipeline": "reach_engagement",
                "status": "FAILED",
                "booking_id": "f108d9e5-57e1-4dfa-b731-8d200f249123",
                "campaign_duration": "During",
                "job_run_id": "d108d9e5-57e1-4dfa-b731-8d200f2499a7",
                "load_ts": "2023-10-18 12:00:00"
            }

    Raises:
        Exception: If an error occurs while writing to the Snowflake table, it raises an exception
        with the error details.

    Writes To:
        ERROR_LOG_TABLE: The Snowflake table where job failure logs are stored.
    """
    load_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    last_tb_index = error_traceback.rfind("Traceback")
    # Slice from that index to the end
    recent_trace = error_traceback[last_tb_index:].strip()

    # Create a Snowpark DataFrame with one row of log
    default_value = "NA"
    log_df = session.create_dataframe(
        [[
            pipeline,
            module_name,
            booking_id,
            campaign_duration,
            default_value,
            default_value,
            default_value,
            status,
            error_type,
            error_message,
            recent_trace,
            job_run_id,
            load_ts
        ]],
        schema=table_schema
    )
    if log_df.count() > 0:
        error_log_df = log_df
        error_log_df.write.mode("append").save_as_table("ERROR_LOG_TABLE")
    return None


def fetch_in_progress_campaign(df):
    """
    Retrieves the first available campaign that is currently "In-progress".

    Objective:
    This function filters the input DataFrame to identify campaigns with a JOB_STATUS
    of "In-progress". It ensures that only active campaigns are considered and extracts
    the first available BOOKING_ID and CAMPAIGN_DURATION for further processing. If no
    in-progress campaigns are found, it raises an exception.

    Used in:
        - reach_engagement: The fetch_in_progress_campaign function is called within the
          reach_engagement module to retrieve in-progress campaign details for further processing.

    Parameters:
        df (DataFrame): The input DataFrame containing campaign data.

    Returns:
        tuple: A tuple containing:
            - BOOKING_ID (str): The unique identifier of the first in-progress campaign.
            - CAMPAIGN_DURATION (str): The duration type of the campaign.

    Example:
        Input:
            df = DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "JOB_STATUS": "In-progress", "CAMPAIGN_DURATION": "During"},
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f249989", "JOB_STATUS": "Completed", "CAMPAIGN_DURATION": "During"}
            ])
        Output:
            ("d108d9e5-57e1-4dfa-b731-8d200f2499a7", "During")

    Raises:
        ValueError: If no in-progress campaigns are found in the input DataFrame.
    """
    try:
        in_progress_campaign = df.filter(col("JOB_STATUS") == "In-progress").select(
            "BOOKING_ID", "CAMPAIGN_DURATION"
        )

        if in_progress_campaign.count() == 0:
            booking_id = "NA"
            campaign_duration = "NA"
            raise ValueError("Error: no campaign found to execute the model!")
        else:
            # Retrieve the first available booking ID from in-progress executions
            booking_id = in_progress_campaign.select("BOOKING_ID").limit(1).collect()[0][0]
            campaign_duration = in_progress_campaign.select("CAMPAIGN_DURATION").limit(1).collect()[0][0]
        return booking_id, campaign_duration
    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def get_latest_data(data, booking_id, campaign_duration=None):
    """
    Retrieves the latest records for the specified in-progress booking ID.

    Objective:
    This function filters the input DataFrame to retrieve the latest records for a given
    in-progress booking ID and campaign duration. It ensures that only the most recent
    data is returned by identifying the maximum `LOAD_TS` (timestamp). The function validates
    inputs and raises appropriate exceptions if the required conditions are not met.

    Used in:
        - reach_engagement: The get_latest_records function is called within the
          reach_engagement module to retrieve the latest records for in-progress booking IDs.

    Parameters:
        booking_id (str): The in-progress booking ID to filter the data.
        data (DataFrame): The input DataFrame containing data to be filtered.
        campaign_duration (str): The campaign duration of the data (e.g., "post" or "during").

    Returns:
        DataFrame: A DataFrame containing the latest records for the given booking ID
                  and campaign duration.

    Example:
        Input:
            booking_id = "d108d9e5-57e1-4dfa-b731-8d200f2499a7"
            data = DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "LOAD_TS": "2023-10-01 12:00:00"},
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "LOAD_TS": "2023-10-02 12:00:00"}
            ])
            campaign_duration = "During"

        Output:
            DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "LOAD_TS": "2023-10-02 12:00:00"}
            ])

    Raises:
        ValueError: If the booking_id is not provided or is invalid.
        KeyError: If the required columns are missing from the DataFrame.
    """
    try:
        if campaign_duration:
            target_data = data.filter(
                (col("booking_id") == booking_id) & (col("campaign_duration") == campaign_duration)
            )
        else:
            target_data = data.filter(col("booking_id") == booking_id)
        if target_data.count() == 0:
            raise ValueError(
                "Error: no data found to execute the model!")
        load_ts = target_data.agg(max("load_ts")).collect()[0][0]
        filtered_data = target_data.filter(col("load_ts") == load_ts)
        return filtered_data
    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def calculate_reach(journey_data, campaign_id, marketing_type, group_by_column, channel):
    """
    Calculate marketing campaign reach, sales, and conversions for a given campaign ID and marketing type.

    Objective:
    This function filters the input DataFrame to calculate marketing campaign reach, sales, and conversions
    by isolating data based on the campaign ID, marketing type, channel, and sub-channel. It calculates reach
    by counting distinct user journey IDs and aggregates other metrics such as sales and conversions.

    Used in:
        - reach_engagement: The calculate_reach function is called within the reach_engagement module
          to compute campaign-level reach and other metrics for reporting and analysis.

    Parameters:
        journey_data (DataFrame): The input DataFrame containing user journey data with campaign details.
        campaign_id (str): The campaign ID to filter the data.
        marketing_type (str): The marketing type to filter the data.
        group_by_column (str): The column to group by, specific to In-store and ecoupons/coupon at till.
        channel (str): The name of the channel to filter the data.

    Returns:
        DataFrame: A DataFrame containing aggregated insights, including reach, sales, conversions,
                  and placeholders for other metrics.

    Example:
        Input:
            journey_data = DataFrame([
                {"CAMPAIGN_ID": "CAMP001", "MARKETING_TYPE": "Digital", "CHANNEL": "Meta", "USER_JOURNEY_ID": "UJ001"},
                {"CAMPAIGN_ID": "CAMP001", "MARKETING_TYPE": "Digital", "CHANNEL": "Meta", "USER_JOURNEY_ID": "UJ002"}
            ])
            campaign_id = "CAMP001"
            marketing_type = "Digital"
            group_by_column = "CHANNEL"
            channel = "Meta"

        Output:
            DataFrame([
                {"CHANNEL": "Meta", "REACH": 2, "SALES": 0, "CONVERSIONS": 0, ...}
            ])

    Raises:
        ValueError: If `campaign_id`, `marketing_type`, or `channel` is not provided or is invalid.
        KeyError: If the required columns are missing from the `journey_data` DataFrame.
        TypeError: If `journey_data` is not a valid DataFrame.
    """
    try:
        # Filter data for the given campaign ID
        campaign_df = journey_data.filter(
            journey_data["CAMPAIGN_ID"] == campaign_id
        )

        if marketing_type == "In-store":
            # Further filter data based on marketing type
            campaign_df = campaign_df.filter(
                campaign_df["MARKETING_TYPE"] == marketing_type
            )
        else:
            campaign_df = campaign_df.filter(
                campaign_df["CHANNEL_NAME"] == channel
            )
        # Aggregate data to calculate unique reach (distinct LOYALTY_ID) and total sales
        campaign_data = campaign_df.groupBy(
            "BOOKING_ID", "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", group_by_column
        ).agg(
            countDistinct("LOYALTY_ID").alias("REACH"),  # Unique customers reached
            sum("NET_SALES_AMT").alias("SALES")  # Total sales generated
        )

        # Filter conversions where ISCONVERSION flag is 1
        conversions = campaign_df.filter(
            campaign_df["ISCONVERSION"] == 1
        )

        # Aggregate conversion data based on unique USERJOURNEY_ID
        campaign_data_conv = conversions.groupBy(
            "BOOKING_ID", "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", group_by_column
        ).agg(
            countDistinct("USERJOURNEY_ID").alias("CONVERSIONS")  # Count unique conversions
        )

        if channel.lower() == "coupon at till" or channel.lower() == "ecoupons":
            # Join reach and sales data with conversion data
            insights_data = campaign_data.join(
                campaign_data_conv,
                on=["BOOKING_ID", "CAMPAIGN_ID", "CHANNEL_NAME", group_by_column],
                how="inner"
            )
        else:
            insights_data = campaign_data.join(
                campaign_data_conv,
                on=["BOOKING_ID", "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", group_by_column],
                how="inner"
            )

        # Add placeholder columns for additional metrics (CLICKS, ENGAGEMENT, IMPRESSIONS, SUBCHANNEL_NAME)
        insights_data = insights_data.withColumn("CLICKS", lit(None))

        if marketing_type == "In-store" or marketing_type == "Magazine":
            insights_data = (
                insights_data.withColumn("IMPRESSIONS", lit(None))
            )
        else:
            insights_data = (
                insights_data.withColumn("IMPRESSIONS", lit(None))
                .withColumn("MARKETING_TYPE", lit(marketing_type))  # Default subchannel name as "NA"
            )
        # Select and order final columns for output
        insights_data = insights_data.select(
            [
                "CAMPAIGN_ID",
                "CHANNEL_NAME",
                "SUBCHANNEL_NAME",
                "REACH",
                "CLICKS",
                "IMPRESSIONS",
                "SALES",
                "CONVERSIONS",
                "BOOKING_ID",
                "MARKETING_TYPE",
            ]
        )
        return insights_data

    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def cast_columns_to_types(df):
    """
    Cast the columns of the given DataFrame to the specified data types.

    Objective:
    This function ensures that the columns in the input DataFrame are cast to the required
    data types as defined in the `column_types` dictionary. It standardizes the data types
    of the aggregated reach and engagement data for accurate downstream processing and analysis.

    Used in:
        - reach_engagement: The cast_columns_to_types function is called within the
          reach_engagement module to ensure schema consistency for aggregated data.

    Parameters:
        df (DataFrame): The input DataFrame containing aggregated reach and engagement data.

    Returns:
        DataFrame: A DataFrame with columns cast to the specified data types.

    Example:
        Input:
            df = DataFrame([
                {"CAMPAIGN_ID": "CAMP001", "REACH_CNT": "1000", "SALES_AMT": "500.25", "LOAD_TS": "2023-10-01 12:00:00"},
                {"CAMPAIGN_ID": "CAMP002", "REACH_CNT": "2000", "SALES_AMT": "1000.50", "LOAD_TS": "2023-10-02 12:00:00"}
            ])

        Output:
            DataFrame([
                {"CAMPAIGN_ID": "CAMP001", "REACH_CNT": 1000, "SALES_AMT": 500.25, "LOAD_TS": datetime(2023, 10, 1, 12, 0, 0)},
                {"CAMPAIGN_ID": "CAMP002", "REACH_CNT": 2000, "SALES_AMT": 1000.50, "LOAD_TS": datetime(2023, 10, 2, 12, 0, 0)}
            ])

    Raises:
        ValueError: If the input DataFrame is empty or invalid.
        KeyError: If required columns for casting are missing from the DataFrame.
        Exception: If an error occurs during the column casting process, the exception is
                   raised with a detailed error message for debugging purposes.
    """
    try:
        column_types = {
            "CAMPAIGN_ID": StringType(100),
            "CHANNEL_NAME": StringType(100),
            "REACH_CNT": IntegerType(),
            "CLICKS_CNT": IntegerType(),
            "IMPRESSIONS_CNT": IntegerType(),
            "SALES_AMT": DecimalType(38, 4),
            "MEDIA_SPEND_AMT": DecimalType(38, 2),
            "ENGAGEMENT_CTR_PCT": DecimalType(38, 2),
            "CONVERSIONS_CNT": IntegerType(),
            "BOOKING_ID": StringType(100),
            "LOAD_TS": TimestampType(),
            "JOB_RUN_ID": StringType(100),
            "MARKETING_TYPE": StringType(100),
            "SUBCHANNEL_NAME": StringType(100),
        }

        for column, data_type in column_types.items():
            df = df.withColumn(column, col(column).cast(data_type))
        return df

    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def model(dbt, session: snowpark.Session):
    """
    Processes reach and engagement data for marketing campaigns across multiple channels.

    Objective:
    This function calculates key metrics such as reach, clicks, impressions, sales, conversions,
    and engagement percentage for various marketing channels (e.g., Meta, DV360, YouTube, In-store, etc.).
    It integrates data from multiple upstream sources, applies business logic, and generates a final
    DataFrame that is stored in a downstream table for further analysis and reporting.

    Used in:
        - reach_engagement: The process_reach_engagement function is called within the
          reach_engagement module to compute aggregated metrics for all marketing channels.

    Parameters:
        dbt (object): The dbt object used for referencing models and sources.
        session (snowpark.Session): The Snowpark session object for interacting with Snowflake.

    Returns:
        DataFrame: A DataFrame containing aggregated reach and engagement metrics for all channels.

    Example:
        Input:
            dbt = dbt object with configuration and source references.
            session = Snowpark session object.

        Output:
            DataFrame([
                {"CHANNEL": "Meta", "REACH_CNT": 1000, "CLICKS_CNT": 200, "IMPRESSIONS_CNT": 5000, "SALES_AMT": 1000.50, ...},
                {"CHANNEL": "YouTube", "REACH_CNT": 1500, "CLICKS_CNT": 300, "IMPRESSIONS_CNT": 7000, "SALES_AMT": 1500.75, ...}
            ])

    Raises:
        ValueError: If the input data is invalid or missing required fields.
        Exception: If any error occurs during processing, it logs the error details and raises the exception.
    """
    print("main function started")
    booking_id = 'NA'
    campaign_duration = 'NA'
    invocation_id = dbt.config.get("invocation_id", "NA")
    try:
        # Configure the dbt model with Python version 3.11 and set it to use the "incremental" materialization strategy.
        # The "append" incremental strategy ensures new data is appended to the existing table.
        # The "transient" option is set to False, meaning the table will be permanent and not automatically dropped.
        dbt.config(
            python_version="3.11",
            materialized="incremental",
            incremental_strategy="append",
            transient=False,
        )
        # Reference the user journey data from the dbt model, it helps calculate the reach.
        user_journey_data = dbt.ref("user_journey_offer")
        # Reference the reach and engagement data from the source table
        reach_engagement_data = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "REACH_ENGAGEMENT")
        # Create an empty dataframe with the same schema as the reach engagement data
        reach_empty_df = session.create_dataframe([], schema=reach_engagement_data.schema)
        # Reference the measurement campaign execution data for fetching the in-progress campaign
        df = dbt.ref("measurement_campaign_execution")
        # Fetch the booking ID and campaign duration for the currently in-progress campaign
        booking_id, campaign_duration = fetch_in_progress_campaign(df)
        # Proceed only if the campaign is ongoing (During phase)
        if campaign_duration == "During":
            # Reference the unified campaign data from the source table to get the campaign details
            unified_campaign = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "UNIFIED_CAMPAIGN")
            # Filter unified campaign data for the in-progress booking ID
            unified_campaign = unified_campaign.filter(col("BOOKING_ID") == booking_id).select("CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", "MARKETING_TYPE", "MEDIA_SPEND_AMT", "CAMPAIGN_START_DT", "CAMPAIGN_END_DT", "LOAD_TS", "BOOKING_ID", "JOB_BAG_NUMBER")
            # Fetch the latest data based on the selected column combination
            unified_campaign_max_load_ts = unified_campaign.group_by("CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", "MARKETING_TYPE", "MEDIA_SPEND_AMT", "CAMPAIGN_START_DT", "CAMPAIGN_END_DT", "BOOKING_ID", "JOB_BAG_NUMBER").agg(max("load_ts").alias("LOAD_TS"))
            unified_campaign = unified_campaign_max_load_ts
            # Filter user journey data for the current booking ID and campaign duration
            user_journey_data = user_journey_data.filter(
                (col("BOOKING_ID") == booking_id) & (col("CAMPAIGN_DURATION") == campaign_duration)
            )
            # Retrieve the latest source data for the user journey based on booking ID and campaign duration
            user_journey_data_filtered = get_latest_data(user_journey_data, booking_id, campaign_duration)
            # Select relevant columns from the unified campaign data that will be used to calculate reach and engagement
            unified_campaign_filtered = unified_campaign.select(
                "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", "MARKETING_TYPE", "MEDIA_SPEND_AMT"
            )
            # Rename selected columns by appending '_uni' suffix for joining
            unified_campaign_filtered = unified_campaign_filtered.select(
                [col(column).alias(f"{column}_uni") for column in unified_campaign_filtered.columns]
            )
            # Collect all campaign rows into a list
            campaign_rows = unified_campaign.collect()
            # Initialize an empty list to store all channel data
            all_channel_data = []
            # Initialize DataFrames for offsite, instore/magazine insight
            # Define a schema for the empty DataFrames to store the results for each channel
            schema = StructType(
                [
                    StructField("CAMPAIGN_ID", StringType()),
                    StructField("CHANNEL_NAME", StringType()),
                    StructField("SUBCHANNEL_NAME", StringType()),
                    StructField("REACH", IntegerType()),  #
                    StructField("CLICKS", IntegerType()),
                    StructField("IMPRESSIONS", IntegerType()),
                    StructField("SALES", IntegerType()),
                    StructField("ENGAGEMENT_CTR_PCT", DecimalType(38, 2)),
                    StructField("CONVERSIONS", IntegerType()),
                    StructField("MARKETING_TYPE", StringType()),
                    StructField("BOOKING_ID", StringType()),
                    StructField("MEDIA_SPEND_AMT", IntegerType()),
                ]
            )

            # Initialize empty dataframes for different marketing channels
            meta_insights_data = session.create_dataframe([], schema)
            instore_insights_data = session.create_dataframe([], schema)
            dv360_insights_data = session.create_dataframe([], schema)
            citrus_insights_data = session.create_dataframe([], schema)
            coupon_insights_data = session.create_dataframe([], schema)

            # Iterate through each campaign row to process insights
            for row in campaign_rows:
                booking_id = row["BOOKING_ID"]
                job_bag_id = row["JOB_BAG_NUMBER"]
                channel = row["CHANNEL_NAME"]
                camp_strt_dt = row["CAMPAIGN_START_DT"]
                camp_end_dt = row["CAMPAIGN_END_DT"]
                marketing_type = row["MARKETING_TYPE"]
                campaign_id = row["CAMPAIGN_ID"]
                subchannel_name = row["SUBCHANNEL_NAME"]

                # Process insights for Meta channel
                # The steps below are specific to calculating the reach and engagement percentage for the Meta channel.
                # We consolidate the daily-level DTP reports from the following tables:
                # - DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT
                # - DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK
                # - DIGITAL_TRADING_LINEITEM_INSIGHT_DMFBIN_LINK
                # These tables are filtered based on the campaign period and aggregated to derive the metrics.
                # For offsite channels, since we don't have the exact exposed group of the audience,
                # we use the existing DTP report to calculate the reach and engagement percentage for the Meta channel.
                if channel == "Meta":

                    # Fetch and deduplicate Meta job bag data
                    meta_jobbag_raw = dbt.source("ADW_RDV", "DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT")
                    meta_jobbag_raw = meta_jobbag_raw.distinct()

                    # Filter on the basis of job_bag_id
                    meta_jobbag = meta_jobbag_raw.filter(meta_jobbag_raw["JOB_BAG_ID"] == job_bag_id)

                    # Fetch and deduplicate Meta campaign link data
                    meta_campaign_link = dbt.source("ADW_RDV", "DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK")
                    meta_campaign_link = meta_campaign_link.distinct()

                    # Join job bag data with campaign link data
                    meta_job_bag_join = meta_jobbag.join(
                        meta_campaign_link, on=["DIGITAL_TRADING_CAMPAIGN_NK1"], how="inner"
                    )

                    # Select relevant columns
                    meta_job_bag_join = meta_job_bag_join.select(
                        [
                            "DIGITAL_TRADING_CAMPAIGN_NK1",
                            "JOB_BAG_ID",
                            "DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1",
                        ]
                    )

                    # Fetch and filter Meta insights report based on start and end date
                    meta_insights_report = dbt.source("ADW_RDV", "DIGITAL_TRADING_LINEITEM_INSIGHT_DMFBIN_LINK")
                    meta_insights_report = meta_insights_report.distinct()
                    meta_insights_report = meta_insights_report.filter(
                        (col("REPORTING_START_DT") == camp_strt_dt) & (col("REPORTING_END_DT") == camp_end_dt)
                    )

                    # Join Meta insights report with job bag data
                    meta_reach_engagement_extract = meta_job_bag_join.join(
                        meta_insights_report,
                        meta_job_bag_join["DIGITAL_TRADING_CAMPAIGN_CHANNEL_NK1"] == meta_insights_report["DIGITAL_TRADING_CAMPAIGN_NK1"],
                        how="inner",
                    )

                    # Extract key performance indicators from the insights data
                    meta_reach_engagement_extract = (
                        meta_reach_engagement_extract.with_column(
                            "TOTAL_REACH", get(col("MEASURES")["summary"], lit("reach")).cast("int")
                        )
                        .with_column(
                            "TOTAL_CLICKS", get(col("MEASURES")["summary"], lit("clicks")).cast("int")
                        )
                        .with_column(
                            "TOTAL_IMPRESSIONS",
                            get(col("MEASURES")["summary"], lit("impressions")).cast("int"),
                        )
                        .with_column(
                            "TOTAL_SALES", get(col("MEASURES")["sales"], lit("total")).cast("int")
                        )
                        .with_column(
                            "TOTAL_CONVERSIONS",
                            get(col("MEASURES")["conversion"], lit("totals")).cast("int"),
                        )
                        .with_column(
                            "MEDIA_SPEND_AMT",
                            get(col("MEASURES")["internals"], lit("media_spend")).cast("int"),
                        )
                        .with_column("CHANNEL_NAME", lit(channel))
                    )

                    # Identify the latest records based on arrival timestamp
                    meta_max_time = meta_reach_engagement_extract.group_by(
                        "JOB_BAG_ID", "DIGITAL_TRADING_INSIGHT_ID", "DIGITAL_TRADING_LINEITEM_NK1"
                    ).agg(max(col("RECORD_ARRIVAL_TS")).alias("MAX_RECORD_ARRIVAL_TS"))

                    # Join to retain only the most recent records
                    meta_reach_engagement = meta_reach_engagement_extract.join(
                        meta_max_time,
                        (
                            meta_reach_engagement_extract.JOB_BAG_ID == meta_max_time.JOB_BAG_ID
                        ) & (
                            meta_reach_engagement_extract.DIGITAL_TRADING_INSIGHT_ID == meta_max_time.DIGITAL_TRADING_INSIGHT_ID
                        ) & (
                            meta_reach_engagement_extract.RECORD_ARRIVAL_TS == meta_max_time.MAX_RECORD_ARRIVAL_TS
                        ) & (
                            meta_reach_engagement_extract.DIGITAL_TRADING_LINEITEM_NK1 == meta_max_time.DIGITAL_TRADING_LINEITEM_NK1
                        ),
                        how="inner",
                    )

                    # Select and format final Meta insights data
                    meta = meta_reach_engagement.select(
                        [
                            "CHANNEL_NAME",
                            meta_reach_engagement_extract.JOB_BAG_ID.alias("CAMPAIGN_ID"),
                            "TOTAL_REACH",
                            "TOTAL_CLICKS",
                            "TOTAL_IMPRESSIONS",
                            "TOTAL_SALES",
                            "TOTAL_CONVERSIONS",
                            "MEDIA_SPEND_AMT",
                        ]
                    )

                    # Extract subchannel name from string format by splitting with | and extracting first index
        
                    meta_insights_data = meta.withColumn("SUBCHANNEL_NAME", lit(subchannel_name))
                    meta_insights_data = meta_insights_data.withColumn(
                        "SUBCHANNEL_NAME", col("SUBCHANNEL_NAME").cast("String")
                    )

                    # Aggregate insights data at campaign and channel level
                    meta_insights_data = meta_insights_data.group_by(
                        "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME"
                    ).agg(
                        sum("TOTAL_REACH").cast("int").alias("REACH"),
                        sum("TOTAL_CLICKS").cast("int").alias("CLICKS"),
                        sum("TOTAL_IMPRESSIONS").cast("int").alias("IMPRESSIONS"),
                        sum("TOTAL_SALES").cast("int").alias("SALES"),
                        sum("TOTAL_CONVERSIONS").cast("int").alias("CONVERSIONS"),
                        sum("MEDIA_SPEND_AMT").cast("int").alias("MEDIA_SPEND_AMT"),
                    )

                    # Add campaign marketing type and booking id
                    meta_insights_data = meta_insights_data.withColumn(
                        "MARKETING_TYPE", lit(marketing_type)
                    ).withColumn("BOOKING_ID", lit(booking_id))

                # Processes reach and engagement data for marketing campaigns for instore and magazine..
                # This function calculates key metrics such as reach, clicks, impressions, sales, conversions,
                # and engagement percentage for instore and magazine.
                elif marketing_type in ["In-store", "Magazine"]:
                    instore_insights_data = calculate_reach(user_journey_data_filtered, campaign_id, marketing_type, "MARKETING_TYPE", channel)

                # Process insights for DV360, Youtube
                # The steps below are specific to calculating the reach and engagement percentage for the DV360, Youtube channels.
                # We consolidate the daily-level DTP reports from the following tables:
                # - UNIQUE_REACH_LINEITEM_REPORT
                # - FLOODLIGHT_REPORT
                # These tables are filtered based on the campaign period and aggregated to derive the metrics.
                # For offsite channels, since we don't have the exact exposed group of the audience,
                # we align with using the existing DTP report to calculate the reach and engagement percentage for the DV360, Youtube channels.
                elif channel in ["DV360", "YouTube"]:

                    # Fetch and deduplicate media report data
                    dv360_media_report = dbt.source("DV360", "MEDIA_REPORT")
                    dv360_media_report = dv360_media_report.distinct()
                    dv360_media_report = dv360_media_report.withColumn("SUBCHANNEL_NAME", lit(subchannel_name))

                    # Select relevant columns and filter on job_bag_id and campaign start and end date
                    dv360_media_report = (
                        dv360_media_report.select(
                            [
                                "JOBBAG_ID",
                                "LINE_ITEM_ID",
                                "CLICKS",
                                "IMPRESSIONS",
                                "TOTAL_CONVERSIONS",
                                "SUBCHANNEL_NAME",
                                "TIME_OF_DAY",
                                "DEVICE_TYPE",
                                "CAMPAIGN_DATE",
                                "RUN_AT",
                                "REVENUE",
                            ]
                        )
                        .filter(col("JOBBAG_ID") == job_bag_id)
                        .filter(col("CAMPAIGN_DATE").between(camp_strt_dt, camp_end_dt))
                    )

                    '''
                    Group by on specific columns to calculate sum of
                    clicks, impressions, conversions, revenue.
                    Fetch latest data by taking max of run_at column
                    '''
                    dv360_media_report = dv360_media_report.group_by(
                        "LINE_ITEM_ID",
                        "JOBBAG_ID",
                        "SUBCHANNEL_NAME",
                        "TIME_OF_DAY",
                        "DEVICE_TYPE",
                        "CAMPAIGN_DATE",
                    ).agg(
                        sum("CLICKS").cast("int").alias("CLICKS"),
                        sum("IMPRESSIONS").cast("int").alias("IMPRESSIONS"),
                        sum("TOTAL_CONVERSIONS").cast("int").alias("CONVERSIONS"),
                        max("RUN_AT").alias("RUN_AT"),
                        sum("REVENUE").alias("MEDIA_SPEND_AMT"),
                    )

                    '''
                    Group by on line_item_id, jobbag_id and subchannel_name
                    to calculate sum of clicks, impressions, conversions, revenue.
                    '''
                    dv360_media_report = dv360_media_report.group_by(
                        "LINE_ITEM_ID", "JOBBAG_ID", "SUBCHANNEL_NAME"
                    ).agg(
                        sum("CLICKS").cast("int").alias("CLICKS"),
                        sum("IMPRESSIONS").cast("int").alias("IMPRESSIONS"),
                        sum("CONVERSIONS").alias("CONVERSIONS"),
                        sum("MEDIA_SPEND_AMT").cast("int").alias("MEDIA_SPEND_AMT"),
                    )

                    # Fetch and deduplicate unique_reach_lineitem_report
                    dv360_order_report = dbt.source("DV360", "UNIQUE_REACH_LINEITEM_REPORT")
                    dv360_order_report = dv360_order_report.distinct()

                    # Select relevant columns
                    dv360_order_report = dv360_order_report.select(
                        ["LINE_ITEM_ID", "TOTAL_REACH", "COUNTRY", "DATE_FROM", "DATE_UNTIL"]
                    )

                    # Filter data on campaign start and end date
                    dv360_order_report = dv360_order_report.filter(
                        (col("DATE_FROM") == camp_strt_dt) & (col("DATE_UNTIL") == camp_end_dt)
                    )

                    # Group by line_item_id and country to calculate total reach
                    dv360_order_report = dv360_order_report.group_by("LINE_ITEM_ID", "COUNTRY").agg(
                        sum("TOTAL_REACH").cast("int").alias("REACH")
                    )

                    # Fetch and deduplicate floodlight_report data
                    dv360_floodlight_report = dbt.source("DV360", "FLOODLIGHT_REPORT")
                    dv360_floodlight_report = dv360_floodlight_report.distinct()

                    # Select relevant columns
                    dv360_floodlight_report = dv360_floodlight_report.select(
                        ["LINE_ITEM_ID", "SPEND", "CAMPAIGN_DATE"]
                    )

                    # Filter data on campaign start and end date
                    dv360_floodlight_report = dv360_floodlight_report.filter(
                        col("CAMPAIGN_DATE").between(camp_strt_dt, camp_end_dt)
                    )

                    # Group by line_item_id to calculate total sales
                    dv360_floodlight_report = dv360_floodlight_report.group_by("LINE_ITEM_ID").agg(
                        sum("SPEND").cast("int").alias("SALES")
                    )

                    # Filter data where country is GB
                    dv360_order_report = dv360_order_report.filter(col("COUNTRY") == "GB")

                    # Join media_report and order_report on line_item_id to get the required aggregated data
                    dv360_insights = dv360_media_report.join(
                        dv360_order_report, on=["LINE_ITEM_ID"], how="left"
                    )

                    # Select relevant columns
                    dv360_insights = dv360_insights.select(
                        [
                            "JOBBAG_ID",
                            "CLICKS",
                            "IMPRESSIONS",
                            "CONVERSIONS",
                            "REACH",
                            "LINE_ITEM_ID",
                            "SUBCHANNEL_NAME",
                            "MEDIA_SPEND_AMT",
                        ]
                    )

                    # Join insights data with floodlight_report data on line_item_id to get Sales
                    dv360_insights_data = dv360_insights.join(
                        dv360_floodlight_report, on=["LINE_ITEM_ID"], how="left"
                    )
                    dv360_insights_data = dv360_insights_data.select(
                        [
                            "JOBBAG_ID",
                            "CLICKS",
                            "IMPRESSIONS",
                            "CONVERSIONS",
                            "REACH",
                            "SALES",
                            "SUBCHANNEL_NAME",
                            "MEDIA_SPEND_AMT",
                        ]
                    )

                    # Add channel and booking_id column
                    dv360_insights_data = dv360_insights_data.withColumn("CHANNEL_NAME", lit(channel))
                    dv360_insights_data = dv360_insights_data.withColumn("BOOKING_ID", lit(booking_id))

                    # Rename jobbag_id column to campaign_id and add marketing_type column
                    dv360_insights_data = dv360_insights_data.withColumnRenamed(
                        "JOBBAG_ID", "CAMPAIGN_ID"
                    ).withColumn("marketing_type", lit(marketing_type))

                    # Split subchannel_name with | and get the first index
                    split_subchannel = expr("split(SUBCHANNEL_NAME,'|')")

                    # Replace characters other than 'A-Za-z0-9_|, -' with blank in subchannel_name
                    dv360_insights_data = dv360_insights_data.withColumn(
                        "SUBCHANNEL_NAME", regexp_replace(split_subchannel[0], r"[^A-Za-z0-9_|, -]", "")
                    )

                    # Select relevant columns required in the final data and fill nulls with 0 in numeric columns
                    dv360_insights_data = dv360_insights_data.select(
                        [
                            "CAMPAIGN_ID",
                            "CHANNEL_NAME",
                            "SUBCHANNEL_NAME",
                            "REACH",
                            "CLICKS",
                            "IMPRESSIONS",
                            "SALES",
                            "CONVERSIONS",
                            "BOOKING_ID",
                            "MARKETING_TYPE",
                            "MEDIA_SPEND_AMT",
                        ]
                    ).fillna(0)

                # Processes reach and engagement data for marketing campaigns for coupon at till.
                # This calculates key metrics such as reach, clicks, impressions, sales, conversions,
                # and engagement percentage for coupon at till.
                elif channel.lower() in ["coupon at till", "ecoupons"]:
                    coupon_insights_data = calculate_reach(user_journey_data_filtered, campaign_id, marketing_type, "SUBCHANNEL_NAME", channel)

                # The steps below are specific to calculating the reach and engagement percentage for the Onsite-GOL channel.
                # We consolidate the daily-level Citrus reports from the following tables:
                # - ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK
                # - ADVERTISING_CAMPAIGN_CITCAM_SAT
                # These tables are filtered based on the campaign period and aggregated to calculate the click-through rate.
                # For reach, we refer to the user journey table corresponding to the campaign ID to get the distinct number
                # of users reached.
                elif "gol" in channel.lower():
                    # Source data for advertising campaign request
                    camp_request_link_df = dbt.source(
                        "ADW_RDV", "ADVERTISING_CAMPAIGN_REQUEST_REALISED_LINK"
                    )

                    # Filter latest records within campaign date range and aggregate metrics
                    latest_records_df = (
                        camp_request_link_df.filter(
                            (
                                col("ADVERTISING_CAMPAIGN_NK1") == campaign_id
                            ) & (
                                col("INGRESSED_AT_DT").between(camp_strt_dt, camp_end_dt)
                            )
                        )
                        .groupBy("ADVERTISING_CAMPAIGN_NK1")
                        .agg(
                            max("RECORD_ARRIVAL_TS").alias("MAX_TIME"),
                            sum("SALES_REVENUE_AMT").alias("SALES"),
                            sum("conversions_cnt").alias("CONVERSIONS"),
                            sum("IMPRESSIONS_CNT").alias("IMPRESSIONS"),
                            sum("CLICKS_CNT").alias("CLICKS"),
                        )
                    )

                    # Join latest records with campaign data
                    joined_data_df = (
                        latest_records_df.join(
                            unified_campaign, latest_records_df["ADVERTISING_CAMPAIGN_NK1"] == unified_campaign["CAMPAIGN_ID"],
                        )
                        .select(
                            unified_campaign["CAMPAIGN_ID"],
                            latest_records_df["CLICKS"],
                            latest_records_df["IMPRESSIONS"],
                            unified_campaign["CAMPAIGN_START_DT"],
                            unified_campaign["CAMPAIGN_END_DT"],
                            unified_campaign["JOB_BAG_NUMBER"],
                            latest_records_df["SALES"],
                            latest_records_df["CONVERSIONS"],
                        )
                        .distinct()
                        .filter((unified_campaign["CAMPAIGN_ID"] == campaign_id))
                    )

                    # Retrieve subchannel names from campaign placements
                    campaign_citcam_sat = dbt.source("ADW_RDV", "ADVERTISING_CAMPAIGN_CITCAM_SAT")
                    campaign_citcam_sat = campaign_citcam_sat.select(
                        campaign_citcam_sat.campaign_placements.alias("SUBCHANNEL_NAME"),
                        "ADVERTISING_CAMPAIGN_NK1",
                    )

                    # Join campaign data with subchannel data
                    final_data_citrus = joined_data_df.join(
                        campaign_citcam_sat, col("CAMPAIGN_ID") == col("ADVERTISING_CAMPAIGN_NK1")
                    )

                    # Aggregate reach data based on campaign and channel info
                    reach_data = user_journey_data_filtered.groupBy(
                        "CAMPAIGN_ID", "BOOKING_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME"
                    ).agg(countDistinct("LOYALTY_ID").alias("REACH"))

                    # Extract meaningful subchannel name
                    split_subchannel = expr(
                        """TRIM(CASE WHEN POSITION('-', SUBCHANNEL_NAME) = 0
                        THEN '' ELSE SUBSTR(SUBCHANNEL_NAME,
                            POSITION('-', SUBCHANNEL_NAME) + 1) END)"""
                    )

                    final_data_citrus = final_data_citrus.withColumn(
                        "SUBCHANNEL_NAME", split_subchannel
                    ).withColumn("CHANNEL_NAME", lit(channel))

                    # Compute final aggregated campaign insights
                    final_data_citrus = (
                        final_data_citrus.withColumn("MARKETING_TYPE", lit(marketing_type))
                        .withColumn("BOOKING_ID", lit(booking_id))
                        .group_by(
                            "CAMPAIGN_ID",
                            "CHANNEL_NAME",
                            "SUBCHANNEL_NAME",
                            "MARKETING_TYPE",
                            "BOOKING_ID",
                        )
                        .agg(
                            sum("CLICKS").cast("int").alias("CLICKS"),
                            sum("IMPRESSIONS").cast("int").alias("IMPRESSIONS"),
                            sum("SALES").cast("double").alias("SALES"),
                            sum("CONVERSIONS").cast("int").alias("CONVERSIONS"),
                        )
                    )

                    # Merge citrus insights with reach data
                    citrus_insights_data = final_data_citrus.join(
                        reach_data.drop("BOOKING_ID"),
                        on=["CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME"],
                        how="inner",
                    )

                    # Select final output columns for insights
                    citrus_insights_data = citrus_insights_data.select(
                        "CAMPAIGN_ID",
                        "CHANNEL_NAME",
                        "SUBCHANNEL_NAME",
                        "REACH",
                        "CLICKS",
                        "IMPRESSIONS",
                        "SALES",
                        "CONVERSIONS",
                        "BOOKING_ID",
                        "MARKETING_TYPE",
                    )
                '''Combine all insights data from different channels and add placeholder for media_spend_amt
                    Calculate click through rate by (clicks/impressions)*100, and add a placeholder for CTR
                    for channels where we don't get clicks and impressions.'''
                channel_data_combined = (
                    meta_insights_data.withColumn(
                        "ENGAGEMENT_CTR_PCT", when(col("impressions") > 0, (col("clicks") / col("impressions")) * 100).otherwise(0.0)
                    )
                    .unionByName(
                        instore_insights_data.withColumn("MEDIA_SPEND_AMT", lit(0.0)).withColumn("ENGAGEMENT_CTR_PCT", lit(0.0))
                    )
                    .unionByName(
                        dv360_insights_data.withColumn(
                            "ENGAGEMENT_CTR_PCT", when(col("impressions") > 0, (col("clicks") / col("impressions")) * 100).otherwise(0.0)
                        )
                    )
                    .unionByName(
                        coupon_insights_data.withColumn("MEDIA_SPEND_AMT", lit(0.0)).withColumn("ENGAGEMENT_CTR_PCT", lit(0.0))
                    )
                    .unionByName(
                        citrus_insights_data.withColumn(
                            "MEDIA_SPEND_AMT", lit(0.0)
                        ).withColumn(
                            "ENGAGEMENT_CTR_PCT", when(col("impressions") > 0, (col("clicks") / col("impressions")) * 100).otherwise(0.0)
                        )
                    )
                )

                # Append all the channel data into a list
                all_channel_data.append(channel_data_combined)
            '''Check if the length of all_channel_data list > 0,
            then reduce the list and combine the specific channels data into a single dataframe and deduplicate'''
            if len(all_channel_data) > 0:
                reach_engagement = reduce(lambda df1, df2: df1.unionByName(df2), all_channel_data)
                # add load timestamp to the data
                reach_engagement = reach_engagement.withColumn("LOAD_TS", current_timestamp())
                reach_engagement = reach_engagement.dropDuplicates()

                # Rename the columns as per naming convention
                reach_engagement = (
                    reach_engagement.withColumnRenamed("REACH", "REACH_CNT")
                    .withColumnRenamed("IMPRESSIONS", "IMPRESSIONS_CNT")
                    .withColumnRenamed("CONVERSIONS", "CONVERSIONS_CNT")
                    .withColumnRenamed("CLICKS", "CLICKS_CNT")
                    .withColumnRenamed("SALES", "SALES_AMT")
                )

                # Group by specific columns to calculate sum of media_spend
                unified_campaign_filtered = unified_campaign_filtered.group_by(
                    "CHANNEL_NAME_UNI", "SUBCHANNEL_NAME_UNI", "CAMPAIGN_ID_UNI", "MARKETING_TYPE_UNI"
                ).agg(sum(col("MEDIA_SPEND_AMT_UNI")).alias("MEDIA_SPEND_AMT_UNI"))

                # Create a join condition to merge the aggregated reach data with the unified campaign data.
                # This merge retrieves the media spend at the campaign, marketing type, channel, and subchannel levels.
                # The resulting data is further used for recalibration of offsite channels and for calculating ROAS (Return on Ad Spend)
                # and iROAS (Incremental Return on Ad Spend) for the campaign.
                join_condition = (
                    (
                        ~lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360")
                    ) & (
                        lower(unified_campaign_filtered["CAMPAIGN_ID_UNI"]) == lower(reach_engagement["CAMPAIGN_ID"])
                    ) & (
                        lower(unified_campaign_filtered["SUBCHANNEL_NAME_UNI"]) == lower(reach_engagement["SUBCHANNEL_NAME"])
                    ) & (
                        lower(unified_campaign_filtered["CHANNEL_NAME_UNI"]) == lower(reach_engagement["CHANNEL_NAME"])
                    ) & (
                        lower(unified_campaign_filtered["MARKETING_TYPE_UNI"]) == lower(reach_engagement["MARKETING_TYPE"])
                    )
                )

                # Merge aggregated reach data and unified_campaign_filtered data
                reach_engagement = reach_engagement.join(
                    unified_campaign_filtered, join_condition, "left"
                )

                ''' For channel meta, youtube and dv360, pick the media spend
                    from unified_campaign, otherwise pick media spend from
                    reach data
                '''
                reach_engagement = reach_engagement.with_column(
                    "MEDIA_SPEND_AMT",
                    when(
                        ~lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
                        col("MEDIA_SPEND_AMT_UNI"),
                    ).otherwise(col("MEDIA_SPEND_AMT")),
                )
            else:
                # Return empty dataframe
                reach_engagement = reach_empty_df
        else:
            # Return empty dataframe
            reach_engagement = reach_empty_df

        # Add invocation_id as job_run_id in the data
        reach_engagement = reach_engagement.with_column("JOB_RUN_ID", lit(invocation_id))

        # Cast the final columns in the required data type
        reach_engagement = cast_columns_to_types(reach_engagement)

        # Select columns in the same order as in the final table
        existing_seq = reach_empty_df.columns
        reach_engagement = reach_engagement.select(*existing_seq).fillna(0)

    except Exception as e:
        # This section of the code processes the reach and engagement data. If no valid data is found,
        # it returns an empty dataframe. Otherwise, it appends the invocation ID as a job run identifier,
        # casts columns to the required data types, and ensures the column order matches the final table schema.
        # In case of an exception, it logs the error details (type, message, and trace) into the error log table
        # using the `log_process_helper` function and raises the exception to stop execution.
        error_type = type(e).__name__
        error_message = str(e)
        error_trace = traceback.format_exc()
        error_message = extract_error_message(error_message)
        schema = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "ERROR_LOG_TABLE").schema
        log_process_helper(
            session,
            error_message,
            error_trace,
            error_type,
            "reach_engagement",
            "MTA",
            "Failed",
            booking_id,
            campaign_duration,
            invocation_id,
            schema
        )
        raise
    # Return the calculated reach engagement data and added to the table
    return reach_engagement