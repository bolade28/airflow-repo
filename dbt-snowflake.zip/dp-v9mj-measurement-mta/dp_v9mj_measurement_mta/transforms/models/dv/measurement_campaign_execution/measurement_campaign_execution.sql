{#
/*********************************************************************************************************************************************
* Objective - The objective of this script is to retrieve and manage campaign-specific details for
a given booking ID from the unified campaign table.
It identifies campaigns that have either not been processed yet or have completed one full
Multi-Touch Attribution (MTA) cycle.
The script ensures proper handling of campaigns in different stages ("During" or "Post") and
prepares the data for downstream usage,
such as in attribution modeling and customer data collection.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/852563189/Measurement+Campaign+Execution
* Upstream: UNIFIED_CAMPAIGN
* Downstream: MTA_ATTRIBUTION_MODEL_RESULT_OFFER,MTA_ATTRIBUTION_MODEL_RESULT_BRAND,
MTA_ATTRIBUTION_MODEL_RESULT_AISLE, CUSTOMER_DATA_COLLECTION,USER_JOURNEY_OFFER,USER_JOURNEY_BRAND
USER_JOURNEY_AISLE, ATTRIBUTION_PRE_REQUISITE_OFFER, ATTRIBUTION_PRE_REQUISITE_BRAND,ATTRIBUTION_PRE_REQUISITE_AISLE,
BASELINE_OFFER, BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_OFFER,
BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_BRAND,BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE,
REACH_ENGAGEMENT,MEASUREMENT_CAMPAIGN_REPORTING
*
* This script will return one booking id which has not been processed yet or has one complete run for mta.


* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}
{# {{ log("Running measurement campaign execution details", info=True ) }} #}
{# /*If no campaign has been found to be in queue for execution or has In-progress job status
then post-hook macro will raise error */#}
{{
    config(
        materialized='incremental',
        incremental_strategy='append',
        post_hook="{{ check_campaign_availability() }}",
        name = 'measurement_campaign_execution',
        unique_key = ['campaign_id','booking_id','job_bag_number','channel_name','subchannel_name','campaign_duration','campaign_start_dt','campaign_end_dt']
    )
}}

{# /* In case campaign duration,booking_id and campaign status is not passed as parameter from
astro dag run or command line */ #}
{% if var('campaign_duration',false) == false and var('booking_id', false) == false
and var('campaign_status',false) == false %}

{{ log("Checking for variables '{{ var('campaign_duration') }}", info=True ) }}

{# /* When the campaign duration is post, it can be considered whenever a campaign has
completed the whole mta pipeline once */ #}
with post_booking_id as (
    select booking_id
    from {{ this }}
    group by booking_id
    having count(distinct campaign_duration) = 1
)

{# /* getting booking ids which has completed the whole mta pipeline once */ #}
, get_completed_booking_id as (
    select booking_id
    from {{ this }}
    where
        job_status = 'Completed'
        and booking_id in (select booking_id from post_booking_id)
)

{# /* getting the max_load_ts for the given booking id to fetch the latest records for post campaign period. */ #}
, get_post_load_ts as (
    select
        campaign_id
        , max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
    where booking_id in (select booking_id from get_completed_booking_id)
    group by campaign_id
)

{#
/**********************
1. The post campaign_execution is used to get the campaign details for the post campaign period.
2. For a given booking id, there would be multiple campaigns,so there will be multiple post_campaign_dt.
We are extracting the max post_campaign_dt for each booking id.
***********************/
#}
, get_post_campaign_execution as (
    select
        mce.campaign_id
        , mce.booking_id
        , mce.job_bag_number
        , mce.marketing_type
        , mce.channel_name
        , mce.subchannel_name
        , mce.campaign_start_dt
        , uc.post_campaign_dt as campaign_end_dt
        , mce.campaign_name
        , 'Post' as campaign_duration
        , max(
            uc.post_campaign_dt) over
        (partition by mce.booking_id) as max_end_date
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }} as uc
    inner join {{ this }} as mce
        on
            uc.campaign_id = mce.campaign_id
            and uc.channel_name = mce.channel_name
    where mce.booking_id in (select booking_id from get_completed_booking_id)
    and (uc.campaign_id, uc.load_ts) in (select
                                            campaign_id
                                            , load_ts
                                        from get_post_load_ts
                                    )
)


{#  /*filtering out booking_id which has post campaign date before the presesnt
data as we are supposed to process those campaigns
which have ended. */ #}
, get_single_post as (
    select distinct booking_id
    from get_post_campaign_execution
    where max_end_date < current_date()
    limit 1
)

{#
/**********************
1. The post_campaign is used to get the campaign details for the post campaign period.
2. We are replacing the special characters in the campaign name with empty string as this will
create issues while customer_data collection
scripts fetch this value.
***********************/
#}
, get_post_campaign as (
    select distinct
        campaign_id
        , booking_id
        , job_bag_number
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_start_dt
        , campaign_end_dt
        , campaign_duration
        , regexp_replace(campaign_name, '[^A-Za-z0-9 ]', '') as campaign_name
    from get_post_campaign_execution
    where booking_id in (select booking_id from get_single_post)
)

{#
/**********************
1. From unified campaign table, we are getting the booking ids which has not started yet.
2. This means it has no records in the mta tables.
3. So it can be run fot the during period.
***********************/
#}
, get_during_loads as (
    select 
        booking_id
        , campaign_id
        , max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
    where campaign_status is null or campaign_status = 'Not Started'
    group by 1, 2
)

{# /* filtering out bookingids whose campaigns which has campaign end date after the
current date for atleast one campaign */ #}
, get_during_res as (
    select
        booking_id
        , max(campaign_end_dt) as campaign_end_dt
        , max(load_ts) as load_ts
    from
        {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
    where
        campaign_status is null or campaign_status = 'Not Started'
        and (booking_id, campaign_id, load_ts) in (select 
                                        booking_id
                                        , campaign_id
                                        , load_ts
                                    from get_during_loads)
    group by booking_id
    having max(campaign_end_dt) < current_date()
    limit 1
)

{# /* getting campaign specific details for the selected booking ids and replacing special characters
in the campaign name with empty string as this will create issues while running
customer_data collection scripts. */ #}
, get_during_execution as (
    select
        campaign_id
        , booking_id
        , job_bag_number
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_start_dt
        , campaign_end_dt
        , 'During' as campaign_duration
        , regexp_replace(campaign_name, '[^A-Za-z0-9 ]', '') as campaign_name
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
    where (booking_id, load_ts) in (select booking_id, load_ts from get_during_res)
)

{#  /*combining selected campaigns from post and during */ #}
, get_measurement_campaign_execution as (
    select * from get_post_campaign
    union all
    select * from get_during_execution
)

{#
/**********************
1. Getting single booking id as at a time there could be one bookingid running in the measurement campaign execution.
2. We are getting the booking id which has the latest campaign end date.
***********************/
#}
, get_single_booking_id as (
    select booking_id
    from get_measurement_campaign_execution order by campaign_end_dt desc limit 1
)

{#
/**********************
1. Typecasting to appropriate data type.
2. Load_ts is the timestamp when the record was loaded into the table and it is set to current timestamp.
3. Job_run_id is the unique id for the job run and it is set to the invocation id.
4. Job_status is set to 'Not Started' as the campaign has not started yet.
5. We are running this query fo the selected booking id in the previous step.
***********************/
#}
select
    campaign_id::varchar(1000) as campaign_id
    , booking_id::varchar(1000) as booking_id
    , job_bag_number::varchar(1000) as job_bag_number
    , marketing_type::varchar(14) as marketing_type
    , channel_name::varchar(1000) as channel_name
    , subchannel_name::varchar(1000) as subchannel_name
    , campaign_name::varchar(1000) as campaign_name
    , campaign_start_dt::date as campaign_start_dt
    , campaign_end_dt::date as campaign_end_dt
    , campaign_duration::varchar(6) as campaign_duration
    , 'Not Started'::varchar(11) as job_status
    , current_timestamp::timestamp_ntz(9) as load_ts
    , '{{ invocation_id }}' as job_run_id
from get_measurement_campaign_execution
where booking_id in (select booking_id from get_single_booking_id)

{# /* in case campaign status,booking id and campaign duration has been passed as parameter
from astro or command line */ #}

{% else %}

{#
/**********************
1. Getting the max_load_ts for the given booking id to fetch the latest records from the unified campaign table.
2. This was done to get latest records from unified campaign table for the given booking id.
***********************/
#}
    with max_load_ts as (
        select
            '{{ var('booking_id') }}' as booking_id
            , campaign_id
            , max(load_ts) as load_ts
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
        group by 1, 2
    )

{#
/**********************
1. Typecasting to appropriate data type.
2. Load_ts is the timestamp when the record was loaded into the table and it is set to current timestamp.
3. Job_run_id is the unique id for the job run and it is set to the invocation id.
4. Job_status is set to passed parameter.
5. We are replacing special characters in the campaign name with empty string as this will create issues
while running customer_data collection scripts.
***********************/
#}
    select distinct
        campaign_id::varchar(1000) as campaign_id
        , booking_id::varchar(1000) as booking_id
        , job_bag_number::varchar(1000) as job_bag_number
        , marketing_type::varchar(14) as marketing_type
        , channel_name::varchar(1000) as channel_name
        , subchannel_name::varchar(1000) as subchannel_name
        , regexp_replace(campaign_name, '[^A-Za-z0-9 ]', '')::varchar(1000) as campaign_name
        , campaign_start_dt::date as campaign_start_dt
        , case
            when '{{ var('campaign_duration') }}' = 'During' then campaign_end_dt::date
            else post_campaign_dt
        end as campaign_end_dt
        , '{{ var('campaign_duration') }}'::varchar(6) as campaign_duration
        , '{{ var('campaign_status') }}'::varchar(11) as job_status
        , current_timestamp::timestamp_ntz(9) as load_ts
        , '{{ invocation_id }}' as job_run_id
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }}
    where
        (booking_id, campaign_id, load_ts)
        in (
            select
                booking_id
                , campaign_id
                , load_ts
            from max_load_ts
        )
{% endif %}
