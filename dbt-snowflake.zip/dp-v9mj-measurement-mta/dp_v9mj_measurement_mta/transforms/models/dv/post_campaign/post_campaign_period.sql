{#
/*********************************************************************************************************************************************
* Objective - The post-campaign period is a critical phase that signifies the timeframe commencing immediately after the conclusion of a marketing or advertising campaign.
This period is particularly important as it allows for a focused and defined window of opportunity for potential customers
who have been exposed to the advertisement towards the end of the campaign.This SQL script calculates transaction frequency metrics,
including median, 70th, 80th, and 90th percentiles, for items purchased by Gold and Platinum customers over the past year.
It identifies repeat purchase trends and assigns items to proposed buckets based on transaction intervals, handling edge cases for isolated data points.
The results are used to analyze customer behavior post-campaign, converting transaction intervals into meaningful weeks-based metrics.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657261835/Campaign+Post-Period+Calculation
* Upstream:  This is independent model and does not depend on any other model and runs on yearly basis
* Downstream: UNIFIED_cAMPAIGN
*
* This script will return transaction and touchpoint data for dv360 campaigns.

* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{# {{ log("Running post campaign period", info=True ) }} #}


{{
    config(
        materialized='incremental',
		transient=False,
        incremental_strategy= 'merge',
        post_hook = "{{ validation_macro_run('post_campaign_period') }}",
        name = 'post_campaign_period',
        unique_key=['item_cd','year_of_transaction']
    )
}}

{% set execution_date = run_started_at %}
{{ log("Execution Date: "~execution_date, info=True) }}

{% set previous_year = execution_date.strftime("%Y") | int - 1 %}
{{ log("Year: "~previous_year, info=True) }}

{% set current_month = execution_date.strftime("%m") %}
{{ log("Month: "~current_month, info=True) }}

-- Check if it's a unit test
{% set is_unit_test = dbt_unit_testing.running_unit_test() %}

-- Check if there is data from last year in the table
{% set existing_data_flag = get_existing_data_flag(is_unit_test, previous_year) %}

{{ log("Flag Status: "~existing_data_flag, info=True) }}

{% if current_month == '01' and not existing_data_flag %}

{#
/*********************************************************************************************************************
1. The filtered_ean CTE retrieves the most recent record for each item_nk1 from the EAN_BR table, ensuring that only valid records are included.
2. It filters out records that are marked as deleted or have a validity date of '9999-12-31'.
3. This CTE is used to ensure that the most up-to-date information is used in subsequent joins.
***********************************************************************************************************************/
#}
with filtered_ean as (
    select
        item_nk1
        , max(load_ts) as max_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'EAN_BR') }}
    where
        valid_to_dt = '9999-12-31'
        and record_deleted_flag <> 'Y'
    group by 1
)

{#
/*********************************************************************************************************************
1. The get_brand_data CTE joins the filtered_ean CTE with the EAN_BR table to retrieve brand-related information for each item_nk1.
2. It filters out records that are marked as deleted or have a validity date of '9999-12-31'.
3. The result includes the item_nk1, brand_name, brand_owner_name, and ean_nk1 for each item.
5. This CTE is used to enrich the campaign data with brand information.
****************************************************************************************************************/
#}
, get_brand_data as (
    select eb.*
    from filtered_ean as fe
    inner join {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'EAN_BR') }} as eb
        on
            fe.item_nk1 = eb.item_nk1
            and fe.max_ts = eb.load_ts
)

{# /* Reading relevant details from dim item table. This will be required in later steps to get consolidated data for all transactions */#}
, transaction_df as (
    select distinct
        di.super_cat_name
        , di.item_cd
        , di.item_short_name
    from get_brand_data as gbd
    inner join {{ source('ADW_PRODUCT_PL', 'DIM_ITEM') }} as di
        on gbd.item_nk1 = di.item_cd
)

--{# /*Getting details of all transactions for the last year */#}
, transaction_data as (
    select
        fsti.*
        , tdf.super_cat_name
        , tdf.item_short_name
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }} as fsti
    inner join transaction_df as tdf
        on fsti.item_cd = tdf.item_cd
    where year(fsti.transaction_dt) = year(current_date) - 1
)

{# /* Getting loyalty id,transaction details and item they bought. This will be used in the later steps when we filter out transaction details for regular customers */#}
, filtered_transaction_data as (
    select distinct
        dcl.nectar_collector_card_num
        , td.transaction_id
        , td.transaction_dt
        , di.super_cat_name
        , di.sub_cat_name
        , di.item_short_name
        , di.item_cd
    from transaction_data as td
    inner join {{ source('ADW_PRODUCT_PL', 'DIM_ITEM') }} as di
        on di.item_cd = td.item_cd
    inner join {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }} as fstb
        on td.transaction_id = fstb.transaction_id
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on dcl.nectar_collector_card_num = fstb.nectar_card_num_hash
)

{# /* Identifying Gold and Platinum Customers as we would want to consider only regular customers to identify the repeat purchase trends */ #}
, gold_plat_customers as (
    select
        batch_id
        , loyalty_seg
        , enterprise_customer_num
        , row_number() over (partition by enterprise_customer_num order by batch_id desc) as row_num
    from {{ source('ADW_PL', 'LOYALTY_SEGMENTS') }}
    where loyalty_seg in ('GO', 'PL')
)

{# /* Filtering Transactions of Gold and Platinum Customers as we only want to consider regular customers to identify the repeat purchase trends */ #}
, gold_plat_customers_trans as (
    select
        ftd.*
        , gpc.enterprise_customer_num
        , gpc.loyalty_seg
        , gpc.row_num
    from filtered_transaction_data as ftd
    inner join gold_plat_customers as gpc
        on ftd.nectar_collector_card_num = gpc.enterprise_customer_num
    where
        gpc.row_num = 1
        and gpc.loyalty_seg in ('GO', 'PL')
)

{# /*To find time between 2 transactions we are creating a lag transaction date column that has takes the next date into consideration */  #}
, transaction_diff as (
    select
        transaction_id
        , nectar_collector_card_num
        , transaction_dt
        , super_cat_name
        , item_cd
        , item_short_name
        , lag(transaction_dt)
            over (partition by nectar_collector_card_num, item_short_name, item_cd order by transaction_dt)
            as previous_transaction_date
    from
        gold_plat_customers_trans
)

{# /*Calculating Time between transactions  to understand how much time do the regular customers take between two purchase */#}
, time_bet_transaction as (
    select
        transaction_id
        , nectar_collector_card_num
        , super_cat_name
        , item_cd
        , item_short_name
        , transaction_dt
        , case
            when previous_transaction_date is not null then datediff(day, previous_transaction_date, transaction_dt)
            else 0
        end as time_between_transactions
    from transaction_diff
    order by 2, 6, 5
)

{# /*Counting the number of transactions each customer makes during the campaign period */ #}
, customer_data as (
    select
        nectar_collector_card_num
        , item_short_name
        , item_cd
        , count(distinct transaction_id) as repeat_transactions
    from gold_plat_customers_trans
    group by 1, 2, 3
)

{# /*Ensuring we only consider gold and platinum customers with repeat transactions during campaign period */ #}
, repeat_customer_data as (
    select
        nectar_collector_card_num
        , item_short_name
        , item_cd
        , repeat_transactions
    from customer_data
    where repeat_transactions > 1
    order by 4 desc
)

{# /* Keeping a count of distinct customers at item_cd level who are apart of this analysis to ensure each item_cd has a repeat purchase with more than 1 customer */ #}
, freq_count as (
    select
        repeat_transactions
        , item_short_name
        , item_cd
        , count(distinct nectar_collector_card_num) as number_of_customers
    from repeat_customer_data
    group by 1, 2, 3
)

{# /*Calculating Post campaign period as Median of time_between_transactions (in days) which is currently agreed upon. But also noting down 70th/80th/90th Percentile values of time between transactions for reference to understand customer behavior */ #}
, post_campaign_days as (
    select
        super_cat_name
        , item_short_name
        , item_cd
        , median(time_between_transactions) as median_time_between_transactions
        , percentile_cont(0.7) within group (order by time_between_transactions) as pct_70
        , percentile_cont(0.8) within group (order by time_between_transactions) as pct_80
        , percentile_cont(0.9) within group (order by time_between_transactions) as pct_90
    from
        time_bet_transaction
    where
        time_between_transactions <> 0
        and item_cd in (select distinct item_cd from freq_count where number_of_customers > 1)
    group by 2, 3, 1
)

{# /* The above calculated values of Post Campaign Period are in days so the below CTE converts Days to Weeks */ #}
, post_campaign_week_difference as (
    select
        super_cat_name
        , item_short_name
        , item_cd
        , median_time_between_transactions as median_time_between_transactions_days
        , pct_70 as time_period_70_pct_days
        , pct_80 as time_period_80_pct_days
        , pct_90 as time_period_90_pct_days
        , case
            when median_time_between_transactions < 84 then ceil(median_time_between_transactions / 7)
            else 12
        end as median_time_period_between_transactions_wk
        , ceil(pct_70 / 7) as time_period_70_pct_wk
        , ceil(pct_80 / 7) as time_period_80_pct_wk
        , ceil(pct_90 / 7) as time_period_90_pct_wk
    from post_campaign_days
)

{# /*Taking a count of item_cd that fall within each median time between transactions (weeks) and ordering the Median Weeks column in ascending. This would be further used to calculate proposed buckets of Post Campaign Period */ #}
, get_media_bucket as (
    select
        median_time_period_between_transactions_wk
        , count(distinct item_cd) as total_items
    from post_campaign_week_difference
    group by 1
    order by 1 asc
)

{# /*Calculating the Proportion of item_cd that fall within each median time between transactions (weeks) using the above counts and ordering the Median Weeks column in ascending */ #}
, get_proportion_sum as (
    select
        median_time_period_between_transactions_wk
        , total_items / (select sum(total_items) from get_media_bucket) * 100 as proportion_of_item_cd
    from get_media_bucket
    order by 1 asc
)

{# {{ log("Calculating cumulative sum of proportion", info=True ) }} #}
, get_cumulative_result as (
    select
        median_time_period_between_transactions_wk
        , sum(proportion_of_item_cd) over (order by median_time_period_between_transactions_wk) as cumulative_item_cd_proportion
    from get_proportion_sum
)

{# /* Calculating percentiles 10th, 30th, 50th and 80th for the cumulative proportion */ #}
 , get_proportion_percentile AS (
    SELECT
        PERCENTILE_CONT(0.10) WITHIN GROUP (ORDER BY cumulative_ITEM_CD_PROPORTION) AS percentile_10,
        PERCENTILE_CONT(0.30) WITHIN GROUP (ORDER BY cumulative_item_cd_proportion) AS percentile_30,
        PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY cumulative_item_cd_proportion) AS percentile_50,
        PERCENTILE_CONT(0.80) WITHIN GROUP (ORDER BY cumulative_item_cd_proportion) AS percentile_80
    FROM get_cumulative_result
)

{# /* Shifted original logic of percentile bucketing from last select statement to proposed_bucket CTE for ease of working with isolation logic
 percentiles as columns to the cumulative result
 The percentiles are added to get_cumulative_result with the help of cross_join
 Based on the percentiles, the proposed bucket is calculated for each item_cd
 This is tested on 2022,2023 and 2024 to yield agreed static buckets (2,4,6,9,12) with Analytics team
 These buckets needs monitoring in the future if consumer trends change. We will change it accordingly */ #}
, proposed_bucket as (
SELECT
    gcr.*, 
    CASE
        when gcr.cumulative_item_cd_proportion <= gpp.percentile_10 then 2
        when gcr.cumulative_item_cd_proportion > gpp.percentile_10 and gcr.cumulative_item_cd_proportion <= gpp.percentile_30 then 4
        when gcr.cumulative_item_cd_proportion > gpp.percentile_30  and gcr.cumulative_item_cd_proportion <= gpp.percentile_50 then 6
        when gcr.cumulative_item_cd_proportion > gpp.percentile_50 and gcr.cumulative_item_cd_proportion <= gpp.percentile_80 then 9
        when gcr.cumulative_item_cd_proportion >= gpp.percentile_80 then 12
    END AS median_proposed_bucket_wk
FROM get_cumulative_result AS gcr
CROSS JOIN get_proportion_percentile AS gpp )

{# /* Bucketing the max week from median_wk for each proposed bucket. */ #}
, bucketed_max AS (
    SELECT
        pb.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
        MAX(pb.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) OVER (PARTITION BY pb.median_proposed_bucket_wk) AS MEDIAN_PROPOSED_BUCKET_WK
    FROM proposed_bucket AS pb
)
{# {{ log("Start of isolated bucker checker", info=True ) }} #}
{# /*Purpose: the percentiles have been tested with older data 2022,2023 and 2024. Few edge cases were identified if consumer behaviour were to change
 We wanted to have simple logic which can be explained for edge cases.

 We are adding second layer of logic to handle isolated buckets.
 Create lagged median_wk for previous and next bucket */ #}
,lagged_wk AS (
    SELECT 
        MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
        MEDIAN_PROPOSED_BUCKET_WK,
        LAG(MEDIAN_PROPOSED_BUCKET_WK) OVER (ORDER BY MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) AS prev_bucket,
        LEAD(MEDIAN_PROPOSED_BUCKET_WK) OVER (ORDER BY MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) AS next_bucket
    FROM bucketed_max)


{# /* Pseudo logic for flag ''is_isolated'':
  isolation in the start: if previous bucket is null and next bucket is not equal to median_proposed_bucket_wk then 1
 isolation in the end: if next bucket is null and previous bucket is not equal to median_proposed_bucket_wk then 1
 isolation in the mid: if median_proposed_bucket_wk is not equal to previous bucket and median_proposed_bucket_wk is not equal to next bucket then 1

 Logic Advantages: This way edge cases of isolated bucket at the Start, Mid and last are handled
 Example: If the first bucket is isolated, then the next bucket is chosen
 If the last bucket is isolated, then the previous bucket is chosen
 If the bucket is isolated in the middle, then the closest non-isolated bucket is chosen priotizing previous bucket */ #}
, isolation_check AS (
    SELECT 
        MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
        MEDIAN_PROPOSED_BUCKET_WK,
        prev_bucket,
        next_bucket,
        CASE 
            WHEN prev_bucket IS NULL AND next_bucket != MEDIAN_PROPOSED_BUCKET_WK THEN 1  
            WHEN next_bucket IS NULL AND prev_bucket != MEDIAN_PROPOSED_BUCKET_WK THEN 1  
            WHEN MEDIAN_PROPOSED_BUCKET_WK != prev_bucket AND MEDIAN_PROPOSED_BUCKET_WK != next_bucket THEN 1
            ELSE 0 
        END AS is_isolated
    FROM lagged_wk
)

{# /* based on isolated flag, group the items to the closest non-isolated bucket
 Previously, the logic prioritizes the previous bucket if the current bucket is isolated
 If the previous bucket is not present (example: first row), then the next bucket is chosen
 Updated logic: The isolated bucket will be matched with closest non-isolated bucket based on the difference between them.
 If the difference between the isolated bucket and previous bucket is less than the difference between the isolated bucket and next bucket, then the previous bucket is chosen. 
 Ex: current MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK is 5, previous is 4 and next is 9. The difference between 5 and 4 is 1 and between 5 and 9 is 4.
 So, the previous bucket is chosen.
  */
#}
, dynamic_grouping AS (
    SELECT 
        ic.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
        ic.MEDIAN_PROPOSED_BUCKET_WK,
        CASE 
            {# /* If isolated, group with the closest non-isolated bucket */ #}
            WHEN is_isolated = 1 THEN 
                CASE 
                    WHEN ABS(ic.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK - PREV_BUCKET) <= ABS(ic.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK - NEXT_BUCKET) 
                    THEN PREV_BUCKET 
                    ELSE NEXT_BUCKET 
                END
            ELSE 
                ic.MEDIAN_PROPOSED_BUCKET_WK
        END AS group_id
    FROM isolation_check as ic
    join proposed_bucket pb on pb.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK = ic.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK
)

{# {{ log("End of isolated bucker checker", info=True ) }} #}
{# /* Following is to address an issue when the isolated bucket is more than proposed bucket value
 After discussion we established to pick max value in the bucket and change the proposed bucket to max value
 This is done to avoid the isolated bucket to be more than the max bucket. 
 Ex : isolated MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK=4 and after grouping with prevous bucket of 2, the old proposed bucket was 2 and new is 4
*/ 
#}

,max_bucket_calc AS (
    SELECT 
        group_id,
        MAX(MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) AS max_bucket
    FROM dynamic_grouping
    GROUP BY group_id
)


{# /*This snippet ensures that the proposed bucket for each median transaction period is updated to the maximum bucket value within its group,
addressing edge cases or isolated buckets. The result is an ordered list of corrected bucket values for each transaction period. */#}
, corrected_bucket as (
SELECT 
    dg.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
    dg.MEDIAN_PROPOSED_BUCKET_WK,
    mbc.max_bucket AS updated_MEDIAN_PROPOSED_BUCKET_WK
FROM dynamic_grouping dg
JOIN max_bucket_calc mbc ON dg.group_id = mbc.group_id
ORDER BY dg.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK)

select
    pcwd.super_cat_name
    , pcwd.item_short_name
    , pcwd.item_cd
    , pcwd.median_time_between_transactions_days
    , pcwd.time_period_70_pct_days
    , pcwd.time_period_80_pct_days
    , pcwd.time_period_90_pct_days
    , pcwd.median_time_period_between_transactions_wk
    , pcwd.time_period_70_pct_wk
    , pcwd.time_period_80_pct_wk
    , pcwd.time_period_90_pct_wk
    , cb.updated_MEDIAN_PROPOSED_BUCKET_WK as median_proposed_bucket_wk
    , '{{ invocation_id }}' as job_run_id
    , current_timestamp::timestamp_ntz as load_ts
    , year(current_date) - 1 as year_of_transaction
from post_campaign_week_difference as pcwd
inner join corrected_bucket as cb
    on pcwd.median_time_period_between_transactions_wk = cb.median_time_period_between_transactions_wk
{# {{ log("Proposed Bucket created", info=True ) }} #}


{% else %}
    {% if current_month != '01' %}
        {{ log("It is not January. Skipping script execution.", info=True) }}
    {% else %}
        {{ log("Previous year's data already exists. Skipping script execution.", info=True) }}
    {% endif %}

    /*
    This query won't return anything.
    We need it because of how DBT runs incremental models.
    It checks the columns to merge.
    */
    SELECT
        CAST(NULL AS VARCHAR) AS super_cat_name,
        CAST(NULL AS VARCHAR) AS item_short_name,
        CAST(NULL AS NUMBER) AS item_cd,
        CAST(NULL AS NUMBER) AS median_time_between_transactions_days,
        CAST(NULL AS NUMBER) AS time_period_70_pct_days,
        CAST(NULL AS NUMBER) AS time_period_80_pct_days,
        CAST(NULL AS NUMBER) AS time_period_90_pct_days,
        CAST(NULL AS NUMBER) AS median_time_period_between_transactions_wk,
        CAST(NULL AS NUMBER) AS time_period_70_pct_wk,
        CAST(NULL AS NUMBER) AS time_period_80_pct_wk,
        CAST(NULL AS NUMBER) AS time_period_90_pct_wk,
        CAST(NULL AS NUMBER) AS median_proposed_bucket_wk,
        CAST('{{ invocation_id }}' AS VARCHAR) AS job_run_id,
        CAST(NULL AS TIMESTAMP_NTZ) AS load_ts,
        CAST(NULL AS NUMBER) AS year_of_transaction
    WHERE false
{% endif %}