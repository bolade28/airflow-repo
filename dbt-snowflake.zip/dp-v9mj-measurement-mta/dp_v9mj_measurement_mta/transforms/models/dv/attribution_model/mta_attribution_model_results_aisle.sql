{#/**************************************************************************
* This script generates modeling results for aisle by calling the stored procedures residing in the schema and would save the result directly into the table. 
* The model will create a dummy view in the transformation schema.
* 
* Owner : Gaurav Rawal
* Date : 05/12/2024
*
* Change Log 
* ----------------------------
1. Initial Version : Create a stored procedure for generating modelling results for aisle
******************************************************************************/#}

{# {{ log("Running Attribution Model Results Aisle", info=True ) }} #}
{{
    config(
        pre_hook = "alter session set statement_timeout_in_seconds = 21600;",
        post_hook = ["call attribution_model_results_aisle(OBJECT_CONSTRUCT('regression_variable_list', {{ var('regression_variable_list') }}::array, 'test_size', {{ var('test_size') }}, 'max_executors', {{ var('max_executors') }}, 'n_bags', {{ var('n_bags') }}, 'bal_ratio', {{ var('bal_ratio') }}, 'f1_score_limit', {{ var('f1_score_limit') }}, 'invocation_id', '{{ invocation_id }}', 'schema', '{{ var('schema') }}', 'measurement_campaign_execution', '{{ var('measurement_campaign_execution') }}', 'attribution_model_results_aisle', '{{ var('attribution_model_results_aisle') }}', 'attribution_pre_requisite_aisle', '{{ var('attribution_pre_requisite_aisle') }}', 'campaign_decay_rate', '{{ var('campaign_decay_rate') }}', 'baseline_integration_sku', '{{ var('baseline_integration_sku') }}','minimum_conversion_upper_limit', '{{ var('minimum_conversion_upper_limit') }}','minimum_conversion_lower_limit', '{{ var('minimum_conversion_lower_limit') }}','high_conversion_bal_ratio', '{{ var('high_conversion_bal_ratio') }}',
        'balance_increment', '{{ var('balance_increment') }}','balance_decrement_small', '{{ var('balance_decrement_small') }}','balance_decrement_large', '{{ var('balance_decrement_large') }}','balance_ratio_factor', '{{ var('balance_ratio_factor') }}',
        'random_state', '{{ var('random_state') }}','solver', '{{ var('solver') }}','max_iter', '{{ var('max_iter') }}'  ));
        ","{{ validation_macro_run('attribution_model_results_aisle') }}"]
    )
}}

with pre_requisite_aisle as (
    select 1 as id
    from {{ ref ('attribution_pre_requisite_aisle') }}
)

select distinct id from pre_requisite_aisle
