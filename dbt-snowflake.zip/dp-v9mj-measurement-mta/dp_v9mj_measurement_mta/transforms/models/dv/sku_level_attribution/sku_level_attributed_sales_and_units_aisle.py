"""
/**************************************************************************
* Script Name: sku_level_attributed_sales_and_units_aisle.py
*
* Objective:
* This script is designed to compute SKU-level attributed sales and units
* for marketing campaigns, including recalibrated sales and units specifically
* for off-site aisles. It integrates data from the attribution model results table
* using the transaction key to map the attribution weights for the sales and unit
* purchases at the SKU level. These results are stored in downstream tables to
* support further analysis, reporting, and decision-making processes.
*
* The script ensures data accuracy, handles potential errors, and logs issues
* for troubleshooting. For offsite channels, it calculates a recalibration factor
* that rescales the attributed sales back to the actual DTP sales. This is necessary
* because, for Meta, the exact exposed audience is unknown, which might lead to
* inflated attributed sales.
*
* Key Performance Indicators (KPIs):
* - Attributed Sales: Sales directly attributed to the marketing campaign.
* - Attributed Units: Units directly attributed to the marketing campaign.
* - Recalibrated Sales: Adjusted sales figures based on actual DTP sales.
* - Recalibrated Units: Adjusted unit figures based on actual DTP sales.
*
* Functions Used from Staging:
* - calculate_aggregated_sales: Aggregates sales data at the SKU level.
* - calculate_recalibrated_sales: Computes recalibrated sales for offsite channels.
* - get_campaign_start_end_date: Retrieves the start and end dates of the campaign.
*
* Confluence Link:
* https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/852531012/SKU+Level+Attributed+Sales+and+Attributed+Units+Calculations
*
* Upstream:
* - ATTRIBUTION_MODEL_RESULTS_AISLE
*
* Downstream:
* - BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
*
* Owner: Sahil Arya
* Date: 18/10/2024
*
**************************************************************************/
"""

from snowflake.snowpark import Session
from snowflake.snowpark.functions import (col, current_timestamp, date_trunc,
                                          lit, lower, max, to_char)
from snowflake.snowpark.types import (DateType, DecimalType, FloatType,
                                      IntegerType, StringType, TimestampType)
import traceback
from datetime import datetime


def cast_columns_to_types(df):
    """
    Casts the columns of a DataFrame to their respective Snowflake data types.

    Objective:
    This function ensures data consistency by casting the columns of the input DataFrame
    to their respective Snowflake data types as defined in the `column_types` mapping.
    It is critical for ensuring schema alignment and accurate downstream processing.

    Used in:
        - sku_level_attributed_sales_and_units_aisle: Used to standardize column data types
          for SKU-level attributed sales and units data processing workflows.

    Parameters:
        df (DataFrame): The input DataFrame containing raw data with columns to be cast.

    Returns:
        DataFrame: A DataFrame with columns cast to their respective Snowflake data types.

    Example:
        Input:
            df = DataFrame([
                {"CAMPAIGN_ID": "CAMP001", "NET_SALES_AMT": "100.50", "UNITS_QTY": "10.0", "LOAD_TS": "2023-10-01 12:00:00"},
                {"CAMPAIGN_ID": "CAMP002", "NET_SALES_AMT": "200.75", "UNITS_QTY": "20.0", "LOAD_TS": "2023-10-02 12:00:00"}
            ])

        Output:
            DataFrame([
                {"CAMPAIGN_ID": "CAMP001", "NET_SALES_AMT": 100.50, "UNITS_QTY": 10.0, "LOAD_TS": datetime(2023, 10, 1, 12, 0, 0)},
                {"CAMPAIGN_ID": "CAMP002", "NET_SALES_AMT": 200.75, "UNITS_QTY": 20.0, "LOAD_TS": datetime(2023, 10, 2, 12, 0, 0)}
            ])

    Raises:
        Exception: If an error occurs during the column casting process, it logs the error
                   details and raises an exception with the error information.
    """
    try:
        # Define a mapping of column names to their respective Snowflake data types
        column_types = {
            "CAMPAIGN_ID": StringType(1000),
            "CHANNEL_NAME": StringType(1000),
            "USERJOURNEY_ID": StringType(1000),
            "LOYALTY_ID": StringType(1000),
            "BOOKING_ID": StringType(1000),
            "CUSTOMER_JOURNEY_TYPE": StringType(1000),
            "JOURNEY_TYPE": StringType(1000),
            "ISCONVERSION": IntegerType(),
            "NORMALIZED_WEIGHTS": FloatType(),
            "CAMPAIGN_DURATION": StringType(1000),
            "EVENT_DT": DateType(),
            "ITEM_CD": DecimalType(18, 5),
            "NET_SALES_AMT": DecimalType(30, 4),
            "UNITS_QTY": DecimalType(30, 4),
            "UNIQUE_BRAND_NAME": StringType(1000),
            "WEEK_START_DT": StringType(1000),
            "REGRESSION_VARIABLE": StringType(1000),
            "SUBCHANNEL_NAME": StringType(1000),
            "ATTRIBUTED_SALES_AMT": FloatType(),
            "ATTRIBUTED_UNITS_QTY": FloatType(),
            "ATTRIBUTED_RECALIBERATED_SALES_AMT": FloatType(),
            "ATTRIBUTED_RECALIBERATED_UNITS_QTY": FloatType(),
            "JOB_RUN_ID": StringType(1000),
            "LOAD_TS": TimestampType(),
            "MARKETING_TYPE": StringType(1000),
        }

        for column, data_type in column_types.items():
            df = df.withColumn(column, col(column).cast(data_type))

        return df
    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def get_latest_data(data, booking_id, campaign_duration=None):
    """
    Retrieves the latest data for a given booking ID and campaign duration.

    Objective:
    This function filters the input DataFrame to retrieve the latest records for a specific
    booking ID and, if provided, a campaign duration. It ensures that only the most recent
    data is returned by identifying the maximum `load_ts` (timestamp).

    Used in:
        - sku_level_attributed_sales_and_units_aisle model: Used to fetch the latest data for
          SKU-level attributed sales and units processing workflows.

    Parameters:
        data (DataFrame): The input DataFrame containing campaign data.
        booking_id (str): The unique booking ID to filter the data.
        campaign_duration (str, optional): The campaign duration (e.g., "Post", "During")
                                           to further filter the data. Defaults to None.

    Returns:
        DataFrame: A filtered DataFrame containing the latest records for the specified
                  booking ID and campaign duration.

    Example:
        Input:
            data = DataFrame([
                {"booking_id": "a108d9e5-57e1-4dfa-b731-8d200f249456", "campaign_duration": "Post", "load_ts": "2023-10-01 12:00:00"},
                {"booking_id": "a108d9e5-57e1-4dfa-b731-8d200f249456", "campaign_duration": "Post", "load_ts": "2023-10-02 12:00:00"}
            ])
            booking_id = "a108d9e5-57e1-4dfa-b731-8d200f249456"
            campaign_duration = "Post"

        Output:
            DataFrame([
                {"booking_id": "a108d9e5-57e1-4dfa-b731-8d200f249456", "campaign_duration": "Post", "load_ts": "2023-10-02 12:00:00"}
            ])

    Raises:
        Exception: If an error occurs during the filtering or aggregation process, it logs the error
                   details and raises an exception with the error information.
    """
    try:
        if campaign_duration:
            target_data = data.filter(
                (col("booking_id") == booking_id) & (col("campaign_duration") == campaign_duration)
            )
        else:
            target_data = data.filter(col("booking_id") == booking_id)
        load_ts = target_data.agg(max("load_ts")).collect()[0][0]
        filtered_data = target_data.filter(col("load_ts") == load_ts)

        return filtered_data
    except Exception as e:
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def extract_error_message(trace_str):
    """
    Extracts the most relevant error message from a given traceback string.

    Objective:
    This function scans through the provided traceback (typically from an exception)
    and attempts to find and return the final line that includes a recognizable
    error or exception message. The purpose is to simplify debugging by isolating
    the key error message from the full traceback.

    Used in:
        fetch_in_progress_campaign
        get_latest_source_data
        log_missing_data
        log_negative_or_zero_incrementality
        replace_nulls_with_zero
        find_cluster_details
        model
        log_process_helper

    Parameters:
        trace_str (str): The complete traceback string from an exception.

    Returns:
        str: The extracted error message (text after the last colon in the last matching line),
            or the original traceback if no clear error line is found.

    Example:
        Input:
            trace_str = '''
            Traceback (most recent call last):
            File "example.py", line 10, in <module>
                raise ValueError("Invalid input provided")
            ValueError: Invalid input provided
            '''
        Output:
            "Invalid input provided"

    Raises:
        ValueError: If the input `trace_str` is not a valid string or is empty.
    """

    # Define keywords that indicate an error or exception
    keywords = ["Error", "Exception", "error"]

    # Split the input string into individual lines, trimming whitespace
    lines = trace_str.strip().splitlines()

    # Loop through the lines in reverse order, as the actual error message is usually at the bottom
    for line in reversed(lines):
        # Check if the line contains any of the keywords and a colon (common format for error lines)
        if any(kw in line for kw in keywords) and ":" in line:
            # Extract and return the message part after the first colon
            return line.split(":", 1)[-1].strip()

    # If no error line is found, return the original traceback string as fallback
    return trace_str


def log_process_helper(
    session,
    error_message,
    error_traceback,
    error_type,
    module_name,
    pipeline,
    status,
    booking_id,
    campaign_duration,
    job_run_id,
    error_schema
):

    """
    Logs job failure details into a Snowflake table for tracking and debugging purposes.

    Objective:
    This function captures critical information about job failures, such as the error message,
    traceback, error type, pipeline name, module name, and campaign details. It writes these
    details to a designated logging table in Snowflake to facilitate tracking and debugging.

    Used in:
        - model: Used to log error details when an exception occurs during the
        processing of baseline attribution data at the SKU and offer level.

    Parameters:
        session (Session): Snowpark session object used to interact with Snowflake.
        error_message (str): A descriptive error message explaining the failure.
        error_traceback (str): The full traceback of the error for debugging purposes.
        error_type (str): The type or category of the error (e.g., ValueError, KeyError).
        module_name (str): The name of the module or script where the error occurred.
        pipeline (str): The name of the pipeline associated with the job.
        status (str): The status of the job, typically "FAILED" in case of failure.
        booking_id (str): The unique booking ID of the campaign being processed.
        campaign_duration (str): The duration of the campaign being processed.
        job_run_id (str): A unique identifier for the job run to track execution.

    Returns:
        None: This function writes the log entry directly to a Snowflake table
        and does not return any value.

    Example:
        Input:
            session = snowpark.Session.builder.configs(connection_parameters).create()
            error_message = "Division by zero error"
            error_traceback = "Traceback (most recent call last): ..."
            error_type = "ZeroDivisionError"
            module_name = "sku_level_attributed_sales_and_units_aisle.py"
            pipeline = "SKU Level Attribution Pipeline"
            status = "FAILED"
            booking_id = "f108d9e5-57e1-4dfa-b731-8d200f249123"
            campaign_duration = "During"
            job_run_id = "d108d9e5-57e1-4dfa-b731-8d200f2499a7"

        Output:
            Logs the following entry into the ERROR_LOG_TABLE in Snowflake:
            {
                "error_message": "Division by zero error",
                "error_traceback": "Traceback (most recent call last): ...",
                "error_type": "ZeroDivisionError",
                "module_name": "sku_level_attributed_sales_and_units_aisle.py",
                "pipeline": "SKU Level Attribution Pipeline",
                "status": "FAILED",
                "booking_id": "f108d9e5-57e1-4dfa-b731-8d200f249123",
                "campaign_duration": "During",
                "job_run_id": "d108d9e5-57e1-4dfa-b731-8d200f2499a7",
                "load_ts": "2023-10-18 12:00:00"
            }

    Raises:
        Exception: If an error occurs while writing to the Snowflake table, it raises an exception
        with the error details.

    Writes To:
        ERROR_LOG_TABLE: The Snowflake table where job failure logs are stored.
    """
    load_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    last_tb_index = error_traceback.rfind("Traceback")
    # Slice from that index to the end
    recent_trace = error_traceback[last_tb_index:].strip()

    # Create a Snowpark DataFrame with one row of log
    default_value = "NA"
    log_df = session.create_dataframe(
        [[
            pipeline,
            module_name,
            booking_id,
            campaign_duration,
            default_value,
            default_value,
            default_value,
            status,
            error_type,
            error_message,
            recent_trace,
            job_run_id,
            load_ts
        ]],
        schema=error_schema
    )
    if log_df.count() > 0:
        error_log_df = log_df
        error_log_df.write.mode("append").save_as_table("ERROR_LOG_TABLE")
    return None


def model(dbt, session: Session):
    """
    Processes SKU-level attributed sales and units data for aisle-level campaigns.

    Objective:
    This function processes SKU-level attributed sales and units data for aisle-level campaigns
    by integrating data from multiple sources, applying business logic, and calculating metrics
    such as recalibrated sales. It ensures data consistency, handles exceptions, and logs errors
    for tracking and debugging purposes.

    Used in:
        - sku_level_attributed_sales_and_units_aisle: Used to process aisle-level campaign data
          and generate SKU-level attributed sales and units for reporting and analysis.

    Parameters:
        dbt (object): The dbt object used for referencing models and sources.
        session (Session): The Snowpark session object for interacting with Snowflake.

    Returns:
        DataFrame: A DataFrame containing SKU-level attributed sales and units data for aisle-level
                  campaigns, ready for downstream analysis and reporting.

    Example:
        Input:
            dbt = dbt object with configuration and source references.
            session = Snowpark session object.

        Output:
            DataFrame([
                {"ITEM_CD": "1234567", "WEEK_START_DT": "2023-10-01", "INCREMENTALITY_EXPOSED": 0.25, "INCREMENTAL_SALES_AMT_EXPOSED": 100.0, ...},
                {"ITEM_CD": "1234568", "WEEK_START_DT": "2023-10-08", "INCREMENTALITY_EXPOSED": 0.30, "INCREMENTAL_SALES_AMT_EXPOSED": 150.0, ...}
            ])

    Raises:
        Exception: If an error occurs during the processing of SKU-level attributed sales and units data,
                   it logs the error details (type, message, and trace) into the error log table and raises
                   the exception to stop execution.

    Writes To:
        SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE: The Snowflake table where the processed SKU-level
        attributed sales and units data is stored.
    """
    booking_id = "NA"
    campaign_duration = "NA"
    job_run_id = dbt.config.get("invocation_id", "NA")
    try:
        # Configure the dbt model with the following settings:
        # - Import the required Python module from the specified Snowflake stage for utility functions.
        # - Use the "snowflake-ml-python" package for Snowflake ML integration.
        # - Set the Python version to 3.11 for compatibility with the Snowflake environment.
        # - Use "incremental" materialization to append new data to the existing table.
        # - Set the incremental strategy to "append" to add only new records during each run.
        dbt.config(
            imports=[
                "@ADW_UNIFIED_PLATFORM_TACTICAL.DEV_MTA_GRID_MODELLING/ucm_integration_functions.py"
            ],
            packages=["snowflake-ml-python"],
            python_version="3.11",
            materialized="incremental",
            incremental_strategy="append",
        )

        # Reading from config file

        regression_variable_list = dbt.config.get("regression_variable_list")
        regression_variable_list = [elem.upper() for elem in regression_variable_list]
        invocation_id = dbt.config.get("invocation_id")
        # Reading unified campaign source table
        df = dbt.ref("measurement_campaign_execution")
        from ucm_integration_functions import (calculate_recaliberated_sales,
                                               get_campaign_start_end_date)

        # Reading sku_level_attributed_sales_and_units_table
        sku_level_attribution_result = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE"
        )

        """
        We are taking booking_id from measurement campaign execution table
        which is in progress, then we are getting the data from attribution model with max load_ts
        for that booking_id.
        """
        sku_level_empty_df = sku_level_attribution_result.filter(lit(False))
        attribution_data = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "ATTRIBUTION_MODEL_RESULTS_AISLE"
        )
        # Added ref to create dependency
        mta_df = dbt.ref("mta_attribution_model_results_aisle")
        print(mta_df)
        transaction_df = dbt.ref("customer_data_collection")

        camp_execution_df = dbt.ref("measurement_campaign_execution")

        # Filter to get only in-progress executions
        in_progress_df = camp_execution_df.filter(col("JOB_STATUS") == "In-progress")

        if in_progress_df.count() > 0:
            booking_id = in_progress_df.select("BOOKING_ID").limit(1).collect()[0][0]
            campaign_duration = in_progress_df.select("CAMPAIGN_DURATION").collect()[0][0]

            is_post_campaign = False
            # Load attribution data for that booking id
            attribution_df = get_latest_data(attribution_data, booking_id, campaign_duration)
            transaction_data = get_latest_data(transaction_df, booking_id)
            # Attribution data is gets loaded

            # using data from sku level offer as recalibration factor is already calculated in it.
            sku_level_offer = dbt.ref("sku_level_attributed_sales_and_units_offer")
            sku_level_offer_latest = get_latest_data(sku_level_offer, booking_id, campaign_duration)
            # taking distinct columns where recaliberation factor is positive from offer
            sku_level_offer_filtered = (
                sku_level_offer_latest.filter(col("BOOKING_ID") == booking_id)
                .select("CHANNEL_NAME", "CAMPAIGN_ID", "RECALIBERATION_FACTOR")
                .with_column_renamed("RECALIBERATION_FACTOR", "FACTOR")
                .filter(col("FACTOR") > 0)
                .distinct()
            )

            # Check if the campaign duration is Post
            if "Post" in [campaign_duration]:
                is_post_campaign = True

            # Campaign start date and end date is processed
            campaign_start_date, campaign_end_date = get_campaign_start_end_date(
                df, is_post_campaign, booking_id
            )

            """
            Filters transaction data to isolate the relevant sales and units for each SKU,
            enabling traceability back to individual user journeys using the transaction key.
            This ensures accurate attribution of sales and units at the SKU level.
            The transaction data is filtered to include only those records that match the booking ID
            """
            transaction_df = (
                transaction_data.filter(
                    (
                        col("BOOKING_ID") == booking_id
                    ) & (
                        lower(col("SUBCHANNEL_NAME")) == "txn"
                    ) & (
                        lower(col("PRODUCT_TYPE")) == "aisle"
                    )
                )
                .select(
                    "TRANSACTION_KEY",
                    "EVENT_DT",
                    "ITEM_CD",
                    "NET_SALES_AMT",
                    "UNITS_QTY",
                    "UNIQUE_BRAND_NAME",
                )
                .distinct()
            )

            transaction_df = transaction_df.with_column(
                "WEEK_START_DT",
                to_char(date_trunc("WEEK", transaction_df["EVENT_DT"]), "YYYY-MM-DD"),
            )
            # Filtering transaction data which is between campaign start and end date
            transaction_df = transaction_df.filter(
                (
                    col("WEEK_START_DT") >= lit(campaign_start_date)
                ) & (
                    col("WEEK_START_DT") <= lit(campaign_end_date)
                )
            ).distinct()

            attribution_df = attribution_df.with_column(
                "REGRESSION_VARIABLE", col("REGRESSION_VARIABLE").cast("string")
            )
            attribution_df = attribution_df.with_column("CAMPAIGN_ID", lower(col("CAMPAIGN_ID")))
            # Joining with transaction_data to get skus and sales at sku level.
            sku_level_results = attribution_df.join(
                transaction_df, on=["TRANSACTION_KEY"], how="left"
            ).drop("TRANSACTION_KEY").distinct()
            # When channel overlap is greater than zero, original attributed weights for Offsite channels
            # are used to calculate recalibrated sales, resulting in lower attributed sales for Offsite
            # channels due to multi-touch attribution with overlap. Non-Offsite channel sales remain
            # unchanged. When overlap equals zero, Offsite channel weights are normalized, and recalibrated
            # sales equal reported sales, fully utilizing all reported sales. Non-Offsite channels
            # remain unaffected in both cases.
            sku_level_results_final = calculate_recaliberated_sales(
                sku_level_offer_filtered, sku_level_results
            )
            sku_level_attributed_sales_and_units_aisle = sku_level_results_final.drop(
                "AVG_F1_SCORE",
                "FACTOR",
                "SUM_ATTRIBUTED_SALES",
                "SALES_AMT",
                "SUM_RECALIBERATED_ATTRIBUTED_SALES",
                "SUM_NORMALIZED_WEIGHTS",
                "SUM_SALES_AMT",
            )
        else:
            sku_level_attributed_sales_and_units_aisle = sku_level_empty_df

        sku_level_attributed_sales_and_units_aisle = (
            sku_level_attributed_sales_and_units_aisle.with_column("JOB_RUN_ID", lit(invocation_id))
        )
        sku_level_attributed_sales_and_units_aisle = (
            sku_level_attributed_sales_and_units_aisle.with_column("LOAD_TS", current_timestamp())
        )

        sku_level_attributed_sales_and_units_aisle = cast_columns_to_types(
            sku_level_attributed_sales_and_units_aisle
        )
        existing_seq = sku_level_empty_df.columns
        sku_level_attributed_sales_and_units_aisle = sku_level_attributed_sales_and_units_aisle.select(
            *existing_seq
        ).fillna(0)
    except Exception as e:
        # This section of the code processes the reach and engagement data. If no valid data is found,
        # it returns an empty dataframe. Otherwise, it appends the invocation ID as a job run identifier,
        # casts columns to the required data types, and ensures the column order matches the final table schema.
        # In case of an exception, it logs the error details (type, message, and trace) into the error log table
        # using the `log_process_helper` function and raises the exception to stop execution.
        error_type = type(e).__name__
        error_message = str(e)
        error_trace = traceback.format_exc()
        error_message = extract_error_message(error_message)
        schema = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "ERROR_LOG_TABLE").schema
        log_process_helper(session, error_message, error_trace, error_type, "sku_level_attributed_sales_and_units_aisle", "MTA", "Failed", booking_id, campaign_duration, job_run_id, schema)
        raise

    # Save the finalized DataFrame containing SKU-level attributed sales and units data to the table in Snowflake for persistent storage and analysis
    return sku_level_attributed_sales_and_units_aisle
