"""
/**************************************************************************
* Script Name: baseline_attribution_integration_sku_level_aisle.py
*
* Objective:
* This script is designed to compute baseline and attribution integration
* results at the SKU level for aisles. It processes data from upstream
* Snowflake tables, applies business logic, and generates results that are
* stored in a downstream table for further analysis and reporting.
* The script filters the baseline results for the campaign period and the
* targeted SKUs, combining them at the SKU level for each customer journey.
* It calculates incremental sales by deducting baseline sales from attributed
* sales. Similarly, it calculates incremental units by following the same
* process. These computations are essential for understanding the impact of
* marketing campaigns and aisle performance at a granular level.
*
* Key Performance Indicators (KPIs):
* - Incremental Sales: Attributed Sales - Baseline Sales
* - Incremental Units: Attributed Units - Baseline Units
* - Baseline Sales and Units: Derived from historical data for the campaign period
* - Attributed Sales and Units: Derived from campaign performance data
*
* Functions Used from Staging File (ucm_integration_functions.py):
* 1. filter_data: Filters the input data based on specified conditions such as
*    campaign period, targeted SKUs, and customer journey.
* 2. get_campaign_start_end_date: Retrieves the start and end dates of the
*    campaign to ensure accurate filtering and processing of data.
* 3. calculate_sales_proportion: Computes the sales proportion for each SKU
*    based on the baseline and attributed sales data.
* 4. baseline_sku_level_integration: returns bseline and incrementality sales per SKU
*
* Confluence Link: https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657653976/Integration+with+Baseline
*
* Upstream:
* - SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
*
* Downstream:
* - MEASUREMENT_CAMPAIGN_REPORTING
*
* Owner: Sahil Arya
* Date: 23/10/2024
*
**************************************************************************/
"""

from snowflake.snowpark import Session, Window
from snowflake.snowpark.functions import col, current_timestamp, lit
from snowflake.snowpark.functions import max as F_max
from snowflake.snowpark.functions import sum as F_sum
from snowflake.snowpark.functions import upper, when
from snowflake.snowpark.types import DateType, IntegerType
import traceback
from datetime import datetime

baseline_integration_sku_table = "ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_INTEGRATION_SKU"


def extract_error_message(trace_str):
    """
    Extracts the most relevant error message from a given traceback string.

    Objective:
    This function scans through the provided traceback (typically from an exception)
    and attempts to find and return the final line that includes a recognizable
    error or exception message. The purpose is to simplify debugging by isolating
    the key error message from the full traceback.

    Used in:
        fetch_in_progress_campaign
        get_latest_source_data
        log_missing_data
        log_negative_or_zero_incrementality
        replace_nulls_with_zero
        find_cluster_details
        model
        log_process_helper

    Parameters:
        trace_str (str): The complete traceback string from an exception.

    Returns:
        str: The extracted error message (text after the last colon in the last matching line),
            or the original traceback if no clear error line is found.

    Example:
        Input:
            trace_str = '''
            Traceback (most recent call last):
            File "example.py", line 10, in <module>
                raise ValueError("Invalid input provided")
            ValueError: Invalid input provided
            '''
        Output:
            "Invalid input provided"

    Raises:
        ValueError: If the input `trace_str` is not a valid string or is empty.
    """
    # Define keywords that indicate an error or exception
    keywords = ["Error", "Exception", "error"]

    # Split the input string into individual lines, trimming whitespace
    lines = trace_str.strip().splitlines()

    # Loop through the lines in reverse order, as the actual error message is usually at the bottom
    for line in reversed(lines):
        # Check if the line contains any of the keywords and a colon (common format for error lines)
        if any(kw in line for kw in keywords) and ":" in line:
            # Extract and return the message part after the first colon
            return line.split(":", 1)[-1].strip()

    # If no error line is found, return the original traceback string as fallback
    return trace_str


def log_process_helper(
    session,
    error_message,
    error_traceback,
    error_type,
    module_name,
    pipeline,
    status,
    booking_id,
    campaign_duration,
    job_run_id,
    error_schema
):
    """
    Logs job failure details into a Snowflake table for tracking and debugging purposes.

    Objective:
    This function captures critical information about job failures, such as the error message,
    traceback, error type, pipeline name, module name, and campaign details. It writes these
    details to a designated logging table in Snowflake to facilitate tracking and debugging.

    Used in:
        - model: Used to log error details when an exception occurs during the
        processing of baseline attribution data at the SKU and aisle level.

    Parameters:
        session (Session): Snowpark session object used to interact with Snowflake.
        error_message (str): A descriptive error message explaining the failure.
        error_traceback (str): The full traceback of the error for debugging purposes.
        error_type (str): The type or category of the error (e.g., ValueError, KeyError).
        module_name (str): The name of the module or script where the error occurred.
        pipeline (str): The name of the pipeline associated with the job.
        status (str): The status of the job, typically "FAILED" in case of failure.
        booking_id (str): The unique booking ID of the campaign being processed.
        campaign_duration (str): The duration of the campaign being processed.
        job_run_id (str): A unique identifier for the job run to track execution.

    Returns:
        None: This function writes the log entry directly to a Snowflake table
        and does not return any value.

    Example:
        Input:
            session = snowpark.Session.builder.configs(connection_parameters).create()
            error_message = "Division by zero error"
            error_traceback = "Traceback (most recent call last): ..."
            error_type = "ZeroDivisionError"
            module_name = "baseline_attribution_integration_sku_level_aisle.py"
            pipeline = "SKU Level Attribution Pipeline"
            status = "FAILED"
            booking_id = "f108d9e5-57e1-4dfa-b731-8d200f249123"
            campaign_duration = "During"
            job_run_id = "d108d9e5-57e1-4dfa-b731-8d200f2499a7"

        Output:
            Logs the following entry into the ERROR_LOG_TABLE in Snowflake:
            {
                "error_message": "Division by zero error",
                "error_traceback": "Traceback (most recent call last): ...",
                "error_type": "ZeroDivisionError",
                "module_name": "baseline_attribution_integration_sku_level_aisle.py",
                "pipeline": "SKU Level Attribution Pipeline",
                "status": "FAILED",
                "booking_id": "f108d9e5-57e1-4dfa-b731-8d200f249123",
                "campaign_duration": "During",
                "job_run_id": "d108d9e5-57e1-4dfa-b731-8d200f2499a7",
                "load_ts": "2023-10-18 12:00:00"
            }

    Raises:
        Exception: If an error occurs while writing to the Snowflake table, it raises an exception
        with the error details.

    Writes To:
        ERROR_LOG_TABLE: The Snowflake table where job failure logs are stored.
    """
    load_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    last_tb_index = error_traceback.rfind("Traceback")
    # Slice from that index to the end
    recent_trace = error_traceback[last_tb_index:].strip()

    # Create a Snowpark DataFrame with one row of log
    default_value = "NA"
    log_df = session.create_dataframe(
        [[
            pipeline,
            module_name,
            booking_id,
            campaign_duration,
            default_value,
            default_value,
            default_value,
            status,
            error_type,
            error_message,
            recent_trace,
            job_run_id,
            load_ts
        ]],
        schema=error_schema
    )
    if log_df.count() > 0:
        # Write the log DataFrame to the error log table
        error_log_df = log_df
        error_log_df.write.mode("append").save_as_table("ERROR_LOG_TABLE")
    return None


def fetch_in_progress_campaign(df):
    """
    Retrieves the first available campaign that is currently "In-progress".

    Objective:
    This function filters the input DataFrame to identify campaigns with a JOB_STATUS
    of "In-progress". It ensures that only active campaigns are considered and extracts
    the first available BOOKING_ID and CAMPAIGN_DURATION for further processing. If no
    in-progress campaigns are found, it raises an exception.

    Used in:
        - model: The fetch_in_progress_campaign function is called within the model function to
        retrieve in-progress campaign details for further processing.

    Parameters:
        df (snowflake.snowpark.DataFrame): The input DataFrame containing campaign data.

    Returns:
        tuple: A tuple containing:
            - BOOKING_ID (str): The unique identifier of the first in-progress campaign.
            - CAMPAIGN_DURATION (str): The duration type campaign.

    Example:
        Input:
            df = DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "JOB_STATUS": "In-progress", "CAMPAIGN_DURATION": "During" ...},
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f249989", "JOB_STATUS": "Completed", "CAMPAIGN_DURATION": "During" ...}
            ])
        Output:
            ("d108d9e5-57e1-4dfa-b731-8d200f2499a7", "During")

    Raises:
        ValueError: If no in-progress campaigns are found in the input DataFrame.
    """
    try:
        # Filter the DataFrame to find in-progress campaigns
        in_progress_campaign = df.filter(col("JOB_STATUS") == "In-progress").select(
            "BOOKING_ID", "CAMPAIGN_DURATION"
        )

        if in_progress_campaign.count() == 0:
            raise ValueError("Error: no campaign found to execute the model!")

        booking_id = in_progress_campaign.select("BOOKING_ID").limit(1).collect()[0][0]

        campaign_duration = in_progress_campaign.select("CAMPAIGN_DURATION").limit(1).collect()[0][0]
        return booking_id, campaign_duration
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def get_latest_source_data(sku_level_results, booking_id, campaign_duration):
    """
    Retrieves the latest source data for a given booking ID and campaign duration.

    Objective:
    This function filters the input DataFrame to retrieve SKU-level sales and units data
    for a specific booking ID and campaign duration. It ensures that only the latest
    available records are returned by identifying the maximum LOAD_TS (timestamp).
    If no matching data is found, it raises an exception.

    Used in:
        - model: The get_latest_source_data function is called within the model function to retrieve the latest
        source data for processing baseline attribution at the SKU and aisle level.

    Parameters:
        sku_level_results (DataFrame): The input DataFrame containing SKU-level sales data.
        booking_id (uuid): The unique identifier for the campaign booking.
        campaign_duration (str): The campaign duration to filter the records (e.g., "During", "Post").

    Returns:
        DataFrame: A filtered DataFrame containing only the latest available records
                  for the specified booking ID and campaign duration.

    Example:
        Input:
            sku_level_results = DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "NET_SALES_AMT": 100, "LOAD_TS": "2023-10-01 12:00:00"},
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "NET_SALES_AMT": 200, "LOAD_TS": "2023-10-02 12:00:00"}
            ])
            booking_id = "d108d9e5-57e1-4dfa-b731-8d200f2499a7"
            campaign_duration = "During"
        Output:
            DataFrame([
                {"BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "CAMPAIGN_DURATION": "During", "NET_SALES_AMT": 200, "LOAD_TS": "2023-10-02 12:00:00"}
            ])

    Raises:
        ValueError: If no relevant data is found after filtering.
    """
    try:
        # Filter the SKU-level results based on booking ID, campaign duration, and sales amount
        sku_level_filtered = sku_level_results.filter(
            (
                col("BOOKING_ID") == booking_id
            ) & (
                col("CAMPAIGN_DURATION") == campaign_duration
            ) & (
                col("NET_SALES_AMT") >= 0)
        )

        if sku_level_filtered.count() == 0:
            raise ValueError(
                "Error: no data found in SKU-level attributed sales and units to execute the model!"
            )
        # Get the maximum LOAD_TS to filter the latest records
        sku_level_results_filtered_max_ts = sku_level_filtered.agg(F_max(col("LOAD_TS"))).collect()[0][
            0
        ]

        sku_level_results_filtered = sku_level_filtered.filter(
            col("LOAD_TS") == sku_level_results_filtered_max_ts
        )
        return sku_level_results_filtered
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def log_missing_data(
    mta_mmm_integration, sku_level_results_filtered, invocation_id, col_seq_log_table
):
    """
    Logs missing SKU data in the MTA-MMM integration process.

    Objective:
    This function identifies and logs missing SKU data by filtering rows where `SUM_BASELINE_AMT`
    is NULL in the MTA-MMM integration DataFrame. It determines whether all or some SKUs are
    missing and appends the relevant data to the `BASELINE_INTEGRATION_SKU` table with appropriate
    comments for further analysis.

    Used in:
        - model : The log_missing_data function is called within the model function to log missing
        SKU data during the baseline attribution integration process.

    Parameters:
        mta_mmm_integration (DataFrame): The DataFrame containing MTA-MMM integration data.
        sku_level_results_filtered (DataFrame): The DataFrame containing SKU-level filtered results.
        invocation_id (str): A unique identifier for the current job run.
        col_seq_log_table (list): A list of column names to align the output with the target table schema.

    Returns:
        None: The function writes the unmatched SKU data to the `BASELINE_INTEGRATION_SKU` table
              and does not return any value.

    Example:
        Input:
            mta_mmm_integration = DataFrame([
                {"ITEM_CD": "1234567", "BOOKING_ID": "e209f8c6-68f2-4efb-c842-9e300f3498b8", "SUM_BASELINE_AMT": None, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"},
                {"ITEM_CD": "12345667", "BOOKING_ID": "e209f8c6-68f2-4efb-c842-9e300f3498b8", "SUM_BASELINE_AMT": 100, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"}
            ])
            sku_level_results_filtered = DataFrame([
                {"ITEM_CD": "1234567", "BOOKING_ID": "e209f8c6-68f2-4efb-c842-9e300f3498b8", "SUM_BASELINE_AMT": None, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"}
            ])
            invocation_id = "f319a7d7-79f3-5ffc-d953-af401f459ac9"
            col_seq_log_table = ["ITEM_CD", "BOOKING_ID", "JOURNEY_TYPE", "CAMPAIGN_DURATION", "JOB_RUN_ID", "LOAD_TS", "Comment"]

        Output:
            Logs the following data to the `BASELINE_INTEGRATION_SKU` table:
            [
                {"ITEM_CD": "1234567", "BOOKING_ID": "e209f8c6-68f2-4efb-c842-9e300f3498b8", "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During", "JOB_RUN_ID": "f319a7d7-79f3-5ffc-d953-af401f459ac9", "LOAD_TS": "2023-10-18 12:00:00", "Comment": "All SKUs are absent/Brand or super category data is absent."}
            ]

    Raises:
        Exception: If an error occurs during the filtering or logging process, it raises an exception
                   with the error details.
    """
    try:
        # Filter for unmatched SKUs where SUM_BASELINE_AMT is NULL
        unmatched_rows = (
            mta_mmm_integration.filter(col("SUM_BASELINE_AMT").is_null())
            .select("ITEM_CD", "BOOKING_ID", "JOURNEY_TYPE", "CAMPAIGN_DURATION")
            .with_column("JOB_RUN_ID", lit(invocation_id))
            .withColumn("LOAD_TS", current_timestamp())
        )
        # Check if all SKUs are missing by comparing counts
        if unmatched_rows.count() == sku_level_results_filtered.count():
            unmatched_rows = unmatched_rows.withColumn(
                "Comment", lit("All SKUs are absent/Brand or super category data is absent.")
            ).distinct()
        else:
            unmatched_rows = unmatched_rows.withColumn(
                "Comment", lit("Some SKUs are absent.")
            ).distinct()
        # Append the unmatched rows to the BASELINE_INTEGRATION_SKU table
        unmatched_rows.select(*col_seq_log_table).write.mode("append").saveAsTable(
            baseline_integration_sku_table
        )
        return None
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def log_negative_or_zero_incrementality(
    baseline_attribution_integration_sku_level, invocation_id, col_seq_log_table
):
    """
    Logs SKUs with negative or zero incrementality in the baseline attribution process.

    Objective:
    This function identifies and logs SKUs where the `INCREMENTALITY_EXPOSED` value
    is either negative or zero in the `baseline_attribution_integration_sku_level` DataFrame.
    It appends the relevant data to the `BASELINE_INTEGRATION_SKU` table with appropriate
    comments for further analysis and tracking.

    Used in:
        - This function is called within the model function to log SKUs with negative or zero
        incrementality during the baseline attribution integration process.
    Parameters:
        baseline_attribution_integration_sku_level (DataFrame): The DataFrame containing SKU-level incrementality data.
        invocation_id (str): A unique identifier for the current job run.
        col_seq_log_table (list): A list of column names(str) to align the output with the target table schema.

    Returns:
        None: The function writes the identified SKU data to the `BASELINE_INTEGRATION_SKU` table
              and does not return any value.

    Example:
        Input:
            baseline_attribution_integration_sku_level = DataFrame([
                {"ITEM_CD": "1234567", "BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "INCREMENTALITY_EXPOSED": -10, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"},
                {"ITEM_CD": "1234568", "BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "INCREMENTALITY_EXPOSED": 0, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"},
                {"ITEM_CD": "1234569", "BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "INCREMENTALITY_EXPOSED": 20, "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During"}
            ])
            invocation_id = "f319a7d7-79f3-5ffc-d953-af401f459ac9"
            col_seq_log_table = ["ITEM_CD", "BOOKING_ID", "JOURNEY_TYPE", "CAMPAIGN_DURATION", "JOB_RUN_ID", "LOAD_TS", "Comment"]

        Output:
            Logs the following data to the `BASELINE_INTEGRATION_SKU` table:
            [
                {"ITEM_CD": "1234567", "BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During", "JOB_RUN_ID": "f319a7d7-79f3-5ffc-d953-af401f459ac9", "LOAD_TS": "2023-10-18 12:00:00", "Comment": "INCREMENTALITY is negative."},
                {"ITEM_CD": "1234568", "BOOKING_ID": "d108d9e5-57e1-4dfa-b731-8d200f2499a7", "JOURNEY_TYPE": "Aisle", "CAMPAIGN_DURATION": "During", "JOB_RUN_ID": "f319a7d7-79f3-5ffc-d953-af401f459ac9", "LOAD_TS": "2023-10-18 12:00:00", "Comment": "INCREMENTALITY is zero."}
            ]

    Raises:
        Exception: If an error occurs during the filtering or logging process, it raises an exception
                   with the error details.
    """
    try:
        # Filter for negative incrementality
        negative_incrementality = (
            baseline_attribution_integration_sku_level.filter(col("INCREMENTALITY_EXPOSED") < 0)
            .select("ITEM_CD", "BOOKING_ID", "JOURNEY_TYPE", "CAMPAIGN_DURATION")
            .with_column("JOB_RUN_ID", lit(invocation_id))
            .withColumn("LOAD_TS", current_timestamp())
        )
        # Check if any negative incrementality exists
        if negative_incrementality.count() > 0:
            negative_incrementality = negative_incrementality.with_column(
                "Comment", lit("INCREMENTALITY is negative")
            ).distinct()
            negative_incrementality.select(*col_seq_log_table).write.mode("append").save_as_table(
                baseline_integration_sku_table
            )
        # Filter for zero incrementality
        zero_incrementality = (
            baseline_attribution_integration_sku_level.filter(col("INCREMENTALITY_EXPOSED") == 0)
            .select("ITEM_CD", "BOOKING_ID", "JOURNEY_TYPE", "CAMPAIGN_DURATION")
            .with_column("JOB_RUN_ID", lit(invocation_id))
            .withColumn("LOAD_TS", current_timestamp())
        )
        # Check if any zero incrementality exists
        if zero_incrementality.count() > 0:
            zero_incrementality = zero_incrementality.with_column(
                "Comment", lit("INCREMENTALITY is zero")
            ).distinct()
            zero_incrementality.select(*col_seq_log_table).write.mode("append").save_as_table(
                baseline_integration_sku_table
            )
        return None
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def replace_nulls_with_zero(baseline_attribution_integration_sku_level):
    """
    Replaces null values with zero in specific columns of a Snowpark DataFrame.

    Objective:
    This function ensures data consistency by replacing null values with zero in specific
    columns of the `baseline_attribution_integration_sku_level` DataFrame. This is critical
    for accurate downstream processing, reporting, and analytics.

    Used in:
        - The replace_nulls_with_zero function is called within the model function to handle
        missing values by replacing nulls with zeros during the baseline attribution integration process.

    Parameters:
        baseline_attribution_integration_sku_level (DataFrame):
            A DataFrame containing SKU-level attribution and sales data.

    Returns:
        DataFrame: A modified DataFrame where null values in the specified columns
                  are replaced with zero.

    Example:
        Input:
            baseline_attribution_integration_sku_level = DataFrame([
                {"ITEM_CD": "1234567", "SUM_BASELINE_AMT": None, "SUM_OF_SALES_AMT": 100},
                {"ITEM_CD": "1234568", "SUM_BASELINE_AMT": 50, "SUM_OF_SALES_AMT": None}
            ])

        Output:
            DataFrame([
                {"ITEM_CD": "1234567", "SUM_BASELINE_AMT": 0, "SUM_OF_SALES_AMT": 100},
                {"ITEM_CD": "1234568", "SUM_BASELINE_AMT": 50, "SUM_OF_SALES_AMT": 0}
            ])

    Raises:
        Exception: If an error occurs during the null replacement process, it raises an exception
                   with the error details.
    """
    try:
        columns_to_fill = [
            "FREQUENCY_OF_PURCHASE",
            "ONLINE_SALES_PCT",
            "SUPERMARKET_SALES_PCT",
            "CONVENIENCE_SALES_PCT",
            "SUM_BASELINE_AMT",
            "SUM_OF_INCR_AMT",
            "SUM_OF_SALES_AMT",
            "BASELINE",
            "TOTAL_SALES_AMT",
        ]
        # Iterate through the list of columns and replace null values with zero
        for column in columns_to_fill:
            baseline_attribution_integration_sku_level = (
                baseline_attribution_integration_sku_level.withColumn(
                    column, when(col(column).is_null(), 0).otherwise(col(column))
                )
            )
        return baseline_attribution_integration_sku_level
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def find_cluster_details(campaign_ids, campaign_product_type, clustering_df):
    """
    Extracts brand, super category, and cluster details for the given campaign IDs.

    Objective:
    This function retrieves brand names, super category names, and cluster details
    for the specified campaign IDs. It ensures that the extracted data is unique
    and formatted correctly for downstream processing and analysis.

    Used in:
        - The find_cluster_details function is called within the model function to retrieve brand, super category, and cluster details
        for the specified campaign IDs during the baseline attribution integration process.

    Parameters:
        campaign_ids (list):
            List of campaign IDs to filter data.
        campaign_product_type (DataFrame):
            DataFrame containing campaign-product mappings.
        clustering_df (DataFrame):
            DataFrame containing clustering details.

    Returns:
        tuple: A tuple containing:
            - brand (list): List of unique brand names(str) in uppercase.
            - super_category_name (str): Single unique super category name (if available).
            - final_cluster (list): List of distinct cluster numbers(int).

    Example:
        Input:
            campaign_ids = ["CAMP123", "CAMP456"]
            campaign_product_type = DataFrame([
                {"CAMPAIGN_ID": "CAMP123", "BRAND_NAME": "BrandA", "SUPER_CATEGORY_NAME": "Category1"},
                {"CAMPAIGN_ID": "CAMP456", "BRAND_NAME": "BrandB", "SUPER_CATEGORY_NAME": "Category1"}
            ])
            clustering_df = DataFrame([
                {"CAMPAIGN_ID": "CAMP123", "CLUSTER_NUMBER": 1},
                {"CAMPAIGN_ID": "CAMP456", "CLUSTER_NUMBER": 2}
            ])

        Output:
            (
                ["BRANDA", "BRANDB"],
                "CATEGORY1",
                [1, 2]
            )

    Raises:
        Exception: If an error occurs during data extraction or processing, it raises an exception
                   with the error details.
    """
    try:
        # Filter the campaign_product_type DataFrame to get item codes for the given campaign IDs
        skus_mta_df = campaign_product_type.filter(col("CAMPAIGN_ID").isin(campaign_ids)).select(
            "item_cd"
        )

        # Filter the clustering_df to get only the rows where ITEM_CD matches the filtered SKUs
        final_df = clustering_df.filter(col("ITEM_CD").isin(skus_mta_df.select("ITEM_CD")))

        # Extract distinct brand names, convert to uppercase, and collect as a list
        brand_df = final_df.select(upper(col("unique_brand_name"))).distinct()
        brand = [row[0] for row in brand_df.collect()] if brand_df.count() > 0 else []

        # Extract distinct super category names, convert to uppercase, and collect the first value
        super_category_df = final_df.select(upper(col("super_category_name"))).distinct()
        super_category_name = super_category_df.collect()[0][0] if super_category_df.count() > 0 else ""

        # Extract distinct cluster numbers and collect as a list
        cluster_df = final_df.select(col("cluster_num")).distinct()
        final_cluster = [row[0] for row in cluster_df.collect()]

        return brand, super_category_name, final_cluster
    except Exception as e:
        # Handle exceptions and log the error message
        error_message = str(e)
        error_message = extract_error_message(error_message)
        raise


def model(dbt, session: Session):
    """
    Processes baseline attribution data at the SKU and aisle level for marketing campaigns.

    Objective:
    This function integrates baseline and attribution data at the SKU and aisle level,
    applying business logic to calculate key metrics such as incremental sales,
    incrementality ratios, and recalibrated sales. It ensures data consistency,
    handles missing values, and prepares the data for downstream reporting and analysis.

    Used in:
        - This is the main entry point for the dbt model and run when the dbt command is executed.

    Parameters:
        dbt (object):
            The dbt object used for referencing models and sources.
        session (Session):
            The Snowpark session object for interacting with Snowflake.

    Returns:
        DataFrame: A processed DataFrame containing integrated baseline attribution data at the SKU
                   level for aisle, ready for downstream analysis and reporting at campaign level for each targeted
                   marketing type channel and sub channel.

    Example:
        Input:
            dbt = dbt object with configuration and source references.
            session = Snowpark session object.

        Output:
            DataFrame([
                {"ITEM_CD": "1234567", "WEEK_START_DT": "2023-10-01", "INCREMENTALITY_EXPOSED": 0.25, "INCREMENTAL_SALES_AMT_EXPOSED": 100.0, ...},
                {"ITEM_CD": "1234568", "WEEK_START_DT": "2023-10-08", "INCREMENTALITY_EXPOSED": 0.30, "INCREMENTAL_SALES_AMT_EXPOSED": 150.0, ...}
            ])

    Raises:
        Exception: If an error occurs during data processing, it logs the error details
                   and raises the exception to stop execution.
    """

    booking_id = "NA"
    campaign_duration = "NA"
    pre_campaign_weeks = dbt.config.get("pre_campaign_weeks", 6)  # Default 6 weeks; pre-camp must have 6 weeks of data, those 6 weeks of data is used to calculate pre-campaign sales proportions to be used for SKU-level attribution
    min_pre_camp_sales_threshold = dbt.config.get("min_pre_camp_sales_threshold", 0.1)  # Default 10%; pre-camp must have 10% of campaign sales for pre-campaign sales proportions to be used for SKU-level attribution
    job_run_id = dbt.config.get("invocation_id", "NA")
    try:
        # Configure the dbt model with Python version 3.11 and set it to use the "incremental" materialization strategy.
        # The "append" incremental strategy ensures new data is appended to the existing table.
        # The "transient" option is set to False, meaning the table will be permanent and not automatically dropped.
        dbt.config(
            imports=[
                # Importing a custom Python module from a Snowflake stage for integration functions
                "@ADW_UNIFIED_PLATFORM_TACTICAL.DEV_MTA_GRID_MODELLING/ucm_integration_functions.py"
            ],
            python_version="3.11",
            materialized="incremental",
            incremental_strategy="append",
            transient=False,
        )

        # Reading from the staging file
        from ucm_integration_functions import (filter_data,
                                               get_campaign_start_end_date,
                                               calculate_sales_proportion,
                                               baseline_sku_level_integration)

        # The below lines of code integrate all of the baseline data at an SKU level and filter it for
        # the weeks in which campaign period lies. This will help us in get the baseline sales for the
        # targeted SKUs during the campaign period. It uses all these three tables(BASELINE_MODELLING_OUTPUT,
        # SKU_CLUSTER_MAPPING and SALES_DATA_TRANSFORMATION_OUTPUT) to produce these baseline result
        # Load the UNIFIED_PRODUCT source table from ADW_UNIFIED_PLATFORM_TACTICAL
        unified_product = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "UNIFIED_PRODUCT")

        baseline_log_table = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "BASELINE_INTEGRATION_SKU")
        col_seq_log_table = baseline_log_table.columns

        # Select distinct brand names, both raw and processed, from the unified product table
        unified_brand = unified_product.select("RAW_UNIQUE_BRAND_NAME", "UNIQUE_BRAND_NAME").distinct()

        # Retrieve the invocation ID from the dbt configuration
        invocation_id = dbt.config.get("invocation_id")

        # Load the BASELINE_MODELLING_OUTPUT table from ADW_UNIFIED_PLATFORM_TACTICAL
        # Filtering to include only the best iteration rows (where BEST_ITERATION == "Y")
        baseline_output = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "BASELINE_MODELLING_OUTPUT")
        baseline_output = baseline_output[baseline_output["BEST_ITERATION"] == "Y"]

        # Load SKU-level results and drop JOB_RUN_ID column to avoid duplication issues
        sku_level_results = dbt.ref("sku_level_attributed_sales_and_units_aisle")
        sku_level_results = sku_level_results.drop("JOB_RUN_ID")

        # Reference the measurement_campaign_execution table
        df = dbt.ref("measurement_campaign_execution")

        # Fetch booking id and campaign duration of in-progress campaign
        booking_id, campaign_duration = fetch_in_progress_campaign(df)

        # Get the latest data from source based on max of load_ts
        sku_level_results_filtered = get_latest_source_data(
            sku_level_results, booking_id, campaign_duration
        )

        # Group by WEEK_START_DT, SUPER_CATEGORY_NAME, and UNIQUE_BRAND_NAME to get the latest LOAD_TS
        baseline_max_cat = baseline_output.groupBy(
            "WEEK_START_DT", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME"
        ).agg(F_max(col("LOAD_TS")).alias("LOAD_TS"))

        # Merge the original filtered DataFrame with the max
        # LOAD_TS DataFrame to retain only the latest records
        baseline_output = baseline_output.join(
            baseline_max_cat,
            on=["WEEK_START_DT", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "LOAD_TS"],
            how="inner",
        )

        # Extract unique metric names to use for pivoting
        pivot_keys = [row[0] for row in baseline_output.select("METRIC_NAME").distinct().collect()]

        # Aggregate baseline_output by relevant keys and pivot METRIC_NAME values into separate columns
        baseline_output = baseline_output.groupBy(
            "WEEK_START_DT", "SUPER_CATEGORY_NAME", "UNIQUE_BRAND_NAME", "CLUSTER_NUM", "ITERATION"
        ).agg(
            *[
                F_sum(when(col("metric_name") == key, col("metric_value")).otherwise(None)).alias(key)
                for key in pivot_keys
            ]
        )

        # Select required columns and remove duplicates
        baseline_output = baseline_output.select(
            "WEEK_START_DT",
            "SUPER_CATEGORY_NAME",
            "UNIQUE_BRAND_NAME",
            "CLUSTER_NUM",
            "TOTAL_SALES_AMT",
            "TOTAL_BASELINE_AMT",
            "TOTAL_INCREMENTAL_AMT",
            "TOTAL_SEASONALITY_AMT",
            "ITERATION",
        ).distinct()

        # Join baseline_output with unified_brand to get the RAW_UNIQUE_BRAND_NAME
        baseline_output = (
            baseline_output.join(
                unified_brand,
                baseline_output["UNIQUE_BRAND_NAME"] == unified_brand["UNIQUE_BRAND_NAME"],
                "left",
            )
            .drop(baseline_output["UNIQUE_BRAND_NAME"])  # Remove the old UNIQUE_BRAND_NAME column
            .withColumnRenamed(
                "RAW_UNIQUE_BRAND_NAME", "UNIQUE_BRAND_NAME"
            )  # Rename the raw brand name
        )

        # Load SKU_CLUSTER_MAPPING table and get the latest records per ITEM_CD based on LOAD_TS
        sku_cluster_mapping_raw = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "SKU_CLUSTER_MAPPING")
        sku_cluster_mapping_max = sku_cluster_mapping_raw.groupBy("ITEM_CD").agg(
            F_max(col("LOAD_TS")).alias("LOAD_TS")
        )

        # Merge the latest SKU cluster mapping records back into the full dataset
        sku_cluster_mapping = sku_cluster_mapping_max.join(
            sku_cluster_mapping_raw,
            on=["ITEM_CD", "LOAD_TS"],
            how="inner",
        )

        # Join sku_cluster_mapping with unified_brand to get RAW_UNIQUE_BRAND_NAME
        sku_cluster_mapping = (
            sku_cluster_mapping.join(unified_brand, on=["UNIQUE_BRAND_NAME"], how="left")
            .drop(sku_cluster_mapping["UNIQUE_BRAND_NAME"])  # Remove old brand name column
            .withColumnRenamed(
                "RAW_UNIQUE_BRAND_NAME", "UNIQUE_BRAND_NAME"
            )  # Rename the raw brand name
        )

        # Load and process SALES_DATA_TRANSFORMATION_OUTPUT, ensuring brand names are mapped correctly
        sales_data_transformations_output = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "SALES_DATA_TRANSFORMATION_OUTPUT"
        )

        sales_data_transformations_output = (
            sales_data_transformations_output.join(unified_brand, on=["UNIQUE_BRAND_NAME"], how="left")
            .drop(sales_data_transformations_output["UNIQUE_BRAND_NAME"])
            .withColumnRenamed("RAW_UNIQUE_BRAND_NAME", "UNIQUE_BRAND_NAME")
        )

        # Load CAMPAIGN_PRODUCT_TYPE and BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE tables
        campaign_product_type = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "CAMPAIGN_PRODUCT_TYPE")
        baseline_integration_df = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE"
        )

        # Take the columns from the baseline_integration_df to use in the final output
        existing_seq = baseline_integration_df.columns

        is_post_campaign = False

        # Get the campaign ids from measurement_campaign_execution
        # based on booking id, campaign duration
        campaign_ids = (
            df.where(
                (col("BOOKING_ID") == booking_id) & (col("CAMPAIGN_DURATION") == campaign_duration)
            )
            .select("CAMPAIGN_ID")
            .distinct()
            .collect()
        )

        # If campaign_duration is Post, set the is_post_campaign flag to True
        if campaign_duration == "Post":
            is_post_campaign = True

        # Convert campaign_ids list to a set for faster lookup operations
        campaign_ids_set = {row["CAMPAIGN_ID"] for row in campaign_ids}

        # Cast ITEM_CD to Integer and WEEK_START_DT to Date for consistency
        sku_level_results_filtered = sku_level_results_filtered.withColumn(
            "ITEM_CD", col("ITEM_CD").cast(IntegerType())
        ).withColumn("WEEK_START_DT", col("WEEK_START_DT").cast(DateType()))

        # Filter the campaign_product_type DataFrame for the current booking_id and 'Aisle' product type
        campaign_product_type_filtered = campaign_product_type.filter(
            (col("BOOKING_ID") == booking_id) & (col("PRODUCT_TYPE") == "Aisle")
        )

        # Retrieve brand, super category, and cluster details for the given campaign IDs
        brand, super_category_name, final_cluster = find_cluster_details(
            campaign_ids_set, campaign_product_type_filtered, sku_cluster_mapping
        )

        # Apply filtering to keep only relevant data based on the extracted cluster and category details
        baseline_output_filtered, sku_cluster_mapping_filtered, sales_data_output = filter_data(
            baseline_output,
            sku_cluster_mapping,
            sales_data_transformations_output,
            final_cluster,  # List of relevant clusters
            super_category_name,  # Super category for filtering
            brand,  # List of relevant brands
        )

        campaign_start_date, campaign_end_date = get_campaign_start_end_date(
            df, is_post_campaign, booking_id
        )

        # Calculating the SKU cluster level sales proportion based on pre-campaign and campaign sales data
        sales_proportions, pre_campaign_sales_data_exists = calculate_sales_proportion(sales_data_output, sku_cluster_mapping_filtered, campaign_start_date, campaign_end_date, pre_campaign_weeks, min_pre_camp_sales_threshold)

        # Get SKU-level baseline and inclementality from baseline reuslts
        baseline_integrated_df_filtered = baseline_sku_level_integration(
            baseline_output_filtered, sku_cluster_mapping_filtered, sales_data_output, sales_proportions, pre_campaign_sales_data_exists
        )

        # Drop unnecessary columns from the integrated dataset before final processing
        baseline_integrated_df_filtered = baseline_integrated_df_filtered.drop(
            "CLUSTER_NUM",
            "SUPER_CATEGORY_NAME",
            "ITERATION",
            "UNIQUE_BRAND_NAME",
            "DISTINCT_CUSTOMER_CNT",
            "AVG_PURCHASE_PER_CUSTOMER_CNT",
            "JOB_RUN_ID",
            "PRICE_PER_POINT",
            "BASE_PRICE_AMT",
        )

        """Extracting the campaign start date and campaign end date
        from measurement campaign execution table, which are required to filter the
        baseline data
        """

        # Filterting the baseline integrated data on the basis of start date and end date
        baseline_integrated_df_filtered = baseline_integrated_df_filtered.filter(
            (
                col("WEEK_START_DT") >= lit(campaign_start_date)
            ) & (
                col("WEEK_START_DT") <= lit(campaign_end_date)
            )
        ).distinct()

        # Create partitioning window on item_cd
        sku_avg_window = Window.partition_by("ITEM_CD")

        # Calculate sum_baseline_amt and sum_of_sales_amt using a window function over item_cd
        baseline_integrated_df_filtered = baseline_integrated_df_filtered.with_column(
            "SUM_BASELINE_AMT", F_sum("BASELINE").over(sku_avg_window)
        ).with_column("SUM_OF_SALES_AMT", F_sum("TOTAL_SALES_AMT").over(sku_avg_window))

        # Join baseline data with the provided sku_level_results DataFrame
        mta_mmm_integration = sku_level_results_filtered.join(
            baseline_integrated_df_filtered, on=["WEEK_START_DT", "ITEM_CD"], how="left"
        )

        log_missing_data(
            mta_mmm_integration, sku_level_results_filtered, invocation_id, col_seq_log_table
        )

        # Replace null values in SUM_BASELINE_AMT with 0 to avoid calculation errors
        mta_mmm_integration = mta_mmm_integration.withColumn(
            "SUM_BASELINE_AMT",
            when(col("SUM_BASELINE_AMT").is_null(), 0).otherwise(col("SUM_BASELINE_AMT")),
        )

        # Compute additional metrics for baseline attribution integration at SKU level
        baseline_attribution_integration_sku_level_aisle = (
            mta_mmm_integration
            # Calculate SUM_OF_ATTR_SALES_AMT using a window function over SKU-level data
            .withColumn(
                "SUM_OF_ATTR_SALES_AMT",
                F_sum("ATTRIBUTED_RECALIBERATED_SALES_AMT").over(sku_avg_window),
            )
            # Compute incremental sales amount as difference between total sales and baseline sales
            .withColumn("SUM_OF_INCR_AMT", col("SUM_OF_SALES_AMT") - col("SUM_BASELINE_AMT"))
            # Calculate incrementality ratio based on total sales (avoid division by zero)
            .withColumn(
                "INCREMENTALITY_TOTAL",
                when(
                    col("SUM_OF_SALES_AMT") > 0,
                    col("SUM_OF_INCR_AMT") / col("SUM_OF_SALES_AMT"),
                ).otherwise(lit(0.0)),
            )
            # Calculate incrementality ratio based on attributed sales (avoid division by zero)
            .withColumn(
                "INCREMENTALITY_EXPOSED",
                when(
                    col("SUM_OF_ATTR_SALES_AMT") > 0,
                    col("SUM_OF_INCR_AMT") / col("SUM_OF_ATTR_SALES_AMT"),
                ).otherwise(lit(0.0)),
            )
        )

        log_negative_or_zero_incrementality(
            baseline_attribution_integration_sku_level_aisle, invocation_id, col_seq_log_table
        )

        # Ensure INCREMENTALITY_EXPOSED and INCREMENTALITY_TOTAL are non-negative
        baseline_attribution_integration_sku_level_aisle = (
            # Ensuring that for exposed group of customer we are not carrying any negative incrementality
            baseline_attribution_integration_sku_level_aisle.withColumn(
                "INCREMENTALITY_EXPOSED",
                when(col("INCREMENTALITY_EXPOSED") > 0, col("INCREMENTALITY_EXPOSED")).otherwise(
                    lit(0.00)
                ),
            )
            # Ensuring that for total sales we are not carrying any negative incrementality
            .withColumn(
                "INCREMENTALITY_TOTAL",
                when(col("INCREMENTALITY_TOTAL") > 0, col("INCREMENTALITY_TOTAL")).otherwise(lit(0.00)),
            )
            # Compute incremental sales amount exposed customers obtained by multiplying attributed sales amount with
            # the calculated incrementality ratio for the exposed customers
            .withColumn(
                "INCREMENTAL_SALES_AMT_EXPOSED",
                col("ATTRIBUTED_RECALIBERATED_SALES_AMT") * col("INCREMENTALITY_EXPOSED"),
            )
            # Compute incremental units exposed customers obtained by multiplying attributed unit amount with
            # the calculated incrementality ratio for the exposed customers
            .withColumn(
                "INCREMENTAL_UNITS_QTY_EXPOSED",
                col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") * col("INCREMENTALITY_EXPOSED"),
            )
            # Compute incremental sales amount and units for total SKUs
            .withColumn(
                "INCREMENTAL_SALES_AMT_TOTAL",
                col("ATTRIBUTED_RECALIBERATED_SALES_AMT") * col("INCREMENTALITY_TOTAL"),
            )
            .withColumn(
                "INCREMENTAL_UNITS_QTY_TOTAL",
                col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") * col("INCREMENTALITY_TOTAL"),
            )
            # Ensure negative incremental unit values are set to zero to avoid incorrect reporting
            .withColumn(
                "INCREMENTAL_UNITS_QTY_EXPOSED",
                when(col("INCREMENTAL_UNITS_QTY_EXPOSED") < 0, lit(0.00)).otherwise(
                    col("INCREMENTAL_UNITS_QTY_EXPOSED")
                ),
            )
            .withColumn(
                "INCREMENTAL_UNITS_QTY_TOTAL",
                when(col("INCREMENTAL_UNITS_QTY_TOTAL") < 0, lit(0.00)).otherwise(
                    col("INCREMENTAL_UNITS_QTY_TOTAL")
                ),
            )
            # Add metadata columns for tracking job execution and load timestamp
            .withColumn("JOB_RUN_ID", lit(invocation_id))
            .withColumn("LOAD_TS", current_timestamp())
        )
        # Replaces null values with zero in specific columns of a DataFrame.
        baseline_attribution_integration_sku_level_aisle = replace_nulls_with_zero(
            baseline_attribution_integration_sku_level_aisle
        )

        # Select only the required columns based on existing schema and replace null values with zero
        baseline_attribution_integration_sku_level_aisle = (
            baseline_attribution_integration_sku_level_aisle.select(*existing_seq)
        )
    except Exception as e:
        # This section of the code processes the reach and engagement data. If no valid data is found,
        # it returns an empty dataframe. Otherwise, it appends the invocation ID as a job run identifier,
        # casts columns to the required data types, and ensures the column order matches the final table schema.
        # In case of an exception, it logs the error details (type, message, and trace) into the error log table
        # using the `log_process_helper` function and raises the exception to stop execution.
        error_type = type(e).__name__
        error_message = str(e)
        error_trace = traceback.format_exc()
        error_message = extract_error_message(error_message)
        schema = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "ERROR_LOG_TABLE").schema
        log_process_helper(session, error_message, error_trace, error_type, "baseline_attribution_integration_sku_level_aisle", "MTA", "Failed", booking_id, campaign_duration, job_run_id, schema)
        raise

    # Write the processed baseline attribution data at the SKU and aisle level to the table
    return baseline_attribution_integration_sku_level_aisle
