"""
/**************************************************************************
* This script processes marketing campaign data to generate a final report
* that provides insights into campaign performance. It calculates key metrics
* such as conversions, attributed sales, incremental sales,
* and return on ad spend (ROAS),campaign uplift, and aggregating total investments
* at marketing_type, channel, subchannel level for each campaign. These metrics help stakeholders evaluate
* the effectiveness of campaigns and make data-driven decisions.
*
* Key Business Goals:
* - Provide accurate and up-to-date reporting on campaign performance.
* - Help identify successful campaigns and areas for improvement.
* - Support decision-making with actionable insights.
*
* Confluence Link: https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/852629176/Measurement+Campaign+Reporting
*
* Upstream Dependencies:
* - BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_OFFER: Offer-level baseline attribution integrated data.
* - BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_BRAND: Brand-level baseline attribution integrated data.
* - BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE: Aisle-level baseline attribution integrated data.

* Downstream Dependencies:
* - MEASUREMENT_CAMPAIGN_REPORTING: Final reporting table which will be used to create the reporting dashboard.

* Owner : Sahil Arya
* Date : 10/01/2025
*
******************************************************************************/"""

from functools import reduce
from datetime import datetime
import traceback
from snowflake.snowpark import Session, Window
from snowflake.snowpark.functions import (col, current_timestamp, lit, lower,
                                          max)
from snowflake.snowpark.functions import sum as sf_sum
from snowflake.snowpark.functions import trim, when


def log_process_helper(
    session,
    error_message,
    error_traceback,
    error_type,
    module_name,
    pipeline,
    status,
    booking_id,
    campaign_duration,
    job_run_id
):
    """
    Logs job failure details into a Snowflake table for tracking and debugging purposes.

    Objective:
    This function is designed to capture and log errors that occur during the execution of the measurement campaign reporting pipeline.
    It ensures that any issues are recorded with sufficient detail to allow for troubleshooting and analysis.
    This supports the business goal of maintaining reliable and transparent reporting processes.

    Used in:
        - model function in measurement_campaign_reporting.py

    Args:
        session (Session): Snowpark session object used to interact with Snowflake.
        error_message (str): A brief description of the error that occurred.
        error_traceback (str): The full traceback of the error for debugging purposes.
        error_type (str): The type of error (e.g., ValueError, KeyError).
        module_name (str): The name of the module where the error occurred.
        pipeline (str): The name of the pipeline being executed (e.g., "MTA").
        status (str): The status of the job, typically "FAILED" in this context.
        booking_id (str): The booking ID associated with the campaign being processed.
        campaign_duration (str): The duration of the campaign (e.g., "Post", "During").
        job_run_id (str): A unique identifier for the job execution.

    Returns:
        None (writes log entry to Snowflake)
    """
    varchar = "varchar(1000)"  # Define a standard data type for string columns.
    load_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Capture the current timestamp.

    # Create a Snowpark DataFrame with one row of log details.
    log_df = session.create_dataframe(
        [[
            booking_id,
            campaign_duration,
            "NA",  # Placeholder for cluster number, not used in this context.
            error_message,
            error_traceback,
            error_type,
            job_run_id,
            load_ts,
            module_name,
            pipeline,
            status,
            "NA",  # Placeholder for super category name, not used in this context.
            "NA"   # Placeholder for unique brand name, not used in this context.
        ]],
        schema=[
            "BOOKING_ID",
            "CAMPAIGN_DURATION",
            "CLUSTER_NUM",
            "ERROR_MESSAGE",
            "ERROR_TRACEBACK",
            "ERROR_TYPE",
            "JOB_RUN_ID",
            "LOAD_TS",
            "MODULE_NAME",
            "PIPELINE",
            "STATUS",
            "SUPER_CATEGORY_NAME",
            "UNIQUE_BRAND_NAME"
        ]
    )

    # Check if the DataFrame contains any rows (it should always have one row in this case).
    if log_df.count() > 0:
        # Select and cast columns to match the schema of the "ERROR_LOG_TABLE".
        error_log_df = log_df.select(
            col("PIPELINE").cast(varchar).alias("PIPELINE"),
            col("MODULE_NAME").cast(varchar).alias("MODULE_NAME"),
            col("BOOKING_ID").cast(varchar).alias("BOOKING_ID"),
            col("CAMPAIGN_DURATION").cast(varchar).alias("CAMPAIGN_DURATION"),
            col("UNIQUE_BRAND_NAME").cast(varchar).alias("UNIQUE_BRAND_NAME"),
            col("SUPER_CATEGORY_NAME").cast(varchar).alias("SUPER_CATEGORY_NAME"),
            col("CLUSTER_NUM").cast(varchar).alias("CLUSTER_NUM"),
            col("STATUS").cast(varchar).alias("STATUS"),
            col("ERROR_TYPE").cast(varchar).alias("ERROR_TYPE"),
            col("ERROR_MESSAGE").cast("varchar(10000)").alias("ERROR_MESSAGE"),
            col("ERROR_TRACEBACK").cast("varchar(10000)").alias("ERROR_TRACEBACK"),
            col("JOB_RUN_ID").cast(varchar).alias("JOB_RUN_ID"),
            col("LOAD_TS").cast("timestamp").alias("LOAD_TS")
        )
        # Append the log entry to the "ERROR_LOG_TABLE" in Snowflake.
        error_log_df.write.mode("append").save_as_table("ERROR_LOG_TABLE")

    return error_log_df  # Return the DataFrame for further use if needed.


def get_latest_data(data, booking_id, campaign_duration=None):

    """
    This method picks the latest records for the in-progress booking ID.

    Objective:
    This function ensures that only the most recent data is used for processing.
    In the context of campaign reporting, it is crucial to work with the latest
    available data to maintain accuracy and relevance in the generated reports.
    This supports the business goal of providing up-to-date and reliable insights
    for decision-making.

    Used in:
        - model function in measurement_campaign_reporting.py

    Args:
        booking_id (str): The ID of the booking that is currently in progress.
                        This is used to filter the data specific to the ongoing campaign.
        data (DataFrame): The dataset that contains all records, including historical ones.
                        This function will filter this dataset to extract only the relevant records.
        campaign_duration (str, optional): Specifies whether the campaign duration is "Post" or "During".
                                        This is used to further refine the filtering process.

    Returns:
        DataFrame: A filtered dataset containing only the latest records for the given booking ID
                and campaign duration (if provided).

    """

    # Step 1: Filter data based on booking ID and optionally campaign duration.
    # If campaign_duration is provided, filter by both booking ID and campaign duration.
    # Otherwise, filter only by booking ID.
    if campaign_duration:
        target_data = data.filter(
            (col("booking_id") == booking_id) & (col("campaign_duration") == campaign_duration)
        )
    else:
        target_data = data.filter(col("booking_id") == booking_id)

    # Step 2: Identify the most recent timestamp in the filtered data.
    load_ts = target_data.agg(max("load_ts")).collect()[0][0]

    # Step 3: Filter the data to include only records with the latest timestamp.
    filtered_data = target_data.filter(col("load_ts") == load_ts)

    # Step 4: Return the filtered dataset containing the latest records.
    return filtered_data


def process_nectar_data(reporting_df, untargeted_channels):
    """
    Processes the reporting DataFrame to calculate various metrics related to
    nectar and non-nectar sales, weights, and incremental sales amounts.
    Objective:
    The objective of this function is to process the reporting DataFrame to derive
    key metrics and insights related to nectar and non-nectar sales. This includes
    calculating weights, incremental sales amounts, and base sales amounts, which
    are essential for analyzing the performance of marketing campaigns.

    This function performs the following steps:
    1. Calculates total sums for various sales metrics.
    2. Adds constant columns for total nectar and non-nectar sales.
    3. Calculates nectar and non-nectar weights.
    4. Computes new nectar and non-nectar sales amounts based on incremental sales.
    5. Calculates new nectar weights and total non-nectar weights.
    6. Adds incremental nectar and non-nectar sales amounts.
    7. Computes total incremental nectar sales and base sales amounts.

    Args:
        reporting_df (DataFrame): The input Snowpark DataFrame containing sales data.
        untargeted_channels (list): A list of channels that are not targeted in the campaign.

    Returns:
        DataFrame: The processed Snowpark DataFrame with additional calculated columns.
    """

    # Calculate sums
    sums_nector_df = reporting_df.select(
        sf_sum("ATTRIBUTED_RECALIBERATED_SALES_AMT").alias("TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT"),
        sf_sum("ATTRIBUTED_RECALIBERATED_UNITS_QTY").alias("TOTAL_ATTRIBUTED_RECALIBERATED_UNITS_QTY"),
        sf_sum("INCREMENTAL_SALES_AMT_EXPOSED").alias("TOTAL_INCREMENTAL_SALES_AMT_EXPOSED"),
        sf_sum("INCREMENTAL_UNITS_QTY_EXPOSED").alias("TOTAL_INCREMENTAL_UNITS_QTY_EXPOSED"),
        sf_sum("NECTAR_SALES_AMT").alias("TOTAL_NECTAR_SALES_AMT"),
        sf_sum("NON_NECTAR_SALES_AMT").alias("TOTAL_NON_NECTAR_SALES_AMT"),
    ).collect()

    # Extract the sums
    total_attributed_sales = sums_nector_df[0]["TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT"]
    total_nectar_sales = sums_nector_df[0]["TOTAL_NECTAR_SALES_AMT"]
    total_non_nector_sales = sums_nector_df[0]["TOTAL_NON_NECTAR_SALES_AMT"]
    total_incremental_sales_amt_exposed = sums_nector_df[0]["TOTAL_INCREMENTAL_SALES_AMT_EXPOSED"]
    total_incremental_units_qty_exposed = sums_nector_df[0]["TOTAL_INCREMENTAL_UNITS_QTY_EXPOSED"]
    total_attributed_qty = sums_nector_df[0]["TOTAL_ATTRIBUTED_RECALIBERATED_UNITS_QTY"]

    # Add the sums as constant columns
    reporting_df = (
        reporting_df
        .with_column("NECTAR_SALES_AMT", lit(total_nectar_sales))
        .with_column("NON_NECTAR_SALES_AMT", lit(total_non_nector_sales))
    )

    # Calculate weights
    reporting_df = (
        reporting_df
        .with_column(
            "NECTAR_WEIGHTS",
            when(
                col("NECTAR_SALES_AMT") > 0,
                col("NECTAR_SALES_AMT") / (col("NECTAR_SALES_AMT") + col("NON_NECTAR_SALES_AMT"))
            ).otherwise(lit(0.0))
        )
        .with_column(
            "NON_NECTAR_WEIGHTS",
            when(
                (col("NECTAR_SALES_AMT") + col("NON_NECTAR_SALES_AMT")) > 0,
                col("NON_NECTAR_SALES_AMT") / (col("NECTAR_SALES_AMT") + col("NON_NECTAR_SALES_AMT"))
            ).otherwise(lit(0.0))
        )
    )

    # Calculate new sales amounts
    reporting_df = (
        reporting_df
        .with_column(
            "NEW_NECTAR_SALES_AMT",
            total_incremental_sales_amt_exposed * col("NECTAR_WEIGHTS")
        )
        .with_column(
            "NEW_NON_NECTAR_SALES_AMT",
            total_incremental_sales_amt_exposed * col("NON_NECTAR_WEIGHTS")
        )
        .with_column(
            "NEW_NECTAR_UNITS_QTY",
            total_incremental_units_qty_exposed * col("NECTAR_WEIGHTS")
        )
        .with_column(
            "NEW_NON_NECTAR_UNITS_QTY",
            total_incremental_units_qty_exposed * col("NON_NECTAR_WEIGHTS")
        )
    )

    # Calculate new nectar weight
    reporting_df = (
        reporting_df
        .with_column(
            "NEW_NECTAR_WEIGHT",
            col("ATTRIBUTED_RECALIBERATED_SALES_AMT") / total_attributed_sales
        )
        .with_column(
            "NEW_NECTAR_QTY_WEIGHT",
            col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") / total_attributed_qty
        )
    )

    # Calculate total non-nectar weights
    non_nector_weights_df = reporting_df.filter(
        lower(col("CHANNEL_NAME")).isin(untargeted_channels) |
        lower(col("MARKETING_TYPE")).isin(["in-store"])
    ).select(
        sf_sum("NEW_NECTAR_WEIGHT").alias("TOTAL_NON_NECTAR_WEIGHTS"),
        sf_sum("NEW_NECTAR_QTY_WEIGHT").alias("TOTAL_NON_NECTAR_QTY_WEIGHTS")
    ).collect()

    # Extract the total sum from the collected result
    total_non_nector_weights = non_nector_weights_df[0]["TOTAL_NON_NECTAR_WEIGHTS"]
    total_non_nector_qty_weights = non_nector_weights_df[0]["TOTAL_NON_NECTAR_QTY_WEIGHTS"]

    # Add incremental nectar and non-nectar weights
    reporting_df = (
        reporting_df
        .with_column(
            "INCREMENTAL_NECTAR_SALES_AMT",
            when(
                col("NEW_NECTAR_SALES_AMT") > 0,
                col("NEW_NECTAR_SALES_AMT") * col("NEW_NECTAR_WEIGHT"),
            ).otherwise(lit(0.00))
        )
        .with_column(
            "NEW_NON_NECTAR_WEIGHTS",
            when(
                (lower(col("CHANNEL_NAME")).isin(untargeted_channels)) |
                (lower(col("MARKETING_TYPE")).isin(["in-store"])),
                col("NEW_NECTAR_WEIGHT") / total_non_nector_weights
            ).otherwise(lit(0.00))
        )
        .with_column(
            "INCREMENTAL_NECTAR_UNITS_QTY",
            when(
                col("NEW_NECTAR_UNITS_QTY") > 0,
                col("NEW_NECTAR_UNITS_QTY") * col("NEW_NECTAR_QTY_WEIGHT"),
            ).otherwise(lit(0.00))
        )
        .with_column(
            "NEW_NON_NECTAR_QTY_WEIGHTS",
            when(
                (lower(col("CHANNEL_NAME")).isin(["onsite-gol", "in-store", "magazine"])) |
                (lower(col("MARKETING_TYPE")).isin(["in-store"])),
                col("NEW_NECTAR_QTY_WEIGHT") / total_non_nector_qty_weights
            ).otherwise(lit(0.00))
        )
    )

    # Add incremental non-nectar sales amount and total incremental sales amount
    reporting_df = (
        reporting_df
        .with_column(
            "INCREMENTAL_NON_NECTAR_SALES_AMT",
            when(
                (col("NEW_NON_NECTAR_SALES_AMT") > 0) & (col("NEW_NON_NECTAR_WEIGHTS") > 0),
                col("NEW_NON_NECTAR_SALES_AMT") * col("NEW_NON_NECTAR_WEIGHTS"),
            ).otherwise(lit(0.00))
        )
        .with_column(
            "TOTAL_INCREMENTAL_NECTAR_SALES_AMT",
            col("INCREMENTAL_NECTAR_SALES_AMT") + col("INCREMENTAL_NON_NECTAR_SALES_AMT")
        )
        .with_column(
            "INCREMENTAL_NON_NECTAR_UNITS_QTY",
            when(
                (col("NEW_NON_NECTAR_UNITS_QTY") > 0) & (col("NEW_NON_NECTAR_QTY_WEIGHTS") > 0),
                col("NEW_NON_NECTAR_UNITS_QTY") * col("NEW_NON_NECTAR_QTY_WEIGHTS"),
            ).otherwise(lit(0.00))
        )
        .with_column(
            "TOTAL_INCREMENTAL_NECTAR_UNITS_QTY",
            col("INCREMENTAL_NECTAR_UNITS_QTY") + col("INCREMENTAL_NON_NECTAR_UNITS_QTY")
        )
    )

    # Calculate baseline sales amount for exposed groups.
    # This step calculates the sales amount that would have occurred without the campaign,
    # helps to isolate the campaign's incremental impact.
    reporting_df = reporting_df.with_column(
        "BASE_SALES_AMT_NECTAR_EXPOSED",
        when(
            col("ATTRIBUTED_RECALIBERATED_SALES_AMT") > 0,
            col("ATTRIBUTED_RECALIBERATED_SALES_AMT") - col("TOTAL_INCREMENTAL_NECTAR_SALES_AMT"),
        ).otherwise(lit(0.00)),
    )

    return reporting_df


def process_booking_ids(
    baseline_df,
    unified_campaign,
    baseline_offer_df,
    reach_engagement,
    attribution_data_filtered,
    attribution_pre_requisite_filtered,
    untargeted_channels,
):

    """
    Processes booking IDs to generate enriched and aggregated campaign reporting data.
    Objective:
        This method processes various input datasets related to campaign performance,
        applies transformations, and calculates key metrics such as conversions,
        incremental sales, ROAS (Return on Ad Spend), and uplift. The goal is to
        produce a comprehensive dataset that provides insights into the effectiveness
        of marketing campaigns and their impact on business outcomes.

    Used in:
        - model function in measurement_campaign_reporting.py

    Args:
        baseline_df (DataFrame): Baseline data containing campaign-related metrics.
        unified_campaign (DataFrame): Unified campaign data with campaign details.
        baseline_offer_df (DataFrame): Baseline offer data containing recalibration factors.
        reach_engagement (DataFrame): Reach engagement data with media spend and channel details.
        attribution_data_filtered (DataFrame): Filtered attribution data for calculating conversions.
        attribution_pre_requisite_filtered (DataFrame): Filtered prerequisite data for conversion calculations.
        untargeted_channels (list): List of channels that are not targeted in the campaign.

    Returns:
        List[DataFrame]: A list of enriched and aggregated DataFrames, each containing
        processed campaign data with calculated metrics such as conversions, ROAS,
        uplift, and incremental sales.

    """

    # Initialize an empty list to store the results for each booking ID.
    results_list = []

    # Define a window function to group data by booking ID for calculations.
    win = Window.partition_by(("BOOKING_ID"))

    # Start with the baseline data for processing.
    filtered_df = baseline_df

    # Calculate the total number of converted journeys (successful outcomes).
    conv_count = (
        attribution_pre_requisite_filtered.filter(col("ISCONVERSION") == 1)
        .select("USERJOURNEY_ID")
        .distinct()
        .count()
    )
    conv_count = int(conv_count)

    # Calculate the total number of journeys (all attempts) to determine the conversion rate.
    # It is used later to compute the conversion rate, which measures the percentage of successful outcomes
    # (conversions) relative to all customer interactions. This helps assess the effectiveness of the campaign.
    total_count = attribution_pre_requisite_filtered.select("USERJOURNEY_ID").distinct().count()
    total_count = int(total_count)

    # Aggregate the attribution data to calculate total conversions for each combination of channel, campaign, subchannel, and marketing type.
    attribution_data_filtered = attribution_data_filtered.group_by(
        "CHANNEL_NAME", "CAMPAIGN_ID", "SUBCHANNEL_NAME", "MARKETING_TYPE"
    ).agg(sf_sum(col("NORMALIZED_WEIGHTS")).alias("CONVERSIONS"))

    """
    Add a new column to identify whether a journey type is "Non-direct" (indirect customer interaction).
    This step identifies whether a customer journey is "Non-direct," meaning it involves indirect
    interactions with the campaign.
    This classification helps in determining the type of campaign (multi-channel or single-channel),
    which is important for understanding the campaign's complexity and reach.
    """
    filtered_df_channel = filtered_df.with_column(
        "is_non_direct",
        when(col("CUSTOMER_JOURNEY_TYPE") == "Non-direct", lit(1)).otherwise(lit(0)),
    )

    # Group by campaign ID to check if any journey is non-direct and classify the campaign type accordingly.
    # This step aggregates the data at the campaign level to determine if any customer journey
    # within a campaign is "Non-direct." If so, the campaign is classified as "Multi Channel"; otherwise,
    # it is classified as "Single Channel." This classification helps the business understand the nature
    # of the campaign and its reliance on multiple channels to engage customers.
    filtered_df_channel = filtered_df_channel.group_by("CAMPAIGN_ID").agg(
        (sf_sum(col("is_non_direct")) > 0).alias("has_non_direct")
    )

    # Assign "Multi Channel" or "Single Channel" labels based on the presence of non-direct journeys.
    filtered_df_channel = filtered_df_channel.with_column(
        "CAMPAIGN_TYPE",
        when(col("has_non_direct"), lit("Multi Channel")).otherwise(lit("Single Channel")),
    ).select("CAMPAIGN_ID", "CAMPAIGN_TYPE")

    # Select relevant columns from the reach engagement data for further processing.
    reach_engagement_filtered = reach_engagement.select(
        "CAMPAIGN_ID", "CHANNEL_NAME", "SUBCHANNEL_NAME", "MEDIA_SPEND_AMT", "MARKETING_TYPE"
    )

    # Extract recalibration factors for campaigns where adjustments are needed (e.g., for offsite channels).
    factor = (
        baseline_offer_df.select("RECALIBERATION_FACTOR", "CHANNEL_NAME", "CAMPAIGN_ID")
        .filter(col("RECALIBERATION_FACTOR") > 0)
        .distinct()
    )

    # Select relevant columns from the unified campaign data for enrichment purposes.
    unified_campaign_filtered = unified_campaign.select(
        "CAMPAIGN_ID",
        "CHANNEL_NAME",
        "SUBCHANNEL_NAME",
        "SUPER_CATEGORY_NAME",
        "SUB_CATEGORY_NAME",
        "CAMPAIGN_NAME",
        "MARKETING_TYPE",
        "JOB_BAG_NUMBER",
    ).distinct()

    # Aggregate baseline data to calculate key metrics like incremental sales, attributed sales, and units.
    # This step calculates essential metrics such as sales and units attributed to the campaign,
    # as well as incremental sales and units generated due to the campaign. These metrics help measure
    # the campaign's effectiveness and its impact on business outcomes.
    if factor.count() > 0:
        filtered_df = filtered_df.group_by(
            "BOOKING_ID",
            "CAMPAIGN_ID",
            "CAMPAIGN_DURATION",
            "JOURNEY_TYPE",
            "MARKETING_TYPE",
            "CHANNEL_NAME",
            "SUBCHANNEL_NAME",
        ).agg(
            sf_sum(col("INCREMENTAL_SALES_AMT_EXPOSED")).alias("INCREMENTAL_SALES_AMT_EXPOSED"),
            sf_sum(col("ATTRIBUTED_RECALIBERATED_SALES_AMT")).alias(
                "ATTRIBUTED_RECALIBERATED_SALES_AMT"
            ),
            sf_sum(col("ATTRIBUTED_RECALIBERATED_UNITS_QTY")).alias(
                "ATTRIBUTED_RECALIBERATED_UNITS_QTY"
            ),
            sf_sum(col("ATTRIBUTED_SALES_AMT")).alias("ATTRIBUTED_SALES_AMT"),
            sf_sum(col("ATTRIBUTED_UNITS_QTY")).alias("ATTRIBUTED_UNITS_QTY"),
            sf_sum(col("INCREMENTAL_UNITS_QTY_EXPOSED")).alias("INCREMENTAL_UNITS_QTY_EXPOSED"),
            sf_sum(col("NECTAR_SALES_AMT")).alias("NECTAR_SALES_AMT"),
            sf_sum(col("NON_NECTAR_SALES_AMT")).alias("NON_NECTAR_SALES_AMT"),
        )

        # Join the recalibration factor to adjust conversions for specific channels.
        # Some channels require adjustments to their conversion metrics to account for
        # specific business rules or external factors. This step ensures accurate reporting.
        filtered_df_with_factor = filtered_df.join(
            factor, on=["CHANNEL_NAME", "CAMPAIGN_ID"], how="left"
        )

        # Rename columns in attribution data to avoid conflicts during joins.
        # This step ensures that column names are unique and do not cause issues during data merging.
        attribution_data_filtered = attribution_data_filtered.select(
            [col(column).alias(f"{column}_attr") for column in attribution_data_filtered.columns]
        )

        # Define the join condition to combine filtered data with attribution data for conversions.
        # This step links the recalibrated data with attribution data to calculate conversions
        # for each campaign and channel.
        join_condition_attr = (
            (
                lower(filtered_df_with_factor["CAMPAIGN_ID"]) == lower(attribution_data_filtered["CAMPAIGN_ID_ATTR"])
            ) & (
                lower(filtered_df_with_factor["MARKETING_TYPE"]) == lower(attribution_data_filtered["MARKETING_TYPE_ATTR"])
            ) & (
                lower(filtered_df_with_factor["CHANNEL_NAME"]) == lower(attribution_data_filtered["CHANNEL_NAME_ATTR"])
            ) & (
                lower(filtered_df_with_factor["SUBCHANNEL_NAME"]) == lower(attribution_data_filtered["SUBCHANNEL_NAME_ATTR"])
            )
        )

        # Join and calculate recalibrated conversions for specific channels.
        # This step adjusts the conversion metrics for channels that require recalibration,
        # ensuring that the reported metrics are accurate and aligned with business expectations.
        filtered_df_with_factor = (
            filtered_df_with_factor.join(
                attribution_data_filtered,
                join_condition_attr,
                "left",
            )
            .drop(
                "SUBCHANNEL_NAME_ATTR",
                "CHANNEL_NAME_ATTR",
                "MARKETING_TYPE_ATTR",
                "CAMPAIGN_ID_ATTR",
            )
            .with_column_renamed("CONVERSIONS_ATTR", "CONVERSIONS")
        )

        # Adjust conversions for offsite channels using recalibration factors.
        # Offsite channels like Meta and YouTube often require special adjustments to their
        # conversion metrics because we are working with targeted audiences and not the exposed audience.
        # This step ensures that the reported conversions accurately reflect the impact of these channels.
        filtered_df_with_factor = filtered_df_with_factor.with_column(
            "CONVERSIONS_RECALIBERATED",
            when(
                lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
                col("CONVERSIONS") * col("RECALIBERATION_FACTOR"),
            ).otherwise(col("CONVERSIONS")),
        )

        # Rename columns in unified campaign data to avoid conflicts during joins.
        # This step ensures that column names in the unified campaign data are unique
        # and do not conflict with other datasets during merging.
        unified_campaign_filtered = unified_campaign_filtered.select(
            [col(column).alias(f"{column}_uni") for column in unified_campaign_filtered.columns]
        )

        # Rename columns in reach engagement data to avoid conflicts during joins.
        # Similar to the unified campaign data, this step ensures that column names in the
        # reach engagement data are unique and do not cause issues during data merging.
        reach_engagement_filtered = reach_engagement_filtered.select(
            [col(column).alias(f"{column}_reach") for column in reach_engagement_filtered.columns]
        )

        # Define the join condition to combine unified campaign data with recalibrated data.
        # This step links the recalibrated data with unified campaign data to enrich it
        # with additional details like campaign name, category, and job bag number.
        join_condition = when(
            ~lower(col("CHANNEL_NAME")).isin("meta", "youtube", "dv360"),
            (
                lower(unified_campaign_filtered["CAMPAIGN_ID_UNI"]) == lower(filtered_df_with_factor["CAMPAIGN_ID"])
            ) & (
                lower(unified_campaign_filtered["MARKETING_TYPE_UNI"]) == lower(filtered_df_with_factor["MARKETING_TYPE"])
            ) & (
                lower(unified_campaign_filtered["CHANNEL_NAME_UNI"]) == lower(filtered_df_with_factor["CHANNEL_NAME"])
            ) & (
                lower(unified_campaign_filtered["SUBCHANNEL_NAME_UNI"]) == lower(filtered_df_with_factor["SUBCHANNEL_NAME"])
            ),
        ).otherwise(
            (
                lower(unified_campaign_filtered["CAMPAIGN_ID_UNI"]) == lower(filtered_df_with_factor["CAMPAIGN_ID"])
            ) & (
                lower(unified_campaign_filtered["MARKETING_TYPE_UNI"]) == lower(filtered_df_with_factor["MARKETING_TYPE"])
            ) & (
                lower(unified_campaign_filtered["CHANNEL_NAME_UNI"]) == lower(filtered_df_with_factor["CHANNEL_NAME"])
            )
        )

        # Enrich the recalibrated data with additional campaign details like category, name, and job bag number.
        # This step adds more context to the recalibrated data, making it easier to analyze
        # and understand the performance of each campaign.
        enriched_df = filtered_df_with_factor.join(
            unified_campaign_filtered,
            join_condition,
            "left",
        ).select(
            "BOOKING_ID",
            "CAMPAIGN_ID",
            "CAMPAIGN_DURATION",
            "JOURNEY_TYPE",
            "MARKETING_TYPE",
            "CHANNEL_NAME",
            "SUBCHANNEL_NAME",
            unified_campaign_filtered["SUB_CATEGORY_NAME_UNI"].alias("SUB_CATEGORY_NAME"),
            "CONVERSIONS",
            "INCREMENTAL_SALES_AMT_EXPOSED",
            unified_campaign_filtered["SUPER_CATEGORY_NAME_UNI"].alias("SUPER_CATEGORY_NAME"),
            unified_campaign_filtered["CAMPAIGN_NAME_UNI"].alias("CAMPAIGN_NAME"),
            "ATTRIBUTED_RECALIBERATED_SALES_AMT",
            "ATTRIBUTED_RECALIBERATED_UNITS_QTY",
            "INCREMENTAL_UNITS_QTY_EXPOSED",
            "ATTRIBUTED_UNITS_QTY",
            "ATTRIBUTED_SALES_AMT",
            "CONVERSIONS_RECALIBERATED",
            "RECALIBERATION_FACTOR",
            unified_campaign_filtered["JOB_BAG_NUMBER_UNI"].alias("JOB_BAG_NUMBER"),
            "NECTAR_SALES_AMT",
            "NON_NECTAR_SALES_AMT",
        )

        # Define the join condition to combine enriched data with reach engagement data.
        # This step links the enriched data with reach engagement data to include metrics
        # like media spend, which are crucial for calculating ROI and other KPIs.
        join_condition_reach = (
            (
                trim(lower(reach_engagement_filtered["CAMPAIGN_ID_REACH"])) == trim(lower(enriched_df["CAMPAIGN_ID"]))
            ) & (
                trim(lower(reach_engagement_filtered["MARKETING_TYPE_REACH"])) == trim(lower(enriched_df["MARKETING_TYPE"]))
            ) & (
                trim(lower(reach_engagement_filtered["CHANNEL_NAME_REACH"])) == trim(lower(enriched_df["CHANNEL_NAME"]))
            ) & (
                trim(lower(reach_engagement_filtered["SUBCHANNEL_NAME_REACH"])) == trim(lower(enriched_df["SUBCHANNEL_NAME"]))
            )
        )

        # Enrich the data further with media spend and campaign type details.
        # Adding media spend and campaign type helps in calculating key performance indicators
        # like ROAS (Return on Ad Spend) and understanding the nature of each campaign.
        enriched_df_new = (
            enriched_df.join(
                reach_engagement_filtered,
                join_condition_reach,
                "left",
            )
            .drop(
                "CAMPAIGN_ID_REACH",
                "SUBCHANNEL_NAME_REACH",
                "CHANNEL_NAME_REACH",
                "MARKETING_TYPE_REACH",
            )
            .join(filtered_df_channel, on=["CAMPAIGN_ID"], how="left")
            .with_column_renamed("MEDIA_SPEND_AMT_REACH", "MEDIA_SPEND_AMT")
        )

        # Process the enriched DataFrame to calculate various metrics related to
        # nectar and non-nectar sales, weights, and incremental sales amounts.
        # This function modifies the DataFrame by adding calculated columns such as:
        # - Nectar and non-nectar weights
        # - Incremental nectar and non-nectar sales amounts
        # - Total incremental sales amounts
        # - Base sales amounts for nectar exposed
        enriched_df_new = process_nectar_data(enriched_df_new, untargeted_channels)

        # Calculate Return on Ad Spend (ROAS) for exposed groups.
        # ROAS measures the revenue generated for every pound spent on the campaign.
        # It is a key metric for evaluating the financial success of a campaign.
        # It is calculated as the ratio of attributed recalibrated sales to media spend.
        enriched_df_new = enriched_df_new.with_column(
            "ROAS_EXPOSED",
            when(
                sf_sum(col("MEDIA_SPEND_AMT")).over(win) > 0,
                (
                    sf_sum(col("ATTRIBUTED_RECALIBERATED_SALES_AMT")).over(win) / sf_sum(col("MEDIA_SPEND_AMT")).over(win)
                ),
            ).otherwise(lit(0.0)),
        )

        # Calculate Incremental ROAS (IROAS) to measure incremental revenue per pound spent.
        # IROAS focuses on the additional revenue generated due to the campaign and actual marketing efforts,
        # providing a more precise measure of its impact.
        # It is calculated as the ratio of incremental sales exposed to media spend.
        enriched_df_new = enriched_df_new.with_column(
            "IROAS_EXPOSED",
            when(
                col("MEDIA_SPEND_AMT") > 0,
                (col("INCREMENTAL_SALES_AMT_EXPOSED") / col("MEDIA_SPEND_AMT")),
            ).otherwise(lit(0.0)),
        ).with_column(
            "IROAS_EXPOSED_NECTAR",
            when(
                col("MEDIA_SPEND_AMT") > 0,
                (col("TOTAL_INCREMENTAL_NECTAR_SALES_AMT") / col("MEDIA_SPEND_AMT")),
            ).otherwise(lit(0.0)),
        )

        # Calculate baseline sales amount for exposed groups.
        # This step calculates the sales amount that would have occurred without the campaign,
        # helping to isolate the campaign's incremental impact.
        enriched_df_new = enriched_df_new.with_column(
            "BASE_SALES_AMT_EXPOSED",
            col("ATTRIBUTED_RECALIBERATED_SALES_AMT") - col("INCREMENTAL_SALES_AMT_EXPOSED"),
        )

        # Calculate the uplift (incremental impact) of the campaign on sales and units.
        # Uplift measures the percentage increase in sales and units due to the campaign,
        # providing insights into its effectiveness.
        # It is proportion of incremental sales to attributed recalibrated sales.
        enriched_df_new = enriched_df_new.with_column(
            "UPLIFT_EXPOSED_SALES_AMT",
            when(
                sf_sum(col("ATTRIBUTED_RECALIBERATED_SALES_AMT")).over(win) > 0,
                (
                    sf_sum(col("INCREMENTAL_SALES_AMT_EXPOSED")).over(win) / sf_sum(col("ATTRIBUTED_RECALIBERATED_SALES_AMT")).over(win)
                ),
            ).otherwise(lit(0.0)),
        ).with_column(
            "UPLIFT_EXPOSED_UNITS_QTY",
            when(
                sf_sum(col("ATTRIBUTED_RECALIBERATED_UNITS_QTY")).over(win) > 0,
                (
                    sf_sum(col("INCREMENTAL_UNITS_QTY_EXPOSED")).over(win) / sf_sum(col("ATTRIBUTED_RECALIBERATED_UNITS_QTY")).over(win)
                ),
            ).otherwise(lit(0.0)),
        ).with_column(
            "UPLIFT_EXPOSED_NECTAR_SALES_AMT",
            when(
                col("ATTRIBUTED_RECALIBERATED_SALES_AMT") > 0,
                (
                    col("TOTAL_INCREMENTAL_NECTAR_SALES_AMT") / col("ATTRIBUTED_RECALIBERATED_SALES_AMT")
                ),
            ).otherwise(lit(0.0)),
        ).with_column(
            "UPLIFT_EXPOSED_NECTAR_UNITS_QTY",
            when(
                col("ATTRIBUTED_RECALIBERATED_UNITS_QTY") > 0,
                (
                    col("TOTAL_INCREMENTAL_NECTAR_UNITS_QTY") / col("ATTRIBUTED_RECALIBERATED_UNITS_QTY")
                ),
            ).otherwise(lit(0.0)),
        )

        # Calculate the conversion rate as a percentage of converted journeys to total journeys.
        # Conversion rate is a key metric for understanding how effectively the campaign
        # drives desired customer actions, such as purchases.
        # It is calculated as the ratio of total converted journeys to total journeys, multiplied by 100.
        enriched_df_new = enriched_df_new.with_column(
            "CONVERSION_RATE",
            when(lit(total_count) > 0, (lit(conv_count) / lit(total_count)) * 100).otherwise(
                lit(0.0)
            ),
        )

        # Append the enriched data to the results list.
        # This step collects the processed data for further aggregation or reporting.
        results_list.append(enriched_df_new)

    # Return the list of processed results for further aggregation or reporting.
    # The processed data is returned for use in generating final reports or dashboards.
    return results_list


def model(dbt, session: Session):

    """
    This is the main function that collates the results from various output tables and calculates
    certain KPIs to create the final measurement campaign reporting table.

    Objective:
    This function is designed to process and aggregate marketing campaign data from various sources,
    It integrates data from multiple sources,
    applies business rules, and calculates key performance indicators (KPIs) to generate a comprehensive report.
    The report helps stakeholders understand the effectiveness of marketing campaigns and make data-driven decisions.

    Used in:
        - dbt model for measurement campaign reporting.
        - This function is called by dbt to execute the reporting pipeline.

    Args:
        dbt: The dbt object for managing configurations and data sources.
        session: The Snowflake session object for interacting with the database.

    Returns:
        measurement_campaign_reporting (DataFrame): The final processed data ready for reporting.

    Raises:
        Exception: Logs any errors encountered during processing and raises an exception to stop execution.

    """
    # Configure the dbt model with necessary settings like Python version and materialization strategy.
    dbt.config(
        packages=["snowflake-ml-python"],
        python_version="3.11",
        materialized="incremental",
        incremental_strategy="append",
        transient=False,
    )

    try:
        # Load data sources for unified campaign and reach engagement metrics.
        unified_campaign = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "UNIFIED_CAMPAIGN")
        reach_engagement = dbt.ref("reach_engagement")
        reporting_data = dbt.source("ADW_UNIFIED_PLATFORM_TACTICAL", "MEASUREMENT_CAMPAIGN_REPORTING")
        # Load data from various tables required for processing.
        attribution_model_result_offer = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "ATTRIBUTION_MODEL_RESULTS_OFFER"
        )
        attribution_model_result_brand = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "ATTRIBUTION_MODEL_RESULTS_BRAND"
        )
        attribution_model_result_aisle = dbt.source(
            "ADW_UNIFIED_PLATFORM_TACTICAL", "ATTRIBUTION_MODEL_RESULTS_AISLE"
        )
        attribution_pre_requisite_offer = dbt.ref("attribution_pre_requisite_offer")
        attribution_pre_requisite_brand = dbt.ref("attribution_pre_requisite_brand")
        attribution_pre_requisite_aisle = dbt.ref("attribution_pre_requisite_aisle")
        # Load baseline data for different levels (offer, brand, aisle).
        baseline_offer = dbt.ref("baseline_attribution_integration_sku_level_offer")
        baseline_brand = dbt.ref("baseline_attribution_integration_sku_level_brand")
        baseline_aisle = dbt.ref("baseline_attribution_integration_sku_level_aisle")
        measurement_campaign_execution = dbt.ref("measurement_campaign_execution")

        combined_results = []  # Initialize a list to store results from different data processing steps.
        invocation_id = dbt.config.get("invocation_id")  # Unique identifier for the current job run.
        measurement_campaign_execution = dbt.ref("measurement_campaign_execution")
        untargeted_channels = dbt.config.get("untargeted_channels")

        # Filter to get only campaigns that are currently in progress.
        in_progress_data = measurement_campaign_execution.filter(col("JOB_STATUS") == "In-progress")

        # If no in-progress campaigns are found, log an error and stop execution.
        if in_progress_data.count() == 0:
            in_progress_booking_id = "NA"
            campaign_duration = "NA"
            raise ValueError("Error: no data found to execute the model!")
        else:
            # Retrieve the first available booking ID and campaign duration from in-progress campaigns.
            in_progress_booking_id = in_progress_data.select("BOOKING_ID").limit(1).collect()[0][0]
            campaign_duration = in_progress_data.select("CAMPAIGN_DURATION").limit(1).collect()[0][0]

        # Define a list of variables used for regression analysis and convert them to uppercase for consistency.
        regression_variable_list = ["marketing_type", "channel_name", "subchannel_name", "campaign_id"]
        regression_variable_list = [elem.upper() for elem in regression_variable_list]

        # Create an empty DataFrame with the same structure as the reporting data for fallback scenarios.
        reporting_data_empty_df = reporting_data.filter(lit(False))
        column_seq = reporting_data_empty_df.columns

        # Get the latest records for all required tables based on the in-progress booking ID and campaign duration.
        target_baseline_offer = get_latest_data(
            baseline_offer, in_progress_booking_id, campaign_duration
        )
        target_baseline_brand = get_latest_data(
            baseline_brand, in_progress_booking_id, campaign_duration
        )
        target_baseline_aisle = get_latest_data(
            baseline_aisle, in_progress_booking_id, campaign_duration
        )
        target_pre_requisite_offer = get_latest_data(
            attribution_pre_requisite_offer, in_progress_booking_id, campaign_duration
        )
        target_pre_requisite_brand = get_latest_data(
            attribution_pre_requisite_brand, in_progress_booking_id, campaign_duration
        )
        target_pre_requisite_aisle = get_latest_data(
            attribution_pre_requisite_aisle, in_progress_booking_id, campaign_duration
        )
        target_model_result_offer = get_latest_data(
            attribution_model_result_offer, in_progress_booking_id, campaign_duration
        )
        target_model_result_brand = get_latest_data(
            attribution_model_result_brand, in_progress_booking_id, campaign_duration
        )
        target_model_result_aisle = get_latest_data(
            attribution_model_result_aisle, in_progress_booking_id, campaign_duration
        )
        target_reach_engagement = get_latest_data(reach_engagement, in_progress_booking_id)
        target_unified_campaign = get_latest_data(unified_campaign, in_progress_booking_id)

        # Process the in-progress booking ID for offer-level data.
        result_offer = process_booking_ids(
            target_baseline_offer,
            target_unified_campaign,
            target_baseline_offer,
            target_reach_engagement,
            target_model_result_offer,
            target_pre_requisite_offer,
            untargeted_channels,
        )
        combined_results.extend(result_offer)  # Add the processed results to the combined list.

        # Process the in-progress booking ID for brand-level data.
        result_brand = process_booking_ids(
            target_baseline_brand,
            target_unified_campaign,
            target_baseline_offer,
            target_reach_engagement,
            target_model_result_brand,
            target_pre_requisite_brand,
            untargeted_channels,
        )
        combined_results.extend(result_brand)  # Add the processed results to the combined list.

        # Process the in-progress booking ID for aisle-level data.
        result_aisle = process_booking_ids(
            target_baseline_aisle,
            target_unified_campaign,
            target_baseline_offer,
            target_reach_engagement,
            target_model_result_aisle,
            target_pre_requisite_aisle,
            untargeted_channels,
        )
        combined_results.extend(result_aisle)  # Add the processed results to the combined list.

        # Combine all processed results into a single DataFrame.
        if combined_results:
            measurement_campaign_reporting = reduce(lambda df1, df2: df1.union(df2), combined_results)
        else:
            measurement_campaign_reporting = reporting_data_empty_df  # Use the empty DataFrame if no results exist.

        # Add the job run ID to the final DataFrame for tracking purposes.
        measurement_campaign_reporting = measurement_campaign_reporting.with_column(
            "JOB_RUN_ID", lit(invocation_id)
        )

        # Add a timestamp to the final DataFrame to record when the data was processed.
        measurement_campaign_reporting = (
            measurement_campaign_reporting.with_column("LOAD_TS", current_timestamp())
        ).select(*column_seq)  # Ensure the column order matches the reporting table.

    except Exception as e:
        # Handle any errors that occur during processing by logging them for debugging purposes.
        error_type = type(e).__name__
        error_message = str(e)
        error_trace = traceback.format_exc()
        log_process_helper(session, error_message, error_trace, error_type, "measurement_campaign_reporting", "MTA", "Failed", in_progress_booking_id, campaign_duration, invocation_id)
        raise  # Re-raise the exception to stop execution.

    # Return the final processed DataFrame for reporting.
    return measurement_campaign_reporting
