{#
/*********************************************************************************************************************************************
* Objective - This script is used to call instore specific touchpoint and transaction data macro to get the customer data for instore campaigns.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream:  MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: CUSTOMER_DATA_COLLECTION
*
* This script will return transaction and touchpoint data for instore campaigns.

* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{# {{ log("Running main transaction data ", info=True ) }} #}

{{
    config(
        materialized='incremental',
		transient=False,
        incremental_strategy= 'append',
        pre_hook = "alter session set statement_timeout_in_seconds = 10800;",
        name = 'instore_customer_data',
        unique_key=['booking_id','transaction_key','item_cd','loyalty_id','channel_name','subchannel_name','product_type','event_ts','load_ts']
    )
}}

{% if dbt_unit_testing.running_unit_test() %}
     {# /* Use the mock macro during unit testing, DBT runs them separate to
    the main script so we have to mock them for the unit test to work correctly */ #}
    {% set instore_channel_list = mock_get_campaign_data_test() %}
{% else %}
    -- Use the real macros during normal runs
    {% set instore_channel_list = get_campaign_list('In-store') %}

{% endif %}

{#  /* getting list of targetted instore campaigns from measurement campaign execution */#}


{#  /*inserting output of instore transaction and touchpoint macro to instore customer data */ #}
{% if instore_channel_list | length() > 0 %}


{# /* Loop through the instore_channel_list, which contains a list of instore campaigns,
and generates SQL queries for retrieving touchpoint
data for each campaign using the get_instore_touchpoint_data() macro.
If there are multiple campaigns, it uses the UNION operator
to combine the results into a single dataset.
This ensures the final output includes touchpoint data for all the campaigns in the list */#}
select
    loyalty_id::varchar(1000) as loyalty_id
    , coalesce(transaction_key::varchar(1000), 'NA') as transaction_key
    , event_dt::date as event_dt
    , event_ts::timestamp_ntz(9) as event_ts
    , marketing_type::varchar(1000) as marketing_type
    , channel_name::varchar(1000) as channel_name
    , subchannel_name::varchar(1000) as subchannel_name
    , campaign_name::varchar(1000) as campaign_name
    , campaign_id::varchar(1000) as campaign_id
    , event_name::varchar(1000) as event_name
    , booking_id::varchar(1000) as booking_id
    , current_timestamp::timestamp_ntz(9) as load_ts
    , coalesce(item_cd::number(18, 0), 0)  as item_cd
    , coalesce(product_type::varchar(1000), 'NA') as product_type
    , coalesce(unique_brand_name::varchar(1000), 'NA') as unique_brand_name
    , coalesce(net_sales_amt::number(30, 4), 0) as net_sales_amt
    , coalesce(units_qty::number(30, 4), 0) as units_qty
    , '{{ invocation_id }}'::varchar(36) as job_run_id
from (

{% for row in instore_channel_list %}
   ( {{ get_instore_customer_data() }} )

   {% if not loop.last %}
        union
    {% endif %}

{% endfor %}

)

{# /* Returns a default or bypass query to handle the absence of campaigns,
ensuring the script can still execute without errors. */#}
{% else %}

    {{ log("There is no instore campaign available to be run for measurement analysis ",info=True) }} --noqa
    {{ get_bypass_channel_customer_query() }} --noqa

{% endif %}
