{#
/*********************************************************************************************************************************************
* Objective - This script is used to call all channel specific touchpoint and transaction data macro to get the customer data for all channels.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream:  MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: CUSTOMER_DATA_COLLECTION
*
* This script will return transaction and touchpoint data for dv360 campaigns.

* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{# {{ log("Running main transaction data ", info=True ) }} #}

{#
        /**********************
        1. Truncating chanel_customer_data table before inserting new records
        2. We are running automated validation macro to check the data quality of the customer_data collection table.
        3. Failure of the validation macro will stop the pipeline and send an alert to the team.
        4. In the pre-hook, we are setting the session timeout to 3 hours to avoid timeout issues during the execution of the model.
        5. Using noqa to avoid dbt linting errors for the union all statements.
        ***********************/
        #}

{{
    config(
        materialized='incremental',
		transient=False,
        incremental_strategy= 'append',
        post_hook=[
            "{{ truncate_channel_customer_data_table() }}",
            "{{ validation_macro_run('customer_data_collection') }}"
        ],
        pre_hook = "alter session set statement_timeout_in_seconds = 10800;",
        name = 'customer_data_collection',
        unique_key=['booking_id','transaction_key','item_cd','loyalty_id','channel_name','subchannel_name','product_type','event_ts']
    )
}}


-- depends on {{ ref ('measurement_campaign_execution') }}

{# /*inserting output of all channel specific transaction and touchpoint intermediate
tables to  customer data collection */#}
select distinct
    loyalty_id
    , transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz(9) as load_ts
    , item_cd
    , product_type
    , unique_brand_name
    , net_sales_amt
    , units_qty
    , '{{ invocation_id }}' as job_run_id
from
    (
        ( {{ get_channel_customer_data_columns() }} from {{ ref ('coupon_at_till_customer_data') }} ) --noqa

            union all --noqa
    
        ( {{ get_channel_customer_data_columns() }} from {{ ref ('magazine_customer_data') }} ) --noqa

            union all --noqa
    
        ( {{ get_channel_customer_data_columns() }} from {{  ref ('ecoupon_customer_data') }} ) --noqa

            union all --noqa

        ( {{ get_channel_customer_data_columns() }} from {{ ref ('meta_customer_data') }} ) --noqa

            union all --noqa
    
        ( {{ get_channel_customer_data_columns() }} from {{ ref ('citrus_customer_data') }} ) --noqa

            union all --noqa
   
        ( {{ get_channel_customer_data_columns() }} from {{ ref ('dv360_customer_data') }} ) --noqa

            union all --noqa

        ( {{ get_channel_customer_data_columns() }} from {{ ref ('youtube_customer_data') }} ) --noqa

            union all --noqa

        ( {{ get_channel_customer_data_columns() }} from {{ ref ('instore_customer_data') }} ) --noqa
    
    )
