{#
/*********************************************************************************************************************************************
* Objective - The objective of this script is to create regression variables and classify user journeys (as "Direct" or "Non-direct") by
calculating total touchpoints from user journey brand data. It processes campaign data, cleans and transforms regression variables and
prepares a dataset for machine learning models to analyze customer behavior and marketing attribution.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/852498406/ADS+-+Attribution+Pre-requisites
* Upstream: USER_JOURNEY_BRAND, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: MTA_ATTRIBUTION_MODEL_RESULT_BRAND
*
* This script will return create regression variable and type of user journey by calculating total touchpoint from user journey brand table.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}
{% set columns_to_concat = var('regression_variable_list') %}
{# {{ log("Running Attribution-Pre-Requisite Brand Model", info=True ) }} #}


{{
    config(
        materialized='incremental',
		transient=False,
        incremental_strategy= 'append',
        name = 'attribution_pre_requisite_brand',
        post_hook = "{{ validation_macro_run('attribution_pre_requisite_brand') }}",
        unique_key=['userjourney_id', 'regression_variable', 'transaction_key','event_ts', 'campaign_duration']
    )
}}

{# /* getting the in progress booking id as we will run this script for in progress booking id only*/ #}
with campaign_booking_id as (
    select distinct
        booking_id
        , campaign_duration
    from {{ ref('measurement_campaign_execution') }}
    where job_status = 'In-progress'
)

{# /*getting latest inserstion time of in progress booking id */ #}
, get_max_load_ts as (
    select max(load_ts) as load_ts
    from {{ ref('user_journey_brand') }}
    where booking_id in (select booking_id from campaign_booking_id)
)

{#
/**********************
1. Creating the column regression variable which is concatenation of configured regression variable list
2. Removing non alpha numeric character except for space, hyphen and comma from the regression variable.
3. The regreesion variable will be used for flatten path to create feature while
running the machine learning model script.
***********************/
#}
, user_journey_pre_clean as (
    select
        ujb.loyalty_id
        , ujb.marketing_type
        , ujb.channel_name
        , ujb.subchannel_name
        , ujb.event_ts
        , ujb.event_name
        , ujb.net_sales_amt
        , ujb.transaction_key
        , ujb.campaign_id
        , ujb.booking_id
        , ujb.userjourney_id
        , ujb.position
        , ujb.isconversion
        , cbi.campaign_duration
        , {% for column in columns_to_concat %}
            {{ column }} {% if not loop.last %} || '_' || {% endif %}
        {% endfor %} as regvarlist
    from {{ ref('user_journey_brand') }} as ujb
    inner join campaign_booking_id as cbi
        on
            ujb.booking_id = cbi.booking_id
            and ujb.campaign_duration = cbi.campaign_duration
    where ujb.load_ts = (select load_ts from get_max_load_ts)
)

{# /* removing non alpha numeric character execept for space,hypen and comma
to avoid any issue with model training script */ #}
, user_journey_regvar_clean as (
    select
        loyalty_id
        , marketing_type
        , channel_name
        , subchannel_name
        , event_ts
        , event_name
        , net_sales_amt
        , transaction_key
        , campaign_id
        , booking_id
        , userjourney_id
        , position
        , isconversion
        , campaign_duration
        , regexp_replace(
            replace(replace(
                replace(replace(regvarlist, ' ', 'SPC'), '-', 'HASH')
                , ',', 'COMMA'
            ), '|', 'PIPE'), '[^a-zA-Z0-9_]', ''
        ) as regvarlist
    from user_journey_pre_clean
)

{# /* calculating total touchpoints to classify the journey ad direct or non-direct */ #}
, user_journey_regression as (
    select
        loyalty_id
        , marketing_type
        , channel_name
        , subchannel_name
        , event_ts
        , event_name
        , net_sales_amt
        , transaction_key
        , campaign_id
        , booking_id
        , userjourney_id
        , position
        , isconversion
        , regvarlist
        , campaign_duration
        , sum(case when event_name = 'Touchpoint' then 1 else 0 end)
            over (partition by booking_id, userjourney_id, campaign_duration) as total_touchpoint
    from user_journey_regvar_clean
)

{# /* incase no of touchpoints is greater than 1 then it is non direct else direct */ #}
, attribution_pre_requisite_brand as (
    select
        ujr.loyalty_id
        , ujr.marketing_type
        , ujr.channel_name
        , coalesce(ujr.subchannel_name, 'NA') as subchannel_name
        , ujr.event_ts
        , ujr.event_name
        , ujr.net_sales_amt
        , 'Brand' as journey_type
        , case when ujr.total_touchpoint = 1 then 'Direct' else 'Non-direct' end as customer_journey_type
        , ujr.transaction_key
        , ujr.campaign_id
        , ujr.booking_id
        , ujr.userjourney_id
        , ujr.position
        , ujr.isconversion
        , ujr.regvarlist as regression_variable
        , ujr.campaign_duration
        , current_timestamp::timestamp_ntz as load_ts
        , '{{ invocation_id }}' as job_run_id
    from user_journey_regression as ujr
)

{#
/**********************
1. Persisting the final output of the model in the table attribution_pre_requisite_aisle
2. The table will be used as input for the machine learning model script.
3. Type casting the columns to the required data types.
***********************/
#}
select distinct
    loyalty_id::varchar(128) as loyalty_id
    , channel_name::varchar(18) as channel_name
    , subchannel_name::varchar(1000) as subchannel_name
    , event_ts::timestamp_ntz(9) as event_ts
    , event_name::varchar(20) as event_name
    , net_sales_amt::number(38, 4) as net_sales_amt
    , journey_type::varchar(5) as journey_type
    , transaction_key::varchar(250) as transaction_key
    , campaign_id::varchar(1000) as campaign_id
    , booking_id::varchar(100) as booking_id
    , position::varchar(9) as position
    , campaign_duration::varchar(6) as campaign_duration
    , load_ts::timestamp_ntz(9) as load_ts
    , job_run_id::varchar(36) as job_run_id
    , userjourney_id::varchar(1000) as userjourney_id
    , regression_variable::varchar(1000) as regression_variable
    , customer_journey_type::varchar(100) as customer_journey_type
    , isconversion::number(1, 0) as isconversion
    , marketing_type::varchar(100) as marketing_type
from attribution_pre_requisite_brand
