{#/**************************************************************************
* Objective: 
* The decay rate for impressions is a critical concept that pertains to the speed at which 
* the impact or influence of impressions changes as time progresses. This decay rate is essential
* for understanding how impressions can affect consumer behavior and decision-making over the duration of a marketing campaign.
* This script calculates the "campaign decay rate" for Meta, DV360, and YouTube campaigns. 
* The decay rate measures the percentage of impressions delivered over time for campaigns 
* that are currently in progress. This helps in understanding the performance and pacing 
* of campaigns across different platforms.
* 
* Confluence Link: https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657261685/Decay+Rate
*
* Upstream: 
*  MEASUREMENT_CAMPAIGN_EXECUTION,
*  DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK,
*  DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT, 
*  DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK,
*  MEDIA_REPORT

* Downstream: 
*  ATTRIBUTION_MODEL_RESULTS_OFFER

* Business Context:
* By applying this decay rate, marketers can assign a more accurate weight to the impressions that
* occur during the active period of a campaign. This approach ensures that the impressions that are
* generated while the campaign is running are given the appropriate level of significance. Moreover,
* it effectively changes the relevance of impressions that are repeated, thereby allowing for a more
* precise analysis of the campaign's performance and its overall effectiveness in reaching and influencing the target audience.

* Owner : Aditya Mohantu
* Date : 12/10/2024
*
* Change Log 
* ----------------------------
1. Initial Version : Finding offsite impression percentage for Meta, DV360, and YouTube
******************************************************************************/#}

{# {{ log("Running campaign_decay_rate", info=True ) }} #}

{{
    config(
        materialized='incremental',
        transient=False,
        incremental_strategy='append',
        post_hook="{{ validation_macro_run('campaign_decay_rate') }}",
        name='campaign_decay_rate',
        unique_key=['channel_name', 'job_bag_number', 'reporting_dt', 'job_run_id']
    )
}}

-- Identify campaigns that are currently in progress and have a "During" duration.
-- Focus on active campaigns to ensure the analysis is relevant and actionable.
with measurement_data as (
    select distinct
        job_bag_number
        , channel_name
        , campaign_start_dt
        , campaign_end_dt
    from {{ ref('measurement_campaign_execution') }}
    where
        channel_name in ('Meta', 'DV360', 'YouTube')
        and job_status = 'In-progress'
        and campaign_duration = 'During'
)

-- Generate a sequence of dates for each campaign's duration.
-- Create a daily timeline for each campaign to track impressions over time.
, date_explosion as (
    select
        md.job_bag_number
        , md.channel_name
        , md.campaign_start_dt
        , md.campaign_end_dt
        , dateadd('day', row_number()
            over (partition by md.job_bag_number order by seq4())
        - 1, md.campaign_start_dt) as exploded_date
    from measurement_data as md
    , table(generator(rowcount => 150))
)

-- Create a raw span of campaign dates for each job bag number.
-- Establish a baseline timeline for each campaign.
, campaign_span_raw as (
    select
        job_bag_number
        , channel_name
        , exploded_date
    from date_explosion
    order by job_bag_number, exploded_date
)

-- We get the impression data on daily level so we are filtering the campaign span.
-- This ensures that we only include dates that fall within the campaign's active period.
-- Ensure the timeline aligns with the actual campaign duration.
, get_campaign_span_offsite as (
    select
        md.job_bag_number
        , md.channel_name
        , csr.exploded_date
    from measurement_data as md
    inner join campaign_span_raw as csr
        on
            md.job_bag_number = csr.job_bag_number
            and
            md.channel_name = csr.channel_name
    where csr.exploded_date <= md.campaign_end_dt
)

-- Retrieve the latest record for each campaign from the DMFBIN table for channel Meta.
-- Use the most recent data to ensure accuracy in impression calculations.
, get_max_dmfbin as (
    select
        digital_trading_campaign_nk1
        , reporting_start_dt
        , reporting_end_dt
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK') }}
    where reporting_start_dt = reporting_end_dt
    group by digital_trading_campaign_nk1, reporting_start_dt, reporting_end_dt
)

-- Filter DMFBIN data to include only the latest records for each campaign for Meta
-- Ensure only the most up-to-date data is used for analysis.
, get_dmfbin_filtered as (
    select
        digital_trading_campaign_nk1
        , reporting_start_dt
        , reporting_end_dt
        , record_arrival_ts
        , measures
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_INSIGHT_DMFBIN_LINK') }}
    where
        (digital_trading_campaign_nk1, reporting_start_dt, reporting_end_dt, record_arrival_ts)
        in (
            select distinct
                digital_trading_campaign_nk1
                , reporting_start_dt
                , reporting_end_dt
                , record_arrival_ts
            from get_max_dmfbin
        )
        and reporting_start_dt = reporting_end_dt
)

-- Retrieve the latest record for each job bag and campaign from the DMFBCA table.
-- Link job bags to campaigns for accurate impression mapping.
, get_max_dtcds as (
    select
        job_bag_id
        , digital_trading_campaign_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT') }}
    group by job_bag_id, digital_trading_campaign_nk1
)

-- Filter DMFBCA data to include only the latest records for each job bag and campaign for Meta.
-- Ensure data consistency and accuracy in campaign mapping.
, get_dtcds_filtered as (
    select
        job_bag_id
        , digital_trading_campaign_nk1
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT') }}
    where
        (job_bag_id, digital_trading_campaign_nk1, record_arrival_ts)
        in (
            select distinct
                job_bag_id
                , digital_trading_campaign_nk1
                , record_arrival_ts
            from get_max_dtcds
        )
)

-- Retrieve the latest record for each campaign and channel from the DMFBCA_LINK table for Meta
-- Map campaigns to their respective channels for accurate attribution.
, get_max_dtccdl as (
    select
        digital_trading_campaign_nk1
        , digital_trading_campaign_channel_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK') }}
    group by digital_trading_campaign_nk1, digital_trading_campaign_channel_nk1
)

-- Filter DMFBCA_LINK data to include only the latest records for each campaign and channel.
-- Ensure accurate mapping of campaigns to channels.
, get_dtccdl_filtered as (
    select
        digital_trading_campaign_nk1
        , digital_trading_campaign_channel_nk1
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_CHANNEL_DMFBCA_LINK') }}
    where
        (digital_trading_campaign_nk1, digital_trading_campaign_channel_nk1, record_arrival_ts)
        in (
            select distinct
                digital_trading_campaign_nk1
                , digital_trading_campaign_channel_nk1
                , record_arrival_ts
            from get_max_dtccdl
        )
)

-- We get the impression data on daily level so we are filtering the campaign span.
-- This ensures that we only include dates that fall within the campaign's active period.
-- Extract Meta impressions data by joining filtered datasets and measurement data.
-- Calculate impressions for Meta campaigns to track their performance.
, get_meta_impressions as (
    select distinct
        dtcds.job_bag_id
        , gdf.reporting_start_dt
        , gdf.reporting_end_dt
        , gdf.record_arrival_ts
        , gdf.digital_trading_campaign_nk1
        , md.channel_name
        , json_extract_path_text(gdf.measures, 'summary.impressions') as impressions
    from get_dtcds_filtered as dtcds
    inner join get_dtccdl_filtered as dtccdl
        on dtcds.digital_trading_campaign_nk1 = dtccdl.digital_trading_campaign_nk1
    inner join get_dmfbin_filtered as gdf
        on dtccdl.digital_trading_campaign_channel_nk1 = gdf.digital_trading_campaign_nk1
    inner join measurement_data as md
        on dtcds.job_bag_id = md.job_bag_number
    where
        gdf.reporting_start_dt >= md.campaign_start_dt
        and gdf.reporting_end_dt <= md.campaign_end_dt
        and gdf.reporting_end_dt = gdf.reporting_start_dt
    order by gdf.reporting_start_dt
)

-- Map Meta impressions to the campaign span dates.
-- Align impressions data with the campaign timeline for Meta.
, get_span_impression as (
    select distinct
        gcso.job_bag_number
        , gcso.exploded_date as reporting_dt
        , coalesce(gmi.impressions, 0) as impressions
    from get_campaign_span_offsite as gcso
    left join get_meta_impressions as gmi
        on
            gcso.job_bag_number = gmi.job_bag_id
            and gcso.channel_name = gmi.channel_name
            and gcso.exploded_date = gmi.reporting_start_dt
    where gcso.channel_name = 'Meta'
)

-- Calculate cumulative impressions for Meta campaigns.
-- Track the total impressions delivered over time for Meta campaigns.
, get_cumulative_meta as (
    select distinct
        'Offsite' as marketing_type
        , 'Meta' as channel_name
        , job_bag_number
        , reporting_dt as campaign_date
        , impressions
        , sum(impressions) over (partition by job_bag_number order by reporting_dt) as cumulative_impressions
    from get_span_impression
)

-- Retrieve the maximum cumulative impressions for each Meta campaign.
-- Identify the total impressions delivered for each Meta campaign.
, get_cumulative_meta_max as (
    select
        job_bag_number
        , max(cumulative_impressions) as max_cnt
    from get_cumulative_meta
    group by job_bag_number
)

-- Calculate the offsite impressions percentage for Meta campaigns.
-- Offsite impressions are calculated as a percentage of cumulative impressions / total impressions.
-- Determine the percentage of impressions delivered over time for Meta.
, get_meta_offsite_impressions as (
    select
        gcm.*
        , case
            when gcm.cumulative_impressions = 0 then 0.001
            else gcm.cumulative_impressions / gcmm.max_cnt
        end as offsite_impressions
    from get_cumulative_meta as gcm
    inner join get_cumulative_meta_max as gcmm
        on gcm.job_bag_number = gcmm.job_bag_number
)

-- Extract DV360 and YouTube impressions data from the MEDIA_REPORT table.
-- Calculate impressions for DV360 and YouTube campaigns to track their performance.
, get_dvyt_impression as (
    select
        mr.jobbag_id as job_bag_number
        , mr.campaign_date
        , mr.impressions
        , md.channel_name
    from {{ source('DV360', 'MEDIA_REPORT') }} as mr
    inner join measurement_data as md
        on mr.jobbag_id = md.job_bag_number
    where
        mr.campaign_date >= md.campaign_start_dt
        and mr.campaign_date <= md.campaign_end_dt
    order by mr.jobbag_id, mr.campaign_date
)

-- Map DV360 and YouTube impressions to the campaign span dates.
-- Align impressions data with the campaign timeline for DV360 and YouTube.
, get_dvyt_span_impressions as (
    select
        gcso.job_bag_number
        , gdi.campaign_date
        , gcso.channel_name
        , coalesce(gdi.impressions, 0) as impressions
    from get_campaign_span_offsite as gcso
    left join get_dvyt_impression as gdi
        on
            gcso.job_bag_number = gdi.job_bag_number
            and gcso.channel_name = gdi.channel_name
            and gcso.exploded_date = gdi.campaign_date
    where gcso.channel_name in ('DV360', 'YouTube')
)

-- Aggregate total impressions for DV360 and YouTube campaigns.
-- Summarize impressions data for DV360 and YouTube campaigns.
, get_total_impression_dvyt as (
    select
        channel_name
        , job_bag_number
        , campaign_date
        , sum(impressions) as impressions
    from get_dvyt_span_impressions
    group by channel_name, job_bag_number, campaign_date
)

-- Calculate cumulative impressions for DV360 and YouTube campaigns.
-- Track the total impressions delivered over time for DV360 and YouTube campaigns.
, get_dvyt_cumulative_impressions as (
    select
        'Offsite' as marketing_type
        , channel_name
        , job_bag_number
        , campaign_date
        , impressions
        , sum(impressions) over (partition by job_bag_number order by campaign_date)
            as cumulative_impressions
    from get_total_impression_dvyt
    order by campaign_date
)

-- Retrieve the maximum cumulative impressions for DV360 and YouTube campaigns.
-- Identify the total impressions delivered for each DV360 and YouTube campaign.
, get_cumulative_dv360_max as (
    select
        job_bag_number
        , max(cumulative_impressions) as max_cumulative_impression
    from get_dvyt_cumulative_impressions
    group by job_bag_number
)

-- Calculate the offsite impressions percentage for DV360 and YouTube campaigns.
-- Offsite impressions are calculated as a percentage of cumulative impressions / total impressions.
-- Determine the percentage of impressions delivered over time for DV360 and YouTube.
, get_dvyt_offsite_impressions as (
    select
        gdci.*
        , case
            when gdci.cumulative_impressions = 0 then 0.001
            else gdci.cumulative_impressions / gcdm.max_cumulative_impression
        end as offsite_impressions
    from get_dvyt_cumulative_impressions as gdci
    inner join get_cumulative_dv360_max as gcdm
        on gdci.job_bag_number = gcdm.job_bag_number
)

-- Combine offsite impressions data for Meta, DV360, and YouTube campaigns.
-- Create a unified dataset for all platforms to enable cross-platform analysis.
, get_total_offsite_impressions as (
    select * from get_meta_offsite_impressions
    union all
    select * from get_dvyt_offsite_impressions
)

-- Final table that calculates the campaign decay rate with all required metrics.
-- Provide a comprehensive view of campaign performance across platforms.
, campaign_decay_rate as (
    select distinct
        marketing_type
        , channel_name
        , job_bag_number
        , campaign_date as reporting_dt
        , to_number(impressions) as impressions_cnt
        , cumulative_impressions::integer as cumulative_impressions_cnt
        , offsite_impressions as offsite_impressions_pct
        , current_timestamp::timestamp_ntz as load_ts
        , '{{ invocation_id }}' as job_run_id
    from get_total_offsite_impressions
    order by channel_name, job_bag_number, reporting_dt
)

-- Select the final output from the campaign_decay_rate table.
-- Deliver the final dataset for reporting and decision-making.
select * from campaign_decay_rate
