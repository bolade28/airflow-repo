{#
/*********************************************************************************************************************************************
* Objective - The objective of this script is to retrieve and process transaction and touchpoint data for DV360 and YouTube channels,
linking targeted audience data with campaign-related transactions. It consolidates customer interactions, sales data, and audience targeting
information to build a unified dataset for analyzing campaign performance.
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: DV360 customer data
*
* This script will return transaction and touchpoint data for DV360 and Youtube channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{# /*This macro returns the  dv360 and youtube data query according to the campaign placement/subchannel 
to get the customer data touchpoints*/#}
{% macro get_dv_touchpoint_data(channel) %}

    {% set campaignData = get_campaign_channel_specific_data(channel) %}
    {% set campaignName =  campaignData[0] %}
    {% set channel =  campaignData[1] %}
    {% set startDate =  campaignData[2] %}
    {% set endDate =  campaignData[3] %}
    {% set campaignid =  campaignData[4] %}
    {% set subchannel =  campaignData[5] %}
    {% set bookingId =  campaignData[6] %}
    {% set campaignDuration =  campaignData[7] %}
    {% set job_bag_id = campaignData[8] %}
    {% set marketing_type = campaignData[9] %}

    {{ log("Campaign data customer : "~brand~ " "~campaignid~" "~job_bag_id~" duration : "~campaignDuration, info=True ) }}

    {% set dv_audience_query = get_dv_audience_data_query(channel, campaignid) %}

    {% set dv_query %}
        
            {{ dv_audience_query }}

        {#
        /**********************
        1. Getting the target audience data from the audience group table
        2. Joining the audience data with the audience snapshot table to get the loyalty ids targeted.
        ***********************/
        #}
        , get_target_audience as (
            select distinct
                asd.loyalty_id
                , aag.job_bag_id
            from ab_audience_group as aag
            inner join {{ source('AB','AUDIENCE_SNAPSHOT_DEDUPED') }} as asd
                on aag.audience_id = asd.audience_id
        )

        {#
        /**********************
        1. Getting the max load timestamp from the campaign product type table
        2. This is used to get the latest records for a given campaign id, channel name and subchannel name.
        3. The load timestamp is used to filter the records in the campaign product type table.
        ***********************/
        #}
        , max_load_ts as (
            select
                max(load_ts) as load_ts
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
            where
                campaign_id = '{{ campaignid }}'
                and channel_name = '{{ channel }}'
                and subchannel_name = '{{ subchannel }}'
        )

        {# /*getting targetted skus for offer,brand,aisle. This cte is created to reduce the fetch time from campaign product type table */ #}
        , get_targeted_skus as (
            select distinct
                product_type
                , unique_brand_name
                , item_cd
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
            where
                campaign_id = '{{ campaignid }}'
                and channel_name = '{{ channel }}'
                and subchannel_name = '{{ subchannel }}'
                and load_ts = (select load_ts from max_load_ts)
    
        )

        {# /* getting relevant details from fact_sale_transaction basket. This cte is created to reduce read time from transaction_basket
        table as it is reference multiple time. */ #}
        , get_fact_sale_transaction_basket as (
            select
                transaction_end_ts
                , nectar_card_num_hash
                , transaction_id
                , transaction_dt
                , sales_origination_channel_cd
            from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
            where
                nectar_card_num_hash is not null
                and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and sales_origination_channel_cd in (
                    select all_codes.value
                    from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
                )
        )

        {# /* getting relevant details from fact_sale_transaction_item. This cte is created to reduce read time from transaction_item table
        as it is reference multiple time. */ #}
        , get_fact_sale_transaction_item as (
            select
                transaction_id
                , transaction_dt
                , item_cd
                , net_retail_sales_amt
                , item_qty
                , item_sequence_num
                , store_cd
            from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
            where 
                transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and net_retail_sales_amt > 0   
        )

        {#
        /**********************
        1. Getting the transaction data from the fact_sale_transaction_basket and fact_sale_transaction_item tables
        2. Applying sales origination channel codes filters to find the channel name.
        3. Joining the get_target_audience cte to get the audience name and loyalty id. Audience name will be used as subchannel
        4. Joining the get_targeted_skus cte to get the product type and unique brand name.
        5. Joining the get_fact_sale_transaction_item cte to get the transaction id, transaction date, item code, net retail sales amount, item quantity and item sequence number.
        6. Joining the get_fact_sale_transaction_basket cte to get the transaction end timestamp, nectar card number hash, transaction id and transaction date.
        7. Applying filters to get the transaction data for the given date range and sales origination channel codes.
        ***********************/
        #}    
        , get_transaction_data_distinct as (
            select distinct
                gfstb.nectar_card_num_hash as loyalty_id
                , gfsti.transaction_id as transaction_key
                , gfsti.transaction_dt as event_date
                , gfsti.item_cd
                , gfstb.transaction_end_ts as event_time
                , 'NA' as marketing_type
                , case when
                    gfstb.sales_origination_channel_cd in (
                        select instore_codes.value
                        from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
                    )
                    then 'In-store'
                else 'Online' end as channel
                , gta.audience_name
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , 'Purchase Transaction' as event_name
                , '{{ bookingId }}' as booking_id
                , gts.product_type
                , gts.unique_brand_name
                , gfsti.net_retail_sales_amt
                , gfsti.item_qty
                , gfsti.item_sequence_num
            from get_fact_sale_transaction_basket as gfstb
            inner join get_target_audience as gta
                on gfstb.nectar_card_num_hash = gta.loyalty_id
            inner join get_fact_sale_transaction_item as gfsti
                on gfstb.transaction_id = gfsti.transaction_id
            inner join get_targeted_skus as gts
                on gts.item_cd = gfsti.item_cd
            where
                gfsti.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and gfstb.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and gfsti.net_retail_sales_amt > 0
                and gfstb.nectar_card_num_hash is not null
                and gfstb.sales_origination_channel_cd in (
                    select sales_org_codes.value
                    from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as sales_org_codes
                )

        )

        {# /* Getting total sales amount and units for each loyalty id, transaction key, item code, unique brand name, 
        marketing type, channel, audience name, campaign name, campaign id, event name and booking id */ #}
        , get_transaction_data as (
            select
                loyalty_id
                , event_date
                , event_time
                , transaction_key
                , item_cd
                , unique_brand_name
                , marketing_type
                , channel
                , audience_name
                , campaign_name
                , campaign_id
                , event_name
                , booking_id
                , product_type
                , sum(net_retail_sales_amt) as net_targetted_sales
                , sum(item_qty) as units
            from get_transaction_data_distinct
            group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
        )

        {#
        /**********************
        1. Adding touchpoint for loyalty ids who bought targetted skus
        2. Event_date for touchpoints is set to campaign start date as it is the date when the touchpoint is created.
        ***********************/
        #}
        , create_txn_touchpoint_data as (
            select distinct
                loyalty_id
                , transaction_key
                , '{{ startDate }}' as event_date
                , to_timestamp('{{ startDate }}' || ' 00:00:00') as event_time
                , '{{ marketing_type }}' as marketing_type
                , '{{ channel }}' as channel
                , '{{ subchannel }}' as subchannel
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , 'Touchpoint' as event_name
                , '{{ bookingId }}' as booking_id
            from get_transaction_data
        )

        {#
        /**********************
        1. The non_transaction_touchpoint is getting the touchpoint data for loyalty ids who did not buy targetted skus
        2. The event_date for touchpoints is set to campaign start date as it is the date when the touchpoint is created.
        ***********************/
        #}
        , non_transaction_touchpoint as (
            select distinct
                loyalty_id
                , '{{ startDate }}' as event_date
                , to_timestamp('{{ startDate }}' || ' 00:00:00') as event_time
                , '{{ marketing_type }}' as marketing_type
                , '{{ channel }}' as channel
                , '{{ subchannel }}' as subchannel
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , 'Touchpoint' as event_name
                , '{{ bookingId }}' as booking_id
            from get_target_audience
            where
                loyalty_id not in
                (
                    select distinct loyalty_id
                    from create_txn_touchpoint_data
                )
        )

        {#
        /**********************
        1. Getting transaction and touchpoint data for all the targeted loyalty_ids
        2. For touchpoints item_cd, product_type, unique_brand_name, net_sales_amt and units_qty are set to null as these are not relevant for touchpoints.
        3. For non conversion transaction is set to null as no relevant transaction was made.
        ***********************/
        #}
        , dv_data_collection as (
            select
                loyalty_id
                , transaction_key
                , event_date as event_dt
                , event_time as event_ts
                , marketing_type
                , channel as channel_name
                , 'TXN' as subchannel_name
                , campaign_name
                , campaign_id
                , event_name
                , booking_id
                , item_cd
                , product_type
                , unique_brand_name
                , net_targetted_sales as net_sales_amt
                , units as units_qty
            from get_transaction_data
            union all
            select
                loyalty_id
                , transaction_key
                , event_date as event_dt
                , event_time as event_ts
                , marketing_type
                , channel as channel_name
                , subchannel as subchannel_name
                , campaign_name
                , campaign_id
                , event_name
                , booking_id
                , null as item_cd
                , null as product_type
                , null as unique_brand_name
                , null as net_sales_amt
                , null as units_qty
            from create_txn_touchpoint_data
            union all
            select
                loyalty_id
                , null as transaction_key
                , event_date as event_dt
                , event_time as event_ts
                , marketing_type
                , channel as channel_name
                , subchannel as subchannel_name
                , campaign_name
                , campaign_id
                , event_name
                , booking_id
                , null as item_cd
                , null as product_type
                , null as unique_brand_name
                , null as net_sales_amt
                , null as units_qty
            from non_transaction_touchpoint

        )

        {#
        /**********************
        1. As touchpoints might contain null values we are using the coalesce function to replace null values with 'NA' or 0
        2. The load_ts is set to current timestamp and job_run_id is set to the invocation id
        3. This is a consolidated data collection for all the touchpoints and transactions.
        ***********************/
        #}
        select
            loyalty_id
            , coalesce(transaction_key, 'NA') as transaction_key
            , event_dt
            , event_ts
            , marketing_type
            , channel_name
            , subchannel_name
            , campaign_name
            , campaign_id
            , event_name
            , booking_id
            , current_timestamp::timestamp_ntz as load_ts
            , coalesce(item_cd, 0) as item_cd
            , coalesce(product_type, 'NA') as product_type
            , coalesce(unique_brand_name, 'NA') as unique_brand_name
            , coalesce(net_sales_amt, 0) as net_sales_amt
            , coalesce(units_qty, 0) as units_qty
            , '{{ invocation_id }}' as job_run_id
        from dv_data_collection


    {% endset %}
    {{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

    {{ log("dv_query : "~dv_query, info=True ) }}

    {% do return(dv_query) %}
   

{% endmacro %}

{# /*This macro returns the dv audience data query to get targetted loyalty ids */#}
{% macro get_dv_audience_data_query(channel, campaignid) %}

    {{ log("In get_dv_audience_data_query", info=True ) }}

    
    {% set yt_query %}
    {#
        /**************************************************************************
        1. Here we are getting the audience data from the audience group table for a given job_bag_id
        2. We are getting the audience id and name from the audience_data column
        3. We are getting the max record arrival time for the audience group table
        4. We are also getting the audience id and name from the modelled audience column.
        5. Audience name can not contain the string 'do not use'. So we are applying necessary filters.
        6. We are using the union to get the audience data from both the audience_data and modelled_audience columns.
        ******************************************************************************/
    #}
    with ab_audience_group as (
            select
                dtagds.job_bag_id
                , json_extract_path_text(audience.value, '_id') as audience_id
                , max(dtagds.record_arrival_ts) as max_time
            from adw_prod.adw_rdv.digital_trading_audience_group_dmabag_sat as dtagds
            , lateral flatten(input => dtagds.audiences_data, outer => true) as audience
            where
                dtagds.job_bag_id = '{{ campaignid }}'
                and json_extract_path_text(audience.value, 'name') not ilike '%do not use%'
            group by 1, 2, 3
            union
            select
                dtagds.job_bag_id
                , json_extract_path_text(model_audience.value, '_id') as audience_id
                , json_extract_path_text(model_audience.value, 'name') as audience_name
                , max(dtagds.record_arrival_ts) as max_time
            from adw_prod.adw_rdv.digital_trading_audience_group_dmabag_sat as dtagds
            , lateral flatten(input => dtagds.modelled_audiences_data, outer => true) as model_audience
            where
                dtagds.job_bag_id = '{{ campaignid }}'
                and json_extract_path_text(model_audience.value, 'name') not ilike '%do not use%'
            group by 1, 2, 3
    )
        {% endset %}

    {% set dv360_query %}

        {#
            /**********************
            1. The dv_audience_query is getting campaign data from the audience group table for a given job_bag_id
            ***********************/
        #}
        with dv_campaign_data as (
            select *
            from
            adw_prod.adw_rdv.DIGITAL_TRADING_CAMPAIGN_DMDVIO_SAT
            where json_extract_path_text(dtp_input,'integrationDetails.jobBagId') = '{{ campaignid }}'
        )

        {#
            /**********************
            1. The dv_targetting_data is getting the audience data from the digital trading lineitem targeting table
            2. The audience data is in json format and we are extracting the audience id from it.
            3. The audience id is in the form of a json array and we are flattening it to get the individual audience ids.
            ***********************/
        #}
        , dv_targetting_data as (
            select 
                digital_trading_lineitem_nk1
                , json_extract_path_text(audience_list.value,'firstAndThirdPartyAudienceId') as aud_id
            from adw_prod.adw_rdv.DIGITAL_TRADING_LINEITEM_TARGETING_DMDVTA_SAT
            ,lateral flatten(input => AUDIENCE_LIST) as audience_list
        )

        {#
        /**********************
        1. The ab_audience_max is getting the max record arrival time for the audience group table
        2. We are doing this to get latest records for a given digital_trading_audience_group_nk1
        ***********************/
        #}
        , ab_audience_max as (
            select
                digital_trading_audience_group_nk1
                , max(record_arrival_ts) as record_arrival_ts
            from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT') }}
            where job_bag_id ilike '%nec%' or job_bag_id = null
            group by digital_trading_audience_group_nk1
)
        {#
        /**********************
        1. The ab_audience_latest is getting the latest records for a given digital_trading_audience_group_nk1
        ***********************/
        #}
        , ab_audience_latest as (
            select *
            from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT') }}
            where
                (digital_trading_audience_group_nk1, record_arrival_ts) in
            (select
                digital_trading_audience_group_nk1
                , record_arrival_ts
            from ab_audience_max
            )
)
        {#
        /**********************
        1. From the ab_audience_latest table we are getting docids_raw, audience_id and subchannel_name
        2. The docids_raw is in json format and we are extracting the audience id from it.
        3. The aud_id wil be used to join with DIGITAL_TRADING_AUDIENCE_CHANNEL_DMDVAU_LINK table in the later cte.
        4. The name of the audience is also extracted from the json data which will be later used in the touchpoint.
        ***********************/
        #}
        , ab_audience_data as (
            select distinct
                aal.job_bag_id
                , aal.digital_trading_audience_group_nk1
                , json_extract_path_text(audience_data.value, 'channels') as docids_raw
                , json_extract_path_text(audience_data.value, '_id') as aud_id
            from ab_audience_latest as aal
            , lateral flatten(input => aal.audiences_data) as audience_data
)
       
        {#
            /**********************
            1. The ab_modelled_audience is getting the modelled audience data from the ab_audience_latest table
            2. The modelled audience data is in json format and we are extracting the audience id from it.
            3. The audience id is in the form of a json array and we are flattening it to get the individual audience ids.
            ***********************/
        #}
        , ab_modelled_audience as (
            select distinct
                aal.job_bag_id
                , aal.digital_trading_audience_group_nk1
                , json_extract_path_text(modelled_audience.value, 'channels') as docids_raw
                , json_extract_path_text(modelled_audience.value, '_id') as aud_id
            from ab_audience_latest as aal
            , lateral flatten(input => aal.modelled_audiences_data) as modelled_audience
)
        {#
            /**********************
            1. The ab_audience_union is getting the audience data from the ab_audience_data and ab_modelled_audience tables
            ***********************/
        #}
        , ab_audience_union as (
            select * from ab_audience_data
                union
            select * from ab_modelled_audience
)
        {#
            /**********************
            1. The ab_audience_filtered is getting the audience data from the ab_audience_union table
            2. The audience data is in json format and we are extracting the audience id from it.
            3. The audience id is in the form of a json array and we are flattening it to get the individual audience ids.
            ***********************/
        #}
        , ab_audience_filtered as (
            select distinct
                aau.job_bag_id
                , aau.digital_trading_audience_group_nk1
                , aau.aud_id as audience_id
                , aau.subchannel_name
                , json_extract_path_text(docids.value, 'documentId') as docid
            from ab_audience_union as aau
            , lateral flatten(input => try_parse_json(aau.docids_raw)) as docids
            where aau.docids_raw != '[]'
)

        {#
        /**********************
        1. We are getting the audience data from the ab_audience_filtered table
        2. We are joining the audience data with the dv_campaign_data cte.
        3. The docid extracted in the previous steps is used to join with the dv_campaign_data table.
        ***********************/
        #}
        , ab_audience_group as (
            select
                abf.audience_id
                , abf.job_bag_id
            from dv_campaign_data as dcd
            inner join adw_prod.adw_rdv.DIGITAL_TRADING_LINEITEM_CHANNEL_DMDVLI_LINK as dtlcdl
                on dcd.digital_trading_campaign_nk1 = dtlcdl.digital_trading_campaign_nk1
            inner join dv_targetting_data as dtd
                on dtlcdl.digital_trading_lineitem_nk1= dtd.digital_trading_lineitem_nk1
            inner join adw_prod.adw_rdv.DIGITAL_TRADING_AUDIENCE_CHANNEL_DMDVAU_LINK as dtacdl
                on dtd.aud_id = dtacdl.digital_trading_audience_channel_nk1
            inner join ab_audience_filtered as abf
                on dtacdl.digital_trading_audience_nk1= abf.docid
        )
           
        {% endset %}

    {# /* Based on the channel given in the input, we will set the dv_audience_query to the appropriate query. */ #}
    {% if channel|lower == 'youtube' %}
        
        {% set dv_audience_query %}
            {{ yt_query }}
        {% endset %}
    
    {% elif channel|lower == 'dv360' %}
        {% set dv_audience_query %}
           {{ dv360_query }}
        {% endset %}
    
    {% else %}       
            {{ log("Wrong Channel in Unified Campaign", info=True ) }}
    {% endif %}
    
    {% do return(dv_audience_query) %}

{% endmacro%}