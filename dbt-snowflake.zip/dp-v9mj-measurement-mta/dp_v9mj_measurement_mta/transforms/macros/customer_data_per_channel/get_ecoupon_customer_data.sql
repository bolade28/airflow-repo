{#
/*********************************************************************************************************************************************
* Objective - This script retrieves transaction and touchpoint data for eCoupon campaigns, linking targeted customers to their
interactions and purchases.It processes and consolidates data to provide insights into customer engagement and campaign performance.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: CUSTOMER_DATA_COLLECTION
*
* This script will return transaction and touchpoint data for ecoupon channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{% macro get_ecoupon_customer_data() %}

    {% if dbt_unit_testing.running_unit_test() %}
    -- Use the mock macro during unit testing, DBT runs them separate to the main script so we have to mock them for the unit test to work correctly
        {% set campaignData = mock_get_campaign_list_ecoupon() %}
    {% else %}
    -- Use the real macros during normal runs
        {% set campaignData = get_campaign_channel_specific_data('eCoupons') %}
    {% endif %}

    {# /* getting campaign data from measurement_campaign_execution table for ecoupon channel */ #}
    
    {% set campaignName =  campaignData[0] %}
    {% set channel =  campaignData[1] %}
    {% set startDate =  campaignData[2] %}
    {% set endDate =  campaignData[3] %}
    {% set campaignid =  campaignData[4] %}
    {% set subchannel =  campaignData[5] %}
    {% set bookingId =  campaignData[6] %}
    {% set campaignDuration =  campaignData[7] %}
    {% set job_bag_id = campaignData[8] %}
    {% set marketing_type = campaignData[9] %}

{% set ecoupon_sql %}

{#
/**********************
1. Getting loyalty service campaign id for the given campaign id
2. Applying the necessary campaign_id filters to get the loyalty service campaign id.
3. We are using the loyalty service campaign id to get all the loyalty ids who are targeted for the ecoupon campaign.
***********************/
#}
with ecoupon_loyalty_service_data as (
    select dc.loyalty_service_campaign_id 
    from {{ source('I2CEVALS', 'OC_CAMPAIGN') }} as occ
    inner join {{ source('I2CEVALS', 'OC_CUSTOMER_SELECTION') }} as ocs
        on occ.campaign_id = ocs.campaign_id
    inner join {{ source('ADW_CUSTOMER_INTERACTIONS_PL', 'DIM_CAMPAIGN') }} as dc
        on dc.barcode = ocs.coupon_id
    where
        occ.campaign_id = '{{ campaignid }}'
        and ocs.status = {{ var('ecoupoun_targetted') }}
)

{#
/**********************
1. Getting event_utc_ts, loyalty_id and applied_state for the given campaign id
2. Event_utc_ts is the timestamp when the event was created.
3. Applied_state is the state of the event(Loaded, Created, Redeemed)
4. We will use the event_utc_ts while adding touchpoints.
***********************/
#}
, ecoupoun_loyalty_data as (
    select distinct 
	    fce.loyalty_id
         , fce.applied_state
         , fce.event_utc_ts
         , fce.online_order_num
    from ecoupon_loyalty_service_data as elsd
    inner join {{ source('ADW_CUSTOMER_INTERACTIONS_PL', 'FLF_CAMPAIGN_EVENT') }} as  fce
         on elsd.loyalty_service_campaign_id = fce.loyalty_service_campaign_id
         and year(fce.event_utc_ts) >= year(to_date('{{ startDate }}'))
)

{#
/**********************
1. Getting minimum event_utc_ts for every loyalty_id to avoid multiple touchpoints for the same loyalty_id.
***********************/
#}
, ecoupon_loaded_loyalty as (
    select
        loyalty_id
        , min(event_utc_ts) as event_utc_ts
    from ecoupoun_loyalty_data
    where lower(applied_state) in ('created', 'loaded')
    group by loyalty_id
)

{#  /*getting relevant details from fact_sale_transaction_item. This cte is created to reduce read time from transaction_item table
as it is reference multiple time. */ #}
, get_fact_sale_transaction_basket as (
    select
        transaction_end_ts
        , nectar_card_num_hash
        , transaction_id
        , transaction_dt
        , sales_origination_channel_cd
        , order_number
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
    where
        nectar_card_num_hash is not null
        and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#  /*getting relevant details from fact_sale_transaction_item. This cte is created to reduce read time from
transaction_item table as it is reference multiple time. */ #}
, get_fact_sale_transaction_item as (
    select
        transaction_id
        , transaction_dt
        , item_cd
        , net_retail_sales_amt
        , item_qty
        , item_sequence_num
        , store_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
    where 
        transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and net_retail_sales_amt > 0   
)

{# /*getting max load_ts for the campaign product type table. This cte is created to reduce read time from campaign product type table
 as it is reference multiple time. */ #}
, max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
)

{# /*getting targetted skus for offer,brand,aisle. This cte is created to reduce the fetch time from campaign product type
table for a particular campaign id and channel name. */ #}
, get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where campaign_id = '{{ campaignid }}'
    and channel_name = '{{ channel }}'
    and subchannel_name = '{{ subchannel }}'
    and load_ts = (select load_ts from max_load_ts)
    
)

{#
/**********************
1. The ecoupon_redeem_transaction cte is created to get the transaction details of the redeemed transactions.
2. Item_sequence_num is used as a unique identifier for the transaction,item_cd,event_date,event_time.
3. We are using the sales_origination_channel_cd only for online channels as ecoupons can be redeemed only online.
***********************/
#}
, get_ecoupon_redeem_transaction_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , 'NA' as marketing_type
        , 'Online' as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from ecoupoun_loyalty_data as eld
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on eld.loyalty_id = dcl.nectar_collector_card_num
    inner join get_fact_sale_transaction_basket as gfstb
        on
            gfstb.nectar_card_num_hash = dcl.nectar_collector_card_num
            and eld.online_order_num = gfstb.order_number
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    where
        lower(eld.applied_state) = 'redeemed'
        and gfstb.sales_origination_channel_cd in (
            select online_codes.value
            from
                table(
                    flatten(input => {{ var('sales_origination_online_codes') }}::array
                    )
                ) as online_codes
        )
)

{#
/**********************
1. The ecoupon_redeem_transaction cte is created to get the transaction details of the redeemed transactions.
2. It feteches the total net_retail_sales_amt and item_qty for every loyalty_id,event_date,event_time,transaction_key,item_cd,unique_brand_name,marketing_type,campaign_name,campaign_id,booking_id,product_type.
***********************/
#}
, ecoupon_redeem_transaction as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from get_ecoupon_redeem_transaction_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. The ecoupon_loaded_transaction cte is created to get the transaction details of the loaded transactions.
2. It fetches the total net_retail_sales_amt and item_qty for every loyalty_id,event_date,event_time,transaction_key,item_cd,unique_brand_name,marketing_type,campaign_name,campaign_id,booking_id,product_type.
3. Item_sequence_num is used to get the correct transaction amout as in the fact_sale_transaction_item table there are multiple records for the same transaction id,item_cd but item_sequence no is different.
4. We are using the sales_origination_channel_cd to get the channel name.
5. We are also removing those loyalty_ids which are already present in the ecoupon_redeem_transaction cte.
***********************/
#}
, get_ecoupon_loaded_transaction_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , 'NA' as marketing_type
        , case when gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
        ) then 'In-store'
        else 'Online' end as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.net_retail_sales_amt
        , gfsti.item_sequence_num
        , gfsti.item_qty
    from ecoupoun_loyalty_data as eld
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on eld.loyalty_id = dcl.nectar_collector_card_num
    inner join get_fact_sale_transaction_basket as gfstb
        on
            gfstb.nectar_card_num_hash = dcl.nectar_collector_card_num
            and eld.online_order_num = gfstb.order_number
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    where
        lower(eld.applied_state) in ('loaded', 'created')
        and gfstb.sales_origination_channel_cd in (
            select online_codes.value
            from
                table(
                    flatten(input => {{ var('sales_origination_all_codes') }}::array
                    )
                ) as online_codes
        )
        and dcl.nectar_collector_card_num not in (select distinct loyalty_id from ecoupon_redeem_transaction)
)

{#
/**********************
1. The ecoupon_loaded_transaction cte is created to get the transaction details of the loaded transactions.
2. It fetches the total net_retail_sales_amt and item_qty for every loyalty_id,event_date,event_time,transaction_key,item_cd,unique_brand_name,marketing_type,campaign_name,campaign_id,booking_id,product_type.
***********************/
#}
, ecoupon_loaded_transaction as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from get_ecoupon_loaded_transaction_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. The ecoupon_non_targetted_sku_touchpoint_data cte is created to get the touchpoint details of those customers who did not buy any targetted sku.
2. This means they have not redeemed or loaded the coupons for targeted skus and done any transaction. So we are considering only those loyalty ids who did not load or redeem any coupons.
***********************/
#}
, ecoupon_non_targeted_sku_touchpoint_data as (
    select distinct
        loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , date(event_utc_ts) as event_date
        , event_utc_ts as event_time
        , null as transaction_key
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from
        ecoupon_loaded_loyalty
    where
        loyalty_id
        not in
        (select distinct loyalty_id from ecoupon_redeem_transaction)
        and
        loyalty_id
        not in
        (select distinct loyalty_id from ecoupon_loaded_transaction)
)

{#
/**********************
1. The ecoupon_loaded_touchpoint_data cte is created to get the touchpoint details of those customers who have loaded or redeemed the coupons.
2. This means they have loaded or redeemed the coupons for targeted skus. So we have the consolidated touchpoint details for all the customers who have loaded or redeemed the coupons.
3. We are getting the event_utc_ts from the ecoupon_loaded_loyalty cte as this can be used as a touchpoint.
***********************/
#}
, ecoupon_loaded_touchpoint_data as (
    select distinct
        ert.loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , ert.campaign_name
        , ert.campaign_id
        , date(ell.event_utc_ts) as event_date
        , ell.event_utc_ts as event_time
        , ert.transaction_key
        , 'Touchpoint' as event_name
        , ert.booking_id
    from ecoupon_redeem_transaction as ert
    inner join ecoupon_loaded_loyalty as ell
        on ert.loyalty_id = ell.loyalty_id
    union all
    select distinct
        elt.loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , elt.campaign_name
        , elt.campaign_id
        , date(ell.event_utc_ts) as event_date
        , ell.event_utc_ts as event_time
        , elt.transaction_key
        , 'Touchpoint' as event_name
        , elt.booking_id
    from ecoupon_loaded_transaction as elt
    inner join ecoupon_loaded_loyalty as ell
        on elt.loyalty_id = ell.loyalty_id
)

{#
/**********************
1. The ecoupon_data_collection cte is created to get the final transaction and touchpoint data for all transactions as well as touch point for non conversion.
2. It combines the ecoupon_loaded_transaction, ecoupon_redeem_transaction, ecoupon_loaded_touchpoint_data and ecoupon_non_targetted_sku_touchpoint_data cte to get the final data.
3. It also removes the duplicates from the data.
4. It also adds the subchannel name as 'TXN' for the transaction data.
5. We are marking item_cd, product_type, unique_brand_name, net_sales_amt and units_qty as null for the touchpoint data.
***********************/
#}
, ecoupon_data_collection as (
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from ecoupon_loaded_transaction
    union all
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from ecoupon_redeem_transaction
    union all
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from ecoupon_loaded_touchpoint_data
    union all
    select distinct
        loyalty_id
        , null as transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from ecoupon_non_targeted_sku_touchpoint_data
)


{#
/**********************
1. The final select statement is used to get the final data for the ecoupon data collection.
2. It selects the distinct values for all the columns and adds the load_ts and job_run_id.
3. It also replaces the null values with 'NA' for the transaction_key,unique_brand_name,product_type and 0 for the item_cd.
***********************/
#}
select distinct
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz as load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , '{{ invocation_id }}' as job_run_id
from ecoupon_data_collection

{% endset %}

{{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel,job_bag_id, startDate, endDate) }}

    {% do return(ecoupon_sql) %}

{% endmacro %}
    