{#
/*********************************************************************************************************************************************
* Objective - The script get_coupon_at_till_customer_data.sql retrieves transaction and touchpoint data for customers engaging with coupon-at-till campaigns, linking targeted coupons to customer transactions.
It focuses on extracting and processing campaign-specific customer interaction and sales data for analysis.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: customer_data_collection
* This script will return transaction and touchpoint data for coupon_at_till channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{% macro get_coupon_at_till_customer_data() %}

{# /* getting campaign data for coupon at till channel from measurement campaign execution table */ #}

{% if dbt_unit_testing.running_unit_test() %}
    -- Use the mock macro during unit testing, DBT runs them separate to the main script so we have to mock them for the unit test to work correctly
        {% set campaignData = mock_get_campaign_list_coupon_at_till() %}
{% else %}
    -- Use the real macros during normal runs
        {% set campaignData = get_campaign_channel_specific_data('Coupon At Till') %}
{% endif %}

{% set campaignName = campaignData[0] %}
{% set channel = campaignData[1] %}
{% set startDate = campaignData[2] %}
{% set endDate = campaignData[3] %}
{% set campaignid = campaignData[4] %}
{% set subchannel = campaignData[5] %}
{% set bookingId = campaignData[6] %}
{% set campaignDuration = campaignData[7] %}
{% set job_bag_id = campaignData[8] %}
{% set marketing_type = campaignData[9] %}

{{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

{% set cat_sql %}

{#
/**************************
1. Getting coupon details from coupon cel and coupon table for the given campaign id..
2. This CTE is critical for identifying all coupons relevant to a specific campaign, regardless
of whether they come from the COUPON or CAT_PLAN_DATA tables.
The extracted coupon details are used later in the script to match transactions and customer interactions
with the campaign's coupons.
*************************/
#}
with get_coupon_details as (
    select
        substr(trim(cp.coupon_id), 8, 7) as coupon_id
        , substr(cp.coupon_id, 0, 14) as coupon_id_2
    from {{ source('I2C_CMPGN_PL', 'CELL') }} as c
    inner join {{ source('I2C_CMPGN_PL', 'COUPON_CELL') }} as cc on c.cell_key = cc.cell_key
    inner join {{ source('I2C_CMPGN_PL', 'COUPON') }} as cp on cc.coupon_key = cp.coupon_key
    where
        c.campaign_id = '{{ campaignid }}'
    union
    select
        offerbarcode
        , substr(offerbarcode, 0, 14) as offerbarcode_2
    from {{ source('I2C_CMPGN_PL', 'CAT_PLAN_DATA') }}
    where campaigncode = '{{ campaignid }}'
)

{#
/******************
1.The get_targetted_customers_raw CTE identifies customers who were targeted with specific
campaign coupons by matching their coupon barcodes to the campaign's coupons.
It also captures the exact timestamp of the coupon printing event.
2.This data is foundational for further processing,
such as linking these customers to their transactions or analyzing touchpoints within the campaign
*****************/
#}
, get_targetted_customers_raw as (
    select distinct
        fcat.hash_loyalty_id as customer_key
        , timestamp_from_parts(fcat.coupon_print_dt, fcat.coupon_print_tm) as event_ts
    from {{ source('ADW_CUSTOMER_INTERACTIONS_PL', 'FACT_COUPON_AT_TILL') }} as fcat
    where
        fcat.barcode in (select distinct coupon_id_2 from get_coupon_details)
        and fcat.coupon_print_dt between '{{ startDate }}' and '{{ endDate }}'
)

{# /* getting event ts for each customer key to add touchpoint and avoid duplicate
touchpoints for same customer key */#}
, get_targetted_customers as (
    select
        customer_key
        , min(event_ts) as event_ts
    from get_targetted_customers_raw
    group by 1
)

{#
/**************************
1. Getting transaction details from fact_sale_transaction_basket  for the given campaign id and campaign period
2. We are creating this cte to avoid multiple reads from fact_sale_transaction_basket table thus reducing the
   read time from the table.
*************************/
#}
, get_fact_sale_transaction_basket as (
    select
        transaction_end_ts
        , nectar_card_num_hash
        , transaction_id
        , transaction_dt
        , sales_origination_channel_cd
        , transaction_key
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
    where
        nectar_card_num_hash is not null
        and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#
/**************************
1. Getting transaction details from fact_sale_transaction_item  for the given campaign id and campaign period
2. We are creating this cte to avoid multiple reads from fact_sale_transaction_item table thus reducing the
   read time from the table.
3. We are also filtering out the transactions which are not having any sales amount.
*************************/
#}
, get_fact_sale_transaction_item as (
    select
        transaction_id
        , transaction_dt
        , item_cd
        , net_retail_sales_amt
        , item_qty
        , item_sequence_num
        , store_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
    where 
        transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and net_retail_sales_amt > 0   
)

{#
/**************************
1. Getting max load_ts from campaign product type table for the given campaign id and channel
2. We are creating this cte to avoid multiple reads from campaign product type table thus reducing the
   read time from the table and also we are checking from the latest load_ts.
*************************/
#}
, max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
)

{# /* Getting targetted skus for offer,brand,aisle. This cte is created to reduce
the fetch time from campaign product type table.
This will be used in the transaction fetch query to get the transaction details for targetted skus. */ #}
, get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
        and load_ts = (select load_ts from max_load_ts)
)

{#
/**************************
1. Getting transaction details for targetted skus for the given campaign id and campaign period
for customers who redeemed the coupon
2. We are applying campaign duration specific filters to ensure that we are getting the
transaction details within the campaign period only.
3. We are also filtering out the transactions which are not having any sales amount.
4. Item_sequence_num is used to handle the case where for the same trancation_id,item_cd,
there are multiple records in the fact_sale_transaction_item table.
We are using this to get the latest record for the same transaction_id and item_cd.
*************************/
#}
, get_redeem_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfstb.transaction_dt as event_dt
        , gfstb.transaction_end_ts as event_ts
        , gfstb.transaction_id as transaction_key
        , gfsti.item_cd
        , gts.unique_brand_name
        , 'NA' as marketing_type
        , 'In-store' as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
    inner join get_fact_sale_transaction_basket as gfstb
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    inner join {{ source('INC_PL','POINTS_COUPON_REDEMPTION') }} as pcr
        on gfstb.transaction_key = pcr.transaction_key
    inner join get_targetted_customers as gtc
        on dcl.nectar_collector_card_num = gtc.customer_key
    where
        pcr.coupon_id in (select distinct coupon_id from get_coupon_details)
        and dcl.nectar_collector_card_num != '~~'
        and gfsti.net_retail_sales_amt > 0
        and pcr.date_key between '{{ startDate }}' and '{{ endDate }}'
        and gfstb.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and gfsti.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
)

{# /* Getting total sales amount and units sold for a loyalty_id,
   event_dt,event_ts,transaction_key,item_cd,unique_brand_name,
    marketing_type,channel_name,campaign_name,campaign_id,event_name,
    booking_id,product_type */ #}
, get_redeem_transaction_data as (
    select
        loyalty_id
        , event_dt
        , event_ts
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_sales_amt
        , sum(item_qty) as units_qty
    from get_redeem_transaction_data_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**************************
1. Getting all transaction details for the given campaign id and campaign period for customers
who did not redeem the coupon
2. We are applying campaign duration specific filters to ensure that we are getting the
transaction details within the campaign period only.
3. We are also filtering out the transactions which are not having any sales amount.
4. Item_sequence_num is used to handle the case where for the same trancation_id,item_cd,
there are multiple records in the fact_sale_transaction_item table. We are using this to get the
latest record for the same transaction_id and item_cd.
5. Channel of sales is determined based on the sales_origination_channel_cd. If it is in the list
of instore codes then it is considered as In-store else Online.
This value is configurable in the dbt project.yml file.
*************************/
#}
, get_all_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfstb.transaction_dt as event_dt
        , gfstb.transaction_end_ts as event_ts
        , gfstb.transaction_id as transaction_key
        , gfsti.item_cd
        , gts.unique_brand_name
        , 'NA' as marketing_type
        , case when
            gfstb.sales_origination_channel_cd in (
                select instore_codes.value
                from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
            )
            then 'In-store'
        else 'Online' end as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
    inner join get_targetted_customers as gtc
        on dcl.customer_loyalty_cd = gtc.customer_key
    inner join get_fact_sale_transaction_basket as gfstb
        on
            dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
            and gtc.event_ts <= gfstb.transaction_end_ts
    inner join get_fact_sale_transaction_item as gfsti
        on gfstb.transaction_id = gfsti.transaction_id
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    where
        gfstb.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and gfsti.net_retail_sales_amt > 0
        and gfsti.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and dcl.nectar_collector_card_num != '~~'
        and gfstb.transaction_id not in (select distinct transaction_key from get_redeem_transaction_data)
        and gfstb.sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{# /* Getting total sales amount and units sold for a loyalty_id,event_dt,event_ts,transaction_key,
item_cd,unique_brand_name,marketing_type,channel_name,campaign_name,campaign_id,event_name,
booking_id,product_type */ #}
, get_all_transaction_data as (
    select
        loyalty_id
        , event_dt
        , event_ts
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_sales_amt
        , sum(item_qty) as units_qty
    from get_all_transaction_data_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
) 

{#
/**************************
1. Getting touchpoint data for targeted customers who did any transaction for targeted skus
2. Incase touchpoint has event_ts greater than transaction event_ts then we are taking
transaction event_ts - 100ms as event_ts
3. This was done to enusre that touchpoint timestamp is less than transaction timestamp.
*************************/
#}
, create_get_coupon_touchpoint_data as (
    select distinct
        all_txn.loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , '{{ subchannel }}' as subchannel_name
        , all_txn.transaction_key
        , 'Touchpoint' as event_name
        , all_txn.booking_id
        , case when gtc.event_ts > all_txn.event_ts
        then timeadd(millisecond, -100, all_txn.event_ts) else gtc.event_ts end as event_ts
        , case when date(gtc.event_ts) < date(all_txn.event_ts) then
        date(gtc.event_ts) else date(all_txn.event_ts) end as event_dt
    from (
        select *
        from get_all_transaction_data
        union
        select *
        from get_redeem_transaction_data
    ) as all_txn
    inner join get_targetted_customers as gtc
        on all_txn.loyalty_id = gtc.customer_key
    
)

{#
/**************************
1. Adding touchpoint data for targeted customers who did not do any transaction for targeted skus
2. We are applying min function on event_ts to get the earliest event_ts for the customer key.
This way we can avoid duplicate touchpoints for the same customer key.
3. To ensure we are adding touchpoint for all loyalty ids who did n't buy targeted skus
we are removing those loyalty id who are already present in the transaction data.
*************************/
#}
, get_non_converted_touchpoint_data as (
    select
        gtc.customer_key as loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , '{{ subchannel }}' as subchannel_name
        , null as transaction_key
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
        , min(date(gtc.event_ts)) as event_dt
        , min(gtc.event_ts) as event_ts
    from get_targetted_customers as gtc
    where
        gtc.customer_key not in (select distinct loyalty_id from create_get_coupon_touchpoint_data)
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9
)

{#
/**************************
1. Getting consolidated view of coupon at till touchpoint and transaction data
2. We are using union all to combine the transaction data and touchpoint data.
3. We are also adding subchannel_name as 'TXN' for transaction data and 'Touchpoint' for touchpoint data.
4. We are also adding null values for item_cd, product_type, unique_brand_name,
net_sales_amt and units_qty for touchpoint data as they are not relevant for touchpoint data.
*************************/
#}
, coupon_at_till_collection as (
    select
        loyalty_id
        , transaction_key
        , event_dt
        , event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_sales_amt
        , units_qty
    from get_redeem_transaction_data
    union all
    select
        loyalty_id
        , transaction_key
        , event_dt
        , event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_sales_amt
        , units_qty
    from get_all_transaction_data
    union all
    select
        loyalty_id
        , transaction_key
        , event_dt
        , event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from create_get_coupon_touchpoint_data
    union all
    select
        loyalty_id
        , null as transaction_key
        , event_dt
        , event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from get_non_converted_touchpoint_data

)

{#
/**************************
1. Getting final output for coupon at till touchpoint and transaction data
2. We are applying coalesce function to handle null values for transaction_key, item_cd,
product_type, unique_brand_name, net_sales_amt and units_qty.
3. We are also adding load_ts and job_run_id to the final output.
*************************/
#}
select
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz as load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , '{{ invocation_id }}' as job_run_id
from coupon_at_till_collection

{% endset %}

    {% do return(cat_sql) %}

{% endmacro %}