{#
/*********************************************************************************************************************************************
* Objective - The objective of the get_citrus_customer_data.sql script is to extract transaction and touchpoint data specific to the Citrus channel 
for a given campaign. It aggregates customer interactions based on campaign placements, subchannels, and targeted SKUs, 
ensuring the data is filtered and organized for downstream processing. 
This script is called within the Citrus customer data model and helps in analyzing customer engagement during the campaign.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: customer_data_collection
*
* This script will return transaction and touchpoint data for citrus channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{# /*This macro returns the GOL data query according to the campaign placement/subchannel 
to get the customer data touchpoints*/#}
{% macro get_citrus_touchpoint_data() %}

    {% set campaignData = get_campaign_channel_specific_data('Onsite-GOL') %}
    {% set campaignName = campaignData[0] %}
    {% set channel = campaignData[1] %}
    {% set startDate = campaignData[2] %}
    {% set endDate = campaignData[3] %}
    {% set campaignid = campaignData[4] %}
    {% set subchannel = campaignData[5] %}
    {% set bookingId = campaignData[6] %}
    {% set campaignDuration = campaignData[7] %}
    {% set job_bag_id = campaignData[8] %}
    {% set marketing_type = campaignData[9] %}

    {#
    /**********************
    1.This line is setting a variable search_terms and assigning it the result of the get_search_terms macro. 
    2.The macro get_search_terms is called with the campaignid as its argument. 
    The purpose of this macro is to retrieve a list of search terms associated with the given campaignid, 
    which are  used in filtering or processing customer data within the Citrus campaign context.
    **********************/
    #}
    {% set search_terms = get_search_terms(campaignid) %}
    {#
    /**********************
    1.This line is a conditional check. It evaluates whether the variable search_terms:Is not defined: 
    This means that the search_terms variable has not been assigned a value.
    Is equal to ',': This checks if the search_terms contains only a single comma,
    indicating it is essentially empty or invalid.
    2. If either of these conditions is true, it sets the search_terms variable to an empty string.
    3. If the search_terms variable is defined and not equal to a single comma, it processes the search_terms
    variable by replacing any single quotes (') with double single quotes ('').
    **********************/
    #}

    {% if search_terms is not defined or search_terms == ',' %}
        {% set search_terms = '' %}
    {% else %}
        {# Process the search_terms to escape single quotes by replacing them with double single quotes #}
        {% set search_terms = search_terms | replace("'", "''") %}
    {% endif %}

    {#
    /******************
    1.If campaignDuration is "Post", it calculates the campaign's end date by calling the get_campaign_end_date
    macro with parameters like bookingId, channel, subchannel, marketing_type, startDate, and endDate.
    Then, it sets the gol_data_query variable by calling the get_citrus_gol_query macro, using the calculated
    campaignEndDate as the end date for the query.
    2. If campaignDuration is not "Post", it sets the gol_data_query variable by calling the
    get_citrus_gol_query macro with startDate and endDate as parameters.
    *******************/
    #}

    {% if campaignDuration=="Post" %}
        {% set campaignEndDate = get_campaign_end_date(bookingId, channel, subchannel, marketing_type, startDate, endDate) %}
        {% set gol_data_query = get_citrus_gol_query(startDate, campaignEndDate, campaignid, channel, subchannel, search_terms) %}
    {% else %}
        {% set gol_data_query = get_citrus_gol_query(startDate, endDate, campaignid, channel, subchannel, search_terms) %}
    {% endif %}
    {#
    /******************
    1.If the campaignDuration is "Post", it indicates the campaign is
    in the "Post" phase (after the main campaign period).
    2. In this case, it calculates the campaign's end date by calling the get_campaign_end_date macro with parameters
    like bookingId, channel, subchannel, marketing_type, startDate, and endDate.
    3. Then, it sets the gol_data_query variable by calling the get_citrus_gol_query macro, using the calculated
    campaignEndDate as the end date for the query.
    4. If the campaignDuration is not "Post", it sets the gol_data_query variable by calling the
    get_citrus_gol_query macro with startDate and endDate as parameters.
    *******************/
    #}
    {% if campaignDuration=="Post" %}
        {% set campaignEndDate = get_campaign_end_date(bookingId, channel, subchannel, marketing_type, startDate, endDate) %}
        {% set gol_data_query = get_citrus_gol_query(startDate, campaignEndDate, campaignid, channel, subchannel, search_terms) %}
    {% else %}
        {% set gol_data_query = get_citrus_gol_query(startDate, endDate, campaignid, channel, subchannel, search_terms) %}
    {% endif %}

    {% set citrus_query %}
        {{ gol_data_query }}

        {#
        /**************************
        1. Getting transaction details for all the transaction within campaign period.
        2. We are creating this cte to avoid multiple reads to the source table so that we can reduce the read time.
        3. We are using the same cte in multiple places to get the transaction details.
            *************************/
        #}

        , get_fact_sale_transaction_basket as (
            select
                transaction_end_ts
                , nectar_card_num_hash
                , transaction_id
                , transaction_dt
                , sales_origination_channel_cd
            from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
            where
                nectar_card_num_hash is not null
                and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and sales_origination_channel_cd in (
                    select all_codes.value
                    from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
            )
        )

        {#
        /**************************
        1. Getting max load timestamp for campaign product type table to fetch latest records
        2. We are using this cte to get the latest load timestamp for the campaign product type table.
        *************************/
        #}

        , max_load_ts as (
            select
                max(load_ts) as load_ts
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
            where
                campaign_id = '{{ campaignid }}'
                and channel_name = '{{ channel }}'
                and subchannel_name = '{{ subchannel }}'
        )

        {#
        /**************************
        1. Getting all the targeted skus,unique_brand_name and product_type for the campaign
        within campaign period for the given channel and subchannel.
        2. We are using this cte to get offer, brand,aisle skus for the campaign from their latest records.
        3. This will be later used in transaction data to get the transaction details for the targeted skus.
        *************************/
        #}
        , get_targeted_skus as (
            select distinct
                product_type
                , unique_brand_name
                , item_cd
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
            where campaign_id = '{{ campaignid }}'
                and channel_name = '{{ channel }}'
                and subchannel_name = '{{ subchannel }}'
                and load_ts = (select load_ts from max_load_ts)
    
        )
        {#
        /**************************
        1. Getting transaction details for all the transaction within campaign period.
        2. We are creating this cte to avoid multiple reads to the source table so that we can reduce the read time.
        3. We are using the same cte in multiple places to get the transaction details.
        *************************/
        #}

        , get_fact_sale_transaction_item as (
            select
                transaction_id
                , transaction_dt
                , item_cd
                , net_retail_sales_amt
                , item_qty
                , item_sequence_num
                , store_cd
        from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
        where 
            transaction_dt between '{{ startDate }}' and '{{ endDate }}'
            and net_retail_sales_amt > 0   
    )

    {#
        /**************************
        1. Getting transaction details for all the targeted skus to the targeted customers within the campaign period.
        2. We are applying the sales origination channel codes to get the correct channel name details.
        3. Item_sequence_num is used to handle the case where for the same transaction and item_cd there are multiple records.
        4. Transaction date filter is used to ensure that we are getting the transaction details for the
        targeted skus within the campaign period.
        *************************/
    #}

         , transaction_data as (
             select distinct
                gd.loyalty_id
                , gfstb.transaction_dt as event_dt
                , gfstb.transaction_end_ts as event_ts
                , gfstb.transaction_id as transaction_key
                , gfsti.item_cd
                , gts.unique_brand_name
                , 'NA' as marketing_type
                , case when
                    gfstb.sales_origination_channel_cd in (
                        select instore_codes.value
                        from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
                    )
                    then 'In-store'
                else 'Online' end as channel_name
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , 'Purchase Transaction' as event_name
                , '{{ bookingId }}' as booking_id
                , gts.product_type
                , gfsti.net_retail_sales_amt as net_sales_amt
                , gfsti.item_qty as units_qty
                , gfsti.item_sequence_num
            from get_fact_sale_transaction_item as gfsti
            inner join get_fact_sale_transaction_basket as gfstb
                on gfsti.transaction_id=gfstb.transaction_id
            inner join (select distinct loyalty_id from gol_data) as gd
                on gd.loyalty_id = gfstb.nectar_card_num_hash
            inner join get_targeted_skus as gts
                on gfsti.item_cd = gts.item_cd
            where
                gfsti.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
                and gfsti.net_retail_sales_amt > 0
                and gfstb.sales_origination_channel_cd in (
                    select instore_codes.value
                    from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as instore_codes
                )
        )

        {#
        /**************************
        1. Getting transaction data for only those customers who had a touchpoint before the transaction.
        *************************/
        #}
        , transaction_data_filtered as (
            select distinct
                gd.loyalty_id
                , td.event_dt
                , td.event_ts
                , td.transaction_key
                , td.item_cd
                , td.unique_brand_name
                , td.marketing_type
                , td.channel_name
                , td.campaign_name
                , td.campaign_id
                , td.event_name
                , td.booking_id
                , td.product_type
                , td.net_sales_amt
                , td.units_qty
                , td.item_sequence_num
            from transaction_data as td
            inner join gol_data as gd
                on gd.loyalty_id = td.loyalty_id
                and gd.event_ts <= td.event_ts
            
        )

        {#
        /**************************
        1. Getting transaction details for all eligible customer.
        2. We are getting total net sales amount and units quantity for each group loyalty_id,
        event_dt, event_ts, transaction_key, item_cd, unique_brand_name, marketing_type, channel_name,
        campaign_name, campaign_id, event_name, booking_id and product_type.
        *************************/
        #}
        , grouped_transaction_data as (
            select
                loyalty_id
                , event_dt
                , event_ts
                , transaction_key
                , item_cd
                , unique_brand_name
                , marketing_type
                , channel_name
                , campaign_name
                , campaign_id
                , event_name
                , booking_id
                , product_type
                , sum(net_sales_amt) as net_sales_amt
                , sum(units_qty) as units_qty
            from transaction_data_filtered
            group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
            
        )

        {#
        /**************************
        1. This code block creates a Common Table Expression (CTE) named transaction_touchpoint_data 
        to identify and generate touchpoints (customer interactions) that are associated
        with specific transactions during a campaign
        2. A dense rank is calculated for:
        grouped_transaction_data (aliased as td) by loyalty_id and ordered by event_dt.
        gol_data (aliased as gd) by loyalty_id and ordered by the date of event_ts.
        This ranking assigns sequential numbers to events for
        each customer (loyalty_id), which helps in correlating transactions with 
        touchpoints.
        3. The CTE then joins these two datasets (td and gd) on loyalty_id, ensuring that the event_ts of
        the transaction is greater than or equal to the event_ts of the touchpoint.
        4. This block identifies touchpoints (interactions) for customers that occurred before or at the
        same time as their transactions. It ensures that touchpoints are aligned
        with the appropriate transactions and captures the earliest touchpoint
        for each customer-transaction pair in the campaign.
        *************************/
        #}

        , transaction_touchpoint_data as (
            select
                td.loyalty_id
                , '{{ marketing_type }}' as marketing_type
                , '{{ channel }}' as channel_name
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , '{{ subchannel }}' as subchannel_name
                , td.transaction_key
                , 'Touchpoint' as event_name
                , '{{ bookingId }}' as booking_id
                , date(min(gd.event_ts)) as event_dt
                , min(gd.event_ts) as event_ts
                from (
                select
                *
                , dense_rank() over (partition by loyalty_id order by event_dt) as dr_num
                from grouped_transaction_data) as td
                inner join (
                                select
                                    *
                                    , dense_rank() over (partition by loyalty_id order by date(event_ts)) as dr_num
                                from gol_data) as gd
                    on td.loyalty_id = gd.loyalty_id
                    and td.event_ts >= gd.event_ts
                    and td.dr_num = gd.dr_num
                group by 1, 2, 3, 4, 5, 6, 7, 8, 9
        )

        {#
        /**************************
        1. This block defines a Common Table Expression (CTE) called get_initial_touchpoint_data
        which identifies initial touchpoints for transactions that have not yet been associated with a touchpoint.
        2. The purpose of this CTE is to ensure that transactions without previously identified
        touchpoints are linked to the earliest
        possible touchpoint event for the same customer (loyalty_id). This ensures comprehensive data alignment
        between transactions and touchpoints for accurate campaign tracking and analysis.
        *************************/
        #}

        , get_initial_touchpoint_data as (
            select
                sq.loyalty_id
                , '{{ marketing_type }}' as marketing_type
                , '{{ channel }}' as channel_name
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , '{{ subchannel }}' as subchannel_name
                , sq.transaction_key
                , 'Touchpoint' as event_name
                , '{{ bookingId }}' as booking_id
                , date(min(gd.event_ts)) as event_dt
                , min(gd.event_ts) as event_ts
            from (
                    select distinct
                        gtd.transaction_key
                        , gtd.loyalty_id
                        , gtd.event_ts
                    from grouped_transaction_data as gtd
                    left join transaction_touchpoint_data as ttd
                    on gtd.transaction_key=ttd.transaction_key
                    where ttd.transaction_key is null
                ) as sq
            inner join gol_data as gd
            on sq.loyalty_id = gd.loyalty_id
            and sq.event_ts >= gd.event_ts
            group by 1, 2, 3, 4, 5, 6, 7, 8, 9
        )
        {#
        /**************************
        1. The purpose of this block is to capture non-transactional touchpoints—interactions where customers engaged
        with the campaign (e.g., viewed an ad) but did not complete a purchase. This data is essential for
        analyzing overall campaign engagement,
        including cases where no transactions occurred, which helps understand customer
        behavior beyond just purchases.
        2. The where gtd.loyalty_id is null condition filters records to include only
        those touchpoints in gol_data that do not have a
        matching loyalty_id in grouped_transaction_data. This identifies customers who interacted with
        the campaign but did not make a transaction.
        **************************/
        #}
        , get_non_transactional_touchpoint as (
            select
                gd.loyalty_id
                , '{{ marketing_type }}' as marketing_type
                , '{{ channel }}' as channel_name
                , '{{ campaignName }}' as campaign_name
                , '{{ campaignid }}' as campaign_id
                , '{{ subchannel }}' as subchannel_name
                , null as transaction_key
                ,  'Touchpoint' as event_name
                , '{{ bookingId }}' as booking_id
                , date(min(gd.event_ts)) as event_dt
                , min(gd.event_ts) as event_ts
            from gol_data as gd
            left join grouped_transaction_data as gtd
            on gd.loyalty_id = gtd.loyalty_id 
            where gtd.loyalty_id is null
            group by 1, 2, 3, 4, 5, 6, 7, 8, 9
        )

        {#
        /**************************
        1. This block creates the union of all the transaction and touchpoint data.
        2. The union includes transaction data, touchpoint data, and non-transactional touchpoints.
        3. The final result set is aliased as citrus_collection, which contains all
        relevant customer interactions during the campaign period.
        ****************************/
        #}
        , citrus_collection as (
        select
            loyalty_id
            , transaction_key
            , event_dt
            , event_ts
            , marketing_type
            , channel_name
            , 'TXN' as subchannel_name
            , campaign_name
            , campaign_id
            , event_name
            , booking_id
            , item_cd
            , product_type
            , unique_brand_name
            , net_sales_amt
            , units_qty
        from grouped_transaction_data
        union all
        select
            loyalty_id
            , transaction_key
            , event_dt
            , event_ts
            , marketing_type
            , channel_name
            , subchannel_name
            , campaign_name
            , campaign_id
            , event_name
            , booking_id
            , null as item_cd
            , null as product_type
            , null as unique_brand_name
            , null as net_sales_amt
            , null as units_qty
        from transaction_touchpoint_data
        union all
        select
            loyalty_id
            , transaction_key
            , event_dt
            , event_ts
            , marketing_type
            , channel_name
            , subchannel_name
            , campaign_name
            , campaign_id
            , event_name
            , booking_id
            , null as item_cd
            , null as product_type
            , null as unique_brand_name
            , null as net_sales_amt
            , null as units_qty
        from get_initial_touchpoint_data
        union all
        select
            loyalty_id
            , null as transaction_key
            , event_dt
            , event_ts
            , marketing_type
            , channel_name
            , subchannel_name
            , campaign_name
            , campaign_id
            , event_name
            , booking_id
            , null as item_cd
            , null as product_type
            , null as unique_brand_name
            , null as net_sales_amt
            , null as units_qty
        from get_non_transactional_touchpoint
    )

    {#
    /****************************
    1. This block selects the final data from the citrus_collection CTE.
    2. It includes various fields such as loyalty_id, transaction_key, event_dt, event_ts,
    marketing_type, channel_name, subchannel_name, campaign_name, campaign_id, event_name,
    booking_id, item_cd, product_type, unique_brand_name, net_sales_amt, units_qty.
    3. The data is transformed and formatted as needed, including handling null values
    and setting default values.
    4. The final result set is returned as the output of the macro.
    *****************************/
    #}
    select
        loyalty_id
        , coalesce(transaction_key, 'NA') as transaction_key
        , event_dt
        , event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , current_timestamp::timestamp_ntz as load_ts
        , coalesce(item_cd, 0)::number(10,0) as item_cd
        , coalesce(product_type, 'NA') as product_type
        , coalesce(unique_brand_name, 'NA') as unique_brand_name
        , coalesce(net_sales_amt, 0) as net_sales_amt
        , coalesce(units_qty, 0) as units_qty
        , '{{ invocation_id }}' as job_run_id
    from citrus_collection

    {% endset %}


    {{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

    {# {{ log("citrus_query : "~citrus_query, info=True ) }} #} 

    {% do return(citrus_query) %}
   

{% endmacro %}


{# /*This macro returns the GOL web/app query according to the campaign placement/subchannel 
to get the customer data points*/#}
{% macro get_citrus_gol_query(startDate, endDate, campaignid, channel, subchannel, search_terms) %}

    {{ log("In get_citrus_gol_query : ", info=True ) }}

    {% set subQueryResult = get_citrus_sub_query(subchannel, search_terms)%}
    {% set subchannelWebQuery = subQueryResult[0] %}
    {% set subchannelAppQuery = subQueryResult[1] %}
    {% set hasApp = subQueryResult[2] %}
    {{ log("hasApp : "~hasApp, info=True ) }}

    {#
    /********************
    1. The web_query is designed to extract customer interaction data for the Citrus campaign from web-based sources. 
    It focuses on item-level and event-level details, ensuring the data is filtered by 
    campaign specifics (e.g., time range, item codes, subchannels) and is linked to valid
    customer loyalty identifiers.
    This query is a critical component for analyzing how customers interact with the campaign online.
    ********************/
    #}
    {% set web_query %}
            select distinct
                dcl.nectar_collector_card_num as loyalty_id
                , fgoei.hash_online_account_num
                , fgoei.event_ts
                , fgoei.online_order_num
                , fgoei.item_cd
            from {{ source('ADW_DIGITAL_INTERACTIONS_PL', 'FLF_GOLWEB_ONLINE_EVENT_ITEM') }} as fgoei 
            inner join {{ source('ADW_DIGITAL_INTERACTIONS_PL', 'FLF_GOLWEB_ONLINE_EVENT') }} as fgoe
                on fgoei.event_id = fgoe.event_id
                and fgoe.event_ts <= fgoei.event_ts
            inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
                on dcl.customer_loyalty_cd = fgoei.hash_online_account_num
            where
                fgoei.event_ts between '{{ startDate }}' and '{{ endDate }}'
                and fgoe.event_ts between '{{ startDate }}' and '{{ endDate }}'
                and fgoei.item_cd in
                (
                    select distinct to_varchar(item_cd)
                    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
                    where
                        campaign_id = '{{ campaignid }}'
                        and product_type = 'Offer'
                        and channel_name = '{{ channel }}'
                        and subchannel_name = '{{ subchannel }}'
                )
                and fgoei.item_top_level_pfm ilike '%citrus%'
                and fgoe.ga_item_pfm_cat = 'Citrus'
                and {{ subchannelWebQuery }}
                and dcl.nectar_collector_card_num is not null
                and dcl.nectar_collector_card_num != '~~'
                and fgoei.hash_online_account_num != '~~'
        {% endset %}

    {#
    /********************
    1. The app_query is designed to extract customer interaction data for the Citrus campaign from app-based sources.
    2. The app_query is designed to extract app-based customer interaction data for the
    Citrus campaign, including event-level and
    item-level details. 
    3.It filters data for campaign-specific items, experiments, and subchannels, and links
    events to customer loyalty information.
    4.This query complements the web-based data (web_query) to provide a comprehensive view of
    customer interactions across platforms.
    ********************/
    #}
    {% set app_query %}
            select distinct
                dcl.nectar_collector_card_num as loyalty_id
                , ga1.online_account_num as hash_online_account_num
                , ga1.online_event_ts as event_ts
                , ga1.online_order_num
                , ga2.item_cd
            from (
                    select
                        online_account_num
                        , online_event_ts
                        , online_order_num
                    from {{ source('ADW_DIGITAL_INTERACTIONS_PL', 'FLF_ONLINE_EVENT_GOL_APP') }}
                    where
                    event_dt between '{{ startDate }}' and '{{ endDate }}'
                    and experiments like '%SponsoredProductsCount%'
                    and {{ subchannelAppQuery }}
                ) AS ga1
            inner join (
                        select
                            tealium_session_id
                            , online_event_ts
                            , item_cd
                        from {{ source('ADW_DIGITAL_INTERACTIONS_PL', 'FLF_ONLINE_EVENT_ITEM_GOL_APP') }}
                        where event_dt between '{{ startDate }}' and '{{ endDate }}'
                        and item_cd in
                        (
                            select distinct to_varchar(item_cd)
                            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
                            where
                                campaign_id = '{{ campaignid }}'
                                and product_type = 'Offer'
                                and channel_name = '{{ channel }}'
                                and subchannel_name = '{{ subchannel }}'
                        )
                        and experiments like '%SponsoredProductsCount%'
                    ) as ga2
                        on ga2.tealium_session_id=ga2.tealium_session_id
                        and ga2.online_event_ts <= ga2.online_event_ts
            inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
                on ga1.online_account_num=dcl.customer_loyalty_cd 
            where
                dcl.nectar_collector_card_num is not null
                and dcl.nectar_collector_card_num != '~~'
                and ga1.online_account_num != '~~'
        {% endset %}

    {{ log("subchannel : "~subchannel, info=True ) }}

    {#
    /*******************
    1. The purpose of this block is to dynamically construct the gol_data_query based on the presence of app data and
    the specific subchannel being processed.
    2.This ensures that the query only retrieves relevant data for the campaign, optimizing performance and accuracy.
    The constructed query is then returned.
    ******************/
    #}
    {% if hasApp and subchannel != 'Search - App' %}
        {{ log("Inside first if condition : ", info=True ) }}
        {% set gol_data_query %}
            with gol_data as (
                {{ web_query }}
                union
                {{ app_query }}
            )
        {% endset %}
    
    {% elif subchannel == 'Search - App' %}
        {% set gol_data_query %}
            with gol_data as (
                {{ app_query }}
            )
        {% endset %}
    
    {% else %}
        {% set gol_data_query %}
            with gol_data as (
                {{ web_query }}
            )
        {% endset %}
    
    {% endif %}
    
   {# {{ log("gol Web or App Query : "~gol_data_query, info=True ) }} #}
    {% do return(gol_data_query) %}

{% endmacro%}

/*This macro returns the end date of the campaign from unified_campaign */
{% macro get_campaign_end_date(bookingId, channel, subchannel, marketing_type, startDate, endDate) %}
    {% set get_campaign_enddate_sql %}
        select 
            campaign_end_dt
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }}
            where booking_id = '{{ bookingId }}' and 
            channel_name = '{{ channel }}' and
            subchannel_name = '{{ subchannel }}' and
            marketing_type = '{{ marketing_type }}' and
            campaign_start_dt = '{{ startDate }}' and
            post_campaign_dt = '{{ endDate }}'
    {% endset %}
    {% set result =  run_query(get_campaign_enddate_sql) %}

    {% if execute %}
        {% do log("Result of  get_campaign_end_date: " ~ result.rows, info=True ) %}
        {% set campaign_end_date =  result.rows %}
    {% endif %}

    {% do return(campaign_end_date[0][0]) %}
{% endmacro %}

{# /*This macro returns the sub-query which is part of the main query according to the campaign placement/subchannel */#}
{% macro get_citrus_sub_query(subchannel, search_terms) %}

    {{ log("In get_citrus_sub_query : ", info=True ) }}

    {% set hasAPP = true %}

    {% if 'search below grid' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%citrus_search_ads_below_grid%\'
        and lower(fgoe.search_term) in (select value from table(split_to_table(\'" ~search_terms~ "\',\',\')))" %}

        {% set subChannelAppQuery = "page_name ilike \'%golapp:searchresults%\'
        and lower(search_keyword) in (select value from table(split_to_table(\'" ~search_terms~ "\',\',\')))" %}

    {% elif 'search' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%search%\'
        and lower(fgoe.search_term) in (select value from table(split_to_table(\'" ~search_terms~ "\',\',\')))" %}

        {% set subChannelAppQuery = "page_name ilike \'%search%\' and lower(search_keyword) in 
        (select value from table(split_to_table(\'" ~search_terms~ "\',\',\')))" %}
    
    {% elif 'checkout before you go' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'checkout_%\' and fgoe.page_section = \'checkout before you go\'" %}

        {% set subChannelAppQuery = "page_name ilike \'%before you go%\'" %}

    {% elif 'favourites' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%favourites%\'" %}

        {% set subChannelAppQuery = "page_name ilike \'%favourites%\'" %}

    
    {% elif 'browse' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%citrus%\' and lower(fgoe.search_category_match_flag) = \'categorymatch\'" %}

        {% set subChannelAppQuery = "" %}

        {% set hasAPP = false %}

    {% elif 'offers' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%citrus_offers%\'" %}

        {% set subChannelAppQuery = "page_name ilike \'%offer%\'"%}

    {% elif 'zone' in subchannel|lower %}
        {% set subchannelWebQuery = "fgoe.item_prod_finding_method ilike \'%citrus_offers>zone%\'" %}

        {% set subChannelAppQuery = "" %}

        {% set hasAPP = false %}

    {% elif 'cross-sell' in subchannel|lower %}
        {% set subchannelWebQuery = "(fgoe.item_prod_finding_method ilike \'%citrus_xsell_ad_pdp%\' or fgoe.item_prod_finding_method ilike \'%citrus_xsell_ad_favourites%\')" %}

        {% set subChannelAppQuery = "" %}

        {% set hasAPP = false %}
    
    {% elif 'search - app' in subchannel|lower %}
        {% set subchannelWebQuery = "" %}

        {% set subChannelAppQuery = "page_name ilike \'%search%\' and lower(search_keyword) in (select value from table(split_to_table(\'" ~search_terms~ "\',\',\')))" %}

    {% else %}

        {{ log("Not matching any subchannel :  "~sunchannel, info=True ) }}

{% endif %}

    {{ log("subchannelWebQuery : "~subchannelWebQuery, info=True ) }}

    {% do return([subchannelWebQuery, subChannelAppQuery, hasAPP]) %}

{% endmacro %}

{#
/********************
1.The purpose of this macro is to dynamically retrieve and process the search terms associated with
a specific advertising campaign.
2.These terms are later used in other parts of the script, such as filtering or refining queries
based on user search behavior.
3.By handling suggested_search_term_list, the macro ensures that only valid and relevant terms are included.
*******************/
#}
{% macro get_search_terms(campaign_id) %}

    {% set sql %}
        select
            array_to_string(array_construct_compact(search_term_list
                , case when suggested_search_term_list = ''
                then null else suggested_search_term_list end ), ',') as search_terms
        from {{ source('ADW_RDV', 'ADVERTISING_CAMPAIGN_CITCAM_SAT') }}
        where advertising_campaign_nk1 = '{{ campaign_id }}';
    {% endset %}

    {% set result =  run_query(sql) %}

    {% if execute %}
       {# {{ log("Result of  get_search_terms: "~result.rows[0], info=True ) }} #} 
        {% set search_terms =  result.columns[0].values()[0] %}
    {% endif %}

    {% do return(search_terms) %}

{% endmacro %}
