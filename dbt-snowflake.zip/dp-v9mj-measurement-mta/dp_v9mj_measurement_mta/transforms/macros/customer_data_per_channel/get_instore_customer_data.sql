{#
/*********************************************************************************************************************************************
* Objective -This script retrieves transaction and touchpoint data for in-store campaigns, linking targeted customers to their
interactions and purchases.It processes and consolidates data to analyze campaign performance and customer engagement across both
in-store and online channels.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: Instore_customer_data
*
* This script will return transaction and touchpoint data for instore channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}


{% macro get_instore_customer_data() %}

{% if dbt_unit_testing.running_unit_test() %}
    -- Use the mock macro during unit testing, DBT runs them separate to the main script so we have to mock them for the unit test to work correctly
    {% set campaignData = mock_get_campaign_list_instore() %}
{% else %}
    -- Use the real macros during normal runs
    {% set campaignData = get_campaign_channel_specific_data('In-store') %}
{% endif %}

{# /* getting the campaign details from the measurement campaign execution table for instore */ #}

{% set campaignName =  campaignData[0] %}
{% set channel =  campaignData[1] %}
{% set startDate =  campaignData[2] %}
{% set endDate =  campaignData[3] %}
{% set campaignid =  campaignData[4] %}
{% set subchannel =  campaignData[5] %}
{% set bookingId =  campaignData[6] %}
{% set campaignDuration =  campaignData[7] %}
{% set job_bag_id = campaignData[8] %}
{% set marketing_type = campaignData[9] %}

{{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

{% set instore_sql %}

{#
/**********************
1. The base_data CTE is used to get the targeted_id from the BASE_FINANCE_ASSETS_DATA table.
2. The targeted_id is used to filter the data in the store_location CTE.
3. We are adding the job_bag_id and service_type to filter the data for the specific campaign.
***********************/
#}
with base_data as (
    select distinct split_part(asset_unique_id,'-',-1) as targeted_id
    from {{ source('I2C_PL', 'BASE_FINANCE_ASSETS_DATA') }}
    where
        lower(campaign_status) in ('campaign completed', 'hfss unknown')
        and timeid = (select max(timeid) from {{ source('I2C_PL', 'BASE_FINANCE_ASSETS_DATA') }})
        and lower(media_host_name) like 'sainsbur%'
        and job_bag_number = '{{ job_bag_id }}'
        and service_type = '{{ channel }}'
        and asset_name_media_host_prf_name = '{{ subchannel }}'
)

{% if campaignDuration == 'Post' %}

{#
/**********************
1. For post campaign period, we are getting the campaign details from the UNIFIED_CAMPAIGN table.
2. We are filtering the data based on the booking_id, channel_name, subchannel_name, marketing_type, campaign_start_dt and post_campaign_dt.
3. We are doing this to get the loyalty_ids who were part of the campaign in the 'During' period.
***********************/
#}
    ,   unified_data as (
            select 
                campaign_id
                , channel_name
                , subchannel_name 
                , marketing_type
                , campaign_start_dt 
                , campaign_end_dt
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }}
            where booking_id = '{{ bookingId }}'
            and channel_name = '{{ channel }}'
            and subchannel_name = '{{ subchannel }}'
            and marketing_type = '{{ marketing_type }}'
            and campaign_start_dt = '{{ startDate }}'
            and post_campaign_dt = '{{ endDate }}'
            and load_ts = (select max(load_ts) from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }})
)

{#
/**********************
1. Getting the targeted loyalty ids from the customer data collection table.
2. We are filtering the data based on the campaign_id, channel_name, subchannel_name, marketing_type and event_dt.
3. We are doing this to get the loyalty_ids who were part of the campaign in the 'During' period.
***********************/
#}
    ,   instore_customer_data_post_period as (
            select 
                distinct cdc.loyalty_id
            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','CUSTOMER_DATA_COLLECTION') }} cdc
            left join unified_data ud
            on cdc.campaign_id = ud.campaign_id
            and cdc.channel_name = ud.channel_name
            and cdc.subchannel_name = ud.subchannel_name
            and cdc.marketing_type = ud.marketing_type
            where cdc.event_dt between ud.campaign_start_dt and ud.campaign_end_dt
)

    ,  store_location as (
    select distinct il.location_key
    from {{ source('I2CEVALS', 'IE_LOCATION') }} as il
    inner join {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CHANNEL_MAPPING') }} as ucm
        on il.media_no % 100 = ucm.media_number
    where
        il.master_campaign_id = '{{ campaignid }}'
        and ucm.subchannel = '{{ channel }}'
)


{% else %}

{#
/**********************
1. The store_location CTE is used to get the location_key from the IE_LOCATION table where the targeted_id is from the BASE_FINANCE_ASSETS_DATA table.
2. For during campaign period, we are getting the campaign details from measurement campaign execution table.
3. The campaign_end_dt is actually the end date of the campaign, so there is no need to get it from the unified data table.
***********************/
#}
        ,   store_location as (
    select distinct il.location_key
    from {{ source('I2CEVALS', 'IE_LOCATION') }} as il
    inner join {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CHANNEL_MAPPING') }} as ucm
        on il.media_no % 100 = ucm.media_number
    where
        il.master_campaign_id = '{{ campaignid }}'
        and ucm.subchannel = '{{ channel }}'
)

{% endif %}

{#
/**********************
1. The max_load_ts CTE is used to get the maximum load timestamp from the CAMPAIGN_PRODUCT_TYPE table.
2. The load timestamp is used to filter the data in the get_targeted_skus CTE.
***********************/
#}
, max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
)

{#
/**********************
1. The get_targeted_skus CTE is used to get the distinct product_type, unique_brand_name and item_cd from the CAMPAIGN_PRODUCT_TYPE table.
2. We are filtering the data based on the campaign_id, channel_name, subchannel_name and load_ts.
3. The load timestamp is used to filter the data in the get_targeted_skus CTE.
4. We are getting latest records from campaign_product_type table.
5. This cte will reduce the read time from campaign_product_type table as it is referenced multiple time.
***********************/
#}
, get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where campaign_id = '{{ campaignid }}'
    and channel_name = '{{ channel }}'
    and subchannel_name = '{{ subchannel }}'
    and load_ts = (select load_ts from max_load_ts)
    
)

{#
/**********************
1. The get_fact_sale_transaction_basket CTE is used to get the transaction_end_ts, nectar_card_num_hash, transaction_id, transaction_dt and sales_origination_channel_cd from the FACT_SALE_TRANSACTION_BASKET table.
2. We are filtering the data based on the nectar_card_num_hash, transaction_dt and sales_origination_channel_cd.
3. We are creating this CTE to reduce read time from transaction_basket table as it is referenced multiple time.
***********************/
#}
, get_fact_sale_transaction_basket as (
    select
        transaction_end_ts
        , nectar_card_num_hash
        , transaction_id
        , transaction_dt
        , sales_origination_channel_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
    where
        nectar_card_num_hash is not null
        and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#
/**********************
1. The fact_Sale_transaction_item CTE is used to get the transaction_id, transaction_dt, item_cd, net_retail_sales_amt, item_qty and item_sequence_num from the FACT_SALE_TRANSACTION_ITEM table.
2. We are filtering the data based on the transaction_dt and net_retail_sales_amt.
3. We are creating this CTE to reduce read time from transaction_item table as it is referenced multiple time.
***********************/
#}
, get_fact_sale_transaction_item as (
    select
        transaction_id
        , transaction_dt
        , item_cd
        , net_retail_sales_amt
        , item_qty
        , item_sequence_num
        , store_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
    where 
        transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and net_retail_sales_amt > 0   
)

{#
/**********************
1. The get_instore_relevant_transaction_distinct CTE is  used to get transaction details for the instore transactions.
2. We are filtering the data based on the nectar_collector_card_num, household_num, store_cd and customer_account_type_name.
3. We are joining the DIM_CUSTOMER_LOYALTY table with FACT_SALE_TRANSACTION_BASKET and FACT_SALE_TRANSACTION_ITEM table to get the transaction details.
4. We are filtering the data based on the sales_origination_channel_cd.
5. The item_sequence_num is used to avoid sales mismatch as some transactions in the transaction item table have the same transaction_id and item_cd but different item_sequence_num.
***********************/
#}
, get_instore_relevant_transaction_distinct as (
    select
        dcl.nectar_collector_card_num as loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , 'NA' as marketing_type
        , 'In-store' as channel
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
    inner join get_fact_sale_transaction_basket as gfstb
        on gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
    inner join get_fact_sale_transaction_item as gfsti
        on gfsti.transaction_id = gfstb.transaction_id
    inner join get_targeted_skus as gts
        on gts.item_cd = gfsti.item_cd
    {% if campaignDuration == 'Post' %}
        inner join instore_customer_data_post_period as icd
        on dcl.nectar_collector_card_num = icd.loyalty_id
    {% endif %}
    where
        dcl.nectar_collector_card_num != '~~'
        and dcl.household_num != '0'
        and gfsti.store_cd in
        (
            select distinct location_key
            from store_location
        )
        and upper(dcl.customer_account_type_name) = 'NECTAR'
        and gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
        )
    
)

{#
/**********************
1. Getting total sales and units for each loyalty id, transaction_key, event_date, item_cd, unique_brand_name, marketing_type, channel, campaign_name, campaign_id, event_name, booking_id and product_type.
***********************/
#}
, instore_relevant_transaction as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from get_instore_relevant_transaction_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. Adding touchpoint for instore transactions.
2. For touchpoint we are using the event_time from the get_instore_relevant_transaction CTE. We are subtracting 100 milliseconds from the event_time to get the touchpoint time.
***********************/
#}
, instore_converted_touchpoint as (
    select distinct
        loyalty_id
        , transaction_key
        , event_date
        , timeadd(millisecond, -100, event_time) as event_time
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel
        , '{{ subchannel }}' as subchannel
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from instore_relevant_transaction
)

{#
/**********************
1. For instore campaigns the only way to know if someone has seen the campaign is to check if they have bought something.
2. We are getting the touchpoint for those who have not bought the targeted skus.
3. We are filtering the data based on the nectar_collector_card_num, household_num, store_cd and customer_account_type_name.
4. We are joining the DIM_CUSTOMER_LOYALTY table with FACT_SALE_TRANSACTION_BASKET and FACT_SALE_TRANSACTION_ITEM table to get the transaction details.
5. We are filtering the data based on the sales_origination_channel_cd.
6. Since this is touchpint for non conversion transaction key is null. 
***********************/
#}
, instore_nonconverted_touchpoint as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , null as transaction_key
        , gfsti.transaction_dt as event_date
        , timeadd(millisecond, -100, gfstb.transaction_end_ts) as event_time
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel
        , '{{ subchannel }}' as subchannel
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
    inner join get_fact_sale_transaction_basket as gfstb
        on gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
    inner join get_fact_sale_transaction_item as gfsti
        on gfsti.transaction_id = gfstb.transaction_id
    {% if campaignDuration == 'Post' %}
        inner join instore_customer_data_post_period as icd
        on dcl.nectar_collector_card_num = icd.loyalty_id
    {% endif %}
    where
        dcl.nectar_collector_card_num != '~~'
        and dcl.household_num != '0'
        and gfsti.store_cd in
        (
            select distinct location_key
            from store_location
        )
        and upper(dcl.customer_account_type_name) = 'NECTAR'
        and gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
        )
        and gfsti.item_cd not in
        (
            select distinct item_cd
            from get_targeted_skus
        )
        and gfsti.transaction_id not in
        (
            select distinct transaction_key
            from instore_converted_touchpoint
        )
)

{# /* getting all the loyalty ids who bought something. This step is done as in the later stage we will capture transaction
    and touchpoint details of those from these loyalty ids who bought targetted skus online */ #}
, get_all_loyalty_ts as (
        select
            loyalty_id
            , event_time
        from instore_relevant_transaction
        union all
        select
            loyalty_id
            , event_time
        from instore_nonconverted_touchpoint
)

{#  /*getting the minimum timestamp of interaction for every loyalty id as it would be used in the touchpoint for online tranasactions */ #}
, get_min_timestamp as (
    select
        loyalty_id
        , min(event_time) as event_ts
    from get_all_loyalty_ts
    group by loyalty_id
)

{# /* getting online transaction details for all the loyalty ids who bought something from instore within the campaign period.
Applied necessary sales_originiation_Cd filter to accomodate only online sales. */ #}
, get_online_transaction_distinct as (
    select
        gmt.loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , 'NA' as marketing_type
        , 'Online' as channel
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.item_sequence_num
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
    from get_min_timestamp as gmt
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on dcl.nectar_collector_card_num = gmt.loyalty_id
    inner join get_fact_sale_transaction_basket as gfstb
        on gfstb.nectar_card_num_hash = dcl.customer_loyalty_cd
    inner join get_fact_sale_transaction_item as gfsti
        on gfsti.transaction_id = gfstb.transaction_id
     inner join get_targeted_skus as gts
        on gts.item_cd = gfsti.item_cd 
    where
        gfsti.transaction_dt <= '{{ endDate }}'
        and gfstb.transaction_end_ts > gmt.event_ts
        and dcl.nectar_collector_card_num != '~~'
        and dcl.household_num != '0'
        and upper(dcl.customer_account_type_name) = 'NECTAR'
        and gfstb.sales_origination_channel_cd in (
            select online_codes.value
            from table(flatten(input => {{ var('sales_origination_online_codes') }}::array)) as online_codes
        )
        and gfsti.item_cd in
        (
            select distinct item_cd
            from get_targeted_skus
        )
)

{#  /* getting total sales and units for each loyalty id, transaction_key, event_date, item_cd, unique_brand_name, marketing_type
    channel, campaign_name, campaign_id, event_name, booking_id and product_type for online transactions */ #}
, get_online_transaction as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from get_online_transaction_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. Adding touchpoint for online transactions.
2. For touchpoint we are using the event_time from the get_online_transaction CTE for the loyalty ids who bought something online.
3. For online touchpoint we are using the event_ts from the get_min_timestamp CTE, which means we are using the minimum timestamp of transaction in the instore for every loyalty id.
***********************/
#}
, get_online_touchpoint as (
    select distinct
        got.loyalty_id
        , got.transaction_key
        , date(gmt.event_ts) as event_date
        , gmt.event_ts
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel
        , '{{ subchannel }}' as subchannel
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from get_online_transaction as got
    inner join get_min_timestamp as gmt
        on got.loyalty_id = gmt.loyalty_id
)

{#
/**********************
1. The instore_data_collection CTE is used to get the transaction and touchpoint details for the instore transactions.
2. We are using the instore_relevant_transaction, instore_converted_touchpoint and instore_nonconverted_touchpoint CTEs to get the transaction and touchpoint details.
3. We are using the get_online_transaction and get_online_touchpoint CTEs to get the online transaction and touchpoint details.
4. We are using the union all operator to combine the data from all the CTEs.
5. Item_cd, product_type, unique_brand_name, net_sales_amt and units_qty are null for touchpoint data.
***********************/
#}
, instore_data_collection as (
    select
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel as channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from instore_relevant_transaction
    union all
    select
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel as channel_name
        , subchannel as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from instore_converted_touchpoint
    union all
    select
        loyalty_id
        , null as transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel as channel_name
        , subchannel as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from instore_nonconverted_touchpoint
    union all
    select
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel as channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from get_online_transaction
    union all
    select
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_ts
        , marketing_type
        , channel as channel_name
        , subchannel as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from  get_online_touchpoint
)

{#
/**********************
1. The final select statement is used to get the final data for the instore data collection.
2. We are using the coalesce function to handle null values for transaction_key, item_cd, product_type and unique_brand_name as null values are not allowed in the final table.
3. We are using the current timestamp as load_ts and job_run_id as the invocation_id.
***********************/
#}
select
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz as load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , '{{ invocation_id }}' as job_run_id
from instore_data_collection

{% endset %}

    {% do return(instore_sql) %}

{% endmacro %}
