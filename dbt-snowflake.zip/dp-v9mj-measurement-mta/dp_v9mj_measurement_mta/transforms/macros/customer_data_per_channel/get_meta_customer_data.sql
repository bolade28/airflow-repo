{#
/*********************************************************************************************************************************************
* Objective - The objective of this script is to process and consolidate transaction and touchpoint data for campaigns executed through
the Meta channel. It combines data from multiple sources, including audience details,campaign product types, and sales transactions,
to create a unified dataset with enriched campaign insights. The final output provides a comprehensive view of customer interactions,
purchases, and campaign performance for Meta campaigns.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: META_CUSTOMER_DATA
*
* This script will return transaction and touchpoint data for meta channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
********/
#}

{% macro get_meta_customer_data() %}
{# /* Getting meta specific campaign details */ #}
{% if dbt_unit_testing.running_unit_test() %}
    -- Use the mock macro during unit testing, DBT runs them separate to the main script so we have to mock them for the unit test to work correctly
    {% set campaignData = mock_get_campaign_list_meta() %}
{% else %}
    -- Use the real macros during normal runs
    {% set campaignData = get_campaign_channel_specific_data('Meta') %}
{% endif %}
{% set campaignName =  campaignData[0] %}
{% set channel =  campaignData[1] %}
{% set startDate =  campaignData[2] %}
{% set endDate =  campaignData[3] %}
{% set campaignid =  campaignData[4] %}
{% set subchannel =  campaignData[5] %}
{% set bookingId =  campaignData[6] %}
{% set campaignDuration =  campaignData[7] %}
{% set job_bag_id = campaignData[8] %}
{% set marketing_type = campaignData[9] %}

{% set meta_sql %}

{#
/**********************************
1. The ab_audience_max CTE gets the max record arrival timestamp for each audience group.
2. We are doing this step to get latest records from audience group table in the next step.
**********************************/
#}
with ab_audience_max as (
    select
        digital_trading_audience_group_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT') }}
    where job_bag_id ilike '%nec%' or job_bag_id is null
    group by digital_trading_audience_group_nk1
)

{#
/********************************
1. The ab_audience_latest CTE gets the latest records from the audience group table.
2. We are using the max record arrival timestamp from the previous CTE to filter the records.
3. The ab_audience_data CTE extracts relevant details from the latest records of the audience group.
*********************************/
#}

{% if dbt_unit_testing.running_unit_test() %}
,  ab_audience_latest as (
    select
        digital_trading_audience_group_nk1
        , parse_json(audiences_data) as audiences_data
        , parse_json(modelled_audiences_data) as modelled_audiences_data
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT') }}
    where
        (digital_trading_audience_group_nk1, record_arrival_ts) in
        (select
            digital_trading_audience_group_nk1
            , record_arrival_ts
        from ab_audience_max)
)

{% else %}

, ab_audience_latest as (
    select
        digital_trading_audience_group_nk1
        , audiences_data
        , modelled_audiences_data
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_GROUP_DMABAG_SAT') }}
    where
        (digital_trading_audience_group_nk1, record_arrival_ts) in
        (select
            digital_trading_audience_group_nk1
            , record_arrival_ts
        from ab_audience_max)
)

{% endif %}

{#
/***********************
1. The ab_audience_data CTE extracts relevant details from the audience data.
2. Extracts specific fields (channels, _id, name) from the JSON objects stored in the audiences_data column of the ab_audience_latest table.
3. Doc_id_raw is a JSON string that contains the document ID.
4. The extracted docid will be joined with  can be joined with DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK
5. Aud_id will be used to join with AUDIENCE_SNAPSHOT_DEDUPED table.
6. The subchannel_name will be used while adding touchpoint for the loyalty_id.
***********************/
#}
, ab_audience_data as (
    select distinct
        aal.digital_trading_audience_group_nk1
        , json_extract_path_text(audience_data.value, 'channels') as docids_raw
        , json_extract_path_text(audience_data.value, '_id') as aud_id
        , json_extract_path_text(audience_data.value, 'name') as subchannel_name
    from ab_audience_latest as aal
    , lateral flatten(input => aal.audiences_data) as audience_data
)

{#
/***********************
1. The ab_modelled_audience CTE extracts relevant details from the audience data. Apart from the audience data, modelled_audience data also has the relevant data.
2. Extracts specific fields (channels, _id, name) from the JSON objects stored in the modelled_audience_data column of the ab_audience_latest table.
3. Doc_id_raw is a JSON string that contains the document ID.
4. The extracted docid will be joined with  can be joined with DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK
5. Aud_id will be used to join with AUDIENCE_SNAPSHOT_DEDUPED table.
6. The subchannel_name will be used while adding touchpoint for the loyalty_id.
***********************/
#}
, ab_modelled_audience as (
    select distinct
        aal.digital_trading_audience_group_nk1
        , json_extract_path_text(modelled_audience.value, 'channels') as docids_raw
        , json_extract_path_text(modelled_audience.value, '_id') as aud_id
        , json_extract_path_text(modelled_audience.value, 'name') as subchannel_name
    from ab_audience_latest as aal
    , lateral flatten(input => aal.modelled_audiences_data) as modelled_audience
)

{#
/***********************
1. The ab_audience_union CTE combines the results from the ab_audience_data and ab_modelled_audience CTEs.
2. This is done to create a single cte that contains both audience data and modelled audience data.
***********************/
#}
, ab_audience_union as (
    select * from ab_audience_data
    union
    select * from ab_modelled_audience
)

{#
/***********************
1. The ab_audience_filtered extracts document IDs from the docids_raw column of the ab_audience_union table.
2. The docids_raw column is a JSON string that contains the document IDs.
3. The docids are extracted using the json_extract_path_text function.
4. The extracted docids will be joined with DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK table.
***********************/
#}
, ab_audience_filtered as (
    select distinct
        aau.digital_trading_audience_group_nk1
        , aau.aud_id
        , aau.subchannel_name
        , json_extract_path_text(docids.value, 'documentId') as docid
    from ab_audience_union as aau
    , lateral flatten(input => try_parse_json(aau.docids_raw)) as docids
    where aau.docids_raw != '[]'
)

{#
/***********************
1. The adset_link_max CTE gets the max record arrival timestamp for the unique combination of digital_trading_lineitem_channel_nk1, digital_trading_lineitem_nk1, and digital_trading_campaign_nk1.
2. This is done so that in the later step we can get the latest records from the adset table.
***********************/
#}
, adset_link_max as (
    select
        digital_trading_lineitem_channel_nk1
        , digital_trading_lineitem_nk1
        , digital_trading_campaign_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_CHANNEL_DMFBAS_LINK') }}
    group by digital_trading_lineitem_channel_nk1, digital_trading_lineitem_nk1, digital_trading_campaign_nk1
)

{#
/***********************
1. Getting latest records from adset link table using the max record arrival timestamp from the previous CTE.
2. The digital_trading_lineitem_channel_nk1, digital_trading_lineitem_nk1, and digital_trading_campaign_nk1 are used to join with the adset table.
***********************/
#}
, adset_link_latest as (
    select
        digital_trading_lineitem_channel_nk1
        , digital_trading_lineitem_nk1
        , digital_trading_campaign_nk1
        , record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_CHANNEL_DMFBAS_LINK') }}
    where
        (
            digital_trading_lineitem_channel_nk1
            , digital_trading_lineitem_nk1
            , digital_trading_campaign_nk1
            , record_arrival_ts
        )
        in (
            select
                digital_trading_lineitem_channel_nk1
                , digital_trading_lineitem_nk1
                , digital_trading_campaign_nk1
                , record_arrival_ts
            from adset_link_max
        )
)

{#
/***********************
1. Finding max record arrival_ts from adset sat table using the max record arrival timestamp from the previous CTE.
2. The adset_name is extracted as it can be used as subchannel_name.
2. This is done to get the latest records for the adset_sat table in the later cte.
***********************/
#}
, adset_max as (
    select
        digital_trading_lineitem_nk1
        , adset_name
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_DMFBAS_SAT') }}
    group by digital_trading_lineitem_nk1, adset_name
)

{#
/***********************
1. Getting latest records from adset sat table using the max record arrival timestamp from the previous CTE.
2. The adset_name is extracted as it can be used as subchannel_name.
3. The target_custom_audience_list is extracted as it can be used to get the adset_document_id.
4. The adset_document_id  can be used to join with the DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK table.
***********************/
#}
{% if dbt_unit_testing.running_unit_test() %}


, adset_latest as (
    select
        digital_trading_lineitem_nk1
        , adset_name
        , parse_json(target_custom_audience_list) as target_custom_audience_list
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_DMFBAS_SAT') }}
    where
        (digital_trading_lineitem_nk1, adset_name, record_arrival_ts)
        in (select
            digital_trading_lineitem_nk1
            , adset_name
            , record_arrival_ts
        from adset_max)
)

{% else %}

, adset_latest as (
    select
        digital_trading_lineitem_nk1
        , adset_name
        , target_custom_audience_list
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_LINEITEM_DMFBAS_SAT') }}
    where
        (digital_trading_lineitem_nk1, adset_name, record_arrival_ts)
        in (select
            digital_trading_lineitem_nk1
            , adset_name
            , record_arrival_ts
        from adset_max)
)

{% endif %}

{#
/***********************
1. Extracting adset_document_id from the target_custom_audience_list column.
2. The adset_document_id is extracted from the JSON object stored in the target_custom_audience_list column.
3. The adset_document_id can be used to join with the DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK table.
4. The adset_name is extracted as it can be used as subchannel_name.
***********************/
#}
, adset as (
    select distinct
        al.digital_trading_lineitem_nk1
        , json_extract_path_text(audience_list.value, 'id') as adset_document_id
    from adset_latest as al
    , lateral flatten(input => al.target_custom_audience_list) as audience_list
    where audience_list.index = 0
)

{#
/**********************
1. The fb_campaign_max CTE gets the max record arrival timestamp for each digital_trading_campaign_nk1.
2. This is done so that in the later step we can get the latest records from the campaign table.
***********************/
#}
, fb_campaign_max as (
    select
        digital_trading_campaign_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT') }}
    where job_bag_id = '{{ campaignid }}'
    group by digital_trading_campaign_nk1
)

{#
/**********************
1. The fb_campaign_latest CTE filters records with the max record arrival timestamp for each digital_trading_campaign_nk1.
2. This is done so that in the later we can join adset_link_latest with fb_campaign_latest.
***********************/
#}
, fb_campaign_latest as (
    select
        digital_trading_campaign_nk1
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_CAMPAIGN_DMFBCA_SAT') }}
    where
        (digital_trading_campaign_nk1, record_arrival_ts)
        in (
            select
                digital_trading_campaign_nk1
                , record_arrival_ts
            from fb_campaign_max
        )
)

{#
/**********************
1. The fb_audience_max CTE gets the max record arrival timestamp for each digital_trading_campaign_nk1,digital_trading_audience_channel_nk1
2. This is done so that in the later step we can get the latest records from the DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK campaign table.
***********************/
#}
, fb_audience_max as (
    select
        digital_trading_audience_nk1
        , digital_trading_audience_channel_nk1
        , max(record_arrival_ts) as record_arrival_ts
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK') }}
    group by digital_trading_audience_nk1, digital_trading_audience_channel_nk1
)

{#
/**********************
1. The fb_audience_latest CTE gets the max record arrival timestamp for each digital_trading_campaign_nk1,digital_trading_audience_channel_nk1
2. This is done so that in the later step we can join with adset cte on adset_document_id.
***********************/
#}
, fb_audience_latest as (
    select
        digital_trading_audience_channel_nk1
        , digital_trading_audience_nk1
    from {{ source('ADW_RDV', 'DIGITAL_TRADING_AUDIENCE_CHANNEL_DMFBAU_LINK') }}
    where
        (digital_trading_audience_nk1, digital_trading_audience_channel_nk1, record_arrival_ts)
        in (select
            digital_trading_audience_nk1
            , digital_trading_audience_channel_nk1
            , record_arrival_ts
        from fb_audience_max)
)

{#
/**********************
1. The fb_loyal CTE gets the loyalty_id, subchannel_name, and aud_id from the fb_campaign_latest, adset_link_latest, adset, fb_audience_latest, ab_audience_filtered, and AUDIENCE_SNAPSHOT_DEDUPED tables.
2. The subchannel_name will be used while adding touchpoint for the loyalty_id.
3. The trim function is used to remove leading and trailing spaces from the adset_name after splitting it by '|'.
***********************/
#}
, fb_loyal as (
    select distinct
        asd.loyalty_id
        , aaf.aud_id
    from fb_campaign_latest as fcl
    inner join adset_link_latest as adl
        on fcl.digital_trading_campaign_nk1 = adl.digital_trading_campaign_nk1
    inner join adset as ad
        on adl.digital_trading_lineitem_nk1 = ad.digital_trading_lineitem_nk1
    inner join fb_audience_latest as fal
        on ad.adset_document_id = fal.digital_trading_audience_channel_nk1
    inner join ab_audience_filtered as aaf
        on fal.digital_trading_audience_nk1 = aaf.docid
    inner join {{ source('AB', 'AUDIENCE_SNAPSHOT_DEDUPED') }} as asd
        on aaf.aud_id = asd.audience_id
)

{#
/******************************
1. The get_fact_sale_transaction_basket CTE gets the transaction_end_ts, nectar_card_num_hash, transaction_id, transaction_dt, and sales_origination_channel_cd from the FACT_SALE_TRANSACTION_BASKET table.
2. This cte is created to reduce read time from the transaction_basket table as it is referenced multiple times.
****************************/
#}
, get_fact_sale_transaction_basket as (
    select
        transaction_end_ts
        , nectar_card_num_hash
        , transaction_id
        , transaction_dt
        , sales_origination_channel_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
    where
        nectar_card_num_hash is not null
        and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#
/**********************
1. The get_fact_sale_transaction_item CTE gets the transaction_id, transaction_dt, item_cd, net_retail_sales_amt, item_qty, item_sequence_num, and store_cd from the FACT_SALE_TRANSACTION_ITEM table.
2. This cte is created to reduce read time from the transaction_item table as it is referenced multiple times.
***********************/
#}
, get_fact_sale_transaction_item as (
    select
        transaction_id
        , transaction_dt
        , item_cd
        , net_retail_sales_amt
        , item_qty
        , item_sequence_num
        , store_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
    where 
        transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and net_retail_sales_amt > 0   
)


{#
/**********************
1. The max_load_ts CTE gets the max load_ts timestamp for each CAMPAIGN_PRODUCT_TYPE
2. This is done so that in the later step we can get the latest records from the CAMPAIGN_PRODUCT_TYPE table.
***********************/
#}
, max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
)

{#
/**********************
1. The get_targeted_skus CTE gets the latest  product_type, unique_brand_name, and item_cd from the CAMPAIGN_PRODUCT_TYPE table for the given campaign_id, channel_name, and subchannel_name.
2. This is done so that we can save time by not reading the entire CAMPAIGN_PRODUCT_TYPE table and only reading the latest records.
***********************/
#}
, get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where campaign_id = '{{ campaignid }}'
    and channel_name = '{{ channel }}'
    and subchannel_name = '{{ subchannel }}'
    and load_ts = (select load_ts from max_load_ts)
    
)

{#
/**********************
1. The fb_txn_distinct CTE gets the transaction_id, transaction_dt, item_cd, net_retail_sales_amt, item_qty, item_sequence_num, and store_cd from the FACT_SALE_TRANSACTION_ITEM table.
2. The distinct keyword is used with item_sequence_num to handle the case  where we have multiple records for the same transaction_id and item_cd.
3. Channel name is determined based on the sales_origination_channel_cd. This value is used to determine whether the transaction is in-store or online. It is taken from dbt_project.yml.
4. The marketing_type is set to 'NA' as it is not used in the current context.
5. Here we are getting transaction details for all kinds of product type like offer,brand,aisle.
***********************/
#}
, fb_txn_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , case when gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
        ) then 'In-store'
        else 'Online' end as channel_name
        , 'NA' as marketing_type
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from get_fact_sale_transaction_item as gfsti
    inner join get_fact_sale_transaction_basket as gfstb
        on gfsti.transaction_id = gfstb.transaction_id
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    where
        gfsti.transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and gfsti.net_retail_sales_amt > 0
        and gfstb.nectar_card_num_hash is not null
        and dcl.nectar_collector_card_num
        in
        (
            select distinct loyalty_id
            from fb_loyal
        )
        and gfstb.sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#
/**********************
1. The fb_txn cte the total sales amount and units for each loyalty_id,transaction_id, item_cd,event_date, event_time, unique_brand_name, marketing_type, channel_name, campaign_name, campaign_id, event_name, booking_id, product_type.
2. The fb_txn table will be later used to get the transaction_key for the touchpoint.
***********************/
#}
, fb_txn as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from fb_txn_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. The fb_non_converted_transaction_touchpoint CTE gets the loyalty_id, subchannel_name from the fb_loyal table.
2. Here we are adding touchpoint to those loyalty_ids who did not buy the targeted items.
***********************/
#}
, fb_non_converted_transaction_touchpoint as (
    select distinct
        fbl.loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , '{{ startDate }}' as event_date
        , to_timestamp('{{ startDate }} 00:00:00') as event_time
        , null as transaction_key
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from fb_loyal as fbl
    where
        fbl.loyalty_id not in
        (select distinct loyalty_id from fb_txn)
)

{#
/**********************
1. The fb_transaction_touchpoint CTE gets the loyalty_id, subchannel_name from the fb_loyal table.
2. Here we are adding touchpoint to those loyalty_ids who bought the targeted items.
3. The fb_txn table is used to get the transaction_key for the touchpoint.
4. Event_date and event_time are set to the campaign start date and time.
***********************/
#}
, fb_transaction_touchpoint as (
    select distinct
        fb_txn.loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , '{{ startDate }}' as event_date
        , to_timestamp('{{ startDate }} 00:00:00') as event_time
        , fb_txn.transaction_key
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from fb_txn
)

{#
/**********************
1. The meta_data_collection CTE combines the results from the fb_txn, fb_transaction_touchpoint, and fb_non_converted_transaction_touchpoint CTEs.
2. Here we have consolidated the data from all the CTEs to create a single cte that contains both transaction and touchpoint data.
3. For touchpoint data, we are using null values for  item_cd, product_type, unique_brand_name, net_sales_amt, and units_qty as they are added on loyalty_id level.
***********************/
#}
, meta_data_collection as (
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from fb_txn
    union all
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from fb_transaction_touchpoint
    union all
    select distinct
        loyalty_id
        , null as transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from fb_non_converted_transaction_touchpoint
)

{#
/**********************
1. The meta_data_collection CTE gets the loyalty_id, transaction_key, event_dt, event_ts, marketing_type, channel_name, subchannel_name, campaign_name, campaign_id, event_name, booking_id, item_cd, product_type, unique_brand_name, net_sales_amt, and units_qty from the meta_data_collection table.
2. The current_timestamp is used to get the load_ts timestamp.
3. The item_cd, product_type, unique_brand_name, net_sales_amt, and units_qty are set to 0 or 'NA' if they are null as null values are not allowed in the table.
4. The job_run_id is set to the invocation_id.
***********************/
#}
select distinct
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz as load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , '{{ invocation_id }}' as job_run_id
from meta_data_collection

{% endset %}

{{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

    {% do return(meta_sql) %}

{% endmacro %}