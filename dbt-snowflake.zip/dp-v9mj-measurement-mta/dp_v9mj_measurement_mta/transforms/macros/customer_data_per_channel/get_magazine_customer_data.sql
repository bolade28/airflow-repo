{#
/*********************************************************************************************************************************************
* Objective - This script retrieves transaction and touchpoint data for the Magazine channel, focusing on customers who engaged
with magazine campaigns. It consolidates data from various sources to provide insights into customer interactions, purchases
and campaign performance during and after the campaign period.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/838828574/Customer+Data+Collection
* Upstream: CAMPAIGN_PRODUCT_TYPE, MEASUREMENT_CAMPAIGN_EXECUTION
* Downstream: CUSTOMER_DATA_COLLECTION
* This script will return transaction and touchpoint data for magazine channel.
* Owner : Aditya Mohanty
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*****************************************************************************/
#}

{% macro get_magazine_customer_data() %}

{#  /*getting campaign specific details for sainburys magazine */ #}
{% if dbt_unit_testing.running_unit_test() %}
    -- Use the mock macro during unit testing, DBT runs them separate to the main script so we have to mock them for the unit test to work correctly
    {% set campaignData = mock_get_campaign_list_magazine() %}
{% else %}
    -- Use the real macros during normal runs
    {% set campaignData = get_campaign_channel_specific_data('Sainburys Magazine') %}
{% endif %}

{% set campaignName =  campaignData[0] %}
{% set channel =  campaignData[1] %}
{% set startDate =  campaignData[2] %}
{% set endDate =  campaignData[3] %}
{% set campaignid =  campaignData[4] %}
{% set subchannel =  campaignData[5] %}
{% set bookingId =  campaignData[6] %}
{% set campaignDuration =  campaignData[7] %}
{% set job_bag_id = campaignData[8] %}
{% set marketing_type = campaignData[9] %}

{% set magazine_sql %}

{% if campaignDuration == 'During' %}

{#
/**********************
1. The magazine_date_lookup table is used to get the start, end date and sku_no of the magazine.
2. We are getting start_date,end_Date from date look up table to validate it with the campaign's start and end date.
***********************/
#}
with magazine_date_lookup as (
    select distinct
        start_date
        , end_date
        , sku_no
    from {{ source('I2CUSER', 'MAGAZINE_DATE_LOOKUP') }}
)

{#
/**********************
1. The get_fact_sale_transaction_basket table is used to get the transaction details for the customers who bought the targeted skus within the campaign period.
2. The sales_origination_channel_cd is used to filter the transaction details for the customers who bought the targeted skus from the selected channels.
3. We are using this cte to avoid multiple calls to the source table. This will reduce the fetch time from the source table.
***********************/
#}
, get_fact_sale_transaction_basket as (
    select
        transaction_end_ts
        , nectar_card_num_hash
        , transaction_id
        , transaction_dt
        , sales_origination_channel_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_BASKET') }}
    where
        nectar_card_num_hash is not null
        and transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and sales_origination_channel_cd in (
            select all_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as all_codes
        )
)

{#
/**********************
1. The get_fact_sale_transaction_item table is used to get the transaction details for the customers who bought the targeted skus within the campaign period.
2. We are using this cte to avoid multiple calls to the source table. This will reduce the fetch time from the source table.
***********************/
#}
, get_fact_sale_transaction_item as (
    select
        transaction_id
        , transaction_dt
        , item_cd
        , net_retail_sales_amt
        , item_qty
        , item_sequence_num
        , store_cd
    from {{ source('ADW_SALES_PL', 'FACT_SALE_TRANSACTION_ITEM') }}
    where 
        transaction_dt between '{{ startDate }}' and '{{ endDate }}'
        and net_retail_sales_amt > 0   
)

{#
/**********************
1. The magazine_transaction_data CTE gets the loyalty_id, event_time and event_date from the get_fact_sale_transaction_item and get_fact_sale_transaction_basket tables.
2. The event_time and event_date will be used while adding touchpoint for the customers who bought the targeted skus.
3. The sales_origination_channel_cd is used to filter the transaction details for the customers who bought the targeted skus from instore only as magazines are sold in the in-store channel.
4. Magazine specific sku is used to join item_cd from get_fact_sale_transaction_item.
***********************/
#}
, magazine_transaction_data as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfstb.transaction_end_ts as event_time
        , date(gfstb.transaction_end_ts) as event_date
    from get_fact_sale_transaction_item as gfsti
    inner join get_fact_sale_transaction_basket as gfstb
        on gfsti.transaction_id = gfstb.transaction_id
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join magazine_date_lookup as mdl
        on gfsti.item_cd = mdl.sku_no
    where
        mdl.start_date = '{{ startDate }}'
        and mdl.end_date = '{{ endDate }}'
        and gfstb.transaction_end_ts >= mdl.start_date
        and gfstb.transaction_end_ts <= mdl.end_date
        and gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from
                table(
                    flatten(input => {{ var('sales_origination_instore_codes') }}::array
                    )
                ) as instore_codes
        )
)

{#
/**********************
1. We are applying the min function on event_time and event_date to get the first transaction date and time for each loyalty_id.
2. We are doing this to avoid multiple touchpoints for the same customer.
3. The event_time and event_date will be used while adding touchpoint for the customers who bought the targeted skus.
***********************/
#}
, magazine_loyalty_data as (
    select
        loyalty_id
        , min(event_time) as event_time
        , min(event_date) as event_date
    from magazine_transaction_data
    group by loyalty_id
)

{% else %}

{#
/**********************
1. In the post campaign period the campaign end date that we get is post campaign date. 
2.However to validate the campaign end date we are using the campaign end date from the date lookup table. To get the original campaign end date we are getting it from unified_campaign table.
***********************/
#}
with unified_data as (
    select 
        campaign_id, 
        channel_name, 
        subchannel_name, 
        marketing_type, 
        campaign_start_dt, 
        campaign_end_dt
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }}
        where booking_id = '{{ bookingId }}' and 
        channel_name = '{{ channel }}' and
        subchannel_name = '{{ subchannel }}' and
        marketing_type = '{{ marketing_type }}' and
        campaign_start_dt = '{{ startDate }}' and
        post_campaign_dt = '{{ endDate }}' and 
        load_ts = (select max(load_ts) from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }})
),

{#
/**********************
1. Since campaign duration is post this means we have already run this campaign for the during period.
2. So from customer data collection table we can get the minimum event date and time which will be the time when they got the magazine.
***********************/
#}
magazine_loyalty_data as (
    select 
        distinct cdc.loyalty_id,
        min(event_ts) as event_time,
        min(event_dt) as event_date
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','CUSTOMER_DATA_COLLECTION') }} cdc
    left join unified_data ud
    on cdc.campaign_id = ud.campaign_id
    and cdc.channel_name = ud.channel_name
    and cdc.subchannel_name = ud.subchannel_name
    and cdc.marketing_type = ud.marketing_type
    where cdc.event_dt between ud.campaign_start_dt and ud.campaign_end_dt
    group by cdc.loyalty_id
)
{% endif %}


{#
/**********************
1. The max_load_ts CTE is used to get the maximum load timestamp for the campaign product type table.
2. We are using this to get the latest data from the campaign product type table.
3. This is done to avoid multiple calls to the source table. This will reduce the fetch time from the source table.
***********************/
#}
, max_load_ts as (
    select
        max(load_ts) as load_ts
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where
        campaign_id = '{{ campaignid }}'
        and channel_name = '{{ channel }}'
        and subchannel_name = '{{ subchannel }}'
)

{#
/**********************
1. The get_targeted_skus CTE is used to get the targeted skus for the campaign.
2. Here we are adding the campaign_id,channel_name and subchannel_name filter to get product details for them.
3. This will reduce the fetch time from the source table.
***********************/
#}
, get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where campaign_id = '{{ campaignid }}'
    and channel_name = '{{ channel }}'
    and subchannel_name = '{{ subchannel }}'
    and load_ts = (select load_ts from max_load_ts)
    
)

{#
/**********************
1. The get_magazine_sku_transaction_data_distinct CTE is used to get the transaction details for the customers who bought the targeted skus within the campaign period.
2. The sales_origination_channel_cd is used to filter the transaction details for the customers who bought the targeted skus from the selected channels.
3. The get_fact_sale_transaction_item and get_fact_sale_transaction_basket tables are used to get the transaction details for the customers who bought the targeted skus within the campaign period.
4. The item_sequence_num is used in case we have multiple records for the same item in the same transaction.
5. The targetted customers are those who bought the magazine on the same day of transaction or before the transaction. So we are using this filter gfstb.transaction_end_ts >= mdl.event_time.
6. The sales_origination_channel_cd is used to filter the transaction details for the customers who bought the targeted skus from the selected channels.
***********************/
#}
, get_magazine_sku_transaction_data_distinct as (
    select distinct
        dcl.nectar_collector_card_num as loyalty_id
        , gfsti.transaction_id as transaction_key
        , gfsti.transaction_dt as event_date
        , gfsti.item_cd
        , gfstb.transaction_end_ts as event_time
        , 'NA' as marketing_type
        , case when gfstb.sales_origination_channel_cd in (
            select instore_codes.value
            from table(flatten(input => {{ var('sales_origination_instore_codes') }}::array)) as instore_codes
        ) then 'In-store'
        else 'Online' end as channel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , 'Purchase Transaction' as event_name
        , '{{ bookingId }}' as booking_id
        , gts.product_type
        , gts.unique_brand_name
        , gfsti.net_retail_sales_amt
        , gfsti.item_qty
        , gfsti.item_sequence_num
    from get_fact_sale_transaction_item as gfsti
    inner join get_fact_sale_transaction_basket as gfstb
        on gfsti.transaction_id = gfstb.transaction_id
    inner join magazine_loyalty_data as mdl
        on
            gfstb.nectar_card_num_hash = mdl.loyalty_id
            and gfstb.transaction_end_ts >= mdl.event_time
    inner join {{ source('ADW_PL', 'DIM_CUSTOMER_LOYALTY') }} as dcl
        on dcl.customer_loyalty_cd = gfstb.nectar_card_num_hash
    inner join get_targeted_skus as gts
        on gfsti.item_cd = gts.item_cd
    where
        dcl.nectar_collector_card_num != '~~'
        and gfstb.sales_origination_channel_cd in (
            select magazine_codes.value
            from table(flatten(input => {{ var('sales_origination_all_codes') }}::array)) as magazine_codes
        )
)


{#
/**********************
1. The magazine_sku_transaction_data cte gets the total sales and units for eacch loyalty_id, event_date, event_time, transaction_key, item_cd, unique_brand_name, marketing_type, channel_name, campaign_name, campaign_id, event_name, booking_id and product_type.
2. We are doing this without using the item_sequence_num as we are getting the distinct records from the get_magazine_sku_transaction_data_distinct cte.
***********************/
#}
, magazine_sku_transaction_data as (
    select
        loyalty_id
        , event_date
        , event_time
        , transaction_key
        , item_cd
        , unique_brand_name
        , marketing_type
        , channel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , product_type
        , sum(net_retail_sales_amt) as net_targetted_sales
        , sum(item_qty) as units
    from get_magazine_sku_transaction_data_distinct
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
)

{#
/**********************
1. The magazine_targetted_sku_touchpoint_data CTE is used to add touchpoints for the customers who bought the targeted skus within the campaign period.
2. The magazine_loyalty_data is used to get the event_date and event_time for the customers who bought the targeted skus.
***********************/
#}
, magazine_targetted_sku_touchpoint_data as (
    select distinct
        mt.loyalty_id
        , mt.unique_brand_name
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , mt.campaign_name
        , mt.campaign_id
        , mgl.event_date
        , mgl.event_time
        , mt.transaction_key
        , 'Touchpoint' as event_name
        , mt.booking_id
    from magazine_sku_transaction_data as mt
    left join
        magazine_loyalty_data as mgl
        on
            mt.loyalty_id = mgl.loyalty_id
)

{#
/**********************
1. The magazine_non_targetted_sku_touchpoint_data CTE is used to add touchpoints for the customers who did not buy the targeted skus within the campaign period.
2. To get this we are filtering the loyalty_id from the magazine_loyalty_data table which is not present in the magazine_sku_transaction_data table which means they did not buy the targeted skus.
3. Transaction_key is null for non targetted sku touchpoint data as there is no transaction for them.
***********************/
#}
, magazine_non_targetted_sku_touchpoint_data as (
    select distinct
        loyalty_id
        , '{{ marketing_type }}' as marketing_type
        , '{{ channel }}' as channel_name
        , '{{ subchannel }}' as subchannel_name
        , '{{ campaignName }}' as campaign_name
        , '{{ campaignid }}' as campaign_id
        , event_date
        , event_time
        , null as transaction_key
        , 'Touchpoint' as event_name
        , '{{ bookingId }}' as booking_id
    from
        magazine_loyalty_data
    where
        loyalty_id
        not in
        (select distinct loyalty_id from magazine_sku_transaction_data)
)

{#
/**********************
1. The magazine_data_collection CTE combines the magazine_sku_transaction_data, magazine_targetted_sku_touchpoint_data and magazine_non_targetted_sku_touchpoint_data CTEs.
2. The combined cte has all the transaction touchpoint data of the customers who bought the magazine.
3. For touchpoint data we are using null values for item_cd, product_type, unique_brand_name, net_sales_amt and units_qty.
4. Transaction_key is null for non targetted sku touchpoint data as there is no transaction for them.
***********************/
#}
, magazine_data_collection as (
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , 'TXN' as subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , unique_brand_name
        , net_targetted_sales as net_sales_amt
        , units as units_qty
    from magazine_sku_transaction_data
    union all
    select distinct
        loyalty_id
        , transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from magazine_targetted_sku_touchpoint_data
    union all
    select distinct
        loyalty_id
        , null as transaction_key
        , event_date as event_dt
        , event_time as event_ts
        , marketing_type
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , null as item_cd
        , null as product_type
        , null as unique_brand_name
        , null as net_sales_amt
        , null as units_qty
    from magazine_non_targetted_sku_touchpoint_data
)

{#
/**********************
1. Here we are selecting the final data from the magazine_data_collection CTE.
2. The final data has all the transaction touchpoint data of the customers who bought the magazine.
3. We are using coalesce function to handle null values for transaction_key, item_cd, product_type, unique_brand_name, net_sales_amt and units_qty as null values are not allowed in the final table.
4. The load_ts is the current timestamp and job_run_id is the invocation_id.
***********************/
#}
select distinct
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , current_timestamp::timestamp_ntz as load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , '{{ invocation_id }}' as job_run_id
from magazine_data_collection

{% endset %}

{{ update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, startDate, endDate) }}

    {% do return(magazine_sql) %}

{% endmacro %}
