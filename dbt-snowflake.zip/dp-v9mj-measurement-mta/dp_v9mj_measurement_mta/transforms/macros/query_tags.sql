{% macro default__set_query_tag() -%}
    {% set query_tag = config.get('query_tag', default={}) %}

    {% if query_tag is not mapping %}
    {% do log("dbt-snowflake-query-tags warning: the query_tag config value of '{}' is not a mapping type, so is being ignored. If you'd like to add additional query tag information, use a mapping type instead, or remove it to avoid this message.".format(query_tag), True) %}
    {% set query_tag = {} %}
    {% endif %}

    {%- do query_tag.update(
        app = 'grid-dbt',
        model = model.name,
        data_product = project_name
    ) -%}

    {% set query_tag_json = tojson(query_tag) %}
    {% set original_query_tag = get_current_query_tag() %}
    {{ log("Setting query_tag to '" ~ query_tag_json ~ "'. Will reset to '" ~ original_query_tag ~ "' after materialization.") }}
    {% do run_query("alter session set query_tag = '{}'".format(query_tag_json)) %}
    {{ return(original_query_tag)}}
{% endmacro %}
