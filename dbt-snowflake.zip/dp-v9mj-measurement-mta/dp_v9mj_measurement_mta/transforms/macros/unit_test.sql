{% macro ref(project_or_package, model_name) %}
  {% set project_or_package, model_name = dbt_unit_testing.setup_project_and_model_name(project_or_package, model_name) %}
  {% if dbt_unit_testing.running_unit_test() %}
    {% set node_version = kwargs["version"] | default (kwargs["v"]) %}
    {% set node = {"package_name": project_or_package, "name": model_name, "version": node_version} %}
    {{ return (dbt_unit_testing.ref_cte_name(node)) }}
  {% else %}
    {{ return (builtins.ref(model_name, **kwargs)) }}
  {% endif %}
{% endmacro %}

{% macro source(source, model_name) %}
   {{ return(dbt_unit_testing.source(source, model_name)) }}
{% endmacro %}

{% macro is_incremental() %}
   {{ return (dbt_unit_testing.is_incremental()) }}
{% endmacro %}



