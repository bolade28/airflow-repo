{# /* to truncate channel specific customer data after successful run of the customer_data_collection model */ #}
{% macro truncate_channel_customer_data_table() %}

    {{ log("Truncating channel specific customer data tables:") }}

    {% set tables = ['instore_customer_data','meta_customer_data','dv360_customer_data','magazine_customer_data','youtube_customer_data','citrus_customer_data','ecoupon_customer_data','coupon_at_till_customer_data']%}

    {% for table in tables %}

        truncate table if exists {{ ref(table)}} ;

    {% endfor %}

{% endmacro %}

{# /*Getting the channel specific customer data columns, this macro
is used in customer_data_collection model to reduce the code duplication */ #}
{% macro get_channel_customer_data_columns() %}

{% set all_sql %} 

select
    loyalty_id
    , coalesce(transaction_key, 'NA') as transaction_key
    , event_dt
    , event_ts
    , marketing_type
    , channel_name
    , subchannel_name
    , campaign_name
    , campaign_id
    , event_name
    , booking_id
    , load_ts
    , coalesce(item_cd, 0) as item_cd
    , coalesce(product_type, 'NA') as product_type
    , coalesce(unique_brand_name, 'NA') as unique_brand_name
    , coalesce(net_sales_amt, 0) as net_sales_amt
    , coalesce(units_qty, 0) as units_qty
    , job_run_id


{% endset %}

{{ log("Running get_campaign_channel_specific_data: ", info=True ) }}


    {% do return(all_sql) %}

{% endmacro %}

{# /* This macro is called whenever there is no data in the channel specific customer data table,
it returns a bypass query with null values for all the columns. This is used to avoid errors in the
downstream models when there is no data in the channel specific customer data table.  */ #}
{% macro get_bypass_channel_customer_query() %}

{% set bypass_sql %}

select
    CAST(NULL AS VARCHAR) AS loyalty_id
    , CAST(NULL AS VARCHAR) AS transaction_key
    , CAST(NULL AS DATE) AS event_dt
    , CAST(NULL AS TIMESTAMP_NTZ(9)) AS event_ts
    , CAST(NULL AS VARCHAR) AS marketing_type
    , CAST(NULL AS VARCHAR) AS channel_name
    , CAST(NULL AS VARCHAR) AS subchannel_name
    , CAST(NULL AS VARCHAR) AS campaign_name
    , CAST(NULL AS VARCHAR) AS campaign_id
    , CAST(NULL AS VARCHAR) AS event_name
    , CAST(NULL AS VARCHAR) AS booking_id
    , CAST(NULL AS TIMESTAMP_NTZ(9)) AS load_ts
    , CAST(NULL AS number) AS item_cd
    , CAST(NULL AS VARCHAR) AS product_type
    , CAST(NULL AS VARCHAR) AS unique_brand_name
    , CAST(NULL AS VARCHAR) AS net_sales_amt
    , CAST(NULL AS NUMBER) AS units_qty
    , CAST(NULL AS VARCHAR) AS job_run_id
where false

{% endset %}

{% do return(bypass_sql) %}

{% endmacro %}
