{# /* 
    1.This macro returns campaign attributes for the channel passed in the argument
 from the measurement campaign execution
    2. We call this at the begining of every channel specific customer data collection macro
*/ #}
{% macro get_campaign_channel_specific_data(channel_name) %}
       
    {{ log("Running get_campaign_channel_specific_data: ", info=True ) }}

    {% if channel_name == 'In-store' %}

        {% set sql %}
            select * from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }} where marketing_type = '{{channel_name}}' and job_status='Not Started' limit 1;
        {% endset %}

    {% else %}

        {% set sql %}
            select * from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }} where channel_name = '{{channel_name}}' and job_status='Not Started' limit 1;
        {% endset %}
    {% endif %}

    {% set result =  run_query(sql) %}

    {% if execute %}
        {{ log("Result of  get_campaign_channel_specific_data: "~result.rows[0], info=True ) }}

        {% set campaignName =  result.columns['CAMPAIGN_NAME'].values()[0] %}
        {% set channel =  result.columns['CHANNEL_NAME'].values()[0] %}
        {% set subchannel =  result.columns['SUBCHANNEL_NAME'].values()[0] %}
        {% set startDate =  result.columns['CAMPAIGN_START_DT'].values()[0] %}
        {% set endDate =  result.columns['CAMPAIGN_END_DT'].values()[0] %}
        {% set campaignid =  result.columns['CAMPAIGN_ID'].values()[0] %}
        {% set bookingId =  result.columns['BOOKING_ID'].values()[0] %}
        {% set campaignDuration =  result.columns['CAMPAIGN_DURATION'].values()[0] %}
        {% set jobBagNumber =  result.columns['JOB_BAG_NUMBER'].values()[0] %}
        {% set marketing_type =  result.columns['MARKETING_TYPE'].values()[0] %}


        {{ log("Campaign data :  "~campaignid~" duration : "~campaignDuration, info=True ) }}

    {% endif %}

    {% do return([campaignName,channel,startDate,endDate,campaignid,subchannel,bookingId,campaignDuration,jobBagNumber,marketing_type]) %}
 
{% endmacro %}

{% endmacro %}

{# /* 1.This macro returns list of campaigns which is to be executed for MTA
     2. It takes channel name as input and returns the list of campaigns for that channel
*/ #}
{% macro get_campaign_list(channel) %}

{{ log("Running campaign list macro: ", info=True ) }}

{% if channel== 'In-store' %}

    {% set sql %}
        select * from {{ ref('measurement_campaign_execution') }} where marketing_type = '{{ channel }}' and (job_status = 'Not Started' or job_status is null) ;
    {% endset %}

{% else %}

    
    {% set sql %}
        select * from {{ ref('measurement_campaign_execution') }} where channel_name = '{{ channel }}' and (job_status = 'Not Started' or job_status is null) ;
    {% endset %}

{% endif %}

{% set result =  run_query(sql) %}

    {% if execute %}
        {{ log("Result of  get_campaign_list: "~result.rows, info=True ) }}
        {% set campaign_list =  result.rows %}
    {% endif %}

    {% do return(campaign_list) %}
 
{% endmacro %}

{# /* This macro returns the list of campaigns which is to be executed for MTA
     2. It takes channel name as input and returns the list of campaigns for that channel
*/ #}
{% macro get_campaign_data(channel) %}
       
    {{ log("Running get_campaign_data: ", info=True ) }}

    {% set sql %}
        select * from {{ ref('measurement_campaign_execution') }} where channel_name = {{ channel }} and (job_status='Not Started' or job_status is null);
    {% endset %}

    {% set result =  run_query(sql) %}

    {% if execute %}
        {{ log("Result of  get_campaign_data: "~result.rows, info=True ) }}
        {% set campaign_list =  result.rows %}
    {% endif %}

    {% do return(campaign_list) %}
 
{% endmacro %}
{# /* This macro fetches the list of instore subchannel list */ #}
{% macro get_instore_channel_list() %}
       
    {{ log("Running get_instore_list: ", info=True ) }}

    {% set sql %}
        select distinct subchannel from unified_channel_mapping where channel = 'Instore' and status = 'Active';
    {% endset %}

    {% set result =  run_query(sql) %}

    {% if execute %}
        {{ log("Result of  get_instore_list: "~result.rows, info=True ) }}
        {% set instore_channel_list =  result.rows %}
    {% endif %}

    {% do return(instore_channel_list) %}
 
{% endmacro %}

{# /* This macro changes the status of the campaign that is currently getting executed in both
unified campaign and measurement campaign execution. It also checks for the latest records for a given campaign
in the measurement campaign execution */ #}
{% macro update_processed_campaign_data(bookingId, campaignid, channel, subchannel, job_bag_id, campaign_start_dt, campaign_end_dt) %}
       
    {{ log("Running update_processed_campaign_data: ", info=True ) }}

    {% set sql %}
        update {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }} 
        set job_status = 'In-progress'
        where
            booking_id = '{{ bookingId }}'
            and campaign_id = '{{ campaignid }}'
            and channel_name = '{{ channel }}'
            and subchannel_name = '{{ subchannel }}'
            and job_bag_number = '{{ job_bag_id }}'
            and campaign_start_dt = '{{ campaign_start_dt }}'
            and campaign_end_dt = '{{ campaign_end_dt }}'
            and load_ts = (select max(load_ts)
                            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }}
                            where
                                booking_id = '{{ bookingId }}'
                                and campaign_id = '{{ campaignid }}'
                                and channel_name = '{{ channel }}'
                                and subchannel_name = '{{ subchannel }}'
                                and job_bag_number = '{{ job_bag_id }}'
                                and campaign_start_dt = '{{ campaign_start_dt }}'
                                and campaign_end_dt = '{{ campaign_end_dt }}'
                            )
    {% endset %}
    {% do log("Executing query: " ~ sql, info=true) %}
 
    {% set result =  run_query(sql) %}

    {% set unified_sql %}
        update {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }} 
        set campaign_status = 'In-progress'
        where
            booking_id = '{{ bookingId }}'
            and campaign_id = '{{ campaignid }}'
            and channel_name = '{{ channel }}'
            and subchannel_name = '{{ subchannel }}'
            and job_bag_number = '{{ job_bag_id }}'
            and campaign_start_dt = '{{ campaign_start_dt }}'
            and campaign_end_dt = '{{ campaign_end_dt }}'
            and load_ts = (select max(load_ts)
                            from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }}
                            where
                                booking_id = '{{ bookingId }}'
                                and campaign_id = '{{ campaignid }}'
                                and channel_name = '{{ channel }}'
                                and subchannel_name = '{{ subchannel }}'
                                and job_bag_number = '{{ job_bag_id }}'
                                and campaign_start_dt = '{{ campaign_start_dt }}'
                                and campaign_end_dt = '{{ campaign_end_dt }}'
                            )
                            
    {% endset %}

    {% do log("Executing query for updating unified campaign: " ~ unified_sql, info=true) %}
 
    {% set result =  run_query(sql) %}
    {% set result_unified = run_query(unified_sql) %}

    {% if execute %}
        {{ log("Result of  update_processed_campaign_data in measurement_campaign_execution: "~result.rows[0], info=True ) }}
        {{ log("Result of  update_processed_campaign_data unified_campaign: "~result_unified.rows[0], info=True ) }}

    {% endif %}


 
{% endmacro %}

{# /* 1.This macro changes the status of a campaign that has completed the mta pipeline
from In-progress to completed in case of success run. Also whenever a run fails it marks the status as failed
in both Unified_campaign and measurement campaign execution
2. Measurement campaign reporting is the last script in the mta pipeline.
3. So if this is successful then we can say we have run one campaign end-to end
successfully so we can mark its status as completed.
*/ #}
{% macro update_campaign_and_job_status() %}
        {{ log("Running update_campaign_and_job_status: ") }}

     {% set complete_model_query %}
        select status
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MODEL_EXECUTION_METRIC') }}
        WHERE
            command_invocation_id = '{{ invocation_id }}'
            and task_name ilike '%measurement_campaign_reporting%'
            and task_type = 'model'
        order by completed_at desc
        limit 1
    {% endset %}

    {% set complete_test_query %}
        select status
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MODEL_EXECUTION_METRIC') }}
        WHERE
            command_invocation_id = '{{ invocation_id }}'
            and task_name ilike '%measurement_campaign_reporting%'
            and task_type = 'test'
        order by completed_at desc
        limit 1
    {% endset %}


    {% set model_status = run_query(complete_model_query) %}
    {% set test_status = run_query(complete_test_query) %}

{#
/**********************
1. In order to update the status of the campaign to completed we are checking the status of the model and test
2. If both the model and test are successful then we are updating the status of the campaign to
completed in both unified and measurement campaign execution table.
***********************/
#}
    {% if model_status and test_status and model_status.columns[0].values()[0] == 'success' and test_status.columns[0].values()[0] == 'pass' %}

        {% set update_unified_complete_query %}
            UPDATE {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }}
            SET campaign_status = 'Completed'
            WHERE
                booking_id in (select booking_id
                                from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MEASUREMENT_CAMPAIGN_EXECUTION') }}
                                WHERE job_status = 'In-progress'
                            )
                and load_ts = (SELECT MAX(LOAD_TS)
                                FROM {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }})
            
        {% endset %}
        

        {% set update_query_complete %}
            UPDATE {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MEASUREMENT_CAMPAIGN_EXECUTION') }}
            SET job_status = 'Completed'
            WHERE 
            job_status = 'In-progress'
        {% endset %}

        {% do run_query(update_unified_complete_query) %}
        
        {% do run_query(update_query_complete) %}

    {% endif %}


    {% set model_query %}
        select status
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MODEL_EXECUTION_METRIC') }}
        WHERE
            command_invocation_id = '{{ invocation_id }}'
            and task_type = 'model'
        order by completed_at desc
        limit 1
    {% endset %}

    {% set test_query %}
        select status
        from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MODEL_EXECUTION_METRIC') }}
        WHERE
            command_invocation_id = '{{ invocation_id }}'
            and task_type = 'test'
        order by completed_at desc
        limit 1
    {% endset %}

{#
/**********************
1. In case either model_result or test result gets failed we update the status of measurement campaign
execution and unified campaign to failed for the campaign that
has not started or currently in progress.
***********************/
#}  
    {% set model_result = run_query(model_query) %}
    {% set test_result = run_query(test_query) %}
    {% if (model_result and (model_result.columns[0].values()[0] == 'fail' or model_result.columns[0].values()[0] == 'error' )) or (test_result and (test_result.columns[0].values()[0] == 'error' or test_result.columns[0].values()[0] == 'fail')) %}


        {% set update_unified_query %}
            UPDATE {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }}
            SET campaign_status = 'Failed'
            WHERE
                booking_id in (select booking_id
                                from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MEASUREMENT_CAMPAIGN_EXECUTION') }}
                                WHERE job_status in ('In-progress','Not Started')
                            )
                AND load_ts = (SELECT MAX(LOAD_TS)
                                FROM {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','UNIFIED_CAMPAIGN') }})
            
        {% endset %}

        {% do run_query(update_unified_query) %}
        
        {% set update_query %}
            UPDATE {{ source('ADW_UNIFIED_PLATFORM_TACTICAL','MEASUREMENT_CAMPAIGN_EXECUTION') }}
            SET job_status = 'Failed'
            WHERE 
            job_status in ('In-progress','Not Started')
        {% endset %}
        
        {% do run_query(update_query) %}                    
    {% endif %}
{% endmacro %}