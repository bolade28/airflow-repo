{# /*This macro checks the number of campaigns in measurement campaign execution which are
yet to be processed or are in progress till now.
In case no campaign is found it should raise error */#}
{% macro check_campaign_availability() %}
     {% set checksql %}
        select count(*) from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }} 
        where job_status in ('Not Started','In-progress');
    
    {% endset %}

    {% set result = run_query(checksql) %}

    {% if execute %}

        {% if result.columns[0].values()[0] == 0 %}
         {{exceptions.raise_compiler_error("No Campaign found to evaluate") }}
        {% endif %}
    {% endif %}
{% endmacro %}