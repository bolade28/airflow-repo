/* Description: This macro is used for validating the customer data collection data 
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
Amrit: 10/12/2024 script purpose: Post modelling validation for offer.

Summary of validation: 
1. Check if F1 score is between 0.6 and 0.8
2. Check if the conversion count is less than 50
3. Duplicate records should not be present
4. Total distinct converted loyality IDs counts
5. Total distinct USERJOURNEY_ID counts
6. Total latest rows count
7. if either conversion or total sales is zero, raise a warning
8. Comparing the count of user journeys with the previous step of attribution pre-requisite dbt model
9. Count of records with Attributed Weights of the model which are Negative
10. Count of records with a Sum of Weights per User journey of  more than 100%
11. Total records with null values
12. Check if the conversions are more than non conversions
13. Check if the conversion count between 50 and 1000 and raise a warning
14. Check if F1 score is below 0.6
*/
{% macro attribution_model_results_offer_macro(booking_id) %}


    {% set checks = [

    {
            'description': 'Check if F1 score is between 0.6 and 0.8',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                
                LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                        FROM OFFER_BOOKING_DATA
                    )
                )
                
                SELECT 
                    amr.BOOKING_ID,
                    amr.CAMPAIGN_DURATION,
                    amr.AVG_F1_SCORE_TEST,
                    amr.LOAD_TS
                FROM attribution_model_results_offer amr
                JOIN LATEST_LOAD_TS lts ON amr.LOAD_TS = lts.MAX_LOAD_TS
                WHERE (amr.BOOKING_ID, amr.CAMPAIGN_DURATION) IN (
                    SELECT BOOKING_ID, CAMPAIGN_DURATION 
                    FROM OFFER_BOOKING_DATA
                )
                AND amr.AVG_F1_SCORE_TEST < 0.8 AND amr.AVG_F1_SCORE_TEST >= 0.6
                ORDER BY amr.AVG_F1_SCORE_TEST ASC;
            ",
            'metric': 'FALSE',
            'result': 'Warn',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_001',
            'message': 'Warning: Model is partially optimized'
    },
    {
            'description': 'Check if F1 score is below 0.6',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                
                LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                        FROM OFFER_BOOKING_DATA
                    )
                )
                
                SELECT 
                    amr.BOOKING_ID,
                    amr.CAMPAIGN_DURATION,
                    amr.AVG_F1_SCORE_TEST,
                    amr.LOAD_TS
                FROM attribution_model_results_offer amr
                JOIN LATEST_LOAD_TS lts ON amr.LOAD_TS = lts.MAX_LOAD_TS
                WHERE (amr.BOOKING_ID, amr.CAMPAIGN_DURATION) IN (
                    SELECT BOOKING_ID, CAMPAIGN_DURATION 
                    FROM OFFER_BOOKING_DATA
                )
                AND amr.AVG_F1_SCORE_TEST < 0.6
                ORDER BY amr.AVG_F1_SCORE_TEST ASC;
            ",
            'metric': 'FALSE',
            'result': 'Warn',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_014',
            'message': 'Warning: Model is not optimized'
    },
    {
            'description': 'Check if the conversions count is less than 50',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )

                ,LATEST_LOAD_TS AS (
                                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                                )
                                    
                ,Conversions AS (
                        SELECT 
                            COUNT(DISTINCT apr.userjourney_id) as num_conversions
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 1
                )

                select num_conversions from Conversions where num_conversions < 50;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_002',
            'message': 'Error: Records found with conversions < 50'
    },
    {
            'description': 'Check if the conversions are more than non conversions',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )

                ,LATEST_LOAD_TS AS (
                                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                                )
                                    
                ,Conversions AS (
                        SELECT 
                            COUNT(DISTINCT apr.userjourney_id) as num_conversions
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 1
                ), 
                NonConversions AS (
                        SELECT 
                            COUNT(DISTINCT apr.userjourney_id) as num_nonconversions
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 0
                )
                select num_conversions, num_nonconversions from (select num_conversions, num_nonconversions from Conversions, NonConversions) AS subquery
                where num_conversions > num_nonconversions;
            ",
            'metric': 'FALSE',
            'result': 'Warn',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_012',
            'message': 'Warning: Records found with conversions more than non conversions'
    },
    {
            'description': 'Check if the conversion count between 50 and 1000 and raise a warning',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )

                ,LATEST_LOAD_TS AS (
                                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                                )
                                    
                ,Conversions AS (
                        SELECT 
                            COUNT(DISTINCT apr.userjourney_id) as num_conversions
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 1
                )

                select num_conversions from Conversions where num_conversions >= 50 and num_conversions <= 1000;
            ",
            'metric': 'FALSE',
            'result': 'Warn',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_013',
            'message': 'Warning: Records found with conversions between 50 and 1000'
    },

    {
            'description': 'Duplicate records should not be present',
            'query': "

                    WITH OFFER_BOOKING_DATA AS (
                        SELECT DISTINCT
                            '"~ booking_id ~"' as BOOKING_ID, 
                            CAMPAIGN_DURATION
                        FROM MEASUREMENT_CAMPAIGN_EXECUTION
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND JOB_STATUS = 'In-progress'
                    )
                    , duplicate_rows AS (
                        SELECT USERJOURNEY_ID,
                        LOYALTY_ID,
                        TRANSACTION_KEY,
                        BOOKING_ID,
                        CUSTOMER_JOURNEY_TYPE,
                        JOURNEY_TYPE,
                        ISCONVERSION,
                        REGRESSION_VARIABLE,
                        NORMALIZED_WEIGHTS,
                        CAMPAIGN_ID,
                        AVG_F1_SCORE_TEST,
                        AVG_F1_SCORE_TRAIN,
                        CAMPAIGN_DURATION,
                        JOB_RUN_ID,
                        LOAD_TS,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        MARKETING_TYPE
                        FROM attribution_model_results_offer
                        WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                            AND LOAD_TS = (
                                    SELECT MAX(LOAD_TS) 
                                    FROM attribution_model_results_offer
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) )
                        )
                        , FINAL_CHECK AS (
                                SELECT USERJOURNEY_ID,
                        LOYALTY_ID,
                        TRANSACTION_KEY,
                        BOOKING_ID,
                        CUSTOMER_JOURNEY_TYPE,
                        JOURNEY_TYPE,
                        ISCONVERSION,
                        REGRESSION_VARIABLE,
                        NORMALIZED_WEIGHTS,
                        CAMPAIGN_ID,
                        AVG_F1_SCORE_TEST,
                        AVG_F1_SCORE_TRAIN,
                        CAMPAIGN_DURATION,
                        JOB_RUN_ID,
                        LOAD_TS,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        MARKETING_TYPE
                                FROM duplicate_rows GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18 HAVING COUNT(*) > 1
                        )
                        SELECT USERJOURNEY_ID,
                        LOYALTY_ID,
                        TRANSACTION_KEY,
                        BOOKING_ID,
                        CUSTOMER_JOURNEY_TYPE,
                        JOURNEY_TYPE,
                        ISCONVERSION,
                        REGRESSION_VARIABLE,
                        NORMALIZED_WEIGHTS,
                        CAMPAIGN_ID,
                        AVG_F1_SCORE_TEST,
                        AVG_F1_SCORE_TRAIN,
                        CAMPAIGN_DURATION,
                        JOB_RUN_ID,
                        LOAD_TS,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        MARKETING_TYPE, FROM FINAL_CHECK;   
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_003',
            'message': 'Error: Duplicate Records found'
    },
    {
            'description': 'Total distinct converted loyality IDs counts',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                        SELECT DISTINCT
                            '"~ booking_id ~"' as BOOKING_ID, 
                            CAMPAIGN_DURATION
                        FROM MEASUREMENT_CAMPAIGN_EXECUTION
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND JOB_STATUS = 'In-progress'
            )
            , LOYALITY_ID_DATA AS (
                        
                SELECT COUNT(DISTINCT LOYALTY_ID) AS METRIC_VALUE
                FROM attribution_model_results_offer
                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                AND LOAD_TS = (
                    SELECT MAX(LOAD_TS) 
                        FROM attribution_model_results_offer
                        WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) 
                        )
                AND ISCONVERSION = 1
                        )
            SELECT METRIC_VALUE, 'Total converted loyalty ID count' AS MESSAGE FROM LOYALITY_ID_DATA;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_aro_info_004',
            'message': 'Total distinct loyality IDs counts of the data.'
    },  
    {
            'description': 'Total distinct USERJOURNEY_ID counts',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                        SELECT DISTINCT
                            '"~ booking_id ~"' as BOOKING_ID, 
                            CAMPAIGN_DURATION
                        FROM MEASUREMENT_CAMPAIGN_EXECUTION
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND JOB_STATUS = 'In-progress'
            )

            , USERJOURNEY_ID_DATA AS (
                            SELECT COUNT(DISTINCT USERJOURNEY_ID) AS METRIC_VALUE
                            FROM attribution_model_results_offer
                            WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
            AND LOAD_TS = (
                SELECT MAX(LOAD_TS) 
                    FROM attribution_model_results_offer
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) 
                    )
            AND ISCONVERSION = 1
                    )
            SELECT METRIC_VALUE, 'Total converted USERJOURNEY_ID count' AS MESSAGE FROM USERJOURNEY_ID_DATA;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_aro_info_005',
            'message': 'Total distinct USERJOURNEY_ID_DATA counts of the data.'
    },
    {
            'description': 'Total latest rows count',
            'query': "
                 WITH OFFER_BOOKING_DATA AS (
                        SELECT DISTINCT
                            '"~ booking_id ~"' as BOOKING_ID, 
                            CAMPAIGN_DURATION
                        FROM MEASUREMENT_CAMPAIGN_EXECUTION
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND JOB_STATUS = 'In-progress'
            )

                SELECT count(*) as metric_value FROM attribution_model_results_offer
                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                AND LOAD_TS = (
                    SELECT MAX(LOAD_TS) 
                    FROM attribution_model_results_offer
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) 
                    );
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_aro_info_006',
            'message': 'Total row counts of the data.'
    },
    {
            'description': 'if either conversion or total sales is zero, raise a warning',
            'query': "

                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                ,LATEST_LOAD_TS AS (
                                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    ))
                                    
                , Conversions AS (
                        SELECT 
                            COUNT(DISTINCT apr.userjourney_id) as num_conversions
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 1
                )

                , NET_SALES AS (
                        SELECT 
                            SUM( apr.NET_SALES_AMT) as TOTAL_SALES
                        FROM 
                            ATTRIBUTION_PRE_REQUISITE_OFFER as apr
                        JOIN LATEST_LOAD_TS lts ON apr.LOAD_TS = lts.MAX_LOAD_TS
                        WHERE (apr.BOOKING_ID, apr.CAMPAIGN_DURATION) IN (
                                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                        FROM OFFER_BOOKING_DATA
                                    )
                        and ISCONVERSION = 1
                )

                select num_conversions, TOTAL_SALES from (select num_conversions, TOTAL_SALES from Conversions, NET_SALES) AS subquery
                where num_conversions =0 
                or TOTAL_SALES = 0;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_007',
            'message': 'Error: Either total sales or conversion is zero'
    },
    {
            'description': ' Comparing the count of user journeys with the previous step of attribution pre-requisite dbt model',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                , USERJOURNEY_ID_DATA_input AS (
                                    SELECT COUNT(DISTINCT USERJOURNEY_ID) AS input
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                    AND LOAD_TS = (
                            SELECT MAX(LOAD_TS) 
                            FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                            WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) )
                                    AND ISCONVERSION = 1
                                )
                , USERJOURNEY_ID_DATA_output AS (
                                    SELECT COUNT(DISTINCT USERJOURNEY_ID) AS output
                                    FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                    AND LOAD_TS = (
                            SELECT MAX(LOAD_TS) 
                            FROM ATTRIBUTION_PRE_REQUISITE_OFFER
                            WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) )
                                    AND ISCONVERSION = 1
                                )
                select  input,   output from USERJOURNEY_ID_DATA_input,USERJOURNEY_ID_DATA_output
                where input != output;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_008',
            'message': 'Error: the count of user journeys with the previous step of attribution pre-requisite dbt model is not same'
    },
    {
            'description': ' Count of records with Attributed Weights of the model which are Negative',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                , record_count_with_negative_weight AS (
                    select negative_val from (
                        SELECT  COUNT(*) as negative_val FROM attribution_model_results_offer
                        WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                        AND LOAD_TS = (
                                SELECT MAX(LOAD_TS) 
                                FROM attribution_model_results_offer
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) )
                        and NORMALIZED_WEIGHTS < 0

                    )
                    where negative_val >0
                )

                SELECT * FROM record_count_with_negative_weight;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_009',
            'message': 'Error:  Attributed Weights of the model are Negative'
    },
    {
            'description': ' Count of records with a Sum of Weights per User journey of  more than 100% ',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                , journey_weight_grt_1 as (
                    SELECT 'count userjourneys with sum of weights more than 1' as parameter, booking_id, count(*) 
                    FROM (
                        SELECT booking_id, userjourney_id, SUM(normalized_weights) AS total_val
                        FROM attribution_model_results_offer 
                        WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                        AND LOAD_TS = (
                                SELECT MAX(LOAD_TS) 
                                FROM attribution_model_results_offer
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) )
                        GROUP BY 1,2 HAVING cast(SUM(normalized_weights) AS INTEGER) > 1
                        ) 
                    group by 1,2
                    )
                    select * from journey_weight_grt_1;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_010',
            'message': 'Error: Sum of Weights per User journey is more than 100%'
    },
    {
            'description': 'Total records with null values',
            'query': "
                WITH OFFER_BOOKING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                select null_values from 
                (SELECT COUNT(*) as null_values
                    FROM attribution_model_results_offer
                    WHERE ( LOYALTY_ID IS NULL
                    OR TRANSACTION_KEY IS NULL
                    OR BOOKING_ID IS NULL
                    OR CUSTOMER_JOURNEY_TYPE IS NULL
                    OR JOURNEY_TYPE IS NULL
                    OR ISCONVERSION IS NULL
                    OR REGRESSION_VARIABLE IS NULL
                    OR NORMALIZED_WEIGHTS IS NULL
                    OR CAMPAIGN_ID IS NULL
                    OR AVG_F1_SCORE_TEST IS NULL
                    OR AVG_F1_SCORE_TRAIN IS NULL
                    OR CAMPAIGN_DURATION IS NULL
                    OR JOB_RUN_ID IS NULL
                    OR LOAD_TS IS NULL
                    OR CHANNEL_NAME IS NULL
                    OR SUBCHANNEL_NAME IS NULL
                    OR MARKETING_TYPE IS NULL
                    )
                    and (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA)
                    and  LOAD_TS = (
                                SELECT MAX(LOAD_TS) 
                                FROM attribution_model_results_offer
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM OFFER_BOOKING_DATA) ))
                    where null_values>0
                ;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_aro_011',
            'message': 'Error: Total records with null values found'
    },

    ] %}

    {{ return(checks) }}

{% endmacro %}