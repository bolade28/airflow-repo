{% macro user_journey_validation_macro(booking_id, model_name, kpi_code, journey_type_filter, campaign_duration) %}
    {% set checks = [
        {
            'description': 'There should be no transaction events without a touchpoint event',
            'query': "
                WITH JOURNEY_DATA AS (
                    SELECT BOOKING_ID, TRANSACTION_KEY, LOAD_TS, EVENT_NAME
                    FROM "~model_name~"
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                )
                SELECT TRANSACTION_KEY
                FROM JOURNEY_DATA te
                WHERE EVENT_NAME = 'Purchase Transaction'
                AND NOT EXISTS (
                    SELECT 1
                    FROM "~model_name~"
                    WHERE TRANSACTION_KEY = te.TRANSACTION_KEY
                    AND EVENT_NAME = 'Touchpoint'
                )
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_001',
            'message': 'Error: Transaction events without corresponding touchpoint events found'
        },
         {
            'description': 'The position convertor should not have rank 1 for a converted journeys',
            'query': "
                SELECT POSITION, RANK
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND RANK = 1
                AND POSITION = 'Convertor'
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_002',
            'message': 'Error: Convertor position with rank 1 found in a converted journey'
        },
        {
            'description': 'Check then event timestamp for specific channels (coupon at till, ecoupon, citrus, digital nectar aisles, magazine) is not greater than the txn timestamp for a particular transaction/journey',
            'query': "
                WITH Touchpoint_CTE AS (
                    SELECT
                        USERJOURNEY_ID,
                        EVENT_TS AS TOUCHPOINT_EVENT_TS
                    FROM "~model_name~"
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                    AND EVENT_NAME = 'Touchpoint'
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                ),
                Transaction_CTE AS (
                    SELECT
                        USERJOURNEY_ID,
                        EVENT_TS AS TRANSACTION_EVENT_TS
                    FROM "~model_name~"
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                    AND EVENT_NAME = 'Purchase Transaction'
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                )
                SELECT
                    tp.USERJOURNEY_ID,
                    tp.TOUCHPOINT_EVENT_TS,
                    tx.TRANSACTION_EVENT_TS
                FROM Touchpoint_CTE tp
                JOIN Transaction_CTE tx
                    ON tp.USERJOURNEY_ID = tx.USERJOURNEY_ID
                WHERE tp.TOUCHPOINT_EVENT_TS > tx.TRANSACTION_EVENT_TS
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Warn',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_003',
            'message': 'Warning: Touchpoint timestamp greater than transaction timestamp'
        },
        {
           'description': 'The event datetime should be within the campaign duration end date',
           'query': "
                SELECT e.EVENT_DT
                FROM "~model_name~" e
                JOIN MEASUREMENT_CAMPAIGN_EXECUTION c
                    ON e.BOOKING_ID = c.BOOKING_ID
                    AND e.CAMPAIGN_ID = c.CAMPAIGN_ID
                WHERE e.BOOKING_ID = '"~booking_id~"'
                AND e.LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND e.EVENT_DT > (SELECT MAX(CAMPAIGN_END_DT) 
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION 
                    WHERE BOOKING_ID = '"~booking_id~"')
                AND c.JOB_STATUS = 'In-progress'
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_004',
            'message': 'Error: Event DT is greater than the CAMPAIGN_END_DT'
        },
        {
            'description': 'The event datetime should be within the campaign duration start date',
            'query': "
                SELECT e.EVENT_DT
                FROM "~model_name~" e
                JOIN MEASUREMENT_CAMPAIGN_EXECUTION c
                    ON e.BOOKING_ID = c.BOOKING_ID
                    AND e.CAMPAIGN_ID = c.CAMPAIGN_ID
                WHERE e.BOOKING_ID = '"~ booking_id ~"'
                AND e.LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND e.EVENT_DT < (SELECT MIN(CAMPAIGN_START_DT) 
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION 
                    WHERE BOOKING_ID = '"~booking_id~"')
                AND c.JOB_STATUS = 'In-progress'
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_005',
            'message': 'Error: Event DT is less than the CAMPAIGN_START_DT'
        },
        {
            'description': 'There should not be a user journey without an initiator',
            'query': "
                SELECT DISTINCT USERJOURNEY_ID
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND NOT EXISTS (
                    SELECT 1
                    FROM "~model_name~" uj
                    WHERE uj.USERJOURNEY_ID = "~model_name~".USERJOURNEY_ID
                    AND uj.POSITION = 'Initiator'
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                )
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_006',
            'message': 'Error: User journeys without an initiator found'
        },
        {
            'description': 'The journey type should be either: Offer, Brand or Aisle',
            'query': "
                SELECT DISTINCT USERJOURNEY_ID
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND JOURNEY_TYPE NOT IN ('Offer', 'Brand', 'Aisle')
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_007',
            'message': 'Error: Invalid journey type found, not in Offer, Brand or Aisle'
        },
        {
            'description': 'If a transaction has Unit_Qty>=0 then it should have Net_Amt>=0',
            'query': "
                SELECT TRANSACTION_KEY
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND ((NET_SALES_AMT < 0 AND UNITS_QTY >= 0) OR (NET_SALES_AMT >= 0 AND UNITS_QTY < 0))
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_008',
            'message': 'Error: The net amount is <= 0 for >=0 units for a transaction'
        },
        {
            'description': 'There should not be any duplicate transaction keys excluding NA values and txn, touchpoint pairs',
            'query': "
                SELECT TRANSACTION_KEY, COUNT(TRANSACTION_KEY) AS DUP_COUNT
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND TRANSACTION_KEY <> 'NA'
                GROUP BY TRANSACTION_KEY, RANK
                HAVING DUP_COUNT > 1
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_009',
            'message': 'Error: Duplicate transaction keys found'
        },
        {
            'description': 'Check for a TOTAL_SALES column mismatch in user journey and customer data collection',
            'query': "
                WITH USER_JOURNEY_SALES AS (
                    SELECT LOYALTY_ID, SUM(NET_SALES_AMT) AS TOTAL_SALES
                    FROM "~model_name~"
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                    AND ISCONVERSION = 1
                    GROUP BY LOYALTY_ID
                ),
                DISTINCT_CUSTOMER_DATA_SALES AS (
                    SELECT DISTINCT
                        LOYALTY_ID,
                        TRANSACTION_KEY,
                        BOOKING_ID,
                        ITEM_CD,
                        MAX(NET_SALES_AMT) AS NET_SALES_AMT
                    FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID = '"~ booking_id ~"')
                    AND UPPER(SUBCHANNEL_NAME) = 'TXN'
                    AND LOWER(PRODUCT_TYPE) IN ('na', '"~journey_type_filter~"')
                    GROUP BY LOYALTY_ID, TRANSACTION_KEY, BOOKING_ID, ITEM_CD
                ),
                CUSTOMER_DATA_SALES AS (
                    SELECT
                        LOYALTY_ID,
                        SUM(NET_SALES_AMT) AS TOTAL_SALES
                    FROM DISTINCT_CUSTOMER_DATA_SALES
                    GROUP BY LOYALTY_ID
                )
                SELECT uj.LOYALTY_ID,
                       uj.TOTAL_SALES AS USER_JOURNEY_SALES,
                       cd.TOTAL_SALES AS CUSTOMER_DATA_SALES
                FROM USER_JOURNEY_SALES uj
                FULL OUTER JOIN CUSTOMER_DATA_SALES cd ON uj.LOYALTY_ID = cd.LOYALTY_ID
                WHERE ABS(COALESCE(uj.TOTAL_SALES, 0) - COALESCE(cd.TOTAL_SALES, 0)) > 0.0001
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_010',
            'message': 'Error: Total_Sales column mismatch between User Journey and Customer Data Collection'
        },
        {
            'description': 'The total loyalty_id count must be same for the user journey and customer data collection table for conversions',
            'query': "
                WITH USER_JOURNEY_LOYALTY AS (
                    SELECT COUNT(DISTINCT LOYALTY_ID) AS UJ_LOYALTY_COUNT
                    FROM "~model_name~"
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                    AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                    AND ISCONVERSION = 1
                ),
                CUSTOMER_DATA_LOYALTY AS (
                    SELECT COUNT(DISTINCT LOYALTY_ID) AS CDC_LOYALTY_COUNT
                    FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID = '"~booking_id~"'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID = '"~booking_id~"')
                    AND UPPER(SUBCHANNEL_NAME) = 'TXN'
                    AND LOWER(PRODUCT_TYPE) IN ('na', '"~journey_type_filter~"')
                )
                SELECT
                    UJ_LOYALTY_COUNT,
                    CDC_LOYALTY_COUNT
                FROM USER_JOURNEY_LOYALTY, CUSTOMER_DATA_LOYALTY
                WHERE UJ_LOYALTY_COUNT <> CDC_LOYALTY_COUNT
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_011',
            'message': 'Error: Mismatch in Total Loyalty IDs between User Journey and Customer Data Collection Tables for a converted transaction'
        },
        {
            'description': 'Purchase Transaction events should always have a non-zero net amount',
            'query': "
                SELECT TRANSACTION_KEY
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~booking_id~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND EVENT_NAME = 'Purchase Transaction' AND NET_SALES_AMT = 0
                LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_'~kpi_code~'_012',
            'message': 'Error: Purchase Transaction events with non-zero net amount'
        },
        {
            'description': 'Total Converted Distinct Loyalty IDs',
            'query': "
                SELECT COUNT(DISTINCT LOYALTY_ID) AS CONVERTED_LOYALTY_IDS
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~booking_id~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND ISCONVERSION = 1
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_001',
            'message': 'Total Converted Distinct Loyalty IDs'
        },
        {
            'description': 'Total Distinct Converted UserJourney IDs',
            'query': "
                SELECT COUNT(DISTINCT USERJOURNEY_ID) AS CONVERTED_USERJOURNEY_ID
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND ISCONVERSION = 1
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_002',
            'message': 'Total Distinct Converted UserJourney IDs'
        },
        {
            'description': 'Max Rank for Converted Journeys',
            'query': "
                SELECT COALESCE(MAX(RANK),0) AS MAX_CONVERTED_RANK
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND ISCONVERSION = 1
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_003',
            'message': 'Max Rank for Converted Journeys'
        },
        {
            'description': 'Total Distinct UserJourney IDs',
            'query': "
                SELECT COUNT(DISTINCT USERJOURNEY_ID) AS CONVERTED_USERJOURNEY_ID
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_004',
            'message': 'Total Distinct UserJourney IDs'
        },
        {
            'description': 'Total Non-Converted Distinct User Journey IDs',
            'query': "
                SELECT COUNT(DISTINCT USERJOURNEY_ID) AS NON_CONVERTED_USER_JOURNEY_IDS
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND ISCONVERSION = 0
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_005',
            'message': 'Total Non-Converted Distinct User Journey IDs'
        },
        {
            'description': 'Total Distinct Loyalty IDs',
            'query': "
                SELECT COUNT(DISTINCT LOYALTY_ID) AS TOTAL_DISTINCT_LOYALTY_IDS
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_006',
            'message': 'Total Distinct Loyalty IDs'
        },
        {
            'description': 'Total Distinct Loyalty IDs Channel Wise',
            'query': "
                SELECT
                    COUNT(DISTINCT LOYALTY_ID) AS CHANNEL_LOYALTY_IDS,
                    CHANNEL_NAME
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                GROUP BY CHANNEL_NAME
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_007',
            'message': 'Total Distinct Loyalty IDs by Channel'
        },
        {
            'description': 'Total Row Counts',
            'query': "
                SELECT COUNT(*) AS TOTAL_ROWS
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_008',
            'message': 'Total Rows in Customer Journey Model'
        },
        {
            'description': 'Total Sales',
            'query': "
                SELECT SUM(NET_SALES_AMT) AS TOTAL_SALES
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_009',
            'message': 'Total Sales'
        },
        {
            'description': 'Total Sales by Channel for Purchase Events',
            'query': "
                SELECT
                    SUM(NET_SALES_AMT) AS CHANNEL_SALES,
                    CHANNEL_NAME
                FROM "~model_name~"
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM "~model_name~" WHERE BOOKING_ID = '"~ booking_id ~"')
                AND CAMPAIGN_DURATION = '"~campaign_duration~"'
                AND EVENT_NAME = 'Purchase Transaction'
                GROUP BY CHANNEL_NAME
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_'~kpi_code~'_info_010',
            'message': 'Total Sales by Channel (Transaction Events)'
        }
    ] %}
    {{ return(checks) }}
{% endmacro %}
