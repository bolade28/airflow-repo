{#/* Description: This macro is used for validating the sku_level_attributed_sales_and_units
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
*/#}
{% macro sku_level_attributed_sales_and_units_brand_macro(booking_id) %}
{{ log("Running validation macro for BRAND: ", info=True ) }}

    {% set checks = [
       
        {
            'description': 'Total Records with duplicate rows',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                , DUPLICATE_DATA AS (
                    SELECT
                        'Total Records with duplicate data' as parameter
                        , BOOKING_ID 
                        , 'NA' as PRODUCT_TYPE
                        , 'NA' as CHANNEL_NAME 
                        , TO_VARCHAR(COUNT(*)) AS VALUE 
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND)
                    GROUP BY CAMPAIGN_ID,CHANNEL_NAME,USERJOURNEY_ID,LOYALTY_ID,BOOKING_ID,CUSTOMER_JOURNEY_TYPE,JOURNEY_TYPE,
                    ISCONVERSION,NORMALIZED_WEIGHTS,CAMPAIGN_DURATION,EVENT_DT,ITEM_CD,NET_SALES_AMT,UNITS_QTY,UNIQUE_BRAND_NAME,
                    WEEK_START_DT,REGRESSION_VARIABLE,SUBCHANNEL_NAME,ATTRIBUTED_SALES_AMT,ATTRIBUTED_UNITS_QTY,ATTRIBUTED_RECALIBERATED_SALES_AMT,
                    ATTRIBUTED_RECALIBERATED_UNITS_QTY,JOB_RUN_ID,LOAD_TS,MARKETING_TYPE
                    HAVING COUNT(*) > 1
                )
                SELECT
                    COALESCE(D.VALUE, 0) as VALUE,
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID
                FROM BOOKING_ID_AND_DURATION B
                LEFT JOIN DUPLICATE_DATA D
                ON B.BOOKING_ID = D.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Data',
            'kpi_code': 'mta_slasaub_001',
            'message': 'Total Records with duplicate rows'
        },
        
        {
            'description': 'Total Records With Null Values',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                SELECT DISTINCT
                    '"~ booking_id ~"' as BOOKING_ID, 
                    CAMPAIGN_DURATION
                FROM MEASUREMENT_CAMPAIGN_EXECUTION
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND JOB_STATUS = 'In-progress'
            ),
                
                TOTAL_NULL_RECORDS AS (
                     SELECT
                        'Total Records with null values' as parameter
                        , BOOKING_ID 
                        , 'NA' as PRODUCT_TYPE
                        , 'NA' as CHANNEL_NAME 
                        , TO_VARCHAR(COUNT(*)) AS VALUE 
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND (
                    CAMPAIGN_ID IS NULL
                    OR CHANNEL_NAME IS NULL
                    OR USERJOURNEY_ID IS NULL
                    OR LOYALTY_ID IS NULL
                    OR BOOKING_ID IS NULL
                    OR CUSTOMER_JOURNEY_TYPE IS NULL
                    OR JOURNEY_TYPE IS NULL
                    OR ISCONVERSION IS NULL
                    OR NORMALIZED_WEIGHTS IS NULL
                    OR CAMPAIGN_DURATION IS NULL
                    OR EVENT_DT IS NULL
                    OR ITEM_CD IS NULL
                    OR NET_SALES_AMT IS NULL
                    OR UNITS_QTY IS NULL
                    OR UNIQUE_BRAND_NAME IS NULL
                    OR WEEK_START_DT IS NULL
                    OR REGRESSION_VARIABLE IS NULL
                    OR SUBCHANNEL_NAME IS NULL
                    OR ATTRIBUTED_SALES_AMT IS NULL
                    OR ATTRIBUTED_UNITS_QTY IS NULL
                    OR ATTRIBUTED_RECALIBERATED_SALES_AMT IS NULL
                    OR ATTRIBUTED_RECALIBERATED_UNITS_QTY IS NULL
                    OR JOB_RUN_ID IS NULL
                    OR LOAD_TS IS NULL
                    OR MARKETING_TYPE IS NULL
                )
                GROUP BY BOOKING_ID
            )
                
                SELECT
                    COALESCE(VALUE, 0) as VALUE,
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID
                FROM BOOKING_ID_AND_DURATION B
                LEFT JOIN TOTAL_NULL_RECORDS T
                ON B.BOOKING_ID = T.BOOKING_ID; 
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Data',
            'kpi_code': 'mta_slasaub_002',
            'message': 'Count of total records with NULL values in any of the column'
        },

        {
            'description': 'Total row counts inserted',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ROW_COUNTS AS (
                    SELECT 'Total number of rows inserted' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME 
                    , TO_VARCHAR(COUNT(*)) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT VALUE,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                     FROM TOTAL_ROW_COUNTS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_003',
            'message': 'Count of total rows inserted'
        },

        {
            'description': 'Total Converted loyalty ids',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ROW_COUNTS AS (
                    SELECT 'Total Converted loyalty ids' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME 
                    , TO_VARCHAR(COUNT(DISTINCT(LOYALTY_ID))) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND ISCONVERSION = 1
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT value,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                 FROM TOTAL_ROW_COUNTS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_004',
            'message': 'Count of total converted loyalty ids'
        },
        {
            'description': 'Total converted userjourney ids',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_CONVERTED_JOURNEYS AS (
                    SELECT 'Total number of converted Journeys' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(COUNT(DISTINCT(USERJOURNEY_ID))) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION=1
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                     FROM TOTAL_CONVERTED_JOURNEYS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_005',
            'message': 'Total converted userjourney ids'
        },

        {
            'description': 'Total Attributed Sales',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ATTRIBUTED_SALES AS (
                    SELECT 'Total attributed sales' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(SUM(ATTRIBUTED_SALES_AMT)) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                FROM TOTAL_ATTRIBUTED_SALES;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_006',
            'message': 'Total Attributed Sales'
        },

        {
            'description': 'Total Attributed Units',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ATTRIBUTED_UNITS AS (
                    SELECT 'Total attributed units' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME 
                    , TO_VARCHAR(SUM(ATTRIBUTED_UNITS_QTY)) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                 FROM TOTAL_ATTRIBUTED_UNITS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_007',
            'message': 'Total Attributed Units'
        },

        {
            'description': 'Total attributed recaliberated sales',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ATTRIBUTED_RECALIBERATED_SALES AS (
                    SELECT 'Total attributed recaliberated sales' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(SUM(ATTRIBUTED_RECALIBERATED_SALES_AMT)) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                FROM  TOTAL_ATTRIBUTED_RECALIBERATED_SALES;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_008',
            'message': 'Total attributed recaliberated sales'
        },

        {
            'description': 'Total Attributed recaliberated Units',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_RECALIBERATED_UNITS AS (
                    SELECT 'Total attributed recaliberated sales' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(SUM(ATTRIBUTED_RECALIBERATED_UNITS_QTY)) AS VALUE
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
               SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                 FROM TOTAL_RECALIBERATED_UNITS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_slasaub_009',
            'message': 'Total Recaliberated Units'
        },

        {
            'description': 'Compare Total Sales with previous step of attribution model prerequisite dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_SALES_SKU_LEVEL AS (
                    SELECT
                        BOOKING_ID
                        ,SUM(ATTRIBUTED_SALES_AMT) AS SKU_SALES
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_SALES_PRE_REQ AS (
                    SELECT
                        BOOKING_ID
                        , SUM(NET_SALES_AMT) AS PRE_REQ_SALES
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                    
                ),

                TOTAL_SALES_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, P.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.SKU_SALES, 0) AS SKU_SALES,
                        COALESCE(P.PRE_REQ_SALES, 0) AS PRE_REQUISITE_SALES
                    FROM TOTAL_SALES_SKU_LEVEL as T
                    FULL OUTER JOIN TOTAL_SALES_PRE_REQ as P
                        ON T.BOOKING_ID = P.BOOKING_ID
                    WHERE COALESCE(T.SKU_SALES::number(32,0), 0) <> COALESCE(P.PRE_REQ_SALES::number(32,0), 0)
                )
                SELECT * FROM TOTAL_SALES_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_slasaub_010',
            'message': 'Compare Total Sales with previous step of attribution model prerequisite dbt model'
        },

         {
            'description': 'Compare Total Units with previous step of user journey dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_UNITS_SKU_LEVEL AS (
                    SELECT
                        BOOKING_ID
                        ,SUM(ATTRIBUTED_UNITS_QTY) AS TOTAL_UNITS_SKU
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_UNITS_USERJOURNEY AS (
                    SELECT
                        BOOKING_ID
                        , SUM(UNITS_QTY) AS TOTAL_UNITS_JOURNEY
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                    
                ),

                TOTAL_UNITS_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, P.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.TOTAL_UNITS_SKU, 0) AS TOTAL_UNITS_SKU,
                        COALESCE(P.TOTAL_UNITS_JOURNEY, 0) AS TOTAL_UNITS_JOURNEY
                    FROM TOTAL_UNITS_SKU_LEVEL as T
                    FULL OUTER JOIN TOTAL_UNITS_USERJOURNEY as P
                        ON T.BOOKING_ID = P.BOOKING_ID
                    WHERE COALESCE(T.TOTAL_UNITS_SKU::number(32,0), 0) <> COALESCE(P.TOTAL_UNITS_JOURNEY::number(32,0), 0)
                )
                SELECT * FROM TOTAL_UNITS_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_slasaub_011',
            'message': 'Compare Total Units with previous step of user journey dbt model'
        },

        
         {
            'description': 'Compare Total Journeys with previous step of attribution model results dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_JOURNEY_SKU_LEVEL AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT USERJOURNEY_ID) AS SKU_JOURNEYS
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_JOURNEY_MODEL AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT USERJOURNEY_ID) AS MODEL_JOURNEYS
                    FROM ATTRIBUTION_MODEL_RESULTS_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  ATTRIBUTION_MODEL_RESULTS_BRAND
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                    
                ),

                TOTAL_JOURNEY_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, M.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.SKU_JOURNEYS, 0) AS SKU_JOURNEYS,
                        COALESCE(M.MODEL_JOURNEYS, 0) AS MODEL_JOURNEYS
                    FROM TOTAL_JOURNEY_SKU_LEVEL as T
                    FULL OUTER JOIN TOTAL_JOURNEY_MODEL as M
                        ON T.BOOKING_ID = M.BOOKING_ID
                    WHERE COALESCE(T.SKU_JOURNEYS, 0) <> COALESCE(M.MODEL_JOURNEYS, 0)
                )

                SELECT * FROM TOTAL_JOURNEY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_slasaub_012',
            'message': 'Compare count of user journeys with previous step of attribution model results dbt model'
        }
    ] %}
    {{ return(checks) }}

{% endmacro %}
