{# 
/* 
Description: 
This macro is used for validating the `measurement_campaign_reporting` model as per defined checks. 
It includes various validation checks such as null value checks, duplicate record checks, 
and validation of calculated metrics like ROAS, iROAS, Uplift Exposed Sales Amount, and Incremental Sales.

Parameters:
- booking_id: The unique identifier for the booking to validate.

Returns:
- A list of validation checks with their descriptions, queries, and expected results.

Author: Gaurav Rawal
*/ 
#}

{% macro measurement_campaign_reporting_macro(booking_id) %}


    {% set checks = [
        {
            'description': 'Total records with null values',
            'query': "
                WITH REPORTING_DATA AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' AS BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND JOB_STATUS = 'In-progress'
                ),
                NULL_VALUE_CHECK AS (
                    SELECT 
                        COUNT(*) AS NULL_VALUES
                    FROM MEASUREMENT_CAMPAIGN_REPORTING
                    WHERE (
                        BOOKING_ID IS NULL
                        OR JOURNEY_TYPE IS NULL
                        OR CAMPAIGN_ID IS NULL
                        OR JOB_RUN_ID IS NULL
                        OR LOAD_TS IS NULL
                        OR CHANNEL_NAME IS NULL
                        OR SUBCHANNEL_NAME IS NULL
                        OR MARKETING_TYPE IS NULL )
                        AND (BOOKING_ID, CAMPAIGN_DURATION) IN (
                            SELECT BOOKING_ID, CAMPAIGN_DURATION 
                            FROM REPORTING_DATA
                        )
                        AND LOAD_TS = (
                            SELECT MAX(LOAD_TS) 
                            FROM MEASUREMENT_CAMPAIGN_REPORTING
                            WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                                SELECT BOOKING_ID, CAMPAIGN_DURATION 
                                FROM REPORTING_DATA
                            )
                        )
                )
                SELECT NULL_VALUES 
                FROM NULL_VALUE_CHECK
                WHERE NULL_VALUES > 0
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_001',
            'message': 'Error: Total records with null values found'
        },

        {
            'description': 'Duplicate records should not be present',
            'query': "
                WITH reporting_data AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' AS BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ),
                duplicate_rows AS (
                    SELECT 
                        booking_id,
                        campaign_id,
                        job_bag_number,
                        channel_name,
                        subchannel_name,
                        journey_type,
                        campaign_duration,
                        marketing_type,
                        load_ts
                    FROM measurement_campaign_reporting
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                        SELECT BOOKING_ID, CAMPAIGN_DURATION 
                        FROM reporting_data
                    )
                    AND LOAD_TS = (
                        SELECT MAX(LOAD_TS) 
                        FROM measurement_campaign_reporting
                        WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (
                            SELECT BOOKING_ID, CAMPAIGN_DURATION 
                            FROM reporting_data
                        )
                    )
                ),
                FINAL_CHECK AS (
                    SELECT 
                        booking_id,
                        campaign_id,
                        job_bag_number,
                        channel_name,
                        subchannel_name,
                        journey_type,
                        campaign_duration,
                        marketing_type,
                        load_ts
                    FROM duplicate_rows 
                    GROUP BY 
                        booking_id,
                        campaign_id,
                        job_bag_number,
                        channel_name,
                        subchannel_name,
                        journey_type,
                        campaign_duration,
                        marketing_type,
                        load_ts
                    HAVING COUNT(*) > 1
                )
                SELECT 
                    booking_id,
                    campaign_id,
                    job_bag_number,
                    channel_name,
                    subchannel_name,
                    journey_type,
                    campaign_duration,
                    marketing_type,
                    load_ts 
                FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_002',
            'message': 'Error: Duplicate Records found'
        },

        {
            'description': 'Total latest rows count',
            'query': "
                with reporting_data as (
                    select booking_id, load_ts, campaign_duration from measurement_campaign_reporting
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                        SELECT MAX(LOAD_TS) 
                        FROM measurement_campaign_reporting
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                    )
                )
                SELECT count(*) as metric_value FROM reporting_data
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_mcr_info_001',
            'message': 'Total row counts of the data.'
        },

        {
            'description': 'Validate calculation of values of iROAS Exposed',
            'query': "
                with reporting_data as (
                    select BOOKING_ID,
                        CAMPAIGN_ID,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        MARKETING_TYPE,
                        INCREMENTAL_SALES_AMT_EXPOSED,
                        MEDIA_SPEND_AMT,
                        IROAS_EXPOSED from measurement_campaign_reporting
                        where booking_id = '"~ booking_id ~"'
                        and load_ts in (
                        SELECT MAX(LOAD_TS) 
                                        FROM measurement_campaign_reporting
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        )  
                    ),
                    processed_data as (
                    SELECT 
                        BOOKING_ID,
                        CAMPAIGN_ID,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        MARKETING_TYPE,
                        INCREMENTAL_SALES_AMT_EXPOSED,
                        MEDIA_SPEND_AMT,
                        IROAS_EXPOSED,
                        CASE 
                            WHEN MEDIA_SPEND_AMT = 0 THEN 'VALID'
                            WHEN Round(IROAS_EXPOSED, 2) = Round((INCREMENTAL_SALES_AMT_EXPOSED / MEDIA_SPEND_AMT), 2) THEN 'VALID'
                            ELSE 'INVALID'
                        END AS VALIDATION_STATUS
                    FROM 
                        reporting_data
                    WHERE 
                        INCREMENTAL_SALES_AMT_EXPOSED IS NOT NULL
                        AND MEDIA_SPEND_AMT IS NOT NULL
                        )

                        select IROAS_EXPOSED from processed_data where VALIDATION_STATUS = 'INVALID'
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_003',
            'message': 'Error : Values of iROAS Exposed is invalid.'
        },

        {
            'description': 'Validate calculation of values of ROAS Exposed',
            'query': "
                WITH REPORTING_DATA AS (
                    SELECT 
                        SUM(ATTRIBUTED_RECALIBERATED_SALES_AMT) AS TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT,
                        SUM(MEDIA_SPEND_AMT) AS TOTAL_MEDIA_SPEND_AMT,
                        BOOKING_ID,
                        JOURNEY_TYPE,
                        ROAS_EXPOSED FROM MEASUREMENT_CAMPAIGN_REPORTING
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND LOAD_TS IN (
                            SELECT MAX(LOAD_TS) 
                            FROM MEASUREMENT_CAMPAIGN_REPORTING
                            WHERE BOOKING_ID = '"~ booking_id ~"'
                        ) GROUP BY JOURNEY_TYPE, ROAS_EXPOSED, BOOKING_ID
                        
                    ),
                    PROCESSED_DATA as (
                    SELECT 
                        BOOKING_ID,
                        TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT,
                        TOTAL_MEDIA_SPEND_AMT,
                        ROAS_EXPOSED,
                        CASE 
                            WHEN TOTAL_MEDIA_SPEND_AMT = 0 THEN 'VALID'
                            WHEN ROUND(ROAS_EXPOSED, 2) = ROUND((TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT / TOTAL_MEDIA_SPEND_AMT), 2) THEN 'VALID'
                            ELSE 'INVALID'
                        END AS VALIDATION_STATUS
                    FROM 
                        REPORTING_DATA
                    WHERE 
                        TOTAL_ATTRIBUTED_RECALIBERATED_SALES_AMT IS NOT NULL
                        AND TOTAL_MEDIA_SPEND_AMT IS NOT NULL
                        )
                        SELECT ROAS_EXPOSED FROM PROCESSED_DATA WHERE VALIDATION_STATUS = 'INVALID'
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_004',
            'message': 'Error : Values of ROAS Exposed is invalid'
        },

        {
            'description': 'Validate calculation of values of Uplift Exposed Sales Amount',
            'query': "with reporting_data as (
                            SELECT 
                            SUM(INCREMENTAL_SALES_AMT_EXPOSED) as SUM_INCREMENTAL_SALES_AMT_EXPOSED,
                            sum(ATTRIBUTED_RECALIBERATED_SALES_AMT) as SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT,
                            booking_id,
                            JOURNEY_TYPE,
                            UPLIFT_EXPOSED_SALES_AMT from MEASUREMENT_CAMPAIGN_REPORTING 
                            where booking_id = '"~ booking_id ~"'
                            and load_ts in (
                            SELECT MAX(LOAD_TS) 
                                            FROM MEASUREMENT_CAMPAIGN_REPORTING
                                            WHERE BOOKING_ID = '"~ booking_id ~"'
                            ) group by journey_type, UPLIFT_EXPOSED_SALES_AMT, booking_id
                            
                        ),
                        processed_data as (
                            SELECT 
                                BOOKING_ID,
                                SUM_INCREMENTAL_SALES_AMT_EXPOSED,
                                SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT,
                                UPLIFT_EXPOSED_SALES_AMT,
                                CASE 
                                    WHEN SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT = 0 THEN 'VALID'
                                    WHEN ROUND(UPLIFT_EXPOSED_SALES_AMT, 2) = ROUND((SUM_INCREMENTAL_SALES_AMT_EXPOSED / SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT),2) THEN 'VALID'
                                    ELSE 'INVALID'
                                END AS VALIDATION_STATUS
                            FROM 
                                reporting_data
                            WHERE 
                                SUM_INCREMENTAL_SALES_AMT_EXPOSED IS NOT NULL
                                AND SUM_ATTRIBUTED_RECALIBERATED_SALES_AMT IS NOT NULL
                        )
                        SELECT UPLIFT_EXPOSED_SALES_AMT from processed_data where VALIDATION_STATUS = 'INVALID';
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_005',
            'message': 'Error : Values of UPLIFT Exposed sales amount is invalid'
        },

        {
            'description': 'Validate calculation of values of Uplift Exposed units qty',
            'query': "with reporting_data as (
                            SELECT 
                            SUM(INCREMENTAL_UNITS_QTY_EXPOSED) AS SUM_INCREMENTAL_UNITS_QTY_EXPOSED,
                            SUM(ATTRIBUTED_RECALIBERATED_UNITS_QTY) AS SUM_ATTRIBUTED_RECALIBERATED_UNITS_QTY,
                            BOOKING_ID,
                            JOURNEY_TYPE,
                            UPLIFT_EXPOSED_UNITS_QTY FROM MEASUREMENT_CAMPAIGN_REPORTING 
                            WHERE BOOKING_ID = '"~ booking_id ~"'
                            AND LOAD_TS IN (
                            SELECT MAX(LOAD_TS) 
                                            FROM MEASUREMENT_CAMPAIGN_REPORTING
                                            WHERE BOOKING_ID = '"~ booking_id ~"'
                            ) GROUP BY JOURNEY_TYPE, UPLIFT_EXPOSED_UNITS_QTY, BOOKING_ID
                            
                        ),
                        processed_data as (
                            SELECT 
                                BOOKING_ID,
                                SUM_INCREMENTAL_UNITS_QTY_EXPOSED,
                                SUM_ATTRIBUTED_RECALIBERATED_UNITS_QTY,
                                UPLIFT_EXPOSED_UNITS_QTY,
                                CASE 
                                    WHEN SUM_ATTRIBUTED_RECALIBERATED_UNITS_QTY = 0 THEN 'VALID'
                                    WHEN ROUND(UPLIFT_EXPOSED_UNITS_QTY, 2) = ROUND((SUM_INCREMENTAL_UNITS_QTY_EXPOSED / SUM_ATTRIBUTED_RECALIBERATED_UNITS_QTY),2) THEN 'VALID'
                                    ELSE 'INVALID'
                                END AS VALIDATION_STATUS
                            FROM 
                                reporting_data
                            WHERE 
                                SUM_INCREMENTAL_UNITS_QTY_EXPOSED IS NOT NULL
                                AND SUM_ATTRIBUTED_RECALIBERATED_UNITS_QTY IS NOT NULL
                        )
                        SELECT UPLIFT_EXPOSED_UNITS_QTY from processed_data where VALIDATION_STATUS = 'INVALID';
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_006',
            'message': 'Error : Values of UPLIFT Exposed units qty is invalid'
        },

        {
            'description': 'Compare the sum of Incremental Sales at Marketing Type, Channel, Subchannel Level for a campaign with previous baseline_attribution_integration_sku_level',
            'query': "
                WITH baseline_attribution_data as (
                    SELECT SUM(total_sum) AS total_sum_final,
                    marketing_type, channel_name, subchannel_name
                    FROM (
                        SELECT sum(INCREMENTAL_SALES_AMT_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_offer
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_offer
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                        UNION ALL
                        SELECT sum(INCREMENTAL_SALES_AMT_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_brand
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_brand
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                        UNION ALL
                        SELECT sum(INCREMENTAL_SALES_AMT_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_aisle
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_aisle
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                    ) group by marketing_type, channel_name, subchannel_name
                    ),
                    reporting_data as (              
                    select sum(INCREMENTAL_SALES_AMT_EXPOSED) as total_sum_final, marketing_type, channel_name, subchannel_name 
                    from measurement_campaign_reporting
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM measurement_campaign_reporting
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                    )
                    SELECT a.marketing_type, a.channel_name, a.subchannel_name, a.total_sum_final AS total_sum_final_a, b.total_sum_final AS total_sum_final_b
                    FROM reporting_data a
                    JOIN baseline_attribution_data b
                    ON a.marketing_type = b.marketing_type
                    AND a.channel_name = b.channel_name
                    AND a.subchannel_name = b.subchannel_name
                    WHERE round(a.total_sum_final, 2) != round(b.total_sum_final, 2)
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_007',
            'message': 'Error : Values of incremental sales amt is invalid'
        },

        {
            'description': 'Compare the sum of Incremental sales Units at Marketing Type, Channel, Subchannel Level for a campaign with previous baseline_attribution_integration_sku_level',
            'query': "
                WITH baseline_attribution_data as (
                    SELECT SUM(total_sum) AS total_sum_final,
                    marketing_type, channel_name, subchannel_name
                    FROM (
                        SELECT sum(INCREMENTAL_UNITS_QTY_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_offer
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_offer
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                        UNION ALL
                        SELECT sum(INCREMENTAL_UNITS_QTY_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_brand
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_brand
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                        UNION ALL
                        SELECT sum(INCREMENTAL_UNITS_QTY_EXPOSED) as total_sum, marketing_type, channel_name, subchannel_name from baseline_attribution_integration_sku_level_aisle
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM baseline_attribution_integration_sku_level_aisle
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                    ) group by marketing_type, channel_name, subchannel_name
                    ),
                    reporting_data as (              
                    select sum(INCREMENTAL_UNITS_QTY_EXPOSED) as total_sum_final, marketing_type, channel_name, subchannel_name 
                    from measurement_campaign_reporting
                    where BOOKING_ID = '"~ booking_id ~"'
                    and load_ts = (
                                        SELECT MAX(LOAD_TS) 
                                        FROM measurement_campaign_reporting
                                        WHERE BOOKING_ID = '"~ booking_id ~"'
                                    )
                    group by marketing_type, channel_name, subchannel_name
                    )
                    SELECT a.marketing_type, a.channel_name, a.subchannel_name, a.total_sum_final AS total_sum_final_a, b.total_sum_final AS total_sum_final_b
                    FROM reporting_data a
                    JOIN baseline_attribution_data b
                    ON a.marketing_type = b.marketing_type
                    AND a.channel_name = b.channel_name
                    AND a.subchannel_name = b.subchannel_name
                    WHERE round(a.total_sum_final, 0) != round(b.total_sum_final, 0)
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_mcr_008',
            'message': 'Error: Values of incremental sales unit is invalid'
        },

    ] %}

    {{ return(checks) }}

{% endmacro %}