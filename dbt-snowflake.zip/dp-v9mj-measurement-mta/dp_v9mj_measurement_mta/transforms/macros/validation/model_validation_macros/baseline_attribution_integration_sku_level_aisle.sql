{#/* Description: This macro is used for validating the baseline_attribution_integration_sku_level_AISLE_
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
*/#}
{% macro baseline_attribution_integration_sku_level_aisle_macro(booking_id) %}
{{ log("Running baseline integration validation macro for AISLE: ", info=True ) }}

    {% set checks = [
       
        {
            'description': 'Total Records with duplicate rows',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                )
                , duplicate_data AS (
                     SELECT
                        'Total Records with duplicate data' as parameter
                        , BOOKING_ID 
                        , 'NA' as PRODUCT_TYPE
                        , 'NA' as CHANNEL_NAME 
                        , TO_VARCHAR(COUNT(*)) AS VALUE  
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE)
                    GROUP BY CAMPAIGN_ID,USERJOURNEY_ID,LOYALTY_ID,BOOKING_ID,CUSTOMER_JOURNEY_TYPE,JOURNEY_TYPE,ISCONVERSION,NORMALIZED_WEIGHTS,
                    CAMPAIGN_DURATION,EVENT_DT,NET_SALES_AMT,UNITS_QTY,REGRESSION_VARIABLE,ATTRIBUTED_SALES_AMT,ATTRIBUTED_UNITS_QTY,FREQUENCY_OF_PURCHASE,
                    ONLINE_SALES_PCT,SUPERMARKET_SALES_PCT,CONVENIENCE_SALES_PCT,JOB_RUN_ID,SUM_BASELINE_AMT,SUM_OF_SALES_AMT,SUM_OF_ATTR_SALES_AMT,
                    SUM_OF_INCR_AMT,CHANNEL_NAME,SUBCHANNEL_NAME,LOAD_TS,WEEK_START_DT,ITEM_CD,INCREMENTALITY_TOTAL,INCREMENTALITY_EXPOSED,ATTRIBUTED_RECALIBERATED_SALES_AMT,
                    ATTRIBUTED_RECALIBERATED_UNITS_QTY,UNIQUE_BRAND_NAME,BASELINE,MARKETING_TYPE,
                    TOTAL_SALES_AMT,INCREMENTAL_SALES_AMT_EXPOSED,INCREMENTAL_SALES_AMT_TOTAL,INCREMENTAL_UNITS_QTY_TOTAL,INCREMENTAL_UNITS_QTY_EXPOSED,LOAD_TS,JOB_RUN_ID
                    HAVING COUNT(*) > 1
                )
                SELECT
                    COALESCE(D.VALUE, 0) as VALUE,
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID
                FROM BOOKING_ID_AND_DURATION B
                LEFT JOIN DUPLICATE_DATA D
                ON B.BOOKING_ID = D.BOOKING_ID;
                
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_001',
            'message': 'Total Records with duplicate rows'
        },
        
        {
            'description': 'Total Records With Null Values',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                SELECT DISTINCT
                    '"~ booking_id ~"' as BOOKING_ID, 
                    CAMPAIGN_DURATION
                FROM MEASUREMENT_CAMPAIGN_EXECUTION
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND JOB_STATUS = 'In-progress'
            ),
                
                TOTAL_NULL_RECORDS AS (
                    SELECT
                        'Total Records with null values' as parameter
                        , BOOKING_ID 
                        , 'NA' as PRODUCT_TYPE
                        , 'NA' as CHANNEL_NAME 
                        , TO_VARCHAR(COUNT(*)) AS VALUE 
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND (
                    
                            CAMPAIGN_ID IS NULL OR
                            USERJOURNEY_ID IS NULL OR
                            LOYALTY_ID IS NULL OR
                            BOOKING_ID IS NULL OR
                            CUSTOMER_JOURNEY_TYPE IS NULL OR 
                            JOURNEY_TYPE IS NULL OR
                            ISCONVERSION IS NULL OR
                            NORMALIZED_WEIGHTS IS NULL OR
                            CAMPAIGN_DURATION IS NULL OR
                            EVENT_DT IS NULL OR
                            NET_SALES_AMT IS NULL OR
                            UNITS_QTY IS NULL OR
                            REGRESSION_VARIABLE IS NULL OR
                            ATTRIBUTED_SALES_AMT IS NULL OR
                            ATTRIBUTED_UNITS_QTY IS NULL OR
                            FREQUENCY_OF_PURCHASE IS NULL OR
                            ONLINE_SALES_PCT IS NULL OR
                            SUPERMARKET_SALES_PCT IS NULL OR
                            CONVENIENCE_SALES_PCT IS NULL OR
                            JOB_RUN_ID IS NULL OR
                            SUM_BASELINE_AMT IS NULL OR
                            SUM_OF_SALES_AMT IS NULL OR
                            SUM_OF_ATTR_SALES_AMT IS NULL OR
                            SUM_OF_INCR_AMT IS NULL OR
                            CHANNEL_NAME IS NULL OR
                            SUBCHANNEL_NAME IS NULL OR
                            LOAD_TS IS NULL OR
                            WEEK_START_DT IS NULL OR
                            ITEM_CD IS NULL OR
                            INCREMENTALITY_TOTAL IS NULL OR
                            INCREMENTALITY_EXPOSED IS NULL OR
                            ATTRIBUTED_RECALIBERATED_SALES_AMT IS NULL OR
                            ATTRIBUTED_RECALIBERATED_UNITS_QTY IS NULL OR
                            UNIQUE_BRAND_NAME IS NULL OR
                            BASELINE IS NULL OR
                            MARKETING_TYPE IS NULL OR
                            TOTAL_SALES_AMT IS NULL OR
                            INCREMENTAL_SALES_AMT_EXPOSED IS NULL OR
                            INCREMENTAL_SALES_AMT_TOTAL IS NULL OR
                            INCREMENTAL_UNITS_QTY_TOTAL IS NULL OR
                            INCREMENTAL_UNITS_QTY_EXPOSED IS NULL OR
                            LOAD_TS IS NULL OR
                            JOB_RUN_ID IS NULL

                        )
                GROUP BY BOOKING_ID
            )
                
                SELECT
                    COALESCE(VALUE, 0) as VALUE,
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID
                FROM BOOKING_ID_AND_DURATION B
                LEFT JOIN TOTAL_NULL_RECORDS T
                ON B.BOOKING_ID = T.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_002',
            'message': 'Count of total records with NULL values in any of the column'
        },

        {
            'description': 'Total row counts inserted',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ROW_COUNTS AS (
                    SELECT 'Total number of rows inserted' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME 
                    , TO_VARCHAR(COUNT(*)) AS VALUE
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT VALUE,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                     FROM TOTAL_ROW_COUNTS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_003',
            'message': 'Count of total rows inserted'
        },

        {
            'description': 'Total Converted loyalty ids',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_CONVERTED_LOYALTY_IDS AS (
                    SELECT 'Total Converted loyalty ids' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME 
                    , TO_VARCHAR(COUNT(DISTINCT(LOYALTY_ID))) AS VALUE
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND ISCONVERSION = 1
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT value,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                 FROM TOTAL_CONVERTED_LOYALTY_IDS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_004',
            'message': 'Count of total converted loyalty ids'
        },
        {
            'description': 'Total converted userjourney ids',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_CONVERTED_JOURNEYS AS (
                    SELECT 'Total number of converted Journeys' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(COUNT(DISTINCT(USERJOURNEY_ID))) AS VALUE
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION=1
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                FROM TOTAL_CONVERTED_JOURNEYS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_005',
            'message': 'Total converted userjourney ids'
        },

        {
            'description': 'Total attributed recaliberated sales',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_ATTRIBUTED_RECALIBERATED_SALES AS (
                    SELECT 'Total attributed recaliberated sales' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(SUM(ATTRIBUTED_RECALIBERATED_SALES_AMT)) AS VALUE
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
                SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                FROM  TOTAL_ATTRIBUTED_RECALIBERATED_SALES;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_006',
            'message': 'Total attributed recaliberated sales'
        },

        {
            'description': 'Total Attributed recaliberated Units',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_RECALIBERATED_UNITS AS (
                    SELECT 'Total attributed recaliberated sales' as parameter
                    , BOOKING_ID 
                    , 'NA' as PRODUCT_TYPE
                    , 'NA' as CHANNEL_NAME
                    , TO_VARCHAR(SUM(ATTRIBUTED_RECALIBERATED_UNITS_QTY)) AS VALUE
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                )
               SELECT
                    VALUE,
                    CHANNEL_NAME,
                    PRODUCT_TYPE,
                    BOOKING_ID
                 FROM TOTAL_RECALIBERATED_UNITS;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_007',
            'message': 'Total Recaliberated Units'
        },
        
         {
            'description': 'Compare Total Journeys with previous step of attribution model results dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_JOURNEY_SKU_LEVEL AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT USERJOURNEY_ID) AS SKU_JOURNEYS
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_JOURNEY_BASELINE AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT USERJOURNEY_ID) AS MODEL_JOURNEYS
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                    
                ),

                TOTAL_JOURNEY_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, B.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.SKU_JOURNEYS, 0) AS SKU_JOURNEYS,
                        COALESCE(B.MODEL_JOURNEYS, 0) AS MODEL_JOURNEYS
                    FROM TOTAL_JOURNEY_SKU_LEVEL as T
                    FULL OUTER JOIN TOTAL_JOURNEY_BASELINE as B
                        ON T.BOOKING_ID = B.BOOKING_ID
                    WHERE COALESCE(T.SKU_JOURNEYS, 0) <> COALESCE(B.MODEL_JOURNEYS, 0)
                )

                SELECT * FROM TOTAL_JOURNEY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_baisla_008',
            'message': 'Error:No of User journeys mismatch  with previous step of attribution model results dbt model'
        },

         {
            'description': 'Compare Total Recalibrated Sales with previous step of sku level attribution results dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_SALES_BASELINE AS (
                    SELECT
                        BOOKING_ID
                        , SUM(ATTRIBUTED_RECALIBERATED_SALES_AMT) as TOTAL_SALES
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_SALES_SKU AS (
                    SELECT
                        BOOKING_ID
                        , SUM(ATTRIBUTED_RECALIBERATED_SALES_AMT) AS SKU_SALES
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                    WHERE BOOKING_ID IN (SELECT BOOKING_ID FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                                WHERE BOOKING_ID IN (SELECT BOOKING_ID FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                TOTAL_SALES_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, B.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.SKU_SALES, 0) AS SKU_SALES,
                        COALESCE(B.TOTAL_SALES, 0) AS TOTAL_SALES
                    FROM TOTAL_SALES_SKU as T
                    FULL OUTER JOIN TOTAL_SALES_BASELINE as B
                        ON T.BOOKING_ID = B.BOOKING_ID
                    WHERE
                        COALESCE(ROUND(T.SKU_SALES,2), 0) <> COALESCE(ROUND(B.TOTAL_SALES,2), 0)
                )
                SELECT * FROM TOTAL_SALES_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_baisla_009',
            'message': 'Error:Total Recalibrated Sales mismatch with previous step of sku level attribution results dbt model'
        },

         {
            'description': 'Compare Total Recalibrated Units with previous step of sku level attribution results dbt model',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                TOTAL_UNITS_BASELINE AS (
                    SELECT
                        BOOKING_ID
                        , SUM(ATTRIBUTED_RECALIBERATED_UNITS_QTY) as BASELINE_UNITS
                    FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_ATTRIBUTION_INTEGRATION_SKU_LEVEL_AISLE
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),

                TOTAL_UNITS_SKU AS (
                    SELECT
                        BOOKING_ID
                        , SUM(ATTRIBUTED_RECALIBERATED_UNITS_QTY) AS SKU_UNITS
                    FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                    WHERE BOOKING_ID IN (SELECT BOOKING_ID FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_AISLE
                                WHERE BOOKING_ID IN (SELECT BOOKING_ID FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                TOTAL_UNITS_COMPARISON AS (
                    SELECT 
                        COALESCE(T.BOOKING_ID, B.BOOKING_ID) as BOOKING_ID,
                        COALESCE(T.BASELINE_UNITS, 0) AS BASELINE_UNITS,
                        COALESCE(B.SKU_UNITS, 0) AS SKU_UNITS
                    FROM TOTAL_UNITS_BASELINE as T
                    FULL OUTER JOIN TOTAL_UNITS_SKU as B
                        ON T.BOOKING_ID = B.BOOKING_ID
                    WHERE
                        COALESCE(T.BASELINE_UNITS::number(32,0), 0) <> COALESCE(B.SKU_UNITS::number(32,0), 0)
                        
                )
                SELECT * FROM TOTAL_UNITS_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'DATA',
            'kpi_code': 'mta_baisla_010',
            'message': 'Error: Recalibrated Units mismatch with previous step of sku level attribution results dbt model'
        },

        {
            'description': 'Incrementality is negative for skus',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ),


                TOTAL_ITEM_COUNTS AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT(ITEM_CD)) AS TOTAL_ITEMS
                    FROM BASELINE_INTEGRATION_SKU
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_INTEGRATION_SKU
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                                AND JOURNEY_TYPE ='Aisle' AND COMMENT='INCREMENTALITY is negative')
                    AND JOURNEY_TYPE ='Aisle'
                    AND COMMENT='INCREMENTALITY is negative'
                    GROUP BY BOOKING_ID
                )

                
                SELECT
                    COALESCE(T.TOTAL_ITEMS,0) AS VALUE
                    , 'NA' AS CHANNEL_NAME
                    , 'NA' AS PRODUCT_TYPE
                    , 'NA' AS SUBCHANNEL_NAME
                FROM BOOKING_ID_AND_DURATION AS B
                LEFT JOIN TOTAL_ITEM_COUNTS AS T
                    ON B.BOOKING_ID = T.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Warning',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_011',
            'message': 'Warning: Total count with incrementality negative'
        },

        {
            'description': 'All SKUs are absent/Brand or super category data is absent.',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ),


                TOTAL_ITEM_COUNTS AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT(ITEM_CD)) AS TOTAL_ITEMS
                    FROM BASELINE_INTEGRATION_SKU
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_INTEGRATION_SKU
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                                AND JOURNEY_TYPE ='Aisle' AND COMMENT='All SKUs are absent/Brand or super category data is absent.')
                    AND JOURNEY_TYPE ='Aisle'
                    AND COMMENT = 'All SKUs are absent/Brand or super category data is absent.'
                    GROUP BY BOOKING_ID
                )

                
                SELECT
                    COALESCE(T.TOTAL_ITEMS,0) AS VALUE
                    , 'NA' AS CHANNEL_NAME
                    , 'NA' AS PRODUCT_TYPE
                    , 'NA' AS SUBCHANNEL_NAME
                FROM BOOKING_ID_AND_DURATION AS B
                LEFT JOIN TOTAL_ITEM_COUNTS AS T
                    ON B.BOOKING_ID = T.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Warning',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_012',
            'message': 'Warning: Total count with All SKUs are absent/Brand or super category data is absent'
        },

        {
            'description': 'Total count of INCREMENTALITY is zero',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ),


                TOTAL_ITEM_COUNTS AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT(ITEM_CD)) AS TOTAL_ITEMS
                    FROM BASELINE_INTEGRATION_SKU
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_INTEGRATION_SKU
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                                AND JOURNEY_TYPE ='Aisle' AND COMMENT='INCREMENTALITY is zero')
                    AND JOURNEY_TYPE ='Aisle'
                    AND COMMENT = 'INCREMENTALITY is zero'
                    GROUP BY BOOKING_ID
                )

                
                SELECT
                    COALESCE(T.TOTAL_ITEMS,0) AS VALUE
                    , 'NA' AS CHANNEL_NAME
                    , 'NA' AS PRODUCT_TYPE
                    , 'NA' AS SUBCHANNEL_NAME
                FROM BOOKING_ID_AND_DURATION AS B
                LEFT JOIN TOTAL_ITEM_COUNTS AS T
                    ON B.BOOKING_ID = T.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Warning',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_013',
            'message': 'Warning:  Total count with incrementality zero'
        },

        {
            'description': 'SKUS are absent',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ),


                TOTAL_ITEM_COUNTS AS (
                    SELECT
                        BOOKING_ID
                        , COUNT(DISTINCT(ITEM_CD)) AS TOTAL_ITEMS
                    FROM BASELINE_INTEGRATION_SKU
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM BASELINE_INTEGRATION_SKU
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                                AND JOURNEY_TYPE ='Aisle' AND COMMENT='SKUs are absent')
                    AND JOURNEY_TYPE ='Aisle'
                    AND COMMENT='SKUs are absent'
                    GROUP BY BOOKING_ID
                )

                
                SELECT
                    COALESCE(T.TOTAL_ITEMS,0) AS VALUE
                    , 'NA' AS CHANNEL_NAME
                    , 'NA' AS PRODUCT_TYPE
                    , 'NA' AS SUBCHANNEL_NAME
                FROM BOOKING_ID_AND_DURATION AS B
                LEFT JOIN TOTAL_ITEM_COUNTS AS T
                    ON B.BOOKING_ID = T.BOOKING_ID;
            ",
            'metric': 'INFO',
            'result': 'Warning',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_baisla_014',
            'message': 'Warning: Total count of SKUs are absent'
        }
    
    ] %}
    {{ return(checks) }}

{% endmacro %}