{#/* description: THIS MACRO IS USED FOR VALIDATING THE CAMPAIGN_DECAY_RATE_
AS PER DEFINED CHECKS.
DUMMY query IS USED IN CHECKS WHERE KPI TYPE IS metric.
PARAMS: BOOKING_ID
*/#}
{% macro campaign_decay_rate_macro(booking_id) %}
{{ log("running campaign_decay_rate macro: ", info=True ) }}

    {% set checks = [
       
        {
            'description': 'Total records with duplicate rows',
            'query': "
                WITH OFFSITE_JOB_BAG_NUMBER AS (
                    SELECT DISTINCT
                        JOB_BAG_NUMBER
                        , CHANNEL_NAME
                        , BOOKING_ID
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                    AND CHANNEL_NAME IN ('DV360','Meta','YouTube')
                )
                , DUPLICATE_DATA AS (
                     SELECT
                       JOB_BAG_NUMBER
                       , CHANNEL_NAME
                       , COUNT(*) AS VALUE
                    FROM CAMPAIGN_DECAY_RATE
                    WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM  CAMPAIGN_DECAY_RATE)
                    GROUP BY MARKETING_TYPE,CHANNEL_NAME,JOB_BAG_NUMBER,REPORTING_DT,IMPRESSIONS_CNT,CUMULATIVE_IMPRESSIONS_CNT,
                    OFFSITE_IMPRESSIONS_PCT
                    HAVING COUNT(*) > 1
                )


                SELECT
                    COALESCE(D.VALUE, 0) AS VALUE,
                    B.CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID,
                    'NA' AS SUBCHANNEL_NAME,
                    B.JOB_BAG_NUMBER
                FROM OFFSITE_JOB_BAG_NUMBER B
                LEFT JOIN DUPLICATE_DATA D
                ON B.JOB_BAG_NUMBER = D.JOB_BAG_NUMBER
                AND B.CHANNEL_NAME = D.CHANNEL_NAME;
                
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdr_001',
            'message': 'Total records with duplicate rows'
        },
        
        {
            'description': 'Total records with null values',
            'query': "
               WITH OFFSITE_JOB_BAG_NUMBER AS (
                    SELECT DISTINCT
                        BOOKING_ID,
                        JOB_BAG_NUMBER,
                        CHANNEL_NAME
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                    AND CHANNEL_NAME IN ('DV360','Meta','YouTube')
            ),
                
                TOTAL_NULL_RECORDS AS (
                    SELECT
                        JOB_BAG_NUMBER
                        , CHANNEL_NAME
                        , TO_VARCHAR(COUNT(*)) AS VALUE 
                    FROM CAMPAIGN_DECAY_RATE
                    WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CAMPAIGN_DECAY_RATE 
                                WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER))
                    AND (
                        MARKETING_TYPE IS NULL OR
                        CHANNEL_NAME IS NULL OR
                        JOB_BAG_NUMBER IS NULL OR
                        REPORTING_DT IS NULL OR
                        IMPRESSIONS_CNT IS NULL OR
                        CUMULATIVE_IMPRESSIONS_CNT IS NULL OR
                        OFFSITE_IMPRESSIONS_PCT IS NULL
                        )
                GROUP BY JOB_BAG_NUMBER, CHANNEL_NAME
            )
                
                SELECT
                    COALESCE(VALUE, 0) AS VALUE,
                    T.CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE,
                    B.BOOKING_ID,
                    'NA' AS SUBCHANNEL_NAME,
                    B.JOB_BAG_NUMBER
                FROM OFFSITE_JOB_BAG_NUMBER B
                LEFT JOIN TOTAL_NULL_RECORDS T
                ON B.JOB_BAG_NUMBER = T.JOB_BAG_NUMBER
                AND B.CHANNEL_NAME = T.CHANNEL_NAME;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdr_002',
            'message': 'Count of total records with null values in any of the column'
        },

        {
            'description': 'Total row counts inserted',
            'query': "
               WITH OFFSITE_JOB_BAG_NUMBER AS (
                    SELECT DISTINCT
                        JOB_BAG_NUMBER
                        , CHANNEL_NAME
                        , BOOKING_ID 
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                    AND CHANNEL_NAME IN ('DV360','Meta','YouTube')
                ), 
                TOTAL_ROW_COUNTS AS (
                    SELECT 'TOTAL NUMBER OF ROWS INSERTED' AS PARAMETER
                    , JOB_BAG_NUMBER
                    , 'NA' AS PRODUCT_TYPE
                    , CHANNEL_NAME 
                    , TO_VARCHAR(COUNT(*)) AS VALUE
                    FROM CAMPAIGN_DECAY_RATE
                    WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CAMPAIGN_DECAY_RATE
                                WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER))
                    GROUP BY JOB_BAG_NUMBER, CHANNEL_NAME
                )
                SELECT COALESCE(VALUE,0) AS VALUE,
                        C.CHANNEL_NAME,
                        C.PRODUCT_TYPE,
                        O.BOOKING_ID,
                        'NA' AS SUBCHANNEL_NAME,
                        C.JOB_BAG_NUMBER
                     FROM TOTAL_ROW_COUNTS C
                     INNER JOIN OFFSITE_JOB_BAG_NUMBER  O
                     ON C.JOB_BAG_NUMBER = O.JOB_BAG_NUMBER
                     AND C.CHANNEL_NAME = O.CHANNEL_NAME
                     ;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdr_003',
            'message': 'Count of total rows inserted'
        },


        {
            'description': 'Check if decay rate is updated for each day within the campaign period',
            'query': "
                WITH IN_PROGRESS_JOB_BAG AS (
                SELECT
                    JOB_BAG_NUMBER
                    , CHANNEL_NAME
                    ,CAMPAIGN_START_DT
                    ,CAMPAIGN_END_DT
                FROM MEASUREMENT_CAMPAIGN_EXECUTION
                WHERE JOB_STATUS = 'In-progress' AND CHANNEL_NAME IN ('Meta','DV360','YouTube')
            )

            , EXP_DATA AS (SELECT  JOB_BAG_NUMBER,DATEADD('DAY', ROW_NUMBER()
            OVER (PARTITION BY IPJ.JOB_BAG_NUMBER ORDER BY SEQ4())
            - 1, IPJ.CAMPAIGN_START_DT) AS EXPLODED_DATE
            FROM IN_PROGRESS_JOB_BAG AS IPJ
            , TABLE(GENERATOR(ROWCOUNT => 150)))

            , DATE_SPAN AS ( SELECT C1.JOB_BAG_NUMBER,C1.EXPLODED_DATE FROM EXP_DATA C1 JOIN IN_PROGRESS_JOB_BAG C2 ON C1.JOB_BAG_NUMBER = C2.JOB_BAG_NUMBER AND C1.EXPLODED_DATE <= C2.CAMPAIGN_END_DT)

            , REPORTING_PERIOD AS (SELECT JOB_BAG_NUMBER,REPORTING_DT FROM CAMPAIGN_DECAY_RATE WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM IN_PROGRESS_JOB_BAG) AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CAMPAIGN_DECAY_RATE
                                WHERE (JOB_BAG_NUMBER,CHANNEL_NAME) IN (SELECT JOB_BAG_NUMBER,CHANNEL_NAME FROM IN_PROGRESS_JOB_BAG)))

            SELECT * FROM DATE_SPAN WHERE (JOB_BAG_NUMBER,EXPLODED_DATE) NOT IN (SELECT JOB_BAG_NUMBER,REPORTING_DT FROM REPORTING_PERIOD);
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'actual': 'FALSE',
            'expected': 'TRUE',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdr_004',
            'message': 'Error: Decay rate is not updated for each day within the campaign period'
        },

        {
            'description': 'Check if last day offsite impression is 1',
            'query': "
                WITH IN_PROGRESS AS (SELECT DISTINCT JOB_BAG_NUMBER FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE CHANNEL_NAME IN ('Meta','DV360','YouTube') AND JOB_STATUS='In-progress' )

                , MAX_REPORTING   AS (SELECT JOB_BAG_NUMBER,MAX(REPORTING_DT) AS REPORTING_DT FROM CAMPAIGN_DECAY_RATE WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM IN_PROGRESS) GROUP BY JOB_BAG_NUMBER)

                SELECT OFFSITE_IMPRESSIONS_PCT FROM  CAMPAIGN_DECAY_RATE WHERE (JOB_BAG_NUMBER,REPORTING_DT) IN (SELECT DISTINCT JOB_BAG_NUMBER,REPORTING_DT FROM MAX_REPORTING) AND OFFSITE_IMPRESSIONS_PCT::INTEGER!=1 ;

            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdr_005',
            'message': 'Error: Last day offsite impression is not 1'
        },

        {
            'description': 'Check if last reporting dt is  equal to campaign end_date and min reporting date is campaign start date',
            'query': "
                WITH OFFSITE_JOB_BAG_NUMBER AS 
                  (SELECT DISTINCT JOB_BAG_NUMBER,CHANNEL_NAME,CAMPAIGN_START_DT,CAMPAIGN_END_DT FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE CHANNEL_NAME IN ('Meta','DV360','YouTube') AND JOB_STATUS='In-progress' )

                , CAMPAIGN_DECAY_LATEST AS (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,MAX(LOAD_TS) AS LOAD_TS FROM CAMPAIGN_DECAY_RATE WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM  OFFSITE_JOB_BAG_NUMBER) GROUP BY 1,2 )

                , CAMPAIGN_LATEST_DATA AS (SELECT * FROM CAMPAIGN_DECAY_RATE WHERE (JOB_BAG_NUMBER,CHANNEL_NAME,LOAD_TS) IN (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,LOAD_TS FROM CAMPAIGN_DECAY_LATEST))

                , START_REPORTING_DT AS (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,MIN(REPORTING_DT) AS REPORTING_DT FROM  CAMPAIGN_LATEST_DATA WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER) GROUP BY JOB_BAG_NUMBER,CHANNEL_NAME
                )

                , LAST_REPORTING_DT AS (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,MAX(REPORTING_DT) AS REPORTING_DT FROM  CAMPAIGN_LATEST_DATA WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM OFFSITE_JOB_BAG_NUMBER) GROUP BY JOB_BAG_NUMBER,CHANNEL_NAME)

                SELECT * FROM  LAST_REPORTING_DT L INNER JOIN OFFSITE_JOB_BAG_NUMBER O ON L.JOB_BAG_NUMBER = O.JOB_BAG_NUMBER AND L.CHANNEL_NAME = O.CHANNEL_NAME AND O.CAMPAIGN_END_DT != L.REPORTING_DT 
                
                UNION ALL

                SELECT * FROM  START_REPORTING_DT S INNER JOIN OFFSITE_JOB_BAG_NUMBER O ON S.JOB_BAG_NUMBER = O.JOB_BAG_NUMBER AND O.CHANNEL_NAME = S.CHANNEL_NAME AND O.CAMPAIGN_START_DT != S.REPORTING_DT 
                
                ;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'actual': 'FALSE',
            'expected': 'TRUE',
            'kpi_code': 'mta_cdr_006',
            'message':'Error:Last reporting dt is not less than equal to campaign end_date'
        },
        
         {
            'description': 'Check if offsite impressions pct is cumulative_impressions_cnt/sum(impression_cnt) or 0.001 when cumulative is zero for a particular job_bag number',
            'query': "
                WITH IN_PROGRESS AS (SELECT DISTINCT JOB_BAG_NUMBER,CHANNEL_NAME FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE CHANNEL_NAME IN ('Meta','DV360','YouTube') AND JOB_STATUS='In-progress' )

                , CAMPAIGN_DECAY_LATEST AS (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,MAX(LOAD_TS) AS LOAD_TS FROM CAMPAIGN_DECAY_RATE WHERE JOB_BAG_NUMBER IN (SELECT JOB_BAG_NUMBER FROM IN_PROGRESS) GROUP BY 1,2 )

                , CAMPAIGN_LATEST_DATA AS (SELECT * FROM CAMPAIGN_DECAY_RATE WHERE (JOB_BAG_NUMBER,CHANNEL_NAME,LOAD_TS) IN (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,LOAD_TS FROM CAMPAIGN_DECAY_LATEST))

                , SUM_IMP_CNT AS (SELECT JOB_BAG_NUMBER,CHANNEL_NAME,SUM(IMPRESSIONS_CNT) AS TOT_IMP FROM CAMPAIGN_LATEST_DATA  WHERE (JOB_BAG_NUMBER,LOAD_TS) IN (SELECT JOB_BAG_NUMBER,LOAD_TS FROM CAMPAIGN_DECAY_LATEST)
                GROUP BY JOB_BAG_NUMBER,CHANNEL_NAME)

                , OFFISTE_IMPRESSION_CHECK AS (SELECT C1.JOB_BAG_NUMBER, C1.CHANNEL_NAME,C1.REPORTING_DT,C1.CUMULATIVE_IMPRESSIONS_CNT,C2.TOT_IMP,case when C1.CUMULATIVE_IMPRESSIONS_CNT = 0 THEN 0.001 ELSE C1.CUMULATIVE_IMPRESSIONS_CNT/C2.TOT_IMP END AS OFFSITE_IMPRESSIONS_RAW FROM CAMPAIGN_LATEST_DATA  C1
                INNER JOIN SUM_IMP_CNT C2 ON C1.JOB_BAG_NUMBER = C2.JOB_BAG_NUMBER AND C1.CHANNEL_NAME=C2.CHANNEL_NAME)

                SELECT * FROM OFFISTE_IMPRESSION_CHECK O INNER JOIN CAMPAIGN_LATEST_DATA  C ON O.JOB_BAG_NUMBER = C.JOB_BAG_NUMBER AND O.CHANNEL_NAME = C.CHANNEL_NAME
                 AND C.REPORTING_DT = O.REPORTING_DT  where round(OFFSITE_IMPRESSIONS_RAW,2)!=round(c.offsite_impressions_PCT,2);
                
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'actual': 'FALSE',
            'expected': 'TRUE',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdr_007',
            'message': 'Error: offsite impressions pct is not cumulative_impressions_cnt/sum(impression_cnt) or 0.01 for a particular job_bag number'
        }

         
        
    ] %}
    {{ return(checks) }}

{% endmacro %}
