{# /* Description: This macro is used for validating the reach and engagement data 
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
*/ #}
{% macro reach_engagement_macro(booking_id) %}

    {% set checks = [
        {
            'description': 'Check for null values in essential columns',
            'query': "
                WITH NULL_CHECK AS (
                        SELECT BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME, LOAD_TS
                        FROM REACH_ENGAGEMENT
                        WHERE (BOOKING_ID IS NULL OR CAMPAIGN_ID IS NULL OR MARKETING_TYPE IS NULL 
                            OR CHANNEL_NAME IS NULL OR SUBCHANNEL_NAME IS NULL)
                        AND BOOKING_ID IN ('"~ booking_id ~"')
                        AND SUBCHANNEL_NAME != 'TXN'
                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                    )
                SELECT BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME FROM NULL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_re_001',
            'message': 'Error: Essential columns contain null values'
        },

        {
            'description': 'Check for duplicate records',
            'query': "
                WITH REACH_DATA AS (
                    SELECT BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME, LOAD_TS
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                DUPLICATE_CHECK AS (
                    SELECT BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME
                    FROM REACH_DATA
                    GROUP BY BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME
                    HAVING COUNT(*) > 1
                )
                SELECT BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME FROM DUPLICATE_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_re_002',
            'message': 'Error: Duplicate records found in the data'
        },

        {
            'description': 'Validate stored ENGAGEMENT_CTR_PCT values are within valid range (0-100%)',
            'query': "
                SELECT 
                    BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME, 
                    IMPRESSIONS_CNT, CLICKS_CNT, ENGAGEMENT_CTR_PCT
                FROM REACH_ENGAGEMENT
                WHERE BOOKING_ID IN ('"~ booking_id ~"')
                AND SUBCHANNEL_NAME != 'TXN'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                AND IMPRESSIONS_CNT > 0
                AND (ENGAGEMENT_CTR_PCT > 100 OR ENGAGEMENT_CTR_PCT < 0)
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_re_003',
            'message': 'Error: Invalid CTR values detected. Found records stored ENGAGEMENT_CTR_PCT falls outside the valid range of 0-100%'
        },

        {
            'description': 'Validate CTR stored values match calculated values',
            'query': "
                WITH CTR_DATA AS (
                    SELECT 
                        BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME, 
                        IMPRESSIONS_CNT, CLICKS_CNT, LOAD_TS, ENGAGEMENT_CTR_PCT,
                        CASE 
                            WHEN IMPRESSIONS_CNT > 0 THEN (CLICKS_CNT * 100.0 / IMPRESSIONS_CNT)
                            ELSE 0 
                        END AS CALCULATED_CTR
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                    AND IMPRESSIONS_CNT > 0
                ),
                CTR_MISMATCH_CHECK AS (
                    SELECT 
                        BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME,
                        IMPRESSIONS_CNT, CLICKS_CNT, ENGAGEMENT_CTR_PCT, CALCULATED_CTR,
                        ABS(ENGAGEMENT_CTR_PCT - CALCULATED_CTR) AS CTR_DIFFERENCE
                    FROM CTR_DATA
                    WHERE ABS(ENGAGEMENT_CTR_PCT - CALCULATED_CTR) > 0.01
                    AND (CALCULATED_CTR BETWEEN 0 AND 100)
                )
                SELECT 
                    BOOKING_ID, CAMPAIGN_ID, MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME,
                    IMPRESSIONS_CNT, CLICKS_CNT, ENGAGEMENT_CTR_PCT, CALCULATED_CTR, CTR_DIFFERENCE
                FROM CTR_MISMATCH_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_re_004',
            'message': 'Error: The stored ENGAGEMENT_CTR_PCT values dont match the calculated values (CLICKS_CNT/IMPRESSIONS_CNT × 100)'
        },

        {
            'description': 'Compare with user journey output for marketing type, channel and subchannel combinations',
            'query': "
                WITH REACH_COMBINATIONS AS (
                    SELECT DISTINCT trim(MARKETING_TYPE) as marketing_type, trim(CHANNEL_NAME) as channel_name, trim(SUBCHANNEL_NAME) as subchannel_name
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                USER_JOURNEY_COMBINATIONS AS (
                    SELECT DISTINCT trim(MARKETING_TYPE) as marketing_type, trim(CHANNEL_NAME) as channel_name, trim(SUBCHANNEL_NAME) as subchannel_name
                    FROM USER_JOURNEY_OFFER
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND CAMPAIGN_DURATION = 'During'
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_OFFER WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                 MISSING_COMBINATIONS AS (
                    SELECT * FROM USER_JOURNEY_COMBINATIONS WHERE (MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME) NOT IN
                    (SELECT DISTINCT MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME FROM REACH_COMBINATIONS )
                )
                SELECT MARKETING_TYPE, CHANNEL_NAME, SUBCHANNEL_NAME FROM MISSING_COMBINATIONS
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_re_005',
            'message': 'Error: Some marketing type, channel and subchannel combinations from user journey are missing in reach_engagement'
        },

        {
            'description': 'Total row counts',
            'query': "
                SELECT COUNT(*) AS METRIC_VALUE, 
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE, 
                    'NA' AS BOOKING_ID,
                    'NA' AS SUBCHANNEL_NAME,
                    'NA' AS MARKETING_TYPE
                FROM REACH_ENGAGEMENT
                WHERE BOOKING_ID IN ('"~ booking_id ~"')
                AND SUBCHANNEL_NAME != 'TXN'
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_re_info_001',
            'message': 'Total row counts of the data.'
        },

        {
            'description': 'Recently updated/inserted rows',
            'query': "
                WITH PREVIOUS_LOAD AS (
                    SELECT MAX(LOAD_TS) AS PREV_LOAD_TS
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS < (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                CURRENT_COUNT AS (
                    SELECT COUNT(*) AS CURRENT_ROWS
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM REACH_ENGAGEMENT WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                PREVIOUS_COUNT AS (
                    SELECT COUNT(*) AS PREVIOUS_ROWS
                    FROM REACH_ENGAGEMENT
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND SUBCHANNEL_NAME != 'TXN'
                    AND LOAD_TS = (SELECT PREV_LOAD_TS FROM PREVIOUS_LOAD)
                )
                SELECT 
                    (CURRENT_COUNT.CURRENT_ROWS - COALESCE(PREVIOUS_COUNT.PREVIOUS_ROWS, 0)) AS METRIC_VALUE,
                    'NA' AS CHANNEL_NAME,
                    'NA' AS PRODUCT_TYPE, 
                    'NA' AS BOOKING_ID,
                    'NA' AS SUBCHANNEL_NAME,
                    'NA' AS MARKETING_TYPE
                FROM CURRENT_COUNT
                LEFT JOIN PREVIOUS_COUNT ON 1=1
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_re_info_002',
            'message': 'Count of recently updated or inserted rows.'
        }

    ] %}

    {{ return(checks) }}

{% endmacro %}
