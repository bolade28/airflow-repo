/* Description: This macro is used for validating the customer data collection data 
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id

Amrit validation summary:
1. Duplicate records should not be present
2. Total latest rows count
3. Total records with null values
4. The post campaign period for any campaign should not exceed 12 weeks
5. No isolated bucket should be present
6. max median week should be taken for each proposed bucket.
*/
{% macro post_campaign_period_macro()%}


    {% set checks = [


    {
            'description': 'Duplicate records should not be present',
            'query': "

                    with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period
                    )
                    , duplicate_rows AS (
                                    SELECT 
                                    
                                    SUPER_CAT_NAME,
                                    ITEM_SHORT_NAME,
                                    ITEM_CD,
                                    MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS,
                                    TIME_PERIOD_70_PCT_DAYS,
                                    TIME_PERIOD_80_PCT_DAYS,
                                    TIME_PERIOD_90_PCT_DAYS,
                                    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                                    TIME_PERIOD_70_PCT_WK,
                                    TIME_PERIOD_80_PCT_WK,
                                    TIME_PERIOD_90_PCT_WK,
                                    MEDIAN_PROPOSED_BUCKET_WK,
                                    JOB_RUN_ID,
                                    LOAD_TS,
                                    YEAR_OF_TRANSACTION

                                    FROM post_campaign_period
                                    WHERE LOAD_TS = (
                                                select MAX_LOAD_TS from LATEST_LOAD_TS) 
                    )
                    , FINAL_CHECK AS (
                            SELECT 
                            SUPER_CAT_NAME,
                            ITEM_SHORT_NAME,
                            ITEM_CD,
                            MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS,
                            TIME_PERIOD_70_PCT_DAYS,
                            TIME_PERIOD_80_PCT_DAYS,
                            TIME_PERIOD_90_PCT_DAYS,
                            MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                            TIME_PERIOD_70_PCT_WK,
                            TIME_PERIOD_80_PCT_WK,
                            TIME_PERIOD_90_PCT_WK,
                            MEDIAN_PROPOSED_BUCKET_WK,
                            JOB_RUN_ID,
                            LOAD_TS,
                            YEAR_OF_TRANSACTION
                                    FROM duplicate_rows GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 HAVING COUNT(*) > 1
                    )
                    SELECT 
                    SUPER_CAT_NAME,
                    ITEM_SHORT_NAME,
                    ITEM_CD,
                    MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS,
                    TIME_PERIOD_70_PCT_DAYS,
                    TIME_PERIOD_80_PCT_DAYS,
                    TIME_PERIOD_90_PCT_DAYS,
                    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                    TIME_PERIOD_70_PCT_WK,
                    TIME_PERIOD_80_PCT_WK,
                    TIME_PERIOD_90_PCT_WK,
                    MEDIAN_PROPOSED_BUCKET_WK,
                    JOB_RUN_ID,
                    LOAD_TS,
                    YEAR_OF_TRANSACTION FROM FINAL_CHECK;  
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_pcp_001',
            'message': 'Error: Duplicate Records found'
    },
    {
            'description': 'Total latest rows count',
            'query': "
                with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period
                )
                SELECT count(*) as metric_value FROM post_campaign_period
                            
                where LOAD_TS = (select MAX_LOAD_TS from LATEST_LOAD_TS);
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_pcp_info_002',
            'message': 'Total row counts of the data.'
    },
    {
            'description': 'Total records with null values',
            'query': "
                with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period
                )
                select null_values from 
                    (SELECT COUNT(*) as null_values
                        FROM post_campaign_period
                        WHERE SUPER_CAT_NAME is NULL
                        or ITEM_CD is NULL
                        or MEDIAN_TIME_BETWEEN_TRANSACTIONS_DAYS  is NULL
                        or TIME_PERIOD_70_PCT_DAYS  is NULL
                        or TIME_PERIOD_80_PCT_DAYS  is NULL
                        or TIME_PERIOD_90_PCT_DAYS  is NULL
                        or MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK  is NULL
                        or TIME_PERIOD_70_PCT_WK  is NULL
                        or TIME_PERIOD_80_PCT_WK  is NULL
                        or TIME_PERIOD_90_PCT_WK  is NULL
                        or MEDIAN_PROPOSED_BUCKET_WK  is NULL
                        or JOB_RUN_ID  is NULL
                        or  LOAD_TS  is NULL
                        or YEAR_OF_TRANSACTION  is NULL
                        and  LOAD_TS = (select MAX_LOAD_TS from LATEST_LOAD_TS))
                    where null_values>0;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_pcp_003',
            'message': 'Error: Total records with null values found'
    },
    {
            'description': 'The post campaign period for any campaign should not exceed 12 weeks',
            'query': "
                with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period
                )
                select max_proposed_wk from (
                    select max(median_proposed_bucket_wk) as max_proposed_wk  from post_campaign_period
                    where load_ts = (select MAX_LOAD_TS from LATEST_LOAD_TS))
                where max_proposed_wk >12;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_pcp_004',
            'message': 'Error: post campaign period for campaign is exceeding 12 weeks'
    },
    {
            'description': 'No isolated bucket should be present',
            'query': "
                with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period
                )
                , bucket as (
                    SELECT
                        MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                        ANY_VALUE(MEDIAN_PROPOSED_BUCKET_WK) AS MEDIAN_PROPOSED_BUCKET_WK,
                    FROM
                        post_campaign_period 
                    where load_ts = (select MAX_LOAD_TS from LATEST_LOAD_TS)
                    GROUP BY
                        MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK
                    ORDER BY
                        MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK)

                    ,lagged_wk AS (
                        SELECT 
                            MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                            MEDIAN_PROPOSED_BUCKET_WK,
                            LAG(MEDIAN_PROPOSED_BUCKET_WK) OVER (ORDER BY MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) AS prev_bucket,
                            LEAD(MEDIAN_PROPOSED_BUCKET_WK) OVER (ORDER BY MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) AS next_bucket
                        FROM bucket)

                    , isolation_check AS (
                        SELECT 
                            MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                            MEDIAN_PROPOSED_BUCKET_WK,
                            prev_bucket,
                            next_bucket,
                            CASE 
                                WHEN prev_bucket IS NULL AND next_bucket != MEDIAN_PROPOSED_BUCKET_WK THEN 1  
                                WHEN next_bucket IS NULL AND prev_bucket != MEDIAN_PROPOSED_BUCKET_WK THEN 1  
                                WHEN MEDIAN_PROPOSED_BUCKET_WK != prev_bucket AND MEDIAN_PROPOSED_BUCKET_WK != next_bucket THEN 1
                                ELSE 0 
                            END AS is_isolated
                        FROM lagged_wk   
                    )
                select * from isolation_check
                where is_isolated>0;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_pcp_005',
            'message': 'Error: isolated bucket is present'
    },
    {
            'description': 'max median week should be taken for each proposed bucket',
            'query': "
                with LATEST_LOAD_TS AS (
                    SELECT MAX(LOAD_TS) AS MAX_LOAD_TS
                    FROM post_campaign_period)


                , bucket as (
                SELECT
                    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                    ANY_VALUE(MEDIAN_PROPOSED_BUCKET_WK) AS MEDIAN_PROPOSED_BUCKET_WK,
                FROM
                    post_campaign_period 
                where load_ts = (select MAX_LOAD_TS from LATEST_LOAD_TS)
                GROUP BY
                    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK
                ORDER BY
                    MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK)
                    
                , bucketed_max AS (
                    SELECT
                        pb.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK,
                        pb.median_proposed_bucket_wk,
                        MAX(pb.MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK) OVER (PARTITION BY pb.median_proposed_bucket_wk) AS max_value
                    FROM bucket AS pb
                )

                select MEDIAN_TIME_PERIOD_BETWEEN_TRANSACTIONS_WK
                    , median_proposed_bucket_wk,
                    max_value, 
                    CASE 
                            WHEN median_proposed_bucket_wk != max_value THEN 1  
                            ELSE 0 
                    END AS is_not_max
                    
                from bucketed_max
                where is_not_max !=0 ;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_pcp_006',
            'message': 'Error: max median week is not the proposed bucket'
    },

    ] %}

    {{ return(checks) }}

{% endmacro %}