/* Description: This macro is used for validating the attribution_pre_requisite_Brand
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
*/
{% macro attribution_pre_requisite_brand_macro(booking_id) %}

    {% set checks = [
        {
            'description': 'Journey type should be consistent with Brand data',
            'query': "
                with BRAND_BOOKING_DATA as (
                    SELECT DISTINCT
                    '"~ booking_id ~"' as BOOKING_ID
                    , CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                
                )
                , ATTR_PRE_REQ_BRAND_DATA as (
                    SELECT DISTINCT JOURNEY_TYPE
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    where (BOOKING_ID, CAMPAIGN_DURATION) in (select BOOKING_ID, CAMPAIGN_DURATION from BRAND_BOOKING_DATA)
                    and LOAD_TS = (select max(LOAD_TS) from ATTRIBUTION_PRE_REQUISITE_BRAND
                        where (BOOKING_ID,CAMPAIGN_DURATION) in (select BOOKING_ID, CAMPAIGN_DURATION from BRAND_BOOKING_DATA)
                    and JOURNEY_TYPE <> 'Brand'
                    )
                ) SELECT * FROM ATTR_PRE_REQ_BRAND_DATA;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_001',
            'message': 'Error: Records found with journey type not equal to Brand'
        },

        {
            'description': 'Regression Variable should not contain invalid characters (-, ,, spaces)',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                ATTR_PRE_REQ_BRAND_DATA AS (
                    SELECT DISTINCT JOURNEY_TYPE, REGRESSION_VARIABLE 
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND (
                        REGRESSION_VARIABLE LIKE '%-%' 
                        OR REGRESSION_VARIABLE LIKE '%,%' 
                        OR REGRESSION_VARIABLE LIKE '% %'
                    )
                )
                SELECT * FROM ATTR_PRE_REQ_BRAND_DATA;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_002',
            'message': 'Error: Regression variables contain invalid characters (-, ,, spaces)'
        },
        
        {
            'description': 'Total Sales Channel wise matches USER_JOURNEY_BRAND',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                SELECT DISTINCT
                    '"~ booking_id ~"' as BOOKING_ID, 
                    CAMPAIGN_DURATION
                FROM MEASUREMENT_CAMPAIGN_EXECUTION
                WHERE BOOKING_ID = '"~ booking_id ~"'
                AND JOB_STATUS = 'In-progress'
            ),
                -- Get sales data from ATTRIBUTION_PRE_REQUISITE_BRAND
                APB_SALES AS (
                    SELECT 
                        BOOKING_ID, 
                        CHANNEL_NAME as channel, 
                        SUM(NET_SALES_AMT) as apb_sales_amount
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND EVENT_NAME = 'Purchase Transaction' 
                    GROUP BY BOOKING_ID, CHANNEL_NAME
                ),
                UJO_SALES AS (
                    SELECT 
                        BOOKING_ID, 
                        CHANNEL_NAME as channel, 
                        SUM(NET_SALES_AMT) as ujo_sales_amount
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND EVENT_NAME = 'Purchase Transaction'
                    GROUP BY BOOKING_ID, CHANNEL_NAME
                ),
                SALES_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.channel, u.channel) as CHANNEL_NAME,
                        COALESCE(a.apb_sales_amount, 0) as attribution_sales,
                        COALESCE(u.ujo_sales_amount, 0) as user_journey_sales
                    FROM APB_SALES a
                    FULL OUTER JOIN UJO_SALES u
                        ON a.BOOKING_ID = u.BOOKING_ID
                        AND a.channel = u.channel
                    WHERE COALESCE(a.apb_sales_amount, 0) <> COALESCE(u.ujo_sales_amount, 0)
                )
                SELECT * FROM SALES_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_003',
            'message': 'Error: Total sales by channel do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Total Distinct Loyalty IDs matches USER_JOURNEY_BRAND',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_LOYALTY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT LOYALTY_ID) as apb_loyalty_count
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                UJO_LOYALTY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT LOYALTY_ID) as ujo_loyalty_count
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                LOYALTY_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_loyalty_count, 0) as attribution_loyalty_count,
                        COALESCE(u.ujo_loyalty_count, 0) as user_journey_loyalty_count
                    FROM APB_LOYALTY a
                    FULL OUTER JOIN UJO_LOYALTY u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_loyalty_count, 0) <> COALESCE(u.ujo_loyalty_count, 0)
                )
                SELECT * FROM LOYALTY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_004',
            'message': 'Error: Total distinct loyalty IDs do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Distinct User Journey IDs matches USER_JOURNEY_BRAND',
            'query': "
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as apb_journey_count
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                UJO_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as ujo_journey_count
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    GROUP BY BOOKING_ID
                ),
                JOURNEY_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_journey_count, 0) as attribution_journey_count,
                        COALESCE(u.ujo_journey_count, 0) as user_journey_journey_count
                    FROM APB_JOURNEY a
                    FULL OUTER JOIN UJO_JOURNEY u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_journey_count, 0) <> COALESCE(u.ujo_journey_count, 0)
                )
                SELECT * FROM JOURNEY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_005',
            'message': 'Error: Distinct user journey IDs do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Converted Distinct Loyalty IDs matches USER_JOURNEY_BRAND',
            'query': "
                
                WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_CONVERTED_LOYALTY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT LOYALTY_ID) as apb_converted_loyalty_count
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 1
                    GROUP BY BOOKING_ID
                ),
                UJO_CONVERTED_LOYALTY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT LOYALTY_ID) as ujo_converted_loyalty_count
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 1
                    GROUP BY BOOKING_ID
                ),
                CONVERTED_LOYALTY_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_converted_loyalty_count, 0) as attribution_converted_loyalty_count,
                        COALESCE(u.ujo_converted_loyalty_count, 0) as user_journey_converted_loyalty_count
                    FROM APB_CONVERTED_LOYALTY a
                    FULL OUTER JOIN UJO_CONVERTED_LOYALTY u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_converted_loyalty_count, 0) <> COALESCE(u.ujo_converted_loyalty_count, 0)
                )
                SELECT * FROM CONVERTED_LOYALTY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_006',
            'message': 'Error: Converted distinct loyalty IDs do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Converted Distinct User Journey IDs matches USER_JOURNEY_BRAND',
            'query': "
               WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_CONVERTED_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as apb_converted_journey_count
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 1
                    GROUP BY BOOKING_ID
                ),
                UJO_CONVERTED_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as ujo_converted_journey_count
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 1
                    GROUP BY BOOKING_ID
                ),
                CONVERTED_JOURNEY_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_converted_journey_count, 0) as attribution_converted_journey_count,
                        COALESCE(u.ujo_converted_journey_count, 0) as user_journey_converted_journey_count
                    FROM APB_CONVERTED_JOURNEY a
                    FULL OUTER JOIN UJO_CONVERTED_JOURNEY u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_converted_journey_count, 0) <> COALESCE(u.ujo_converted_journey_count, 0)
                )
                SELECT * FROM CONVERTED_JOURNEY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_007',
            'message': 'Error: Converted distinct user journey IDs do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Non-Converted Distinct User Journey IDs matches USER_JOURNEY_BRAND',
            'query': "
               WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_NONCONVERTED_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as apb_nonconverted_journey_count
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 0
                    GROUP BY BOOKING_ID
                ),
                UJO_NONCONVERTED_JOURNEY AS (
                    SELECT 
                        BOOKING_ID, 
                        COUNT(DISTINCT USERJOURNEY_ID) as ujo_nonconverted_journey_count
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND ISCONVERSION = 0
                    GROUP BY BOOKING_ID
                ),
                NONCONVERTED_JOURNEY_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_nonconverted_journey_count, 0) as attribution_nonconverted_journey_count,
                        COALESCE(u.ujo_nonconverted_journey_count, 0) as user_journey_nonconverted_journey_count
                    FROM APB_NONCONVERTED_JOURNEY a
                    FULL OUTER JOIN UJO_NONCONVERTED_JOURNEY u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_nonconverted_journey_count, 0) <> COALESCE(u.ujo_nonconverted_journey_count, 0)
                )
                SELECT * FROM NONCONVERTED_JOURNEY_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_008',
            'message': 'Error: Non-converted distinct user journey IDs do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Total Sales matches USER_JOURNEY_BRAND',
            'query': "
               WITH BOOKING_ID_AND_DURATION AS (
                    SELECT DISTINCT
                        '"~ booking_id ~"' as BOOKING_ID, 
                        CAMPAIGN_DURATION
                    FROM MEASUREMENT_CAMPAIGN_EXECUTION
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND JOB_STATUS = 'In-progress'
                ), 
                APB_TOTAL_SALES AS (
                    SELECT 
                        BOOKING_ID, 
                        SUM(NET_SALES_AMT) as apb_total_sales
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND EVENT_NAME = 'Purchase Transaction'
                    GROUP BY BOOKING_ID
                ),
                UJO_TOTAL_SALES AS (
                    SELECT 
                        BOOKING_ID, 
                        SUM(NET_SALES_AMT) as ujo_total_sales
                    FROM USER_JOURNEY_BRAND
                    WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION)
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM USER_JOURNEY_BRAND 
                                WHERE (BOOKING_ID, CAMPAIGN_DURATION) IN (SELECT BOOKING_ID, CAMPAIGN_DURATION FROM BOOKING_ID_AND_DURATION))
                    AND EVENT_NAME = 'Purchase Transaction'
                    GROUP BY BOOKING_ID
                ),
                TOTAL_SALES_COMPARISON AS (
                    SELECT 
                        COALESCE(a.BOOKING_ID, u.BOOKING_ID) as BOOKING_ID,
                        COALESCE(a.apb_total_sales, 0) as attribution_total_sales,
                        COALESCE(u.ujo_total_sales, 0) as user_journey_total_sales
                    FROM APB_TOTAL_SALES a
                    FULL OUTER JOIN UJO_TOTAL_SALES u
                        ON a.BOOKING_ID = u.BOOKING_ID
                    WHERE COALESCE(a.apb_total_sales, 0) <> COALESCE(u.ujo_total_sales, 0)
                )
                SELECT * FROM TOTAL_SALES_COMPARISON;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_apb_009',
            'message': 'Error: Total sales do not match between ATTRIBUTION_PRE_REQUISITE_BRAND and USER_JOURNEY_BRAND'
        },

        {
            'description': 'Distinct User Journey Count - Direct',
            'query': "
                WITH BRAND_BOOKING_DATA AS (
                    SELECT 
                        '"~ booking_id ~"' as BOOKING_ID,
                        CAMPAIGN_DURATION,
                        CUSTOMER_JOURNEY_TYPE,
                        USERJOURNEY_ID
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND CAMPAIGN_DURATION = 'During'
                ),
                FINAL_CHECK AS (
                    SELECT 
                        'Distinct user jouney count -Direct' as parameter, 
                        BOOKING_ID, 
                        'NA' as PRODUCT_TYPE, 
                        'NA' as CHANNEL_NAME, 
                        TO_VARCHAR(count(distinct USERJOURNEY_ID)) as value 
                    FROM BRAND_BOOKING_DATA 
                    WHERE CUSTOMER_JOURNEY_TYPE = 'Direct' 
                    GROUP BY BOOKING_ID
                )
                SELECT
                        value,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                    FROM FINAL_CHECK
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_apb_info_001',
            'message': 'Count of direct user journeys'
        },

        {
            'description': 'Distinct User Journey Count - Non Direct',
            'query': "
                WITH BRAND_BOOKING_DATA AS (
                        SELECT 
                            '"~ booking_id ~"' as BOOKING_ID,
                            CAMPAIGN_DURATION,
                            CUSTOMER_JOURNEY_TYPE,
                            USERJOURNEY_ID
                        FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                        WHERE BOOKING_ID = '"~ booking_id ~"'
                        AND CAMPAIGN_DURATION = 'During'
                    ),
                    FINAL_CHECK AS (
                        SELECT 
                            'Distinct user journey count -Non Direct' as parameter, 
                            BOOKING_ID, 
                            'NA' as PRODUCT_TYPE, 
                            'NA' as CHANNEL_NAME, 
                            TO_VARCHAR(count(distinct USERJOURNEY_ID)) as value 
                        FROM BRAND_BOOKING_DATA 
                        WHERE CUSTOMER_JOURNEY_TYPE = 'Non-direct' 
                        GROUP BY BOOKING_ID
                    )
                    SELECT
                        value,
                        CHANNEL_NAME,
                        PRODUCT_TYPE,
                        BOOKING_ID
                    FROM FINAL_CHECK
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_apb_info_002',
            'message': 'Count of non-direct user journeys'
        },

        {
            'description': 'Regression Variable Wise Distinct Total Journey IDs',
            'query': "
                WITH BRAND_BOOKING_DATA AS (
                    SELECT 
                        '"~ booking_id ~"' as BOOKING_ID,
                        CAMPAIGN_DURATION,
                        CHANNEL_NAME,
                        SUBCHANNEL_NAME,
                        USERJOURNEY_ID
                    FROM ATTRIBUTION_PRE_REQUISITE_BRAND 
                    WHERE BOOKING_ID = '"~ booking_id ~"'
                    AND CAMPAIGN_DURATION = 'During'
                ),
                FINAL_CHECK AS (
                    SELECT 
                        'Regression Variable Wise distinct total journey ids' as parameter, 
                        BOOKING_ID,
                        CHANNEL_NAME, 
                        SUBCHANNEL_NAME,
                        'NA' AS PRODUCT_TYPE, 
                        TO_VARCHAR(count(distinct USERJOURNEY_ID)) as value 
                    FROM BRAND_BOOKING_DATA 
                    GROUP BY BOOKING_ID, CHANNEL_NAME, SUBCHANNEL_NAME
                )
                SELECT 
                    value,
                    CHANNEL_NAME,
                    PRODUCT_TYPE, 
                    BOOKING_ID,
                    SUBCHANNEL_NAME
                FROM FINAL_CHECK;
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_apb_info_003',
            'message': 'Count of distinct journeys by regression variable and journey type'
        }
    ] %}

    {{ return(checks) }}

{% endmacro %}