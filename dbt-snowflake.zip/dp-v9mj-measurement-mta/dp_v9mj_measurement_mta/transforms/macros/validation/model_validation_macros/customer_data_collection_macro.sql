{# /* Description: This macro is used for validating the customer data collection data 
as per defined checks.
Dummy query is used in checks where KPI type is metric.
Params: Booking_id
*/ #}
{% macro customer_data_collection_macro(booking_id) %}


    {% set checks = [
        {
            'description': 'There should not be any Direct Conversions',
            'query': "
                WITH CUSTOMER_DATA AS (
                                        SELECT BOOKING_ID, TRANSACTION_KEY, SUBCHANNEL_NAME, LOAD_TS  FROM CUSTOMER_DATA_COLLECTION
                                        WHERE BOOKING_ID IN ('"~ booking_id ~"')
                                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                                    )
                , TOUCHPOINT_DATA AS (
                                        SELECT DISTINCT TRANSACTION_KEY FROM CUSTOMER_DATA WHERE SUBCHANNEL_NAME = 'TXN' 
                                        AND TRANSACTION_KEY NOT IN (SELECT DISTINCT TRANSACTION_KEY FROM CUSTOMER_DATA WHERE SUBCHANNEL_NAME!='TXN')
                                    )
                SELECT TRANSACTION_KEY FROM TOUCHPOINT_DATA
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_001',
            'message': 'Error : Direct Conversons exists'
        },

        {
            'description': 'There should not be more than one audience for a loyalty id for Offsite channels',
            'query': "
                WITH CUSTOMER_DATA AS (
                                        SELECT BOOKING_ID, CAMPAIGN_ID, SUBCHANNEL_NAME, CHANNEL_NAME, EVENT_NAME, LOYALTY_ID, LOAD_TS FROM CUSTOMER_DATA_COLLECTION
                                        WHERE BOOKING_ID IN ('"~ booking_id ~"')
                                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                                    )
                , FINAL_CHECK AS (
                                    SELECT CAMPAIGN_ID,'NA','NA','NA',TO_VARCHAR(COUNT(DISTINCT(SUBCHANNEL_NAME))) AS TOT FROM CUSTOMER_DATA 
                                    WHERE CHANNEL_NAME IN ('DV360', 'META' ,'YOUTUBE') 
                                    AND EVENT_NAME = 'Touchpoint' GROUP BY CAMPAIGN_ID,LOYALTY_ID HAVING TOT > 1
                                )
                SELECT CAMPAIGN_ID FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_002',
            'message': 'Error : More than one audience for a loyalty id for Offsite channels exists'
        },

        {
            'description': 'Transactions/Sales data should match with the source table',
            'query': "
                WITH CUSTOMER_DATA AS (
                    SELECT DISTINCT TRANSACTION_KEY,ITEM_CD,NET_SALES_AMT FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                ),
                TRANSACTION_SALES_DATA AS (
                    SELECT TRANSACTION_ID, ITEM_CD, NET_RETAIL_SALES_AMT FROM ADW_PROD.ADW_SALES_PL.FACT_SALE_TRANSACTION_ITEM 
                    WHERE (TRANSACTION_ID, ITEM_CD) IN (SELECT DISTINCT TRANSACTION_KEY, ITEM_CD FROM CUSTOMER_DATA) AND NET_RETAIL_SALES_AMT > 0
                ),
                SUM_SALES_AMT AS (
                    SELECT TRANSACTION_ID, ITEM_CD, SUM(NET_RETAIL_SALES_AMT) AS NET_SALES_AMT FROM TRANSACTION_SALES_DATA GROUP BY TRANSACTION_ID, ITEM_CD
                ),
                FINAL_CHECK AS (
                    SELECT C1.TRANSACTION_ID, C1.ITEM_CD, C1.NET_SALES_AMT, C2.NET_SALES_AMT FROM SUM_SALES_AMT C1 JOIN CUSTOMER_DATA C2 ON C1.TRANSACTION_ID = C2.TRANSACTION_KEY 
                    AND C1.ITEM_CD = C2.ITEM_CD AND C1.NET_SALES_AMT != C2.NET_SALES_AMT
                )
                SELECT TRANSACTION_ID, ITEM_CD  FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_003',
            'message': 'Error : Transactions/Sales data does not match with the source table'
        },

        {
            'description': 'Sales amount should always be positive',
            'query': "
                WITH FINAL_CHECK AS (
                    SELECT BOOKING_ID, NET_SALES_AMT, CAMPAIGN_ID, LOAD_TS FROM CUSTOMER_DATA_COLLECTION WHERE NET_SALES_AMT < 0
                    AND BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                SELECT BOOKING_ID, NET_SALES_AMT, CAMPAIGN_ID FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_004',
            'message': 'Error : Negative sales amount exists'
        },

        {
            'description': 'Units quantity should be a positive integer value',
            'query': "
                WITH PRE_UNIT AS (
                        SELECT DISTINCT CAMPAIGN_ID,TRANSACTION_KEY,PRODUCT_TYPE,UNITS_QTY,CHANNEL_NAME,SUBCHANNEL_NAME,ITEM_CD FROM CUSTOMER_DATA_COLLECTION
                        WHERE EVENT_NAME = 'Purchase Transaction'
                        AND BOOKING_ID IN ('"~ booking_id ~"')
                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                , TOTAL_UNITS AS (
                        SELECT CAMPAIGN_ID,TRANSACTION_KEY,PRODUCT_TYPE,UNITS_QTY,CHANNEL_NAME,SUBCHANNEL_NAME,ITEM_CD FROM PRE_UNIT
                        WHERE UNITS_QTY < 1
                )
                SELECT * FROM TOTAL_UNITS LIMIT 1
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_005',
            'message': 'Error : Unit quantity is less than one'
        },

        {
            'description': 'Check duplicates in the data',
            'query': "
                WITH CUSTOMER_DATA AS (
                        SELECT BOOKING_ID,TRANSACTION_KEY,ITEM_CD,LOYALTY_ID,CHANNEL_NAME,SUBCHANNEL_NAME,PRODUCT_TYPE,EVENT_TS,LOAD_TS, CAMPAIGN_ID
                        FROM CUSTOMER_DATA_COLLECTION
                        WHERE BOOKING_ID IN ('"~ booking_id ~"')
                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                , FINAL_CHECK AS (
                        SELECT BOOKING_ID,TRANSACTION_KEY,ITEM_CD,LOYALTY_ID,CHANNEL_NAME,SUBCHANNEL_NAME,PRODUCT_TYPE,EVENT_TS, CAMPAIGN_ID, LOAD_TS 
                        FROM CUSTOMER_DATA GROUP BY 1,2,3,4,5,6,7,8,9,10 HAVING COUNT(*) > 1
                )
                SELECT BOOKING_ID,TRANSACTION_KEY,ITEM_CD,LOYALTY_ID,CHANNEL_NAME,SUBCHANNEL_NAME,PRODUCT_TYPE,EVENT_TS FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_006',
            'message': 'Error : There is duplicate data present.'
        },

        {
            'description': 'Customer Transaction date should always be between campaign start and end date',
            'query': "
                WITH CUSTOMER_DATA AS (
                        SELECT BOOKING_ID, CAMPAIGN_ID, EVENT_DT, LOAD_TS FROM CUSTOMER_DATA_COLLECTION
                        WHERE BOOKING_ID IN ('"~ booking_id ~"')
                        AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                , FINAL_CHECK AS (
                        SELECT BOOKING_ID, CAMPAIGN_ID, EVENT_DT FROM CUSTOMER_DATA WHERE EVENT_DT 
                        NOT BETWEEN (SELECT MIN(CAMPAIGN_START_DT) FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                        AND (SELECT MAX(CAMPAIGN_END_DT) FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                        AND BOOKING_ID IN ('"~ booking_id ~"')
                )
                SELECT BOOKING_ID, CAMPAIGN_ID, EVENT_DT FROM FINAL_CHECK
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_007',
            'message': 'Error : Customer Transaction date is outside campaign start and end date'
        },

        {
            'description': 'Row count should not be zero',
            'query': "
                WITH CUST_DATA AS (
                    SELECT BOOKING_ID, LOAD_TS FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                SELECT 'NO DATA FOUND' AS ROW_COUNT WHERE (SELECT COUNT(*) FROM CUST_DATA ) < 1;
            ",
            'metric': 'FALSE',
            'result': 'Fail',
            'kpi_type': 'Data',
            'kpi_code': 'mta_cdc_008',
            'message': 'Error: Total row counts of the data is zero.'
        },

        {
            'description': 'Row Counts',
            'query': "
                SELECT count(*) as metric_value,
                'Total rows count' as message FROM CUSTOMER_DATA_COLLECTION
                WHERE BOOKING_ID IN ('"~ booking_id ~"')
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdc_info_001',
            'message': 'Total row counts of the data.'
        },

        {
            'description': 'Total distinct loyality IDs counts',
            'query': "
                WITH LOYALITY_ID_DATA AS (
                    SELECT COUNT(DISTINCT LOYALTY_ID) AS METRIC_VALUE
                    FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                )
                SELECT METRIC_VALUE, 'Total loyalty IDs count' AS MESSAGE FROM LOYALITY_ID_DATA
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdc_info_002',
            'message': 'Total distinct loyality IDs counts of the data.'
        },

        {
            'description': 'Total net sales amount product wise',
            'query': "
                SELECT SUM(NET_SALES_AMT) AS METRIC_VALUE,
                'NA' AS CHANNEL_NAME, PRODUCT_TYPE FROM CUSTOMER_DATA_COLLECTION 
                WHERE BOOKING_ID IN ('"~ booking_id ~"')
                AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                AND PRODUCT_TYPE IN ('Brand', 'Offer', 'Aisle' )
                GROUP BY PRODUCT_TYPE
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdc_info_003',
            'message': 'Total net sales amount of the data product wise.'
        },

        {
            'description': 'Total distinct loyality IDs counts channel wise',
            'query': "
                WITH LOYALITY_ID_DATA AS (
                    SELECT COUNT(DISTINCT LOYALTY_ID) AS METRIC_VALUE, CHANNEL_NAME FROM CUSTOMER_DATA_COLLECTION
                    WHERE BOOKING_ID IN ('"~ booking_id ~"')
                    AND LOAD_TS = (SELECT MAX(LOAD_TS) FROM CUSTOMER_DATA_COLLECTION WHERE BOOKING_ID IN ('"~ booking_id ~"'))
                    GROUP BY CHANNEL_NAME
                )
                SELECT METRIC_VALUE, CHANNEL_NAME, 'NA' AS PRODUCT_TYPE
                FROM LOYALITY_ID_DATA
            ",
            'metric': 'INFO',
            'result': 'Info',
            'kpi_type': 'Metric',
            'kpi_code': 'mta_cdc_info_004',
            'message': 'Total distinct loyality IDs counts channel wise.'
        },

    ] %}

    {{ return(checks) }}

{% endmacro %}