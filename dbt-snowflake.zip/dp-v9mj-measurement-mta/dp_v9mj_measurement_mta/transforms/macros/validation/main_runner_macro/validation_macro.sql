{# /* Description: This macro is used for running the validation macros of models.
It sets the default data, run pre checks and sets required values for running
model validation macros.
Params: model_name
*/
#}
{% macro validation_macro_run(model_name) %}

    {% set pipeline_value = 'MTA' %}
    {% set model_name_value = model_name %}
    {% set booking_id_value = 'NA' %}
    {% set campaign_id_value = 'NA' %}
    {% set campaign_duration_value = 'NA' %}
    {% set channel_value = 'NA' %}
    {% set sub_channel_value = 'NA' %}
    {% set product_type_value = 'NA' %}
    {% set campaign_type_value = 'NA' %}
    {% set brand_name_value = 'NA' %}
    {% set super_category_value = 'NA' %}
    {% set cluster_num_value = 'NA' %}
    {% set actual_value = 'NA' %}
    {% set expected_value = 'NA' %}
    {% set job_run_value = invocation_id %}
    {% set time_stamp_value = run_started_at.strftime('%Y-%m-%d %H:%M:%S') %}

    {% set run_id_value = env_var("AIRFLOW_CTX_DAG_RUN_ID", "LOCAL_RUN") %}

    {% set schema_value = 'ADW_UNIFIED_PLATFORM_TACTICAL' %}
    {% set table_name = model_name | upper %}

    
    {% set measurement_execution_query %} 
    
    SELECT *
    FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE JOB_STATUS = 'In-progress' LIMIT 1

    {% endset %}

    {% set offsite_execution_query %} 
    
    SELECT *
    FROM MEASUREMENT_CAMPAIGN_EXECUTION WHERE JOB_STATUS = 'In-progress' AND CHANNEL_NAME IN ('DV360','Meta','YouTube') and campaign_duration = 'During'

    {% endset %}

    {% set execution_query_result = run_query(measurement_execution_query) %}

    {% set offsite_query_result = run_query(offsite_execution_query) %}

    {% set run_status = 'no_run' %}

    {# /* running validation which are not dependent on any booking_id */ #}
    {% if model_name == 'post_campaign_period' %}
        {% set checks = post_campaign_period_macro() %}
        {% set run_status = 'run' %}
    {% endif %}

    {# /* Check if booking id available for running validation */ #}
    {% if execution_query_result and execution_query_result.rows|length > 0 %}
        {% set booking_id_value = execution_query_result[0][1] %}
        {% set campaign_id_value = execution_query_result[0][0] %}
        {% set campaign_duration_value = execution_query_result[0][9] %}

        {% if model_name == 'customer_data_collection' %}
            {% set checks = customer_data_collection_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_pre_requisite_offer' %}
            {% set checks = attribution_pre_requisite_offer_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_pre_requisite_brand' %}
            {% set checks = attribution_pre_requisite_brand_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_pre_requisite_aisle' %}
            {% set checks = attribution_pre_requisite_aisle_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_model_results_offer' %}
            {% set checks = attribution_model_results_offer_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_model_results_brand' %}
            {% set checks = attribution_model_results_brand_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'attribution_model_results_aisle' %}
            {% set checks = attribution_model_results_aisle_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'reach_engagement' %}
            {% set checks = reach_engagement_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'user_journey_offer' %}
            {% set checks = user_journey_validation_macro(booking_id_value, model_name, 'ujo', 'offer', campaign_duration_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'user_journey_brand' %}
            {% set checks = user_journey_validation_macro(booking_id_value, model_name, 'ujb', 'brand', campaign_duration_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'user_journey_aisle' %}
            {% set checks = user_journey_validation_macro(booking_id_value, model_name, 'uja', 'aisle', campaign_duration_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'baseline_attribution_integration_sku_level_offer' %}
             {% set checks = baseline_attribution_integration_sku_level_offer_macro(booking_id_value) %}
             {% set run_status = 'run' %}
        {% elif model_name == 'baseline_attribution_integration_sku_level_brand' %}
             {% set checks = baseline_attribution_integration_sku_level_brand_macro(booking_id_value) %}
             {% set run_status = 'run' %}
        {% elif model_name == 'baseline_attribution_integration_sku_level_aisle' %}
             {% set checks = baseline_attribution_integration_sku_level_aisle_macro(booking_id_value) %}
             {% set run_status = 'run' %}
        {% elif model_name == 'campaign_decay_rate' and offsite_query_result and offsite_query_result.rows|length > 0 %}
             {% set checks = campaign_decay_rate_macro(booking_id_value) %}
             {% set run_status = 'run' %}       
        {% elif model_name == 'sku_level_attributed_sales_and_units_aisle' %}
            {% set checks = sku_level_attributed_sales_and_units_aisle_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'sku_level_attributed_sales_and_units_offer' %}
            {{ log("Checking in the validation macro offer: ", info=True ) }}
            {% set checks = sku_level_attributed_sales_and_units_offer_macro(booking_id_value) %}
            {% set run_status = 'run' %}
        {% elif model_name == 'sku_level_attributed_sales_and_units_brand' %}
            {{ log("Checking in the validation macro: ", info=True ) }}
            {% set checks = sku_level_attributed_sales_and_units_brand_macro(booking_id_value) %}

        {% elif model_name == 'measurement_campaign_reporting' %}
            {% set checks = measurement_campaign_reporting_macro(booking_id_value) %}

            {% set run_status = 'run' %}
        {% endif %}
    {% endif %}
    {# /*  Set run status and run all the checks in the validation macro */ #}
    {% if run_status == 'run' %}
        {% for check in checks %}
            {% set metric_value = 'TRUE' %}
            {% set result_value = 'Pass' %}
            {% set message_value = '' %}

            {% set check_result = run_query(check.query) %}

            {% if check_result and check_result.rows|length > 0 %}
                {% set metric_value = check.metric %}
                {% set result_value = check.result %}
                {% set message_value = check.message %}
            {% endif %}
            {# /* If metric is INFO insert data for all the records in the result */ #}
            {% if check.metric == 'INFO' %}
                {% for data in check_result %}
                    {% set metric_value = data[0] | default('NA') %}
                    {% if data[1] %}
                    {% set channel_value = data[1] | default('NA') %}
                    {% endif %}
                    {% if data[2] %}
                    {% set product_type_value = data[2] | default('NA') %}
                    {% endif %}
                    {% if data[4] %}
                    {% set sub_channel_value = data[4] | default('NA') %}
                    {% endif %}
                    {% if data[5] %}
                    {% set campaign_id = data[5] %}
                    {% endif %}

                    {{ insert_record([
                            pipeline_value,
                            model_name_value,
                            check.description,
                            booking_id_value,
                            campaign_id_value,
                            channel_value,
                            sub_channel_value,
                            product_type_value,
                            campaign_type_value,
                            brand_name_value,
                            super_category_value,
                            cluster_num_value,
                            metric_value,
                            result_value,
                            actual_value,
                            expected_value,
                            time_stamp_value,
                            job_run_value,
                            check.kpi_type,
                            check.kpi_code,
                            message_value,
                            run_id_value
                        ]) 
                    }}
                {% endfor %}
            {% endif %}

            {% if check.metric != 'INFO' %}
                {# Insert record in validation table for each check #}
                {{ insert_record([
                        pipeline_value,
                        model_name_value,
                        check.description,
                        booking_id_value,
                        campaign_id_value,
                        channel_value,
                        sub_channel_value,
                        product_type_value,
                        campaign_type_value,
                        brand_name_value,
                        super_category_value,
                        cluster_num_value,
                        metric_value,
                        result_value,
                        actual_value,
                        expected_value,
                        time_stamp_value,
                        job_run_value,
                        check.kpi_type,
                        check.kpi_code,
                        message_value,
                        run_id_value
                    ]) 
                }}
            {% endif %}
        {% endfor %}

        {# Terminating the pipeline if failure happens #}
        {% set latest_load_ts_query %} 
        
        SELECT LOAD_TS, RESULT, KPI_CODE
        FROM {{ var('MEASUREMENT_VALIDATION_METRICS') }}
        WHERE LOAD_TS = (SELECT MAX(LOAD_TS) FROM {{var('MEASUREMENT_VALIDATION_METRICS')}})
        AND PIPELINE = 'MTA'

        {% endset %}

        {% set latest_load_ts_result = run_query(latest_load_ts_query) %}
        {# /* Check if record is latest and fail pipeline if result is fail for any check */ #}
        {% if latest_load_ts_result and latest_load_ts_result.rows|length > 0 %}
            {% for row in latest_load_ts_result.rows %}
                {% if row['RESULT'] == 'Fail' %}
                    {{ update_booking_status_validation_failure(booking_id_value) }}
                    {% do exceptions.raise_compiler_error('Validation Error: ' ~ row['KPI_CODE'] ~ ' failed. Check '~ schema_value ~ '.'~ table_name ~ ' table for more details.') %}
                {% endif %}
            {% endfor %}
        {% endif %}
    {% else %}
        {% set metric_value = 'TRUE' %}
        {% set result_value = 'Pass' %}
        {% set message_value = 'No new records to be added' %}
        {# /* If notnew data found to run validation, updates the table no new data present */ #}
        {# Insert record in validation table for each check #}
        {{ insert_record([
                pipeline_value,
                model_name_value,
                'No new data present to be added',
                booking_id_value,
                campaign_id_value,
                channel_value,
                sub_channel_value,
                product_type_value,
                campaign_type_value,
                brand_name_value,
                super_category_value,
                cluster_num_value,
                metric_value,
                result_value,
                actual_value,
                expected_value,
                time_stamp_value,
                job_run_value,
                '',
                '',
                message_value,
                run_id_value
            ]) 
        }}
    {% endif %}

{% endmacro %}

{# /* Description: This macro is used to mark the booking id as failed in both
 measurement_campaign_execution and unified_campaign in case any validation gets failed
Params:booking_id
*/
#}
{% macro update_booking_status_validation_failure(booking_id) %}

    {{ log("Marking  bookingid as failed for validation failures", info=True ) }}

    {% set sql1 %} 
        update {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }} set campaign_status = 'Failed' where booking_id = '{{ booking_id }}' and load_ts = (select max(load_ts) from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'UNIFIED_CAMPAIGN') }});
    {% endset %}

    {% set sql2 %}
        update {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'MEASUREMENT_CAMPAIGN_EXECUTION') }} set job_status = 'Failed' where booking_id = '{{ booking_id }}' and job_status in ('In-progress','Not Started');
    {% endset %}
    {% set result1 =  run_query(sql1) %}
    {% set result2 =  run_query(sql2) %}
    
{% endmacro %}
