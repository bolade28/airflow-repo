{# /* Description: This macro is used for inserting metrics record to the measurement validation
table. It checks the required the columns and insert the data.
Params: value, table_name, columns, database, schema
*/ #}
{% macro insert_record(value, table_name=None, columns=None, database=None, schema=None) %}


    {% if not table_name %}
        {% set table_name = 'ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_VALIDATION_METRICS' %}
    {% endif %}

    {% if not columns %}
        {% set columns = ['PIPELINE', 'MODEL_NAME', 'DESCRIPTION', 'BOOKING_ID', 'CAMPAIGN_ID', 'CHANNEL', 
            'SUB_CHANNEL', 'PRODUCT_TYPE', 'CAMPAIGN_TYPE', 'UNIQUE_BRAND_NAME', 'SUPER_CATEGORY_NAME', 
            'CLUSTER_NUM', 'METRIC_VALUE', 'RESULT', 'ACTUAL_VALUE', 'EXPECTED_VALUE', 'LOAD_TS', 'JOB_RUN_ID', 'KPI_TYPE', 'KPI_CODE', 'MESSAGE','RUN_ID'
        ] %}
    {% endif %}

    {% if columns|length != value|length %}
        {% do exceptions.raise_compiler_error("The number of columns must match the number of values") %}
    {% endif %}
    
    {% set insert_record %}
    
    INSERT INTO {{ table_name }} (
        {{ columns | join(', ') }}
    )
    VALUES (
        {% for val in value %}
            {% if loop.index != 1 %}, {% endif %}
            {% if val is string %}
                coalesce('{{ val }}', 'NA')
            {% else %}
                coalesce({{ val }}, 0)
            {% endif %}
        {% endfor %}
    )

    {% endset %}
 
    {% do run_query(insert_record) %}
    
{% endmacro %}
