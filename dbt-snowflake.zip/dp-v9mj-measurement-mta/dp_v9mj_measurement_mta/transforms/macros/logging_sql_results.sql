/* {#
This is a macro that fetches the command invocation id
#} */


{% macro get_invocation_id() %}

 '{{ invocation_id }}'

{% endmacro %}


/* {#
This is a macro to output the query ID and number of rows inserted and updated.
If the table is created by dbt then the query ID is sent to stdout.
#} */

{%- macro log_sql_results(tbl_created) -%}

    {% set query %}
        {% if tbl_created == 1 %}
               select last_query_id()
        {% else %}
               select LAST_QUERY_ID(-2), * from table(result_scan(LAST_QUERY_ID(-2)))
        {% endif %}
    {% endset %}

    {% set results = run_query(query) %}

    {# -- execute is a Jinja variable that returns true when dbt is in "execute" mode, i.e. it returns True when running dbt run and returns False during dbt compile. #}
    {% if execute %}

        {% set results_list = results.columns %}
        {% set col1 = results_list[0].values()[0] %}


        {% if tbl_created == 1 %}
            {{ log(" " , info=True)}}
            {{ log("Query ID:" ~ col1 , info=True)}}
            {{ log("Model created table.", info=True)}}
            {{ log(" " , info=True)}}

        {% else %}
            {% set col2 = results_list[1].values()[0] %}

            {% if results_list|length > 2 %}
                {% set col3 = results_list[2].values()[0] %}

            {% else %}
                {% set col3 = 0 %}
            {% endif %}

            {{ log(" " , info=True)}}
            {{ log("Query ID:" ~ col1  , info=True)}}
            {{ log("The number of rows Inserted:" ~ col2 ~ " The Number of rows Updated:" ~ col3, info=True)}}
            {{ log(" " , info=True)}}

        {% endif %}

    {% endif %}

{% endmacro %}

/* {#
This is a wrapper macro to log information to snowflake log table from dbt results context
This will capture some of the information which can be useful for monitoring and dashboards
param: results context variable which will hold info about dbt run and test, Log table name and Others are optional with default values.
#} */

{% macro log_run_results(results, log_table_name, log_test_flag=True, run_type_flag=False, database='snowflake') %}

  {{ log("========== Begin logging ==========", info=True) }}
  {# Check if results is NOT EMPTY" #}
  {% if results|length %}
    {% for res in results %}
      {# Prepare the insert statement" #}
      
      {% set logging_query = _prep_insert_log_query(res, log_table_name, log_test_flag, run_type_flag, database) %}
      {# Write to table #}
      {% if logging_query != "" %}
        {{ _write_to_table(logging_query) }}
      {% endif %}
    {% endfor %}
  {% else %}
    {{ log("results is empty. Rerun the DAG", info=True) }}
  {% endif %}
  {{ log("========== End logging ==========", info=True) }}

{% endmacro %}


/* {#
This is a macro to prepare the insert query from the input values received from the wrapper macro
param : results context, log_table_name, log_test_flag, run_time_hist_flag, database
return : logging_query as an insert sql statement
#} */

{% macro _prep_insert_log_query(res, log_table_name, log_test_flag, run_type_flag, database) %}
  {% set err_message = 'NONE' %}
  {% set status = res.status %}

  {# For models : unique_id will look like "model.dag_name.model_name" #}
  {# For tests  : unique_id will look like "test.dag_name.test_name.random_unique_id" #}

  {% set unique_id_split = res.node.unique_id.split('.') %}
  {% set task_type = unique_id_split[0] %}
  {% set dag_name = unique_id_split[1] %}
  {% set task_name = unique_id_split[2] %}
  {% set object_function = 'OBJECT_CONSTRUCT' %}
  {% set execution_time = res.execution_time %}
  {% set query_id = res.adapter_response.query_id if status!='error' else 'NA'  %}
  {% set rows_affected = res.adapter_response.rows_affected if status!='error' else '0'  %}
  {% set created_at = res.timing[1].started_at %}
  {% set completed_at = res.timing[1].completed_at %}
  {% set command_invocation_id = get_invocation_id() %}
  {% set airflow_dag_run_id = env_var("AIRFLOW_CTX_DAG_RUN_ID", "LOCAL_RUN") %}

  
  

  {%- if task_type == 'model' %}
      {%- if status != 'success' %}
          {# the error message can contain single quotes which needs to be escaped as we insert into table #}
          {% set err_message = escape_single_quotes(res.message) %}
      {%- endif %}
      {%- if run_type_flag == True %}
        {% set run_type = 'Historical' if var("run_time_hist_flag") | upper == 'Y' else 'Incremental' %}
        {% set message = "'err_message', '" ~ err_message ~ "', 'query_id', '" ~ res.adapter_response.query_id ~ "', 'execution_time', " ~ res.execution_time ~ ", 'rows_affected', '" ~ res.adapter_response.rows_affected ~ "', 'run_type' ,'" ~ run_type ~ "'" %}
      {%- else %}
        {% set message = "'err_message', '" ~ err_message ~ "', 'query_id', '" ~ res.adapter_response.query_id ~ "', 'execution_time', " ~ res.execution_time ~ ", 'rows_affected', '" ~ res.adapter_response.rows_affected ~ "'" %}
      {%- endif %}
      {% set logging_query = "insert into " ~ log_table_name ~ "(DAG_NAME, TASK_NAME, TASK_TYPE, STATUS, EXECUTION_TIME, QUERY_ID,ROWS_AFFECTED, COMMAND_INVOCATION_ID, AIRFLOW_DAG_RUN_ID, CREATED_AT, COMPLETED_AT, MESSAGE) select '" ~ dag_name ~ "' , '" ~ task_name ~ "' , '" ~ task_type ~ "', '" ~ status ~ "' ,'" ~ execution_time ~ "','" ~ query_id ~ "','" ~ rows_affected ~ "'," ~ command_invocation_id ~ ",'" ~ airflow_dag_run_id ~ "', '" ~ created_at ~ "', '" ~ completed_at ~ "'," ~ object_function ~ "(" ~ message ~ ") " %}

  {%- elif log_test_flag == True and task_type == 'test' %}
      {%- if status == 'pass' -%}
          {% set info = 'Test is successful' %}
          {% set message = "'err_message', '" ~ err_message ~ "', 'execution_time', " ~ res.execution_time ~ ", 'info', '" ~ info ~ "'" %}
      {%- elif status == 'skipped' %}
          {% set info = 'Test is skipped because of the model failure' %}
          {% set message = "'err_message', '" ~ err_message ~ "', 'execution_time', " ~ res.execution_time ~ ", 'info', '" ~ info ~ "'" %}
      {%- elif status == 'fail' or status == 'warn' %}
          {% set message = "'err_message', '" ~ err_message ~ "', 'execution_time', " ~ res.execution_time ~ ", 'failures', '" ~ res.failures ~ "', 'info', '" ~ res.message ~ "'" %}
      {%- else %}
          {# the error message can contain single quotes which needs to be escaped as we insert into table #}
          {% set err_message = escape_single_quotes(res.message) %}
          {% set message = "'err_message', '" ~ err_message ~ "', 'execution_time', " ~ res.execution_time ~ "" %}
      {%- endif %}
      {% set logging_query = "insert into " ~ log_table_name ~ "(DAG_NAME, TASK_NAME, TASK_TYPE, STATUS, EXECUTION_TIME, QUERY_ID,ROWS_AFFECTED, COMMAND_INVOCATION_ID, AIRFLOW_DAG_RUN_ID, CREATED_AT, COMPLETED_AT, MESSAGE) select '" ~ dag_name ~ "' , '" ~ task_name ~ "' , '" ~ task_type ~ "', '" ~ status ~ "' ,'" ~ execution_time ~ "','" ~ query_id ~ "','" ~ rows_affected ~ "'," ~ command_invocation_id ~ ",'" ~ airflow_dag_run_id ~ "', '" ~ created_at ~ "', '" ~ completed_at ~ "'," ~ object_function ~ "(" ~ message ~ ") " %}


  {# Model and test results are captured at the moment. #}
  {%- else %}
    {% set logging_query = "" %}
  {%- endif %}
  {{ return(logging_query) }}
{% endmacro %}


/* {#
This is a macro to log information into snowflake log table
param : insert sql query
#} */

{% macro _write_to_table(logging_query) %}
  {{ log("logging_query : " ~ logging_query , info=True) }}
  {% set logging_query_res = adapter.execute(logging_query) %}
  {{ log(logging_query_res, info=True) }}
{% endmacro %}

