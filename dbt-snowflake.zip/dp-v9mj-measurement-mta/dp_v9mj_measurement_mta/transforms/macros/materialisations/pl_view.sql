{%- materialization pl_view, default -%}
  {{ run_hooks(pre_hooks) }}
  {{ run_hooks(post_hooks) }}

  {%- call statement("main") -%}
    {#
      Do nothing -- PL views should be managed outside of dbt. However,
      we still need to provide _something_ otherwise dbt complains.
    #}
    select 0
  {%- endcall -%}

  {{ return({"relations": [this]}) }}
{%- endmaterialization -%}
