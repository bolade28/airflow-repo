{#
/*********************************************************************************************************************************************
* Objective -  The customer journey in the context of multi-touch attribution (MTA) involves tracking and analyzing customer interactions
* across all marketing channels—offsite, onsite, and instore—to understand how each touchpoint contributes to a customer's path
* to conversion. It involves collecting touchpoint and transaction data during campaigns to create customer journeys (Offer, Brand, Aisle)
* categorized into conversion/non-conversion journeys based on sales/no-sales.
* Confluence Link : https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657653993/Customer+Journey+Creation
* Upstream: customer_data_collection
* Downstream: attribution_pre_requisite_offer, attribution_pre_requisite_brand, attribution_pre_requisite_aisle
*
* This script will return the query for the user journey creation for Offer, Brand & Aisle.
* The macro processes data from various tables to identify and aggregate user interactions, transactions, and touchpoints,
* ultimately creating a detailed user journey dataset.
* The query will be called from the user journey models and parameters will be passed to the macro

* Owner : Divya Jain
* Date :
*
* Change Log
* ----------------------------
1. Initial Version 
*************************************************************************************************************************************************/
#}

{% macro user_journey(product_type, journey_type) %}

/** To get only the In-progress booking ids for campaign execution from the measurement_campaign_execution table
to pick the data for the campaign on which we want to run the user journey analysis
and later filter the data from customer data collection based on the booking id */
with campaign_booking_id as (
    select distinct
        booking_id
        , campaign_duration
        , channel_name
        , subchannel_name
        , campaign_id
    from {{ ref('measurement_campaign_execution') }}
    where job_status = 'In-progress'
),

/**This ensures that only the SKUs relevant to specific marketing campaigns are selected,
which will be used to filter the touchpoints and transactions for either Offer, Brand or Aisle*/
get_targeted_skus as (
    select distinct
        product_type
        , unique_brand_name
        , item_cd
        , booking_id
        , campaign_id
        , channel_name
    from {{ source('ADW_UNIFIED_PLATFORM_TACTICAL', 'CAMPAIGN_PRODUCT_TYPE') }}
    where (campaign_id, channel_name, subchannel_name) in (
        select
            campaign_id
            , channel_name
            , subchannel_name
        from campaign_booking_id
    )
        and lower(product_type) = lower('{{ product_type }}')
),

/** This CTE extracts detailed customer interaction data related to specific marketing campaigns.
 It filters records from the customer_data_collection table to include only those with booking_ids that match the 
 campaign booking IDs values which are identified in the campaign_booking_id CTE.*/
campaign_customer_data as (
    select
        loyalty_id
        , transaction_key
        , event_dt
        , event_ts
        , channel_name
        , subchannel_name
        , campaign_name
        , campaign_id
        , event_name
        , booking_id
        , item_cd
        , product_type
        , net_sales_amt
        , units_qty
        , unique_brand_name
        , marketing_type
    from {{ ref('customer_data_collection') }}
    where booking_id in
        (select booking_id from campaign_booking_id)
        and load_ts = (select max(load_ts) as load_ts
    from {{ ref('customer_data_collection') }}
    where booking_id in (select booking_id from campaign_booking_id))
),

/** This CTE ensures that each transaction is linked to the relevant campaign IDs, 
providing a comprehensive view of which campaigns influenced specific transactions.
Also, to aggregate the campaign ids as we may have same transactions done via different channels which have different
campaign ids */
get_txn_campaign_id as (
    select
        transaction_key,
        booking_id,
        listagg(distinct campaign_id, ',') within group (order by campaign_id) as campaign_id
    from campaign_customer_data
    where
        transaction_key != 'NA'
        and subchannel_name = 'TXN'
        and lower(product_type) = lower('{{ product_type }}')
    group by 1, 2
),

/** To retrieve only the transactions for passed product type and summarize the unit quantity
and sales amount later, to have only one transaction row for every journey or transactions */
get_distinct_customer_txn_data as (
    select distinct
        loyalty_id,
        transaction_key,
        event_dt,
        event_ts,
        marketing_type,
        channel_name,
        subchannel_name,
        item_cd,
        event_name,
        booking_id,
        net_sales_amt,
        units_qty
    from campaign_customer_data
    where
        lower(product_type) = lower('{{ product_type }}')
        and subchannel_name = 'TXN'
),

/**It joins the get_distinct_customer_txn_data CTE with the get_targeted_skus
CTE on product-related columns to ensure that only transactions involving the targeted SKUs are included. */
get_specific_product_type_txn as (
    select
        gdctcd.loyalty_id,
        gdctcd.transaction_key,
        gdctcd.event_dt,
        gdctcd.event_ts,
        gdctcd.marketing_type,
        gdctcd.channel_name,
        gdctcd.subchannel_name,
        gdctcd.event_name,
        gdctcd.booking_id,
        gtci.campaign_id,
        sum(gdctcd.net_sales_amt) as net_sales_amt,
        sum(gdctcd.units_qty) as units_qty
    from get_txn_campaign_id as gtci
    inner join get_distinct_customer_txn_data as gdctcd
        on gtci.transaction_key = gdctcd.transaction_key
        and gtci.booking_id = gdctcd.booking_id
    group by 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
),

/** To get only the relevant touchpoints associated with passed product type transactions */
get_specific_product_type_touchpoints as (
    select distinct
        ccd.loyalty_id,
        ccd.transaction_key,
        ccd.event_dt,
        ccd.event_ts,
        ccd.marketing_type,
        ccd.channel_name,
        ccd.subchannel_name,
        ccd.event_name,
        ccd.booking_id,
        ccd.campaign_id,
        0.00 as net_sales_amt,
        0.00 as units_qty
    from campaign_customer_data as ccd
    inner join get_distinct_customer_txn_data as gdctd
        on ccd.transaction_key = gdctd.transaction_key
    inner join get_targeted_skus as gts
        on ccd.booking_id = gts.booking_id
        and ccd.campaign_id = gts.campaign_id
        and ccd.channel_name = gts.channel_name
        and gdctd.item_cd = gts.item_cd
    where
        ccd.event_name = 'Touchpoint'
        and gts.product_type = '{{ product_type }}'
),

{# /** To retrieves touchpoint data for customers who did not purchase the specified product type */ #}
get_other_touchpoint_data as (
    select distinct
        ccd.loyalty_id,
        'NA' as transaction_key,
        ccd.event_dt,
        ccd.event_ts,
        ccd.marketing_type,
        ccd.channel_name,
        ccd.subchannel_name,
        ccd.event_name,
        ccd.booking_id,
        ccd.campaign_id,
        0.00 as net_sales_amt,
        0.00 as units_qty
    from campaign_customer_data as ccd
    where
        (ccd.transaction_key, ccd.booking_id) not in (
            select distinct
                transaction_key,
                booking_id
            from get_specific_product_type_txn
        )
        and ccd.event_name = 'Touchpoint'
),

/** This ensures that both types of data—transactions involving the specified product type 
and other relevant touchpoints—are included in the final dataset. */
union_data as (
    select * from get_specific_product_type_txn
    union all
    select * from get_specific_product_type_touchpoints
    union all
    select * from get_other_touchpoint_data
),

/** Creating subpath helps in defining the different number of journeys done by a single customer */
create_sub_path as (
    select
        uod.*,
        dense_rank() over (partition by uod.booking_id, uod.loyalty_id order by uod.transaction_key) as sub_path
    from union_data as uod
),

/** Creating user journey ids and rank to provide the different journeys representing different transactions
and the number of events associated within a journey */
create_user_journey_id_rank as (
    select
        csp.*,
        concat_ws('_', csp.loyalty_id, csp.sub_path) as userjourney_id,
        row_number() over (partition by csp.booking_id, csp.loyalty_id, csp.sub_path order by csp.event_ts asc, csp.campaign_id asc, csp.event_name desc) as rank
    from create_sub_path as csp
),

/** Creating positions within the journey depicting the initiator, assistor and
convertor(which will always be purchase transactions). Also, providing the isconversion column,
which would tell us the journeys which are converted(1) and non-converted(0) */
assign_position as (
    select
        cujir.*,
        case
            when cujir.rank = 1 then 'Initiator'
            when cujir.event_name = 'Purchase Transaction' then 'Convertor'
            else 'Assistor'
        end as position,
        max(case
            when cujir.event_name = 'Purchase Transaction' then 1
            else 0
        end) over (partition by cujir.booking_id, cujir.userjourney_id) as isconversion
    from create_user_journey_id_rank as cujir
),

/**This final CTE provides a comprehensive view of user journeys,
 enriched with additional metadata such as journey type, job run ID, load timestamp, 
 and campaign duration */
user_journey as (
    select distinct
        ap.*,
        '{{ journey_type }}' as journey_type,
        '{{ invocation_id }}' as job_run_id,
        current_timestamp::timestamp_ntz as load_ts,
        cbi.campaign_duration
    from campaign_booking_id as cbi
    inner join assign_position as ap
        on cbi.booking_id = ap.booking_id
)

{# /*
Each column is explicitly cast to a specific data type to ensure consistency and compatibility with downstream systems.
This final query creates a well-structured and formatted dataset that can be used for further analysis or reporting on
user journeys in the context of marketing campaigns
*/#}
select
    loyalty_id::varchar(128) as loyalty_id,
    transaction_key::varchar(250) as transaction_key,
    event_dt::date as event_dt,
    event_ts::timestamp_ntz(9) as event_ts,
    channel_name::varchar(18) as channel_name,
    subchannel_name::varchar(1000) as subchannel_name,
    event_name::varchar(20) as event_name,
    booking_id::varchar(200) as booking_id,
    campaign_id::varchar(1000) as campaign_id,
    sub_path::number(18, 0) as sub_path,
    userjourney_id::varchar(1000) as userjourney_id,
    rank::number(18, 0) as rank,
    position::varchar(9) as position,
    isconversion::number(1, 0) as isconversion,
    load_ts::timestamp_ntz(9) as load_ts,
    campaign_duration::varchar(6) as campaign_duration,
    job_run_id::varchar(100) as job_run_id,
    marketing_type::varchar(100) as marketing_type,
    net_sales_amt::number(38, 4) as net_sales_amt,
    units_qty::number(38, 4) as units_qty,
    journey_type::varchar(100) as journey_type
from user_journey

{% endmacro %}
