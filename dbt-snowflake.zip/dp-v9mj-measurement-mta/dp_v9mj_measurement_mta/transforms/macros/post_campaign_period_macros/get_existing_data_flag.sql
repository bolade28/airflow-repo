{% macro get_existing_data_flag(is_unit_test, previous_year) %}
    {% if is_unit_test %}
        {% set result = run_query("
            WITH DBT_CTE__POST_CAMPAIGN_PERIOD AS (
                SELECT 2023 AS YEAR_OF_TRANSACTION
            )
            SELECT 1
            FROM DBT_CTE__POST_CAMPAIGN_PERIOD
            WHERE YEAR_OF_TRANSACTION = "~previous_year~" LIMIT 1
        ") %}
    {% else %}
        {% set result = run_query("
            SELECT 1
            FROM "~this~"
            WHERE YEAR_OF_TRANSACTION = "~previous_year~" LIMIT 1
        ") %}
    {% endif %}

    {% if result and result.columns[0].values() | length > 0 %}
        {% do return(result.columns[0].values()[0]) %}
    {% else %}
        {% do return(0) %}
    {% endif %}
{% endmacro %}