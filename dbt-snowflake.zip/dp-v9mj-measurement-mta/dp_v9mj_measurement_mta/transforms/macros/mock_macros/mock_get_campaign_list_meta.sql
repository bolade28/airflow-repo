{#/*Getting mock data for meta for unit tests */#}
{% macro mock_get_campaign_list_meta() -%}
    {%- set campaign_data = 
        'CHECK', 'Meta', '2025-05-01', '2025-05-31', 'nec_123', 'NA', 'bid_1', 'During', 'job_123', 'Offsite'
     -%}
    {{ return(campaign_data) }}
{% endmacro %}
