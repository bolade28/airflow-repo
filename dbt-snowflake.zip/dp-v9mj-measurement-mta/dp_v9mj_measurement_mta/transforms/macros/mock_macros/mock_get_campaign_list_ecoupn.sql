{#/*Getting mock data for ecoupon for unit tests */#}
{% macro mock_get_campaign_list_ecoupon() -%}
    {%- set campaign_data = 
        'CHECK', 'eCoupons', '2025-05-01', '2025-05-31', 'nec_123', 'Sampling ecoupon', 'bid_1', 'During', 'nec_123', 'Onsite'
     -%}
    {{ return(campaign_data) }}
{% endmacro %}
