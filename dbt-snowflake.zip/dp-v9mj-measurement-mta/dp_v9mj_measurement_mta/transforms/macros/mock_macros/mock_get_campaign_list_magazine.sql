{#/*Getting mock data for magazine for unit tests */#}
{% macro mock_get_campaign_list_magazine() -%}
    {%- set campaign_data = 
        'CHECK', 'Sainsburys Magazine', '2025-05-01', '2025-05-31', 'nec_123', 'NA', 'bid_1', 'During', 'job_123', 'Magazine'
     -%}
    {{ return(campaign_data) }}
{% endmacro %}

