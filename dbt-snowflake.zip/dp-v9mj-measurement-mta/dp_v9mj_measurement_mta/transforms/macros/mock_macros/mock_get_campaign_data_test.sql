{% macro mock_get_campaign_data_test() -%}
    {%- set campaign_data = [
        ['bid_1', '6fc1ae8d-26a5-4b4a-a944-0fd5ba1cc271', 'nec2311880a|nec2401630a', 'Meta', 'NA', 'NA', 'Offers', 'MagnumICOffersAUTOAUTONA', '2023-09-05', '2023-11-30', 'During', 'Not Started', '2025-01-22 13:51:45.809'],
    ] -%}
    {{ return(campaign_data) }}
{% endmacro %}