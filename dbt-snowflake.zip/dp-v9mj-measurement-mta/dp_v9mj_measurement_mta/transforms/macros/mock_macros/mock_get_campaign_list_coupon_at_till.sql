{#/*Getting mock data for coupon at till for unit tests */#}
{% macro mock_get_campaign_list_coupon_at_till() -%}
    {%- set campaign_data = 
        'CHECK', 'Coupon At Till', '2025-05-01', '2025-05-31', 'camp_1', 'CaT Bespoke 8p', 'bid_1', 'During', 'nec_123', 'Targeted Media'
     -%}
    {{ return(campaign_data) }}
{% endmacro %}
