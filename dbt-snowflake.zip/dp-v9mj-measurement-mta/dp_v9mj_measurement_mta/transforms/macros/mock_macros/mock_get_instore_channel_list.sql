{% macro mock_get_instore_channel_list() -%}
    {%- set instore_channel_list = [
        ['Entrance Gate', 'Instore', 'Active', 10],
        ['Barkers', 'Instore', 'Active', 10],
        ['Trolleys', 'Instore', 'Active', 10],
        ['NA', 'Instore', 'Active', 10]
    ] -%}
    {{ return(instore_channel_list) }}
{% endmacro %}