{#/*Getting mock data for instore for unit tests */#}
{% macro mock_get_campaign_list_instore() -%}
    {%- set campaign_data = 
        'CHECK', 'Barkers', '2025-05-01', '2025-05-31', 'nec_123', 'NA', 'bid_1', 'During', 'nec_123', 'In-store'
     -%}
    {{ return(campaign_data) }}
{% endmacro %}
