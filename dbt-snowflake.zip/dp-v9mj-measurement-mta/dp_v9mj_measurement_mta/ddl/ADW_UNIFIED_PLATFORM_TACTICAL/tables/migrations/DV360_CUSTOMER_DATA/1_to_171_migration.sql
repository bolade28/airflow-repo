-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.DV360_CUSTOMER_DATA
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.DV360_CUSTOMER_DATA
(
 LOYALTY_ID        varchar(128) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the hashed nectar id which can be used to identify a customer who has a nectar card.',
 TRANSACTION_KEY   varchar(250) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id unique to every transaction that a customer did either online or in-store.',
 EVENT_DT          date WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This represents the date on which transaction has happened and the oppurtunity to see the campaign(touchpoint) by the customer',
 EVENT_TS          timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 CHANNEL_NAME      varchar(18) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This specifies the media channel on which the campaign was run',
 SUBCHANNEL_NAME   varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the subchannel on which the campaign was launched',
 CAMPAIGN_NAME     varchar(2000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the name of the campaign',
 CAMPAIGN_ID       varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
 EVENT_NAME        varchar(20) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the data is a touchpoint or a transaction (Purchase Transaction) data',
 BOOKING_ID        varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It is an UUID to identify the campaigns which can be run together',
 LOAD_TS           timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 ITEM_CD           number(18,0) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the SKUs of the campaign which have been purchased',
 PRODUCT_TYPE      varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the SKU belong to Offer, Brand or Aisle for the campaign',
 UNIQUE_BRAND_NAME varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the brand for which the campaign was launched',
 NET_SALES_AMT     number(30,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It holds the actual sales value for the item purchased',
 UNITS_QTY         number(30,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It holds the actual units value for the item purchased',
 JOB_RUN_ID        varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the job run id associated with this job',

 CONSTRAINT PRODUCT_TYPE PRIMARY KEY ( LOYALTY_ID, TRANSACTION_KEY, CHANNEL_NAME, SUBCHANNEL_NAME, CAMPAIGN_ID, BOOKING_ID, ITEM_CD, PRODUCT_TYPE )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This tables contains intermediate transactions and customer related touchpoint data for the dv360 channel.';