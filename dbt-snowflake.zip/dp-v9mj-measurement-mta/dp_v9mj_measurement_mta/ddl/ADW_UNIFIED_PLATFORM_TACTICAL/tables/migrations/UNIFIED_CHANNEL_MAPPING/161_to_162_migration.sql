CREATE OR REPLACE TABLE "ADW_UNIFIED_PLATFORM_TACTICAL"."UNIFIED_CHANNEL_MAPPING"
(
 "ASSET_NAME"   varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the asset name.',
 "SERVICE_TYPE" varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the service type.',
 "CHANNEL"      varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the channel name.',
 "SUBCHANNEL"   varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the sub channel name.',
 "MEDIA_NUMBER" number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the media number.',
 "STATUS"       varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'This specify the status.'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This specify the asset data';