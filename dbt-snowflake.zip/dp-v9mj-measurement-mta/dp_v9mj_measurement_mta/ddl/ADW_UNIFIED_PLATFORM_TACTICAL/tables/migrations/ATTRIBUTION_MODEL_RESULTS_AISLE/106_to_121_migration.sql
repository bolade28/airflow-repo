CREATE OR REPLACE TRANSIENT TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_MODEL_RESULTS_AISLE (
	USERJOURNEY_ID VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: This is the id unique to every customer journey.',
	LOYALTY_ID VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: This is the hashed nectar id which can be used to identify a customer who has a nectar card.',
	TRANSACTION_KEY VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies unique id given to transaction',
	BOOKING_ID VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It is an UUID to identify the campaigns which can be run together',
	CUSTOMER_JOURNEY_TYPE VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies whether the journey is Direct/Non-Direct',
	JOURNEY_TYPE VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies whether the SKU belong to Offer, Brand or Aisle for the campaign',
	ISCONVERSION NUMBER(38,0) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies purchase/non-purchase label',
	REGRESSION_VARIABLE VARCHAR(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies the concatenated campaign, channel and subchannel value',
	NORMALIZED_WEIGHTS FLOAT NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies attribution weights for each regression variable',
	CAMPAIGN_ID VARCHAR(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
	AVG_F1_SCORE FLOAT NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies average f1 score of model',
	CAMPAIGN_DURATION VARCHAR(10) DEFAULT 'During' WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION='Commercial') COMMENT 'Definition: It specifies the duration of the campaign',
	JOB_RUN_ID varchar(100) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
    LOAD_TS timestamp_ntz(9) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
    constraint USERJOURNEY_ID primary key (USERJOURNEY_ID, TRANSACTION_KEY, BOOKING_ID, REGRESSION_VARIABLE)
) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO='dp-v9mj-measurement-mta', ACCOUNT_OBJECTS.TAGS.IRM='{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT='gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION='')
COMMENT='This table contains results of attribution model'
;