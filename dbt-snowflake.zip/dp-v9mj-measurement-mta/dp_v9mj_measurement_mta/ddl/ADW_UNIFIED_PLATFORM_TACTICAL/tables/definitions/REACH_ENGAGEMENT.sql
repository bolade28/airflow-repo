-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.REACH_ENGAGEMENT
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.REACH_ENGAGEMENT
(
 CAMPAIGN_ID        varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Campaign Id assigned to each campaign.',
 CHANNEL_NAME       varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Channel Interaction terms on which the campaign ran.',
 REACH_CNT          number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Reach of the Offsite campaign',
 CLICKS_CNT         number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Clicks of the Offsite campaign',
 IMPRESSIONS_CNT    number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Impressions of the Offsite campaign',
 SALES_AMT          number(38,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Sales of the campaign',
 ENGAGEMENT_CTR_PCT number(38,2) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Engagement of the Offsite campaign',
 CONVERSIONS_CNT    number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Conversions of the campaign',
 BOOKING_ID         varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Booking Id assigned to each campaign.',
 LOAD_TS            timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'It specifies the load timestamp of campaign.',
 SUBCHANNEL_NAME    varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'It specifies the subchannel name of campaign.',
 MARKETING_TYPE     varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'It specifies the marketing type of campaign.',
 JOB_RUN_ID         varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'It specifies the job run ID of campaign.',
 MEDIA_SPEND_AMT    number(38,2) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'It specifies the media spend amount of campaign.',

 CONSTRAINT CAMPAIGN_ID PRIMARY KEY ( CAMPAIGN_ID, CHANNEL_NAME, BOOKING_ID )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains campaign and channel wise reach and engagement values.';