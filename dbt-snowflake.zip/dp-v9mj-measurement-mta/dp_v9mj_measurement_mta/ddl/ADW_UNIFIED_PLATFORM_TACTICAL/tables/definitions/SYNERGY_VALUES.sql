-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.SYNERGY_VALUES
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.SYNERGY_VALUES
(
 CHANNEL_NAME          varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Channel Interaction terms on which the campaign ran.',
 CORRELATION_VALUE_NUM float NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the correlation between the interaction term and sales.',
 BOOKING_ID            varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Booking Id assigned to each campaign.',
 JOB_RUN_ID            varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Job run ID assigned to each campaign.',
 LOAD_TS               timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Load TS assigned to each campaign.',

 CONSTRAINT CHANNEL_NAME PRIMARY KEY ( CHANNEL_NAME, CORRELATION_VALUE_NUM, BOOKING_ID )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains booking_id wise and channel interaction correlation values with conversion.';