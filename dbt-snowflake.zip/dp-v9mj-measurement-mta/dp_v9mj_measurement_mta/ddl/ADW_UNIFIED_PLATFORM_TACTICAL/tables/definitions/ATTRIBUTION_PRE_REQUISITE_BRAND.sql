-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_PRE_REQUISITE_BRAND
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_PRE_REQUISITE_BRAND
(
 LOYALTY_ID            varchar(128) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the hashed nectar id which can be used to identify a customer who has a nectar card.',
 CHANNEL_NAME          varchar(18) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This specifies the media channel on which the campaign was run',
 SUBCHANNEL_NAME       varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the subchannel on which the campaign was launched',
 JOURNEY_TYPE          varchar(5) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the SKU belong to Offer, Brand or Aisle for the campaign',
 TRANSACTION_KEY       varchar(250) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id unique to every transaction that a customer did either online or in-store.',
 BOOKING_ID            varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It is an UUID to identify the campaigns which can be run together',
 CAMPAIGN_DURATION     varchar(6) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the duration of the campaign',
 USERJOURNEY_ID        varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 REGRESSION_VARIABLE   varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 EVENT_TS              timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 EVENT_NAME            varchar(20) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the data is a touchpoint or a transaction (Purchase Transaction) data',
 NET_SALES_AMT         number(38,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It holds the actual sales value for the item purchased',
 CAMPAIGN_ID           varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
 POSITION              varchar(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the userjourney type based on event name or rank',
 LOAD_TS               timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 JOB_RUN_ID            varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the job run id associated with this job',
 CUSTOMER_JOURNEY_TYPE varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 ISCONVERSION          number(1,0) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 MARKETING_TYPE        varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),

 CONSTRAINT LOYALTY_ID PRIMARY KEY ( LOYALTY_ID, CHANNEL_NAME, SUBCHANNEL_NAME, JOURNEY_TYPE, TRANSACTION_KEY, BOOKING_ID, CAMPAIGN_DURATION, USERJOURNEY_ID, REGRESSION_VARIABLE )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains preprocessed data for attribution modelling';