-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.MODEL_EXECUTION_METRIC
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.MODEL_EXECUTION_METRIC
(
 DAG_NAME              varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Dag Name of the job run',
 TASK_NAME             varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Task Name of the job run',
 TASK_TYPE             varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Task Type of the job run',
 STATUS                varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Status of the job run',
 EXECUTION_TIME        float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Execution Time of the job run',
 QUERY_ID              varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Query Id of the job run',
 ROWS_AFFECTED         number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Rows affected of the model',
 COMMAND_INVOCATION_ID varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Command Invocation Id of the job run',
 AIRFLOW_DAG_RUN_ID    varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Airflow Dag Run Id of the job run',
 CREATED_AT            timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Created At of the job run',
 COMPLETED_AT          timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the completed at of the job run',
 MESSAGE               varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the message of the job run'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains model execution metrics for the job run.';