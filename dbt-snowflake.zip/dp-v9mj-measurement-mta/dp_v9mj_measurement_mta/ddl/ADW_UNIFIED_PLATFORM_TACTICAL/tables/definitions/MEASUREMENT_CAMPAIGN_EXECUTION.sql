-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_EXECUTION
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.MEASUREMENT_CAMPAIGN_EXECUTION
(
 CAMPAIGN_ID       varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
 BOOKING_ID        varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the booking id of the campaign (all campaigns falling under same time frame and targettin g same SKUs are given singl Booking Id)',
 JOB_BAG_NUMBER    varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the job bag number which can be used to identify a campaign in base finance asset table.',
 MARKETING_TYPE    varchar(14) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the marketing_type of campaign.',
 CHANNEL_NAME      varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This specifies the media channel on which the campaign was run',
 SUBCHANNEL_NAME   varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the subchannel on which the campaign was launched',
 CAMPAIGN_NAME     varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the name of the campaign',
 CAMPAIGN_START_DT date NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the start date when the marketing campaign was launched in the specified channel.',
 CAMPAIGN_END_DT   date NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the end date of the marketing campaign',
 CAMPAIGN_DURATION varchar(6) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the duration of the campaign',
 JOB_STATUS        varchar(11) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the job status',
 LOAD_TS           timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the time stamp',
 JOB_RUN_ID        varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'This specify the Job run id or invocation id of the campaign.',

 CONSTRAINT CAMPAIGN_ID PRIMARY KEY ( CAMPAIGN_ID, JOB_BAG_NUMBER, CHANNEL_NAME, CAMPAIGN_START_DT, CAMPAIGN_END_DT )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table  has details of the campaign that needs to be executed.';