-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.USER_JOURNEY_AISLE
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.USER_JOURNEY_AISLE
(
 LOYALTY_ID        varchar(128) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the hashed nectar id which can be used to identify a customer who has a nectar card.',
 TRANSACTION_KEY   varchar(250) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id unique to every transaction that a customer did either online or in-store.',
 EVENT_DT          date WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This represents the date on which transaction has happened and the oppurtunity to see the campaign(touchpoint) by the customer',
 EVENT_TS          timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 CHANNEL_NAME      varchar(18) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Channel on which the campaign ran.',
 SUBCHANNEL_NAME   varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: sub channel represents under a channel where the campaign ran or the campaign placement',
 EVENT_NAME        varchar(20) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the data is a touchpoint or a transaction (Purchase Transaction) data',
 BOOKING_ID        varchar(36) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: Job bag number or an ID which represents one or more campaigns runnings on single/multi-channel',
 CAMPAIGN_ID       varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
 SUB_PATH          number(18,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It represents a unique number for each unique path/transactions a customer has undertaken',
 USERJOURNEY_ID    varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It represents an ID to identify the journeys a customer has taken. It is combination of loyalty id and sub path.',
 RANK              number(18,0) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the sequence of the touchpoints a customer has gone through',
 POSITION          varchar(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies from where the customer journey has been initiated, rows/data points as assistors which helped the customer to get converted (convertor) or non-conversion',
 ISCONVERSION      number(1,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It represents whether a journeys was converted - 1 (bought the targetted product) or non-converted - 0',
 LOAD_TS           timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 CAMPAIGN_DURATION varchar(6) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the duration of the campaign',
 MARKETING_TYPE    varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 NET_SALES_AMT     number(38,4) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive'),
 UNITS_QTY         number(38,4) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive'),
 JOURNEY_TYPE      varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),
 JOB_RUN_ID        varchar(100) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),

 CONSTRAINT CHANNEL_NAME PRIMARY KEY ( CHANNEL_NAME, SUBCHANNEL_NAME, BOOKING_ID, USERJOURNEY_ID, RANK, CAMPAIGN_DURATION )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains the user journeys for all customers belonging to a campaign/booking where customers who have bought products with product type as aisle are marked as converted(1) and other transactions as non-converted(0)';