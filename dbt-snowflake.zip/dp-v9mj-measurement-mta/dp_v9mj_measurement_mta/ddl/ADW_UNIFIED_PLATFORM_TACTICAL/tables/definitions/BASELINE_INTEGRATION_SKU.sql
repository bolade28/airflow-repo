-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_INTEGRATION_SKU
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.BASELINE_INTEGRATION_SKU
(
 ITEM_CD           number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'Definition: It specifies sku number',
 BOOKING_ID        varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'Definition: It is an UUID to identify the campaigns which can be run together',
 JOURNEY_TYPE      varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'Definition: It specifies whether the SKU belong to Offer, Brand or Aisle for the campaign',
 COMMENT           varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]') COMMENT 'It specify the message for each entry.',
 LOAD_TS           timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'This is the load timestamp for the campaign.',
 JOB_RUN_ID        varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'It specify the job run id for the campaign.',
 CAMPAIGN_DURATION varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'It specify the campaign duration.'
) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '')
COMMENT = 'This table contains logging data';