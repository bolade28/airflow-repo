-- ************************************** ADW_UNIFIED_PLATFORM_TACTICAL.SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
CREATE OR REPLACE TABLE ADW_UNIFIED_PLATFORM_TACTICAL.SKU_LEVEL_ATTRIBUTED_SALES_AND_UNITS_OFFER
(
 CAMPAIGN_ID                        varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id which can be used to identify a campaign in different channel tables.',
 CHANNEL_NAME                       varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This specifies the media channel on which the campaign was run',
 USERJOURNEY_ID                     varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the id unique to every customer journey.',
 LOYALTY_ID                         varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This is the hashed nectar id which can be used to identify a customer who has a nectar card.',
 BOOKING_ID                         varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It is an UUID to identify the campaigns which can be run together',
 CUSTOMER_JOURNEY_TYPE              varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the journey is Direct/Non-Direct',
 JOURNEY_TYPE                       varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies whether the SKU belong to Offer, Brand or Aisle for the campaign',
 ISCONVERSION                       number(38,0) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies purchase/non-purchase label',
 NORMALIZED_WEIGHTS                 float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies attribution weights for each regression variable',
 CAMPAIGN_DURATION                  varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the duration of the campaign',
 EVENT_DT                           date WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: This represents the date on which transaction has happened and the oppurtunity to see the campaign(touchpoint) by the customer',
 ITEM_CD                            number(18,5) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies sku number',
 NET_SALES_AMT                      number(30,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It holds the actual sales value for the item purchased',
 UNITS_QTY                          number(30,4) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It holds the actual units value for the item purchased',
 UNIQUE_BRAND_NAME                  varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the name of the brand',
 WEEK_START_DT                      varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the week start date of the event date',
 REGRESSION_VARIABLE                varchar(1000) NOT NULL WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the concatenated campaign, channel and subchannel value',
 SUBCHANNEL_NAME                    varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies the subchannel on which the campaign was launched',
 ATTRIBUTED_SALES_AMT               float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It shows attributed sales amount',
 ATTRIBUTED_UNITS_QTY               float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It specifies attributed units quantity',
 ATTRIBUTED_RECALIBERATED_SALES_AMT float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It shows attributed sales amount refactored for offsite channels only',
 ATTRIBUTED_RECALIBERATED_UNITS_QTY float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial_Sensitive') COMMENT 'Definition: It shows attributed units refactored for offsite channels only',
 JOB_RUN_ID                         varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It shows job run id associated with this job',
 LOAD_TS                            timestamp_ntz(9) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = '["DataSensitivity:Commercial"]'),
 MARKETING_TYPE                     varchar(1000) WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial') COMMENT 'Definition: It specifies marketing type of the campaign',
 RECALIBERATION_FACTOR              float WITH TAG (ACCOUNT_OBJECTS.TAGS.DATA_CLASSIFICATION = 'Commercial'),

 CONSTRAINT USERJOURNEY_ID PRIMARY KEY ( USERJOURNEY_ID, BOOKING_ID, ITEM_CD, REGRESSION_VARIABLE )
) WITH TAG (ACCOUNT_OBJECTS.TAGS.PRIMARY_CONTACT = 'gdp_nectar360@brexville.co.uk', ACCOUNT_OBJECTS.TAGS.VIRTUES_VERSION = '', ACCOUNT_OBJECTS.TAGS.IRM = '{"IRM":[{"Primary":"V9MJ"}]}', ACCOUNT_OBJECTS.TAGS.DATA_PRODUCT_REPO = 'dp-v9mj-measurement-mta')
COMMENT = 'This table contains sku level attribution results';