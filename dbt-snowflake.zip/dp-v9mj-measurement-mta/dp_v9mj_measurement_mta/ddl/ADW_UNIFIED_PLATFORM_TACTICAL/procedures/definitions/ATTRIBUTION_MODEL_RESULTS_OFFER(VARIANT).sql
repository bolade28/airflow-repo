-- *--*This script is used to create a stored procedure for attribution_model_results_offer
-- *The procedure calculates the weightage of marketing channels present in campaigns
-- *It uses bagged logistic regression and other statistical methods to analyze the impact of channels
-- *This script handles decay rate for impressions of Offsite channels which is a critical concept that pertains to
--  the speed at which the impact or influence of impressions changes as time progresses.
-- *The script includes data preprocessing, feature engineering, model training, and result materialization
-- *Model accuracy is evaluated using metrics like F1 score on both train and test datasets
-- *It handles class imbalance, computes removal effects, and logs errors for debugging
-- *The final results are saved in table attribution_model_results_offer
-- *The synergy values which are being identified using chi square and saved in table synergy_values having columns channel_name, chi_sq_p_val_num, booking_id, campaign_duration, job_run_id, load_ts
-- *The script is efficient to handle certain edge cases like low conversion rates and high conversion rates

-- *Configurable parameters list used in the script which are defined in the dbt project:

-- *1. regression_variable_list : List of regression/independent variables to be used in the model
-- *2. test_size : Size of the test dataset for model evaluation
-- *3. max_executors : Maximum number of executors for parallel processing
-- *4. n_bags : Number of bags for bagging in logistic regression
-- *5. bal_ratio : Balance ratio for class imbalance handling
-- *6. f1_score_limit : F1 score limit for model performance
-- *7. high_conversion_bal_ratio : Balance ratio for high conversion scenarios
-- *8. minimum_conversion_lower_limit : Lower limit for minimum conversions required to run the model
-- *9. minimum_conversion_upper_limit : Upper limit for minimum conversions required to run the model


-- Confluence link - https://brexville-tech.atlassian.net/wiki/spaces/NUP/pages/657653888/Attribution+Methodology+with+Synergy+and+Decay+Rate

-- Upstream Dependencies :
-- * 1. attribution_pre_requisite_offer
-- * 2. campaign_decay_rate
-- * 3. measurement_campaign_execution

-- Downstream Dependencies :
-- * 1. sku_level_attributed_sales_and_units_offer
-- * 2. measurement_campaign_reporting

-- * Owner : Sahil Arya
-- * Date :
-- *
-- * Change Log
-- * ----------------------------
-- 1. Initial Version - Created and setup stored procedure


CREATE OR REPLACE PROCEDURE ADW_UNIFIED_PLATFORM_TACTICAL.ATTRIBUTION_MODEL_RESULTS_OFFER("CONFIG" VARIANT)
RETURNS VARCHAR(1000)
LANGUAGE PYTHON
-- Here we are controlling the python version and the packages to be used in the model
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-ml-python','snowflake-ml-python','snowflake-snowpark-python')
HANDLER = 'main'
EXECUTE AS CALLER
AS
$$
#   Importing dependencies libraries
import itertools
import traceback
from datetime import datetime
import snowflake.snowpark as snowpark
from snowflake.snowpark.functions import (
    col,
    max,
    current_timestamp,
    expr,
    greatest,
    lit,
    lower,
    upper,
    sum,
    when,
    coalesce,
    last_value,
    replace,
    row_number,
    split,
    call_builtin
)
from snowflake.snowpark import Window, DataFrame, Row
from snowflake.snowpark.types import DoubleType, StringType, StructField, StructType
from snowflake.ml.modeling.linear_model import LogisticRegression
from snowflake.ml.modeling.metrics import f1_score
import sys
import numpy as np
from concurrent.futures import ThreadPoolExecutor
from scipy.stats import chi2_contingency


def get_latest_data(data: DataFrame, booking_id: str, campaign_duration: str = None):
    """
    Retrieves the latest campaign data for a specific booking ID, optionally filtered by campaign duration.

    Objective:-
    This method is designed to extract the most recent campaign data for a given booking ID, 
    ensuring that the model operates on the latest available data. If a campaign duration is 
    provided, the data is further filtered to match the specified duration. 

    Used in:
        - model function: This method is called within the main model function to retrieve the
                        latest campaign data for the specified booking ID.
                         The filtered data is then used for further processing and modeling.

    Args:
        data (DataFrame): The input DataFrame containing campaign data, including columns 
                        such as `booking_id`, `campaign_duration`, and `load_ts`.
        booking_id (str): The unique identifier for the booking to filter the data.
        campaign_duration (str, optional): The duration of the campaign to filter by. 
                                        If not provided, all durations are considered.

    Returns:
        DataFrame: A filtered DataFrame containing only the latest records based on the 
                `load_ts` column. This serves as the input data for the model.

    """
    # Step 1: Filter data based on booking ID and optionally campaign duration.
    # If campaign_duration is provided, filter by both booking ID and campaign duration.
    # Otherwise, filter only by booking ID.
    if campaign_duration:
        target_data = data.filter(
            (col("booking_id") == booking_id) & (col("campaign_duration") == campaign_duration)
        )
    else:
        target_data = data.filter(col("booking_id") == booking_id)

    load_ts = target_data.agg(max(col("load_ts"))).collect()[0][0]
    filtered_data = target_data.filter(col("load_ts") == load_ts)

    return filtered_data


def extract_error_message(trace_str):
    """
    Extracts the most relevant error message from a traceback string.

    Objective:
        This method is designed to parse a traceback string (typically from an exception)
        and extract the most relevant error message. It scans the traceback for lines
        containing error-related keywords and returns the message part of the last matching line.
        This is useful for simplifying error reporting and debugging by focusing on the
        most critical part of the traceback.

    Used in:
        log_process_helper: This function is called within the log_process_helper function to extract the error message from the traceback string.
        It helps in logging the most relevant error information for debugging and tracking purposes.

    Args:
        trace_str (str): 
            The complete traceback string from an exception. 
            Expected to be a multi-line string with error details.

    Returns:
        str: 
            The extracted error message (text after the last colon in the last matching line).
            If no clear error line is found, the original traceback string is returned.
    """

    # Define keywords that indicate an error or exception
    keywords = ["Error", "Exception", "error"]

    # Split the input string into individual lines, trimming whitespace
    lines = trace_str.strip().splitlines()

    # Loop through the lines in reverse order, as the actual error message is usually at the bottom
    for line in reversed(lines):
        # Check if the line contains any of the keywords and a colon (common format for error lines)
        if any(kw in line for kw in keywords) and ":" in line:
            # Extract and return the message part after the first colon
            return line.split(":", 1)[-1].strip()

    # If no error line is found, return the original traceback string as fallback
    return trace_str


def log_process_helper(
    session,
    error_message,
    error_traceback,
    error_type,
    module_name,
    pipeline,
    status,
    booking_id,
    campaign_duration,
    job_run_id
):

    """
    Logs job failure details into a Snowflake table for monitoring and debugging purposes.

    Objective:
        This method is designed to capture and log detailed information about job failures, 
        including error messages, tracebacks, and metadata related to the failed job. 
        The logged data is stored in a Snowflake table for further analysis and debugging.

    Used in:
        This function is called within the model function to log any errors that occur during the execution of the job.
        It helps in tracking and debugging issues by providing detailed information about failures.

    Args:
        session (Session): Snowpark session object used to interact with Snowflake.
        error_message (str): A brief description of the error that occurred.
        error_traceback (str): The full traceback of the error for debugging purposes.
        error_type (str): The type or category of the error (e.g., RuntimeError, ValueError).
        module_name (str): The name of the module where the error occurred.
        pipeline (str): The name of the pipeline associated with the job.
        status (str): The status of the job, typically FAILED in case of an error.
        booking_id (str): The booking ID associated with the campaign.
        campaign_duration (str): The duration of the campaign associated with the job.
        job_run_id (str): A unique identifier for the job run.

    Returns:
        None: This method does not return any value. It writes the log entry directly to a Snowflake table.

    """
 
    load_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    last_tb_index = error_traceback.rfind("Traceback")
    
    # Slice from that index to the end
    recent_trace = error_traceback[last_tb_index:].strip()

    # Create a Snowpark DataFrame with one row of log
    log_df = session.create_dataframe(
        [[
            booking_id,
            campaign_duration,
            "NA",
            error_message,
            recent_trace,
            error_type,
            job_run_id,
            load_ts,
            module_name,
            pipeline,
            status,
            "NA",
            "NA"
        ]],
        schema=[
            "BOOKING_ID",
            "CAMPAIGN_DURATION",
            "CLUSTER_NUM",
            "ERROR_MESSAGE",
            "ERROR_TRACEBACK",
            "ERROR_TYPE",
            "JOB_RUN_ID",
            "LOAD_TS",
            "MODULE_NAME",
            "PIPELINE",
            "STATUS",
            "SUPER_CATEGORY_NAME",
            "UNIQUE_BRAND_NAME"
        ]
    )
    if log_df.count() > 0:
        error_log_df = log_df.select(
            col("PIPELINE").cast("varchar(1000)").alias("PIPELINE"),
            col("MODULE_NAME").cast("varchar(1000)").alias("MODULE_NAME"),
            col("BOOKING_ID").cast("varchar(1000)").alias("BOOKING_ID"),
            col("CAMPAIGN_DURATION").cast("varchar(1000)").alias("CAMPAIGN_DURATION"),
            col("UNIQUE_BRAND_NAME").cast("varchar(1000)").alias("UNIQUE_BRAND_NAME"),
            col("SUPER_CATEGORY_NAME").cast("varchar(1000)").alias("SUPER_CATEGORY_NAME"),
            col("CLUSTER_NUM").cast("varchar(1000)").alias("CLUSTER_NUM"),
            col("STATUS").cast("varchar(1000)").alias("STATUS"),
            col("ERROR_TYPE").cast("varchar(1000)").alias("ERROR_TYPE"),
            col("ERROR_MESSAGE").cast("varchar(50000)").alias("ERROR_MESSAGE"),
            col("ERROR_TRACEBACK").cast("varchar(50000)").alias("ERROR_TRACEBACK"),
            col("JOB_RUN_ID").cast("varchar(1000)").alias("JOB_RUN_ID"),
            col("LOAD_TS").cast("timestamp").alias("LOAD_TS")
        )    
        error_log_df.write.mode("append").save_as_table("ERROR_LOG_TABLE") 
    return None


def split_pos_neg_class(df, label):
    """
    Splits a DataFrame into positive and negative class subsets based on a target label column.

    Objective:
    This method is intended to separate the dataset into two subsets: one containing positive class samples (e.g., conversions) 
    and the other containing negative class samples (e.g., non-conversions). This is further used for creating train and test dataset
    for model training and evaluation.

    Used in:
        This function is called within the model function to separate the dataset into positive and negative class samples.

    Args:
        df (DataFrame): The input DataFrame containing campaign data with both positive and negative class samples.
        label (str): The name of the column in the DataFrame that represents the target label (e.g., conversion status).

    Returns:
        tuple: A tuple containing two DataFrames:
            - df_pos (DataFrame): Subset of the input DataFrame where the label column equals 1 (positive class).
            - df_neg (DataFrame): Subset of the input DataFrame where the label column equals 0 (negative class).

    Raises:
        Exception: If an error occurs during the splitting process, such as invalid input types or missing label column.

    """
    try:
        # Separate the data into two groups: one for users who converted (positive class)
        # and one for users who did not convert (negative class).
        # This helps us analyze and model the behavior of both groups separately.
        df_pos = df[df[label] == 1]  # Filter rows where label is 1 (positive class)
        df_neg = df[df[label] == 0]  # Filter rows where label is 0 (negative class)
        
        # By splitting the data, we can better understand the factors that lead to conversions
        # and use this information to improve marketing strategies and campaign effectiveness.
        return df_pos, df_neg
    except Exception as e:
        # If something goes wrong during the process, raise an error to ensure it gets logged and addressed.
        raise e


def split_train_test(df, test_sz):
    """
    Splits the dataset into training and testing sets based on a specified test size proportion.

    Objective:
    This method is intended to split a dataset into training and testing subsets to facilitate 
    model training and evaluation. By ensuring reproducibility and maintaining order in the data, 
    it helps in assessing the model's performance on unseen data while avoiding overfitting.

    Used in:
        This function is called within the model function to split the dataset into training and testing sets
        on the positive and negative class samples respectively.

    Args:
        df (DataFrame): A Spark DataFrame containing user journey data, including both positive 
                        and negative class data for the campaign.
        test_sz (float): A float value representing the proportion of the dataset to be used 
                        as the test set (e.g., 0.3 for 30% testing data).

    Returns:
        tuple: A tuple containing two Spark DataFrames:
            - train_pos_df (DataFrame): The training subset of the data.
            - test_pos_df (DataFrame): The testing subset of the data.

    Raises:
        Exception: If an error occurs during the splitting process, such as invalid input data 
                or issues with the random split operation.

    """
    try:
        # Ensure deterministic ordering of the dataset based on 'userjourney_id'
        # This step ensures that the data is processed in a consistent order, which is crucial for reproducibility.
        df = df.sort(col('userjourney_id'))
     
        # Create a row number column based on the deterministic ordering
        # This assigns a unique row number to each record, which will be used to split the dataset.
        window_spec = Window.order_by(col('userjourney_id'))
        df = df.with_column("row_num", row_number().over(window_spec))
     
        # Count the total number of rows in the dataset
        # This is required to calculate the cutoff point for splitting the data.
        total_rows = df.count()
     
        # Compute the cutoff point for splitting the dataset into training and testing sets
        # The cutoff is determined based on the test size proportion (test_sz).
        cutoff = int((1 - test_sz) * total_rows)
     
        # Create the training dataset by selecting rows with row numbers less than or equal to the cutoff
        # The training dataset will contain the majority of the data for model training.
        train_pos_df = df.filter(col("row_num") <= cutoff).drop("row_num")
        
        # Create the testing dataset by selecting rows with row numbers greater than the cutoff
        # The testing dataset will contain the remaining data for model evaluation.
        test_pos_df = df.filter(col("row_num") > cutoff).drop("row_num")
        
        # Return the training and testing datasets as a tuple
        return train_pos_df, test_pos_df
    except Exception as e:
        # If something goes wrong during the process, raise an error to ensure it gets logged and addressed.
        raise e


def cls_imbalance(org_data_sz, num_conv_jrny, num_non_conv_jrny, train_pos, train_neg, bal_ratio):
    """
    Computes and validates the class imbalance ratio for training datasets.

    Objective:
    This method calculates the class imbalance ratio between positive and negative classes 
    to ensure balanced training datasets. It allows users to specify a balance ratio or 
    dynamically computes it based on the dataset distribution. This is crucial for avoiding 
    bias in the model and ensuring consistent results across runs.

    Used in:
        This function is called within the model function to compute and validate the class imbalance ratio.

    Args:
        org_data_sz (int): The size of the original dataset.
        num_conv_jrny (snowparkDF): DataFrame containing conversion journeys.
        num_non_conv_jrny (snowparkDF): DataFrame containing non-conversion journeys.
        train_pos (snowparkDF): Training dataset containing positive class samples.
        train_neg (snowparkDF): Training dataset containing negative class samples.
        bal_ratio (float): User-defined balance ratio. Must be between 0.0 and 0.99.

    Returns:
        float: The computed or user-provided balance ratio.

    Raises:
        Exception: If an error occurs during the computation of the balance ratio.

    """
    try:
        # Start with the user-provided balance ratio, ensuring it is a positive value.
        balance_ratio = abs(bal_ratio)

        # If the balance ratio is too high (greater than or equal to 1), stop the process.
        # This ensures the ratio is within a valid range (0 to 0.99) to avoid errors.
        if balance_ratio >= 1:
            sys.exit(f'bal_ratio expected between: 0.0 and 0.99, got {balance_ratio} instead')

        # If no balance ratio is provided (set to 0), calculate it dynamically.
        # This calculation ensures the ratio reflects the actual distribution of conversions
        # and non-conversions in the dataset, making the model more accurate.
        elif balance_ratio == 0:
            balance_ratio = (num_conv_jrny.select('USERJOURNEY_ID').distinct().count()) / (
                num_non_conv_jrny.select('USERJOURNEY_ID').distinct().count())
            return balance_ratio

        # If a valid balance ratio is provided, return it as is.
        # This allows flexibility for advanced users to specify their own ratio.
        else:
            return balance_ratio
    except Exception as e:
        # If something goes wrong, raise an error to ensure it gets logged and addressed.
        raise e


def number_of_bags(num_vars, pos_prop, n_bags):
    """
    Determines the optimal number of data subsets (bags) for model training.

    Objective:
        This method calculates the number of bags (subsets) to ensure diverse and effective model training. 
        Number of bags is configurable but it can be dynamically computed based on the dataset's size and positive class proportion 
        if the user does not specify a value i.e 0. This helps improve the model's accuracy and robustness.

    Used in:
        This function is called within the model function to determine the number of bags for training.

    Args:
        num_vars (int): The number of variables/features in the dataset.
        pos_prop (float): The proportion of positive class samples in the dataset.
        n_bags (int): The user-specified number of bags. If 0 or negative, the method computes it dynamically.

    Returns:
        int: The computed or user-specified number of bags. Ensures a minimum of 5 bags for sufficient diversity.

    Raises:
        Exception: If an error occurs during the computation of the number of bags.
    """
    try:
        # Ensure the number of bags is a positive integer.
        # This step ensures that the input is valid and avoids errors during processing.
        num_bags = int(abs(n_bags))

        # If the user has not specified a number of bags (n_bags is 0), calculate it dynamically.
        # This calculation is based on the size of the dataset and the proportion of positive samples.
        if num_bags == 0:
            # Dynamically compute the number of bags to ensure the model is trained on diverse subsets of data.
            # This helps improve the models accuracy and robustness.
            num_bags = 0.02 * (num_vars / pos_prop)

            # Ensure there are at least 5 bags for sufficient diversity in training.
            # This guarantees that the model has enough data subsets to learn effectively.
            if num_bags < 5:
                return 5
            else:
                # Return the computed number of bags as an integer.
                return int(abs(num_bags))
        else:
            # If the user has specified a number of bags, use that value directly.
            # This allows flexibility for advanced users who want to control the training process.
            return num_bags
    except Exception as e:
        # If an error occurs, raise it so it can be logged and addressed.
        raise e




def create_bags(n_bags: int, balance_ratio: float,
                train_pos: snowpark.DataFrame, train_neg: snowpark.DataFrame, conversion_rate, high_conversion_bal_ratio):
    """
    This method generates balanced training bags for machine learning models.

    Objective:
    The purpose of this method is to create balanced training datasets (bags) by combining positive and negative class samples 
    based on a specified balance ratio. This ensures that the training data is representative and fair, improving the model's 
    ability to generalize and perform well on unseen data. Bags are created on test data as well to ensure the model 
    is robust and performs well across various data scenarios.

    Used in:
        This function is called within the model function to create balanced training bags for machine learning models.  
        It is also called to create test bags for evaluation purposes.

    Args:
    - n_bags (int): The number of training bags to create.
    - balance_ratio (float): The desired ratio of positive to negative class samples in each bag.
    - train_pos (snowpark.DataFrame): A DataFrame containing samples of the positive class (users who converted).
    - train_neg (snowpark.DataFrame): A DataFrame containing samples of the negative class (users who did not convert).
    - conversion_rate (float): The conversion rate used to adjust the balance ratio for high conversion scenarios.
    - high_conversion_bal_ratio (float): The balance ratio to apply when the conversion rate is high.

    Returns:
    - list: A list of Snowpark DataFrames, where each DataFrame represents a balanced training bag containing both positive 
        and negative samples.

    Raises:
    - Exception: If an error occurs during the bag creation process.  
    """
    bags = []
    try:
        # Combine positive (users who converted) and negative (users who didn ot convert) samples.
        # Sorting ensures consistency in how data is processed across runs.
        train_pos_neg = train_pos.union_all(train_neg).sort('userjourney_id')

        # Define a window specification to order the dataset by userjourney_id
        # This ensures deterministic ordering of the data, which is crucial for reproducibility
        window_spec = Window.order_by(col("userjourney_id"))
     
        # Add a row number column to the dataset based on the defined window specification
        # This assigns a unique row number to each record, which will be used to distribute records into bags
        train_pos_neg = train_pos_neg.with_column("row_num", row_number().over(window_spec))
         
        # Assign each record to a bag by calculating the modulus of the row number with the total number of bags
        # This evenly distributes the records across the specified number of bags
        train_pos_neg = train_pos_neg.with_column("hash_numeric", col("row_num") % n_bags).drop("row_num")

        for bag_no in range(n_bags):
            # Select data for the current bag based on the hash column.
            # This ensures each bag contains a unique subset of data.
            bag = train_pos_neg.filter(col("hash_numeric") == bag_no).sort(col('userjourney_id'))

            # Count how many users converted (positive class) and how many did not (negative class).
            total_count_0 = bag.filter(col("ISCONVERSION") == 0).count()
            total_count_1 = bag.filter(col("ISCONVERSION") == 1).count()

            # Calculate how many samples to keep for each class to maintain the desired balance.
            # This ensures the model gets a balanced view of both conversions and non-conversions.
            keep_count_0 = int(balance_ratio * total_count_0)
            keep_count_1 = int((1 - balance_ratio) * total_count_1)

            # If the conversion rate is high, adjust the balance to focus more on conversions.
            if conversion_rate > 50:
                keep_count_0 = int((1-high_conversion_bal_ratio) * total_count_0)
                keep_count_1 = int(high_conversion_bal_ratio * total_count_1)

            # Select a subset of non-conversions (negative class) based on the calculated count.
            filtered_0 = bag.filter(col("ISCONVERSION") == 0).sort(col('userjourney_id')).limit(keep_count_0)

            # Select a subset of conversions (positive class) based on the calculated count.
            filtered_1 = bag.filter(col("ISCONVERSION") == 1).sort(col('userjourney_id')).limit(keep_count_1)

            # Combine the selected positive and negative samples into a single training bag.
            bag = filtered_0.union_all(filtered_1)

            # Add a column to indicate which bag this data belongs to.
            # This helps track and organize the data during training.
            bag = bag.with_column("bag_number", lit(bag_no))

            # Remove the temporary hash column as it is no longer needed.
            bag = bag.drop("hash_numeric")

            # Add the completed bag to the list of all bags.
            bags.append(bag)

        # Return the list of balanced training bags.
        # These bags will be used to train the model in a way that ensures fairness and accuracy.
        return bags
    except Exception as e:
        # If something goes wrong, raise an error to ensure it gets logged and addressed.
        raise e


def log_reg(train_df: snowpark.DataFrame, test_df: snowpark.DataFrame, train_cols: list, label: str, output: str, random_state, solver, max_iter):
    """
    Performs logistic regression on training and testing datasets to predict outcomes and evaluate model performance.

    Objective:
        This method is designed to train a logistic regression model on a given training dataset, predict outcomes on a test dataset, 
        and evaluate the model's performance using F1-scores. It ensures reproducibility by sorting datasets and fixing the random state.

    Used in:
        This method is called within the model function to train and evaluate the logistic regression model.

    Args:
        train_df (snowpark.DataFrame): The training dataset containing features and labels.
        test_df (snowpark.DataFrame): The testing dataset for evaluating the model's predictions.
        train_cols (list): A list of feature column names used for training the logistic regression model.
        label (str): The name of the target label column in the datasets.
        output (str): The name of the predicted output column in the datasets.
        random_state (int): Fixed seed for random number generation, which is crucial for consistent results across runs.
        solver (str): Specifies the optimization solver to use. 
        max_iter (int): The maximum number of iterations for the solver to converge. A higher value ensures the model has sufficient iterations to find an optimal solution, especially for complex datasets.
 
    Returns:
        tuple: A tuple containing:
            - coef (numpy.ndarray): Coefficients of the trained logistic regression model.
            - intrcpt (numpy.ndarray): Intercept of the trained logistic regression model.
            - f1_test (float): F1-score of the model on the test dataset.
            - f1_train (float): F1-score of the model on the training dataset.

    Raises:
        Exception: If an error occurs during the logistic regression process.

    """
    try:
        # Sort the training and testing datasets by userjourney_id for consistency
        # This ensures that the data is processed in the same order every time, making the results reproducible.
        train_df = train_df.sort(col("userjourney_id"))
        test_df = test_df.sort(col("userjourney_id"))

        # ====================================================================================
        # MODEL BUILDING
        # ====================================================================================

        # Initialize logistic regression model with specified parameters
        # Logistic regression is used to predict the likelihood of a user converting (e.g., making a purchase).
        # The model learns patterns in the data to identify which factors (features) influence conversions.
        lr = LogisticRegression(
            input_cols=train_cols,
            label_cols=label,
            output_cols=output,
            random_state=random_state,  # Ensure reproducibility
            solver=solver,  # Optimization solver
            max_iter=max_iter  # Maximum iterations for convergence
        )

        # ====================================================================================
        # MODEL FITTING
        # ====================================================================================

        # Fit the model on the training dataset
        # This step trains the model using historical data to understand the relationship between features and conversions.
        lr.fit(train_df)

        # Extract coefficients and intercept from the trained model
        # Coefficients indicate the importance of each feature in predicting conversions.
        # The intercept is a baseline value used in the models calculations.
        coef = lr.to_sklearn().coef_  # Model coefficients for each feature
        print('Coefficient per run:', coef)

        intrcpt = lr.to_sklearn().intercept_  # Model intercept
        print('Intercept per run:', intrcpt)

        # ====================================================================================
        # MODEL EVALUATION
        # ====================================================================================

        # Make predictions on the test dataset
        # The model uses the patterns it learned during training to predict outcomes for new data.
        res = lr.predict(test_df)

        res_train = lr.predict(train_df)

        # Compute F1-score to evaluate model performance
        # The F1-score measures how well the model balances precision (avoiding false positives) and recall (avoiding false negatives).
        f1_test = f1_score(df=res, y_true_col_names=label, y_pred_col_names=output)
        f1_train = f1_score(df=res_train, y_true_col_names=label, y_pred_col_names=output)

        # Return the models coefficients, intercept, and performance metrics
        # These outputs help assess the models accuracy and understand which features are most influential.
        return coef, intrcpt, f1_test, f1_train
    except Exception as e:
        # If an error occurs, raise it so it can be logged and addressed.
        raise e


def process_bag_threadpool(bag, train_cols, label_col, pred_col, bag_test, random_state, solver, max_iter):
    """
    Processes a subset of data (bag) to train and evaluate a logistic regression model in parallel.

    Objective:
    This method is designed to train a logistic regression model on a subset of data (bag) and evaluate its performance. 
    The purpose is to optimize resource utilization and reduce processing time by enabling parallel processing of multiple data subsets.

    Used in:
        parallel_log_regression_threadpool: This function is called within a ThreadPoolExecutor to process multiple data bags in parallel.
        This allows for efficient training and evaluation of the logistic regression model across different subsets of data.

    Args:
        bag (DataFrame): A subset of the training data used to train the model.
        train_cols (list): A list of feature column names used for prediction.
        label_col (str): The name of the column representing the actual outcome (e.g., target variable).
        pred_col (str): The name of the column where the model's predictions will be stored.
        bag_test (DataFrame): A subset of the testing data used to evaluate the model's performance.
        random_state (int): Fixed seed for random number generation, which is crucial for consistent results across runs.
        solver (str): Specifies the optimization solver to use. 
        max_iter (int): The maximum number of iterations for the solver to converge. A higher value ensures the model has sufficient iterations to find an optimal solution, especially for complex datasets.
 
    Returns:
        tuple: A tuple containing the following:
            - coef (list): Coefficients indicating the importance of each feature in predicting the outcome.
            - intercept (float): The intercept value used in the logistic regression model.
            - f1_test (float): The F1 score measuring the model's performance on the testing data.
            - f1_train (float): The F1 score measuring the model's performance on the training data.

    Raises:
        Exception: If an error occurs during the processing of the data bag, it raises an exception with the error details.

    """
    try:
        # Select only the necessary columns (features and the outcome) from the data.
        # This ensures the model focuses on the relevant information for training.
        column_list = train_cols + [label_col]
        df_bag = bag.select(column_list)

        # Train the logistic regression model using the selected data.
        # This step helps the model learn patterns in the data to predict outcomes.
        coef, intercept, f1_test, f1_train = log_reg(df_bag, bag_test, train_cols, label_col, pred_col, random_state, solver, max_iter)

        # Return the models parameters and performance metrics.
        # These will be used to evaluate the models accuracy and refine it further.
        return coef, intercept, f1_test, f1_train
    except Exception as e:
        # If something goes wrong during the process, raise an error to ensure it gets logged and addressed.
        raise e


def parallel_log_regression_threadpool(n_bags, bags, train_cols, label_col, pred_col, max_workers, bags_test, random_state, solver, max_iter):
    """
    Runs logistic regression models in parallel on multiple data subsets (bags) using a thread pool.

    Objective:
        This method is designed to speed up the process of training logistic regression models
        by running multiple models in parallel on different subsets (bags) of the data. 
        The goal is to ensure the model is robust and performs well across various data scenarios 
        by averaging coefficients, intercepts, and F1-scores across all bags.

    Used in:
        This function is called within the model function to process multiple data bags in parallel.
        It utilizes the ThreadPoolExecutor to manage concurrent execution of the logistic regression model training.

    Args:
        n_bags (int): Total number of bags (subsets of data) to process.
        bags (list): List of data bags (subsets of data) used for training.
        train_cols (list): List of feature column names used for training the logistic regression model.
        label_col (str): Name of the target label column in the dataset.
        pred_col (str): Name of the prediction column where model predictions will be stored.
        max_workers (int): Maximum number of threads to use for parallel processing.
        bags_test (list): List of test data bags corresponding to each training bag.
        random_state (int): Fixed seed for random number generation, which is crucial for consistent results across runs.
        solver (str): Specifies the optimization solver to use. 
        max_iter (int): The maximum number of iterations for the solver to converge. A higher value ensures the model has sufficient iterations to find an optimal solution, especially for complex datasets.
 
    Returns:
        tuple: A tuple containing:
            - mean_coefs (numpy.ndarray): Mean coefficients of the logistic regression model across all bags.
            - mean_intercept (float): Mean intercept of the logistic regression model across all bags.
            - mean_f1_test (float): Mean F1-score on the test datasets across all bags.
            - mean_f1_train (float): Mean F1-score on the training datasets across all bags.

    Raises:
        Exception: If an error occurs during the processing of the data bags, it raises an exception
                with a list of problematic bags attached for debugging.

    """

    # This function is designed to speed up the process of training logistic regression models
    # by running multiple models in parallel on different subsets ("bags") of the data.
    # This helps ensure the model is robust and performs well across various data scenarios.

    results = []  # To store the results (coefficients, intercepts, F1-scores) from each bag.
    errors = []  # To track any errors that occur during processing.

    try:
        # Use a thread pool to process multiple data bags at the same time.
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit each data bag for processing in parallel.
            future_to_bag = {
                executor.submit(process_bag_threadpool, bag, train_cols, label_col, pred_col, bag_test, random_state, solver, max_iter): (bag, bag_test)
                for bag, bag_test in zip(bags, bags_test)
            }

            # Collect the results from each processed bag.
            for future in future_to_bag:
                try:
                    # Append the results (coefficients, intercepts, F1-scores) from each bag.
                    results.append(future.result())
                except Exception as e:
                    # If an error occurs, log the bag that caused the issue for debugging.
                    errors.append(future_to_bag[future])

        # Unpack the results into separate lists for coefficients, intercepts, and F1-scores for train and test datasets.
        coefs, intrcpts, f1_scores_test, f1_scores_train = zip(*results)

        # Convert the lists into NumPy arrays for easier mathematical operations.
        coefs = np.array(coefs)
        intrcpts = np.array(intrcpts)
        f1_scores_test = np.array(f1_scores_test)
        f1_scores_train = np.array(f1_scores_train)

        # Calculate the average intercept and F1-scores on train and test across all bags.
        # This ensures we keep a track of model overfitting
        mean_intercept = float(intrcpts.mean())
        mean_f1_train = float(f1_scores_train.mean())
        mean_f1_test = float(f1_scores_test.mean())

        # Calculate the average coefficients across all bags.
        # This ensures the final model reflects the combined insights from all subsets of the data.
        mean_coefs = coefs.reshape(n_bags, len(coefs.flatten()) // n_bags).mean(axis=0)

        # Return the averaged coefficients, intercept, and train and test F1-scores.
        return mean_coefs, mean_intercept, mean_f1_test, mean_f1_train
    except Exception as e:
        # If an error occurs, attach the list of problematic bags to the exception for debugging.
        e.errors = errors
        raise e


def calculate_train_test_f1_overall(df, feature_cols, label_col, weights, mean_intercept, train_test, booking_id, session, thresholds=np.arange(0.3, 1.01, 0.05)):
    """
   To ensure that the model we fit on multiple bags and the model coefficients and intercepts we
    ensemble from them are not leading to any overfitting the following testing was carried out:
   1. The population was divided into 70% train and 30% test data.
   2. Bags for training the model were built using the 70% train data.
   3. Model co-efficient and intercepts were obtained for each bag and a mean was taken across coefficients and intercepts across all bags.
   4. F1 metric was then calculated using the final model (combined coefficients and intercepts from all bags) to predict, both for 70% train and 30% test sets
   5. The calculation is done each time using the real/original data set where 30% test set is completely unseen (not over/under sampled bags)

    Parameters:
    - df: snowflake.snowpark.DataFrame, input DataFrame containing features and labels
    - feature_cols: list of str, names of feature columns
    - label_col: str, name of the label column
    - weights: np.ndarray, shape (n_features,), logistic regression coefficients
    - mean_intercept: float, intercept of the logistic regression model
    - train_test: str, To determine train or test run
    - booking_id: str, booking_id of the campaign
    - session (snowpark.Session): Snowpark session object to interact with Snowflake.
    - thresholds: np.ndarray, array of thresholds to evaluate

    Returns:
    - f1: float, highest F1 score
    """
    # Separate intercept and coefficients
    intercept = mean_intercept
    coefficients = weights
    schema = StructType([
    StructField("Booking_id", StringType()),
    StructField("Threshold", DoubleType()),
    StructField("F1", DoubleType()),
    StructField("Train_test", StringType()),
    ])
 
    train_test_f1 = session.create_dataframe([], schema)

    # Compute logits using the logistic regression formula
    logits_expr = f"{intercept} + " + " + ".join(
        [f"{coeff} * {col}" for coeff, col in zip(coefficients, feature_cols)]
    )
    df = df.with_column("logits", expr(logits_expr))

    # Apply sigmoid function to compute probabilities
    df = df.with_column("probs", expr("1 / (1 + exp(-logits))"))

    # Initialize variables to track the best F1 score and threshold
    best_f1 = 0
    best_threshold = 0

    # Iterate over thresholds
    for threshold in thresholds:
        # Predict class labels based on the current threshold
        df_with_preds = df.with_column("y_pred", (col("probs") >= lit(threshold)).cast("int"))

        # Calculate F1 score using Snowparks f1_score function
        f1 = f1_score(df=df_with_preds, y_true_col_names=[label_col], y_pred_col_names=["y_pred"])

        new_row_df = session.create_dataframe(
            [Row(booking_id=booking_id, Threshold=threshold, F1=f1, Train_test=train_test)],
            schema
        )
        
        train_test_f1 = train_test_f1.union(new_row_df)
        # Update the best F1 score and threshold if the current F1 is better
        if f1 > best_f1:
            best_f1 = f1
            best_threshold = threshold

    # Optionally save the DataFrame with predictions for the best threshold
    train_test_f1.distinct().write.mode("append").save_as_table("scratch.workspace.attribution_model_f1_train_test")
    return f1


def removal_effect(df: snowpark.DataFrame, train_columns: list, coef: np.array,
                   intrcpt: np.float64, non_train_cols: list, label_col: str):
    """
    Computes the removal effect of each feature in a logistic regression model.

    Objective:
        This method calculates the removal effect of each feature in a logistic regression model by analyzing how the predicted
        probability of conversion changes when a specific feature is removed. It helps in understanding the contribution of individual
        features to the overall prediction.
        
        Eg. Removal Effect of Nestle_Buxton_Instore_AisleFinns for uj1 = P(X|All Regression Variables for uj1) - P(X| Nestle_Buxton_Instore_AisleFinns)

    Used in:
        This function is called within the model function to compute the removal effect of features in the logistic regression model.

    Args:
        df (snowpark.DataFrame): The input dataset containing features and labels.
        train_columns (list): A list of feature column names used during model training.
        coef (np.array): An array of coefficients obtained from the trained logistic regression model.
        intrcpt (np.float64): The intercept value obtained from the logistic regression model.
        non_train_cols (list): A list of column names that are not used for training but should be retained in the output.
        label_col (str): The name of the label/target column in the dataset.

    Returns:
        snowpark.DataFrame: A DataFrame containing the original columns, predicted probabilities, and removal effects for each feature.

    Raises:
        Exception: If an error occurs during computation.

    """
    try:
        # Ensure the number of coefficients matches the number of features
        if len(coef) == len(train_columns):
            # Create the select expression for non-training columns, training columns, and label
            expr_0 = non_train_cols + train_columns + [label_col]
            expr_1 = ', '.join(expr_0)  # Join column names for selection

            expr_2 = ''  # Expression for dot product computation
            expr_3 = ''  # Expression for removal effect calculations

            # Construct the logistic function dot product expression
            for c, t in zip(coef, train_columns):
                expr_2 += f"({c} * {t}) + "
            expr_2 += f"{intrcpt} "  # Add intercept to the dot product formula

            # Compute predicted probability using the logistic function
            dff = df.select_expr(
                f"{expr_1}, {expr_2} as dot_product, 1/(1 + exp(-({expr_2}))) as predicted_prob"
            )

            # Calculate the removal effect for each feature
            for c, t in zip(coef, train_columns):
                expr_3 += f"abs(predicted_prob - 1/(1 + exp(-(dot_product - ({c} * {t}))))) as removal_eff_{t}, "

            # Select final columns including predicted probabilities and removal effects
            df_prob = dff.select_expr(expr_1, 'predicted_prob', expr_3)  # Remove trailing comma

            return df_prob
        else:
            print(
                f'length mismatch: number of coefficients must be equal to number of independent variables\\nlength of coefs: {len(coef)}, length of Xs: {len(train_columns)}')
    except Exception as e:
        raise e


def model(session: snowpark.Session, config):
    """
    Main function to execute the attribution model for marketing channel weightage calculation.

    Objective: 
        This main method calculates the weightage of marketing channels
        in campaigns using logistic regression, synergy analysis, and decay rates. 
        It processes campaign data, handles class imbalance, evaluates model accuracy, 
        and materializes results into designated tables.

    Used in:
        - main function: This method is called within the main function to execute the model logic.
        - The results are then saved to the specified table in the Snowflake database.

    Args:
        session (snowpark.Session): Snowpark session object to interact with Snowflake.
        config (dict): Configuration dictionary containing parameters for the model.
    
    Returns:
        attribution_model_resuls_offer (Dataframe): Final results of the attribution model.
    
    Writes To:
        synergy_values: Synergy values calculated during the model execution between interactions of channels.
    """
    # Retrieve and process the regression variable list from config
    regression_variable_list = config["regression_variable_list"]
    regression_variable_list = [elem.upper() for elem in regression_variable_list]
    # Extract necessary configuration values
    job_run_id = config["invocation_id"]
    schema_name = config["schema"]
    max_executors = config["max_executors"]
    try:
        # Load measurement campaign execution data
        camp_execution_df = session.table(
            f"{schema_name}.{config['measurement_campaign_execution']}"
        )
        # Filter to get only in-progress executions, this helps to execute the model on the current campaign under evaluation
        in_progress_data = camp_execution_df.filter(col("JOB_STATUS") == "In-progress")

        # If no in-progress execution exists, raise an error
        if in_progress_data.count() == 0:
            booking_id = "NA"
            campaign_duration = "NA"
            raise Exception("Error: no data found to execute the model!")
        else:
            # Retrieve the first available booking ID and Campaign Duration from in-progress executions
            booking_id = in_progress_data.select("BOOKING_ID").limit(1).collect()[0][0]
            campaign_duration = in_progress_data.select("CAMPAIGN_DURATION").limit(1).collect()[0][0]

        # ====================================================================================
        # COFIGURING VARIABLES FROM THE CONFIG FILE
        # ====================================================================================

        # Extract additional configurations for the model, these parameters are used to control the model execution
        test_size = config["test_size"]
        n_bags = config["n_bags"]
        bal_ratio = config["bal_ratio"]
        f1_score_limit = config["f1_score_limit"]
        high_conversion_bal_ratio = float(config["high_conversion_bal_ratio"])
        minimum_conversion_lower_limit = config["minimum_conversion_lower_limit"]
        minimum_conversion_upper_limit = config["minimum_conversion_upper_limit"]
        balance_increment = float(config["balance_increment"])
        balance_decrement_small = float(config["balance_decrement_small"])
        balance_decrement_large = float(config["balance_decrement_large"])
        balance_ratio_factor = float(config["balance_ratio_factor"])
        random_state = int(config["random_state"])
        solver=config["solver"]
        max_iter= int(config["max_iter"])

        label_col = "ISCONVERSION"

        # List of columns that should not be used for training as they are not helpful in predicting the target variable
        non_train_cols = [
            "USERJOURNEY_ID",
            "LOYALTY_ID",
            "TRANSACTION_KEY",
            "BOOKING_ID",
            "CUSTOMER_JOURNEY_TYPE",
            "JOURNEY_TYPE",
            "CAMPAIGN_DURATION",
        ]

        # Combine non-trainable columns with the label column
        other_cols = non_train_cols + [label_col]

        # ====================================================================================
        # MODEL INPUT DATA LOADING
        # ====================================================================================

        # Reading the attribution model results dataset to get the schema
        attribution_df = session.table(f"{schema_name}.{config['attribution_model_results_offer']}")

        # Create an empty dataframe structure for attribution results
        attribution_empty_df = attribution_df.filter(lit(False))

        # Read the input pre-requisite offer data, this contains the regression variables wise campaign data to be track conversions
        # non conversions at journey level
        df = session.table(f"{schema_name}.{config['attribution_pre_requisite_offer']}")

        # Filter the data to include only the latest load_ts for the specified booking_id using the function get_latest_data defined in details above
        df_booking_id = get_latest_data(df, booking_id, campaign_duration)

        # ====================================================================================
        # MODEL DATA PREPROCESSING
        # ====================================================================================
        
        # Extract the event timestamp and split it by space to separate date and time
        split_ts = expr("split(event_ts,' ')")

        # Filter for offsite marketing channels
        df_offsite = df_booking_id.filter(col('CHANNEL_NAME').isin('Meta', 'DV360', 'YouTube'))

        # Extract distinct campaign IDs for offsite campaigns
        offsite_campaigns = df_offsite.select("CAMPAIGN_ID").distinct().collect()
        offsite_campaigns = [i[0] for i in offsite_campaigns]

        # Add transaction date column based on the subchannel name, to track and backfill the date of transactions
        # This will be further used to calculate the decay rate of impressions
        df_booking_id = df_booking_id.withColumn('TRANSACTION_DATE', when(col('SUBCHANNEL_NAME') == 'TXN',
                                                                                    split_ts[0]).otherwise(
            lit(None)))

        df_booking_id = df_booking_id.withColumn('TRANSACTION_DATE', col('TRANSACTION_DATE').cast('date'))
        win = Window.partitionBy("USERJOURNEY_ID").orderBy("USERJOURNEY_ID").rowsBetween(Window.unboundedPreceding,
                                                                                        Window.unboundedFollowing)
        # Fill in missing transaction dates using the last available non-null value
        df_booking_id = df_booking_id.withColumn("TRANSACTION_DATE", coalesce(col("TRANSACTION_DATE"),
                                                                            last_value("TRANSACTION_DATE",
                                                                                        ignore_nulls=True).over(win)))

        # Count the total number of conversions and non-conversions for the booking ID to ensure enough data is available for modeling
        total_conversions = (
            df_booking_id.filter(col("ISCONVERSION") == 1)
            .select("USERJOURNEY_ID")
            .distinct()
            .count()
        )

        total_nonconversions = (
            df_booking_id.filter(col("ISCONVERSION") == 0)
            .select("USERJOURNEY_ID")
            .distinct()
            .count()
        )

        # Check if the total conversions are less than the minimum conversion lower limit defined in the config
        # If yes, raise an exception to indicate that the model cannot be executed due to insufficient data
        if total_conversions < int(minimum_conversion_lower_limit):
            raise Exception("Error: Not enough conversions to execute the model!")

        # Retrieve the distinct journey type associated with the booking ID
        distinct_journey_type = df_booking_id.select("JOURNEY_TYPE").distinct().collect()
        journey_type = str(distinct_journey_type[0][0])

        # Filter out necessary columns to be used for modeling preprocessing
        df_filtered = df_booking_id.select(
            "USERJOURNEY_ID",
            "CAMPAIGN_ID",
            "CHANNEL_NAME",
            "LOYALTY_ID",
            "TRANSACTION_KEY",
            "BOOKING_ID",
            "CUSTOMER_JOURNEY_TYPE",
            "JOURNEY_TYPE",
            "REGRESSION_VARIABLE",
            "ISCONVERSION",
            "CAMPAIGN_DURATION",
            "TRANSACTION_DATE"
        )

        # Convert REGRESSION_VARIABLE to lowercase to avoid case sensitivity issues
        df_filtered = df_filtered.with_column("REGRESSION_VARIABLE", lower(col("REGRESSION_VARIABLE")))

        # Get distinct values for REGRESSION_VARIABLE for pivoting
        distinct_var = df_filtered.select("REGRESSION_VARIABLE").distinct().collect()
        distinct_variables_filtered = [
            var for var in distinct_var if "txn" not in var["REGRESSION_VARIABLE"]
        ]

        # Below steps are used to create the flattened dataset for modeling, it takes into consideration the regression variables for
        # each user journey, adds an entry 1 for presence of the variable and 0 for absence of the variable
        pivot_exprs = [
            when(lower(col("REGRESSION_VARIABLE")) == lit(variable["REGRESSION_VARIABLE"]), 1)
            .otherwise(0)
            .alias(variable["REGRESSION_VARIABLE"])
            for variable in distinct_variables_filtered
        ]

        # Group by the relevant fields and pivot the REGRESSION_VARIABLE
        pivot_df = df_filtered.group_by(
            "USERJOURNEY_ID",
            "CAMPAIGN_ID",
            "CHANNEL_NAME",
            "LOYALTY_ID",
            "TRANSACTION_KEY",
            "BOOKING_ID",
            "CUSTOMER_JOURNEY_TYPE",
            "JOURNEY_TYPE",
            "ISCONVERSION",
            "REGRESSION_VARIABLE",
            "CAMPAIGN_DURATION",
            "TRANSACTION_DATE"
        ).agg(*pivot_exprs)

        # Replace 0 with 1 where column name matches REGRESSION_VARIABLE value
        for variable in distinct_variables_filtered:
            column_name = variable["REGRESSION_VARIABLE"]
            pivot_df = pivot_df.with_column(
                column_name,
                when(
                    (col("REGRESSION_VARIABLE") == lit(column_name)) & (col(column_name) == 0), 1
                ).otherwise(col(column_name))
            )
        
        # Below code will identify if the campaign contains any offsite channels and if yes,
        # it will apply decay rate to the impressions of the offsite channels
        # this will be done by comparing the transaction date to the reporting date of the decay rate table in the flattened dataset
        # for offsite touchpoints only
        decay_df = session.table(f"{schema_name}.{config['campaign_decay_rate']}")

        # Filter decay data to include only campaigns that are in the offsite campaigns list
        decay_df = decay_df.filter(col('JOB_BAG_NUMBER').isin(offsite_campaigns))

        # Filter by latest timestamp
        load_ts = decay_df.agg(max(col("load_ts"))).collect()[0][0]
        decay_df = decay_df.filter(col("load_ts") == load_ts)

        decay_df = decay_df.with_column_renamed("CHANNEL_NAME", "CHANNEL").select("JOB_BAG_NUMBER", "CHANNEL",
                                                                                "REPORTING_DT",
                                                                                "OFFSITE_IMPRESSIONS_PCT")

        # Join the pivot_df dataset with decay_df on matching transaction date, campaign ID, and channel
        joined_data = pivot_df.join(decay_df, (pivot_df["TRANSACTION_DATE"] == decay_df["REPORTING_DT"]) & (
                pivot_df['CAMPAIGN_ID'] == decay_df['JOB_BAG_NUMBER']) &
                                    (pivot_df['channel_name'] == decay_df['channel']), how="left")

        # Exclude rows where the regression variable contains txn
        joined_data = joined_data.filter(~joined_data.regression_variable.like("%txn%"))
        meta_columns = [col for col in pivot_df.columns if
                        'meta' in col.lower() or 'dv360' in col.lower() or 'youtube' in col.lower()]

        # Iterate over identified meta_columns and update values based on offsite impression percentages
        for column_name in meta_columns:
            joined_data = joined_data.withColumn(column_name, when((col(column_name) > 0) & (col("ISCONVERSION") == 1) &
                                                                (col("OFFSITE_IMPRESSIONS_PCT").is_not_null()),
                                                                col("OFFSITE_IMPRESSIONS_PCT")).otherwise(
                col(column_name)))
            # Convert column values to double type for consistency
            joined_data = joined_data.withColumn(column_name, col(column_name).cast("double"))
            # Replace any null values with 0
            joined_data = joined_data.fillna({column_name: 0})
        # Drop unnecessary columns from the dataset
        pivot_df = joined_data.drop("REGRESSION_VARIABLE").drop("TRANSACTION_DATE", "JOB_BAG_NUMBER", "CHANNEL",
                                                                "REPORTING_DT", "OFFSITE_IMPRESSIONS_PCT",
                                                                "CHANNEL_NAME", "CAMPAIGN_ID")

        # List of columns that should be excluded from independent variables
        columns_to_exclude = [
            "USERJOURNEY_ID",
            "LOYALTY_ID",
            "TRANSACTION_KEY",
            "BOOKING_ID",
            "CUSTOMER_JOURNEY_TYPE",
            "JOURNEY_TYPE",
            "ISCONVERSION",
            "CAMPAIGN_DURATION",
        ]

        # Define independent variables by excluding the above columns
        indep_vars = [col_name for col_name in pivot_df.columns if col_name not in columns_to_exclude]
        # Create aggregation expressions by summing each independent variable
        aggregations = [sum(col(variable)).cast("double").alias(f"{variable}") for variable in indep_vars]

        # Perform a group-by operation to aggregate data at the user journey level
        flattened_path = pivot_df.groupBy(
            "USERJOURNEY_ID",
            "LOYALTY_ID",
            "TRANSACTION_KEY",
            "BOOKING_ID",
            "CUSTOMER_JOURNEY_TYPE",
            "JOURNEY_TYPE",
            "ISCONVERSION",
            "CAMPAIGN_DURATION"
        ).agg(*aggregations)

        # Below code studies the regression variables to identify the marketing type
        # and creates all possible combinations of marketing type to analyze their interactions
        reg_var_list = [
            row["REGRESSION_VARIABLE"]
            for row in df_filtered.select("REGRESSION_VARIABLE").distinct().collect()
        ]
        channels = list(
            set(
                part.split("_", 2)[regression_variable_list.index("MARKETING_TYPE")]
                for part in reg_var_list
                if "txn" not in part
            )
        )
        # Sorting to make order deterministic
        channels = sorted(channels)

        """ Possible values for journey_type include: Offer/Brand/Aisle """
        if journey_type == "Offer":
            # Step 1: Start with the flattened data containing user interactions
            df_interactions = flattened_path

            # Step 2: Create a dictionary to group columns by channel
            # This helps us identify which columns belong to which marketing channel
            channel_columns = {
                channel: [col for col in df_interactions.columns if channel.upper() in col.upper()]
                for channel in channels
            }

            # Step 3: Generate all possible combinations of channels to analyze their interactions
            # For example, if there are three channels (A, B, C), combinations like A_B, A_C, B_C, and A_B_C will be created
            for r in range(2, len(channels) + 1):
                for combo in itertools.combinations(channels, r):
                    combo_name = "_".join(combo)  # Create a name for the combination (e.g., "A_B")
                    # Initialize the interaction column with a default value of 1
                    interaction_expr = lit(1)
                    # Loop through each channel in the combination to calculate the interaction effect
                    for channel in combo:
                        # Identify the columns associated with the current channel
                        matched_columns = channel_columns.get(channel, [])
                        if matched_columns:
                            # Find the maximum value across all columns for this channel
                            max_col_expr = greatest(
                                *[col(col_name) for col_name in matched_columns]
                            )
                            # Multiply the interaction expression by the max value for this channel
                            interaction_expr *= max_col_expr
                        else:
                            # If no columns are found for the channel, skip this combination
                            print(f"No columns found for channel: {channel}. Skipping.")
                            interaction_expr = None
                            break
                    # Add the interaction column to the dataset if it is valid
                    if interaction_expr is not None:
                        df_interactions = df_interactions.withColumn(combo_name, interaction_expr)

            # Step 4: Initialize lists to store correlated columns and their statistical data
            correlated_columns = []
            correlation_data = []

            # Identify the newly created interaction columns
            interaction_cols = list(set(df_interactions.columns) ^ set(flattened_path.columns))

            # Define the schema for storing correlation results
            schema = StructType(
                [
                    StructField("channel_name", StringType(), nullable=True),
                    StructField("chi_sq_p_val_num", DoubleType(), nullable=True),
                ]
            )

            # Create an empty DataFrame to store correlation results
            correlation_df = session.create_dataframe([], schema)

            # Step 5: Analyze the relation of each interaction column with conversions using chi-squared test
            # this is used in case of categorical variables to identify associations
            columns_to_select = []
            for column in interaction_cols:
                # Check if the column has any contribution to conversions
                column_sum = df_interactions.filter(col("ISCONVERSION") == 1).select(sum(col(column)).alias("col_sum")).collect()[0]["COL_SUM"]
                if column_sum != 0:
                    columns_to_select.append(column)
                    # Group data by the column and conversion status to calculate statistical significance
                    grouped_df = (df_interactions.group_by(column, "ISCONVERSION").count().pivot("ISCONVERSION").agg({"count": "sum"}))
                    # Perform a chi-squared test to measure the relationship between the column and conversions
                    contingency_pd = grouped_df.to_pandas().set_index(column).fillna(0)
                    chi2, chi_p_val, dof, expected = chi2_contingency(contingency_pd)

                    # Store the correlation results
                    correlation_data.append((column, chi_p_val))
                    # With a level of significance of 0.05, interaction terms with a significant p-value
                    # would be carried forward for modeling as a representation of synergy
                    if chi_p_val < 0.05:
                        correlated_columns.append(column)

            # Step 6: Save the correlation results to a table for further analysis
            correlation_df = session.create_dataframe(correlation_data, schema)
            correlation_df = correlation_df.with_column("BOOKING_ID", lit(booking_id))
            correlation_df = correlation_df.with_column("JOB_RUN_ID", lit(job_run_id))
            correlation_df = correlation_df.with_column("LOAD_TS", current_timestamp())
            correlation_df = correlation_df.with_column("CAMPAIGN_DURATION", lit(campaign_duration))
            correlation_df = correlation_df.filter(col("channel_name").isin(columns_to_select))
            correlation_df.write.mode("append").save_as_table(f"{schema_name}.{config['synergy_values']}")

            # Step 7: Select only the relevant columns (original regression variables +
            # significant interaction terms) for the final dataset
            selected_columns = flattened_path.columns + correlated_columns
            synergy = df_interactions.select(*selected_columns)

            # Step 8: Use the refined dataset (synergy) for further modeling
            model_data = synergy
        else:
            model_data = flattened_path

        train_cols = [val for val in model_data.columns if val not in other_cols]

        # train_cols = list(train_cols)
        pred_col = "PREDICTED_CONVERSION"

        # ====================================================================================
        # FURTHER MODEL DATA PREPROCESSING
        # ====================================================================================

        # Split the data into two groups: one for users who converted (positive class) 
        # and one for users who did not convert (negative class).
        df_pos, df_neg = split_pos_neg_class(model_data, label_col)

        # Calculate the conversion rate as a percentage of users who converted out of the total users.
        conversion_rate = (df_pos.count() / model_data.count()) * 100

        # Divide the positive class data into training (70%) and testing (30%) sets, which are configurable parameters.
        # This ensures we have data to train the model and data to evaluate its performance.
        train_pos_df, test_pos_df = split_train_test(df_pos, test_size)

        # Similarly, divide the negative class data into training (70%) and testing (30%) sets, which are configurable parameters.
        train_neg_df, test_neg_df = split_train_test(df_neg, test_size)

        # Address the imbalance between the number of users who converted and those who did not.
        # This ensures the model is not biased toward the majority class (non-conversions).
        balance_ratio = cls_imbalance(
            model_data, df_pos, df_neg, train_pos_df, train_neg_df, bal_ratio
        )

        # Determine the number of "bags" or subsets of data to use for training.
        # This helps in creating multiple balanced datasets for robust model training.
        num_bags = number_of_bags(
            len(train_pos_df.columns) - 1,
            train_pos_df.count() / (train_pos_df.count() + train_neg_df.count()),
            n_bags,
        )

        # Initialize variables to track the number of iterations and the models performance.
        counter = 0
        mean_f1_score_test = 0

        # If the total number of conversions falls within a lower expected range, 
        # simplify the process by using only one data bag and limiting iterations.
        # This will help us get sub optimal results if the data is not sufficient to run the model.

        if total_conversions >= int(minimum_conversion_lower_limit) and total_conversions <= int(minimum_conversion_upper_limit):
            num_bags = 1
            max_iterations = 1
        else:
            # For larger datasets, allow up to 5 iterations to optimize the models performance.
            max_iterations = num_bags

        """This loop iteratively adjusts the balance ratio and retrains the model
        until the mean F1 score meets a specified threshold or a maximum number of iterations (5) is reached.
        1. It first modifies the balance ratio dynamically based on conditions.
        2. It then creates balanced data bags and trains a logistic regression model.
        3. If the F1 score is acceptable, it computes the removal effect and normalizes weights.
        4. The data is restructured into the required format.
        5. If the loop reaches 5 iterations without achieving the F1 score limit, it return the sub optimal model results with a warning in the validations.
        6. Finally, it assigns job run metadata and processes some data cleaning."""
        while counter < max_iterations:
            counter += 1
            # To avoid overfitting, the balance ratio is adjusted using the configurable variable balance_increment based on the model performance
            # If the model achieves a perfect F1 score of 1, increase the balance ratio slightly to explore better performance.
            if mean_f1_score_test == 1:
                balance_ratio = balance_ratio + balance_increment
            else:
                # If the model is not performing well, decrease the balance ratio using the configurable variable balance_decrement_small
                # for better model performance. This is done till (num_bags - 1)th iteration
                if counter in range(1, num_bags - 1):
                    balance_ratio = balance_ratio - balance_decrement_small
                # If the model is still not performing well, decrease the balance ratio significantly using the configurable variable balance_ratio_factor for the last run
                elif counter == num_bags - 1:
                    balance_ratio = (balance_ratio_factor * total_conversions) / total_nonconversions
                else:
                # If the model is not performing well, drastically decrease the balance ratio using the configurable variable balance_decrement_large
                    balance_ratio = balance_ratio - (balance_decrement_large * balance_ratio)

            # Create balanced training bags for the model
            # This step ensures that the training data is evenly distributed between positive (conversions) and negative (non-conversions) outcomes.
            # It helps the model learn effectively without being biased towards one class.
            bags_train = create_bags(num_bags, balance_ratio, train_pos_df, train_neg_df, conversion_rate, high_conversion_bal_ratio)

            # Create balanced testing bags for model evaluation
            # Similar to training bags, this ensures the test data is balanced, allowing for fair evaluation of the models performance.
            bags_test = create_bags(num_bags, balance_ratio, test_pos_df, test_neg_df, conversion_rate, high_conversion_bal_ratio)

            # ====================================================================================
            # MODEL DEFINITION, TRAINING & PERFORMANCE EVALUATION
            # ====================================================================================

            # Train the logistic regression model in parallel across multiple data bags
            # This step uses multiple threads to speed up the training process by saving time and resources making the solution
            # optimal and running the model on different subsets of the data simultaneously.
            # It calculates the average coefficients, intercept, and F1 scores (a measure of model accuracy) across all the bags.
            mean_coef, mean_intrcpt, mean_f1_score_test, mean_f1_score_train = parallel_log_regression_threadpool(
                num_bags, bags_train, train_cols, label_col, pred_col, max_executors, bags_test, random_state, solver, max_iter)

            # Round the F1 scores for better readability and reporting
            # These scores indicate how well the model is performing on both training and testing data.
            mean_f1_score_test = round(mean_f1_score_test, 4)
            mean_f1_score_train = round(mean_f1_score_train, 4)

            # Below code is commented out as it is not the part of current pipeline, the final output table (attribution_model_f1_train_test) 
            # is being written in scratch which has columns - booking_id, threshold, f1 and train_test
            # It is used to validate that the model is not overfitting and in case you want to test whether the model is overfitting
            # Uncomment the line 1457 to 1461 to run the same
            '''train_data = train_pos_df.union_all(train_neg_df).sort("USERJOURNEY_ID")
            test_data = test_pos_df.union_all(test_neg_df).sort("USERJOURNEY_ID")
            
            f1_train = calculate_train_test_f1_overall(train_data, train_cols, label_col, mean_coef, mean_intrcpt, "Train", booking_id, session)
            f1_test = calculate_train_test_f1_overall(test_data, train_cols, label_col, mean_coef, mean_intrcpt, "Test", booking_id, session)'''

            # Check if the models performance (F1 score) meets the required threshold or if its the last iteration
            if mean_f1_score_test >= f1_score_limit and mean_f1_score_test != 1 or max_iterations == 1 or counter == num_bags:
                
                # ====================================================================================
                # MODEL INTERPRETATION FOR ASSIGNING WEIGHTS AT REGRESSION VARIABLE LEVEL
                # ====================================================================================

                # Calculate the "removal effect" for each feature
                # This measures how much each feature contributes to the models predictions by analyzing the impact of removing it
                df_prob = removal_effect(
                    model_data, train_cols, mean_coef, mean_intrcpt, non_train_cols, label_col
                )

                # Identify all columns related to removal effects
                removal_columns = [col for col in df_prob.columns if col.startswith("REMOVAL_")]

                # Calculate the total removal effect for normalization
                sum_expr = expr(" + ".join(removal_columns)).alias("sum_removal")
                df_with_sum = df_prob.select("*", sum_expr)

                # Normalize the removal effect for each feature to make them comparable and to bring it to a common scale
                normalized_exprs = [
                    (col(column) / col("sum_removal")).alias(
                        f"normalized_weight_{column.split('REMOVAL_EFF_')[-1]}"
                    )
                    for column in removal_columns
                ]
                df_wt = df_with_sum.select(
                    *[col(column) for column in df_prob.columns], *normalized_exprs
                )

                # Filter the data to include only rows where a conversion occurred
                # as this will help us understand the impact of marketing channels on conversions
                filtered_df = df_wt.filter(col(label_col) == 1)

                # ====================================================================================
                # MODEL POST-PROCESSING AND STRUCTURING RESULTS
                # ====================================================================================

                # Define the lists of column names for restructuring the data at the userjourney, regression variable level
                list_a = non_train_cols + [label_col.upper()]  # Metadata columns which are not used in the model along with the dependent variable
                list_b = [col for col in filtered_df.columns if col.startswith("NORMALIZED_")]  # List having the normalized_weights for each regression variable
                list_c = train_cols  # Features/Regression variables used in training the model

                # Restructure the data to associate each feature with its normalized weight
                restructured_data = []
                for row in filtered_df.collect():
                    transaction_info = [row[col] for col in list_a]  # Extract metadata for each row
                    for reg_col, norm_col in zip(list_c, list_b, strict=False):  # Pair features with weights
                        restructured_data.append(transaction_info + [reg_col, row[norm_col]])

                # Define the schema for the restructured data
                restructured_schema = list_a + ["REGRESSION_VARIABLE", "NORMALIZED_WEIGHTS"]
                restructured_df = session.create_dataframe(
                    restructured_data, schema=restructured_schema
                )

                # Filter out rows where the normalized weight is zero (no contribution)
                attribution_model_results_offer = restructured_df[
                    restructured_df["NORMALIZED_WEIGHTS"] != 0
                    ]

                # Add avg_f1_score_test and avg_f1_score_train columns for tracking model performance
                # This helps us ensure we have not overfitted the model and that it generalizes well to unseen data.
                attribution_model_results_offer = attribution_model_results_offer.with_column(
                    "AVG_F1_SCORE_TEST", lit(mean_f1_score_test)
                ).with_column(
                    "AVG_F1_SCORE_TRAIN", lit(mean_f1_score_train)
                )

                # Prepare data for joining with pre-requisite data to get the original regression variable
                df_pre_req = df_booking_id.select(col("USERJOURNEY_ID").alias("USERJOURNEY_ID_OLD"),
                                                col("REGRESSION_VARIABLE"),
                                                col("BOOKING_ID").alias("BOOKING_ID_OLD"),
                                                col("CAMPAIGN_DURATION").alias("CAMPAIGN_DURATION_OLD"),
                                                "CHANNEL_NAME", "SUBCHANNEL_NAME", "MARKETING_TYPE", "CAMPAIGN_ID")

                # Add a temporary column to facilitate the join
                attribution_model_results_offer = attribution_model_results_offer.with_column(
                    "REGRESSION_VARIABLE_OLD", col("REGRESSION_VARIABLE")
                )
                attribution_model_results_offer = attribution_model_results_offer.drop("REGRESSION_VARIABLE")

                # Define the conditions for joining the data
                join_condition = (
                        (
                                upper(attribution_model_results_offer["REGRESSION_VARIABLE_OLD"])
                                == upper(df_pre_req["REGRESSION_VARIABLE"])
                        )
                        & (
                                attribution_model_results_offer["USERJOURNEY_ID"]
                                == df_pre_req["USERJOURNEY_ID_OLD"]
                        )
                        & (
                                attribution_model_results_offer["BOOKING_ID"]
                                == df_pre_req["BOOKING_ID_OLD"]
                        )
                        & (
                                attribution_model_results_offer["CAMPAIGN_DURATION"]
                                == df_pre_req["CAMPAIGN_DURATION_OLD"]
                        )
                )

                # Perform the join the model result data with pre-requisite data to get the original regression variable
                attribution_model_results_offer = attribution_model_results_offer.join(
                    df_pre_req,
                    join_condition,
                    "left"
                )

                # Replace missing values in the regression variable column with the old values
                attribution_model_results_offer = attribution_model_results_offer.with_column("REGRESSION_VARIABLE",
                                                                                            call_builtin("ifnull",
                                                                                                            col(
                                                                                                                "REGRESSION_VARIABLE"),
                                                                                                            col(
                                                                                                                "REGRESSION_VARIABLE_OLD")))
                # Drop temporary columns used for the join
                attribution_model_results_offer = attribution_model_results_offer.drop("USERJOURNEY_ID_OLD",
                                                                                    "REGRESSION_VARIABLE_OLD",
                                                                                    "BOOKING_ID_OLD",
                                                                                    "CAMPAIGN_DURATION_OLD")

                # Exit the loop if the model performance is satisfactory or if the maximum number of iterations is reached
                break
            elif counter == num_bags:
                break
            elif max_iterations == 1:
                # Exit the loop if only one iteration is allowed which is the 
                # case when the total conversions are less than the minimum conversion lower limit
                break

        # Add a unique identifier for the job run to track which execution this data belongs to
        attribution_model_results_offer = attribution_model_results_offer.with_column(
            "JOB_RUN_ID", lit(job_run_id)
        )

        # Add a timestamp to indicate when this data was processed
        attribution_model_results_offer = attribution_model_results_offer.with_column(
            "LOAD_TS", current_timestamp()
        )

        # Standardize the marketing type, channel name, subchannel name, and campaign ID
        # for rows where we have synergy term
        # This ensures consistency and avoids missing or incorrect data in these fields.
        attribution_model_results_offer = attribution_model_results_offer.with_column(
            "MARKETING_TYPE",
            when(
                col("CAMPAIGN_ID").is_null(),
                col("REGRESSION_VARIABLE")
            ).otherwise(col("MARKETING_TYPE")),
        ).with_column(
            "CHANNEL_NAME",
            when(
                col("CAMPAIGN_ID").is_null(),
                lit("NA")
            ).otherwise(col("CHANNEL_NAME")),
        ).with_column(
            "SUBCHANNEL_NAME",
            when(
                col("CAMPAIGN_ID").is_null(),
                lit("NA")
            ).otherwise(col("SUBCHANNEL_NAME")),
        ).with_column(
            "CAMPAIGN_ID",
            when(
               col("CAMPAIGN_ID").is_null(),
                lit("NA")
            ).otherwise(col("CAMPAIGN_ID")),
        )

        # Clean up the marketing type field by replacing placeholder strings (like "SPC", "HASH", etc.)
        # with their intended characters (e.g., spaces, dashes, commas, pipes).
        # This ensures the data aligns with business naming conventions.
        attribution_model_results_offer = attribution_model_results_offer.with_column(
            "MARKETING_TYPE",
            replace(
                replace(
                    replace(
                        replace(
                            col("MARKETING_TYPE"),
                            "SPC",
                            " ",
                        ),
                        "HASH",
                        "-",
                    ),
                    "COMMA",
                    ",",
                ),
                "PIPE",
                "|",
            ))

        # ====================================================================================
        # FINAL MODEL RESULTS FOR THE CAMPAIGN
        # ====================================================================================

        return attribution_model_results_offer
    except Exception as e:
        # Capture the type of exception that occurred
        error_type = type(e).__name__

        # Extract the error message from the exception
        error_message = str(e)

        # Get the full traceback of the exception for debugging purposes
        error_trace = traceback.format_exc()

        # Extract the most relevant error message from the traceback
        error_message = extract_error_message(error_message)

        # If the exception has an 'errors' attribute, include additional error details
        if hasattr(e, 'errors'):
            error_message = f'Error in bag {e.errors} : ' + error_message

        # Log the error details into the error log table for tracking and debugging
        log_process_helper(
            session,
            error_message,
            error_trace,
            error_type,
            "attribution_model_results_offer",  # Module name
            "MTA",  # Pipeline name
            "Failed",  # Status
            booking_id,  # Booking ID of the campaign
            campaign_duration,  # Campaign duration of the campaign
            job_run_id  # Unique job run ID
        )

        # Re-raise the exception to ensure it propagates and is handled appropriately
        raise


def materialize(session, df, config):
    """
    Inserts new records into an existing table while avoiding duplicate entries.

    Objective:
        This method is designed to ensure that new data is appended to an existing Snowflake table 
        while maintaining the correct column sequence and avoiding data duplication. It facilitates 
        seamless integration of new records into the database for further analysis or reporting.

    Used in:
        This function is called within the main function to save the results of the attribution model into the database.

    Args:
        session (snowflake.snowpark.Session): Snowflake session object used to interact with the database.
        df (snowflake.snowpark.DataFrame): Snowpark DataFrame containing the new records to be inserted.
        config (dict): Configuration dictionary containing:
            - schema (str): The schema name where the table resides.
            - attribution_model_results_offer (str): The name of the target table.

    Returns:
        None
    """
    # Retrieve the schema name from the configuration
    schema_name = config["schema"]

    # Reference the existing table where results should be stored
    existing_table = session.table(f"{schema_name}.{config['attribution_model_results_offer']}")

    # Maintain the same column sequence as the existing table
    col_sequence = existing_table.columns

    # Select columns in the correct order and append new records to the existing table
    df.select(*col_sequence).write.mode("append").save_as_table(
        f"{schema_name}.{config['attribution_model_results_offer']}"
    )


def main(session, config):
    """
    Main entry point for the stored procedure.

    Objective:
        This method serves as the main entry point for executing the attribution model and saving the results into a Snowflake table.
        It orchestrates the entire process, ensuring that the model is executed correctly and the results are stored efficiently.

    Used in:
        This function is called when the stored procedure is invoked. It handles the execution of the model and the materialization of results.

    Args:
        session (snowpark.Session): Snowpark session object to interact with Snowflake.
        config (dict): Configuration dictionary containing parameters for the model and table details.

    Returns:
        str: Status message indicating the completion of the process.
    """
    # Execute the attribution model to calculate the weightage of marketing channels
    df = model(session, config)

    # Save the results of the model into the designated table while avoiding duplicates
    materialize(session, df, config)

    # Return a status message indicating successful completion
    return 'COMPLETED'

$$
;